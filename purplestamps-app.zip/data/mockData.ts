import { User, TravelCard, Experience, Story, Moment, Chat, ExperienceMoment } from '../types';

export const mockUsers: User[] = [
  {
    id: 'user1',
    name: 'Wanderlust Explorer',
    username: 'wanderlust_exp',
    profilePic: 'https://images.unsplash.com/photo-1494790108755-2616b612c1c?w=100&h=100&fit=crop&crop=face',
    bio: 'Sharing my adventures one Travel Card at a time! 🌍✈️ Digital nomad • 25 countries and counting',
    followers: 12500,
    following: 850,
    countries: 25,
    cities: 87,
    isCreator: true,
    badges: ['Top Creator', 'Adventure Seeker', 'Cultural Explorer'],
  },
  {
    id: 'user2',
    name: 'Foodie Traveler',
    username: 'foodie_travels',
    profilePic: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop&crop=face',
    bio: 'Eating my way around the world! 🍜🍣 Food blogger • Restaurant reviews • Hidden gems',
    followers: 8750,
    following: 920,
    countries: 15,
    cities: 45,
    isCreator: true,
    badges: ['Food Critic', 'Rising Star', 'Local Expert'],
  },
  {
    id: 'user3',
    name: 'Urban Wanderer',
    username: 'urban_wanderer',
    profilePic: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop&crop=face',
    bio: 'Discovering hidden gems in every city. 🏙️ Architecture enthusiast • Street art lover',
    followers: 5200,
    following: 650,
    countries: 8,
    cities: 32,
    isCreator: false,
    badges: ['City Explorer'],
  },
  {
    id: 'user4',
    name: 'Adventure Seeker',
    username: 'adventure_seeker',
    profilePic: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&h=100&fit=crop&crop=face',
    bio: 'Chasing thrills and breathtaking views! 🏞️ Extreme sports • Mountain climbing • Skydiving',
    followers: 15300,
    following: 1200,
    countries: 20,
    cities: 55,
    isCreator: true,
    badges: ['Explorer', 'Thrill Seeker', 'Mountain Master'],
  },
  {
    id: 'user5',
    name: 'Relax & Recharge',
    username: 'zen_traveler',
    profilePic: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop&crop=face',
    bio: 'Finding peace in every journey. 🧘‍♀️ Wellness retreats • Meditation • Yoga',
    followers: 7890,
    following: 430,
    countries: 12,
    cities: 28,
    isCreator: false,
    badges: ['Wellness Guru'],
  },
  {
    id: 'user6',
    name: 'Solo Voyager',
    username: 'solo_explorer',
    profilePic: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=100&h=100&fit=crop&crop=face',
    bio: 'Empowering solo travel adventures! 👤 Safety tips • Budget travel • Solo female travel',
    followers: 18750,
    following: 980,
    countries: 30,
    cities: 95,
    isCreator: true,
    badges: ['Solo Expert', 'Safety Ambassador', 'Budget Master'],
  },
  {
    id: 'user7',
    name: 'Family Adventures',
    username: 'family_fun',
    profilePic: 'https://images.unsplash.com/photo-1544725176-7c40e5a71c5e?w=100&h=100&fit=crop&crop=face',
    bio: 'Creating magical memories with kids! 👨‍👩‍👧‍👦 Family travel expert • Kid-friendly destinations',
    followers: 22100,
    following: 1150,
    countries: 18,
    cities: 67,
    isCreator: true,
    badges: ['Family Expert', 'Kids Specialist', 'Memory Maker'],
  },
  {
    id: 'user8',
    name: 'Luxury Escapes',
    username: 'luxury_life',
    profilePic: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f52?w=100&h=100&fit=crop&crop=face',
    bio: 'Curating the finest travel experiences. ✨ 5-star resorts • Private jets • Exclusive access',
    followers: 35600,
    following: 500,
    countries: 35,
    cities: 120,
    isCreator: true,
    badges: ['Luxury Curator', 'VIP Access', 'Elite Traveler'],
  },
  {
    id: 'user9',
    name: 'Backpack Nomad',
    username: 'backpack_life',
    profilePic: 'https://images.unsplash.com/photo-1531123897727-8f129e1688ce?w=100&h=100&fit=crop&crop=face',
    bio: 'Budget adventures around the globe! 🎒 Hostels • Local transport • Authentic experiences',
    followers: 14200,
    following: 2300,
    countries: 42,
    cities: 156,
    isCreator: true,
    badges: ['Budget King', 'Hostel Hero', 'Authentic Explorer'],
  },
  {
    id: 'user10',
    name: 'Beach Bliss',
    username: 'beach_vibes',
    profilePic: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=100&h=100&fit=crop&crop=face',
    bio: 'Sun, sand, and spectacular coastlines! 🏖️ Beach resorts • Island hopping • Surfing',
    followers: 19800,
    following: 890,
    countries: 28,
    cities: 78,
    isCreator: true,
    badges: ['Beach Expert', 'Island Hopper', 'Wave Rider'],
  },
  {
    id: 'user11',
    name: 'Mountain Explorer',
    username: 'peak_seeker',
    profilePic: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop&crop=face',
    bio: 'Conquering peaks worldwide! ⛰️ Hiking trails • Mountain photography • Alpine adventures',
    followers: 16500,
    following: 1400,
    countries: 22,
    cities: 89,
    isCreator: true,
    badges: ['Peak Conqueror', 'Trail Master', 'Alpine Expert'],
  },
  {
    id: 'user12',
    name: 'Cultural Immersion',
    username: 'culture_deep',
    profilePic: 'https://images.unsplash.com/photo-1494790108755-2616b612c1c?w=100&h=100&fit=crop&crop=face',
    bio: 'Living like a local everywhere I go! 🎭 Cultural exchanges • Language learning • Traditions',
    followers: 11700,
    following: 1800,
    countries: 38,
    cities: 142,
    isCreator: true,
    badges: ['Cultural Ambassador', 'Language Lover', 'Tradition Keeper'],
  }
];

// Enhanced experiences with comprehensive data
export const mockExperiences: Experience[] = [
  // Bali Experiences
  {
    id: 'exp1',
    title: 'Ubud Jungle Villa with Infinity Pool',
    category: 'stay',
    location: 'Ubud, Bali',
    description: 'Luxury eco-villa surrounded by lush tropical rainforest with breathtaking valley views. Features traditional Balinese architecture, private infinity pool, and world-class spa services.',
    rating: 4.8,
    reviewCount: 247,
    cost: 250,
    pricing: '$250/night',
    images: [
      'https://images.unsplash.com/photo-1571896349842-33c89424de2d?w=800&h=600&fit=crop',
      'https://images.unsplash.com/photo-1564501049412-61c2a3083791?w=800&h=600&fit=crop',
      'https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?w=800&h=600&fit=crop',
      'https://images.unsplash.com/photo-1571003123894-1f0594d2b5d9?w=800&h=600&fit=crop'
    ],
    review: 'Absolutely magical stay! The infinity pool overlooking the jungle was the highlight. Staff were incredibly attentive and the traditional Balinese breakfast was divine. Perfect for a romantic getaway.',
    tags: ['Luxury', 'Eco-Friendly', 'Pool', 'Spa', 'Romantic'],
    affiliateLink: 'https://booking.example.com/ubud-villa',
  },
  {
    id: 'exp2',
    title: 'Sisterfields Café - Brunch Paradise',
    category: 'food',
    location: 'Seminyak, Bali',
    description: 'Trendy café known for its Instagram-worthy smoothie bowls, artisanal coffee, and Australian-inspired brunch menu. Popular with digital nomads and health-conscious travelers.',
    rating: 4.6,
    reviewCount: 1850,
    cost: 25,
    pricing: '$15-35 per person',
    images: [
      'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=800&h=600&fit=crop',
      'https://images.unsplash.com/photo-1551024506-0bccd828d307?w=800&h=600&fit=crop',
      'https://images.unsplash.com/photo-1546039907-7fa05f864c02?w=800&h=600&fit=crop'
    ],
    review: 'The açai bowls here are incredible! Fresh tropical fruits, perfect granola crunch, and beautiful presentation. Great WiFi for digital nomads too. Can get busy during peak hours.',
    tags: ['Healthy', 'Instagram-worthy', 'Vegetarian', 'WiFi', 'Brunch'],
    affiliateLink: 'https://delivery.example.com/sisterfields',
  },
  {
    id: 'exp3',
    title: 'Mount Batur Sunrise Trek',
    category: 'activities',
    location: 'Kintamani, Bali',
    description: 'Early morning volcanic trek to catch the spectacular sunrise over Lake Batur. Includes traditional breakfast cooked using volcanic steam and professional guide.',
    rating: 4.9,
    reviewCount: 3210,
    cost: 65,
    pricing: '$65 per person',
    images: [
      'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=800&h=600&fit=crop',
      'https://images.unsplash.com/photo-1551524164-687a55dd1126?w=800&h=600&fit=crop',
      'https://images.unsplash.com/photo-1469474968028-56623f02e42e?w=800&h=600&fit=crop'
    ],
    review: 'Absolutely worth the 3:30 AM wake-up call! The sunrise view was breathtaking and our guide Made was fantastic. The volcanic breakfast was a unique touch. Moderate difficulty level.',
    tags: ['Adventure', 'Sunrise', 'Hiking', 'Nature', 'Guide Included'],
    affiliateLink: 'https://tours.example.com/mount-batur',
  },
  {
    id: 'exp4',
    title: 'Tanah Lot Temple Sunset',
    category: 'activities',
    location: 'Tanah Lot, Bali',
    description: 'Ancient Hindu temple perched on a rock formation in the sea. Famous for spectacular sunset views and cultural significance.',
    rating: 4.5,
    reviewCount: 2890,
    cost: 15,
    pricing: '$15 per person',
    images: [
      'https://images.unsplash.com/photo-1537953773345-d172ccf13cf1?w=800&h=600&fit=crop'
    ],
    review: 'Breathtaking sunset views! The temple silhouette against the orange sky is magical. Arrive early to get a good spot.',
    tags: ['Temple', 'Sunset', 'Cultural', 'Photography', 'Sacred'],
    affiliateLink: 'https://tours.example.com/tanah-lot',
  },
  {
    id: 'exp5',
    title: 'Traditional Balinese Spa Treatment',
    category: 'activities',
    location: 'Ubud, Bali',
    description: 'Authentic Balinese massage and spa treatment using traditional techniques and natural ingredients.',
    rating: 4.7,
    reviewCount: 1560,
    cost: 40,
    pricing: '$40 per person',
    images: [
      'https://images.unsplash.com/photo-1596178060810-4d66fff7bbaf?w=800&h=600&fit=crop'
    ],
    review: 'So relaxing! The massage techniques were incredible and the natural oils smelled amazing.',
    tags: ['Spa', 'Traditional', 'Relaxation', 'Wellness', 'Authentic'],
    affiliateLink: 'https://spa.example.com/bali-treatment',
  },
  {
    id: 'exp6',
    title: 'Tegallalang Rice Terraces Walk',
    category: 'activities',
    location: 'Tegallalang, Bali',
    description: 'Scenic walk through the famous rice terraces with stunning valley views and photo opportunities.',
    rating: 4.4,
    reviewCount: 2340,
    cost: 10,
    pricing: '$10 per person',
    images: [
      'https://images.unsplash.com/photo-1552465011-b4e21bf6e79a?w=800&h=600&fit=crop'
    ],
    review: 'Absolutely stunning! The green terraces are so peaceful and beautiful. Perfect for photos.',
    tags: ['Nature', 'Photography', 'Walking', 'Scenic', 'Rice Terraces'],
    affiliateLink: 'https://tours.example.com/rice-terraces',
  },
  {
    id: 'exp7',
    title: 'Balinese Cooking Class',
    category: 'food',
    location: 'Ubud, Bali',
    description: 'Learn to cook authentic Balinese dishes using traditional ingredients and methods in a local family setting.',
    rating: 4.8,
    reviewCount: 1890,
    cost: 55,
    pricing: '$55 per person',
    images: [
      'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=800&h=600&fit=crop'
    ],
    review: 'Amazing experience! Learned so much about Balinese culture through food. The rendang was incredible!',
    tags: ['Cooking Class', 'Cultural', 'Traditional', 'Family Experience', 'Authentic'],
    affiliateLink: 'https://cooking.example.com/bali-class',
  },
  {
    id: 'exp8',
    title: 'Monkey Forest Sanctuary Visit',
    category: 'activities',
    location: 'Ubud, Bali',
    description: 'Sacred monkey forest sanctuary with ancient temples and playful macaque monkeys in their natural habitat.',
    rating: 4.2,
    reviewCount: 3450,
    cost: 5,
    pricing: '$5 per person',
    images: [
      'https://images.unsplash.com/photo-1546587348-d12660c30c50?w=800&h=600&fit=crop'
    ],
    review: 'Fun experience watching the monkeys! Just be careful with your belongings. The temples are beautiful too.',
    tags: ['Wildlife', 'Nature', 'Temple', 'Photography', 'Family Friendly'],
    affiliateLink: 'https://tours.example.com/monkey-forest',
  },

  // Tokyo Experiences
  {
    id: 'exp9',
    title: 'Shibuya Sky Observation Deck',
    category: 'activities',
    location: 'Shibuya, Tokyo',
    description: 'Rooftop observation deck offering 360-degree panoramic views of Tokyo skyline. Features outdoor sky stage, interactive digital installations, and the famous Shibuya Crossing view.',
    rating: 4.5,
    reviewCount: 4820,
    cost: 20,
    pricing: '¥2000 ($20)',
    images: [
      'https://images.unsplash.com/photo-1540959733332-eab4deabeeaf?w=800&h=600&fit=crop',
      'https://images.unsplash.com/photo-1513407030348-c983a97b98d8?w=800&h=600&fit=crop',
      'https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?w=800&h=600&fit=crop'
    ],
    review: 'Incredible views of Tokyo! Best time to visit is just before sunset to see the city transition from day to night. The outdoor deck experience is worth the price.',
    tags: ['City Views', 'Photography', 'Sunset', 'Modern', 'Instagram'],
    affiliateLink: 'https://tickets.example.com/shibuya-sky',
  },
  {
    id: 'exp10',
    title: 'Senso-ji Temple & Asakusa District',
    category: 'activities',
    location: 'Asakusa, Tokyo',
    description: 'Tokyo\'s oldest temple with traditional shopping street and authentic Japanese cultural experience.',
    rating: 4.6,
    reviewCount: 5670,
    cost: 0,
    pricing: 'Free',
    images: [
      'https://images.unsplash.com/photo-1503899036084-c55cdd92da26?w=800&h=600&fit=crop'
    ],
    review: 'Beautiful traditional temple! The incense ceremony was moving and Nakamise Street has great souvenirs.',
    tags: ['Temple', 'Traditional', 'Cultural', 'Shopping', 'Historic'],
    affiliateLink: 'https://tours.example.com/sensoji',
  },
  {
    id: 'exp11',
    title: 'Tsukiji Outer Market Food Tour',
    category: 'food',
    location: 'Tsukiji, Tokyo',
    description: 'Early morning food tour through the famous Tsukiji market with fresh sushi, street food, and local delicacies.',
    rating: 4.8,
    reviewCount: 2340,
    cost: 65,
    pricing: '¥6500 ($65)',
    images: [
      'https://images.unsplash.com/photo-1559056199-641a0ac8b55e?w=800&h=600&fit=crop'
    ],
    review: 'Incredible fresh sushi! The market atmosphere is amazing and our guide knew all the best stalls.',
    tags: ['Food Tour', 'Sushi', 'Market', 'Local Guide', 'Fresh Fish'],
    affiliateLink: 'https://foodtours.example.com/tsukiji',
  },
  {
    id: 'exp12',
    title: 'Robot Restaurant Show',
    category: 'activities',
    location: 'Shinjuku, Tokyo',
    description: 'Crazy neon-lit robot show with lasers, music, and dancing robots in an electric atmosphere.',
    rating: 4.3,
    reviewCount: 3890,
    cost: 45,
    pricing: '¥4500 ($45)',
    images: [
      'https://images.unsplash.com/photo-1542051841857-5f90071e7989?w=800&h=600&fit=crop'
    ],
    review: 'Absolutely wild experience! Pure sensory overload in the best way. Definitely uniquely Tokyo!',
    tags: ['Entertainment', 'Unique', 'Neon', 'Show', 'Electric'],
    affiliateLink: 'https://tickets.example.com/robot-restaurant',
  },
  {
    id: 'exp13',
    title: 'Traditional Ryokan Stay',
    category: 'stay',
    location: 'Tokyo',
    description: 'Authentic Japanese inn experience with tatami mats, futon beds, and traditional kaiseki dinner.',
    rating: 4.7,
    reviewCount: 1560,
    cost: 180,
    pricing: '¥18000 ($180)/night',
    images: [
      'https://images.unsplash.com/photo-1571896349842-33c89424de2d?w=800&h=600&fit=crop'
    ],
    review: 'Amazing cultural experience! The kaiseki dinner was art on a plate and sleeping on tatami was unique.',
    tags: ['Traditional', 'Ryokan', 'Cultural', 'Kaiseki', 'Authentic'],
    affiliateLink: 'https://booking.example.com/tokyo-ryokan',
  },
  {
    id: 'exp14',
    title: 'Cherry Blossom Viewing in Ueno Park',
    category: 'activities',
    location: 'Ueno, Tokyo',
    description: 'Hanami (cherry blossom viewing) in one of Tokyo\'s most famous parks during sakura season.',
    rating: 4.9,
    reviewCount: 2100,
    cost: 0,
    pricing: 'Free',
    images: [
      'https://images.unsplash.com/photo-1522383225653-ed111181a951?w=800&h=600&fit=crop'
    ],
    review: 'Absolutely magical during cherry blossom season! The pink petals everywhere create a fairytale atmosphere.',
    tags: ['Cherry Blossoms', 'Hanami', 'Park', 'Spring', 'Photography'],
    affiliateLink: 'https://tours.example.com/hanami',
  },
  {
    id: 'exp15',
    title: 'Meiji Shrine Visit',
    category: 'activities',
    location: 'Shibuya, Tokyo',
    description: 'Peaceful Shinto shrine dedicated to Emperor Meiji, surrounded by a beautiful forest in the heart of Tokyo.',
    rating: 4.5,
    reviewCount: 4560,
    cost: 0,
    pricing: 'Free',
    images: [
      'https://images.unsplash.com/photo-1528164344705-47542687000d?w=800&h=600&fit=crop'
    ],
    review: 'So peaceful and spiritual! Hard to believe you\'re in the middle of busy Tokyo. The forest walk is lovely.',
    tags: ['Shrine', 'Peaceful', 'Spiritual', 'Forest', 'Cultural'],
    affiliateLink: 'https://tours.example.com/meiji-shrine',
  },
  {
    id: 'exp16',
    title: 'Harajuku Fashion District',
    category: 'activities',
    location: 'Harajuku, Tokyo',
    description: 'Explore Tokyo\'s fashion capital with unique street style, vintage shops, and colorful culture.',
    rating: 4.4,
    reviewCount: 3450,
    cost: 0,
    pricing: 'Free',
    images: [
      'https://images.unsplash.com/photo-1513407030348-c983a97b98d8?w=800&h=600&fit=crop'
    ],
    review: 'Amazing street fashion! So much creativity and unique style. Great for people watching and shopping.',
    tags: ['Fashion', 'Street Style', 'Shopping', 'Culture', 'Colorful'],
    affiliateLink: 'https://tours.example.com/harajuku',
  },

  // Barcelona Experiences
  {
    id: 'exp17',
    title: 'Sagrada Familia Skip-the-Line Tour',
    category: 'activities',
    location: 'Barcelona, Spain',
    description: 'Priority access to Gaudí\'s architectural masterpiece with expert guide. Includes tower access and detailed history of this UNESCO World Heritage site.',
    rating: 4.9,
    reviewCount: 5670,
    cost: 45,
    pricing: '€45 per person',
    images: [
      'https://images.unsplash.com/photo-1539037116277-4db20889f2d4?w=800&h=600&fit=crop',
      'https://images.unsplash.com/photo-1509840841025-9088ba78a826?w=800&h=600&fit=crop',
      'https://images.unsplash.com/photo-1558642452-9d2a7deb7f62?w=800&h=600&fit=crop'
    ],
    review: 'Absolutely breathtaking! Our guide Maria explained every detail beautifully. The tower views are incredible and skipping the line saved hours. Must-book experience in Barcelona.',
    tags: ['Architecture', 'UNESCO', 'Skip-the-Line', 'Guide', 'Towers'],
    affiliateLink: 'https://tours.example.com/sagrada-familia',
  },
  {
    id: 'exp18',
    title: 'Park Güell Morning Visit',
    category: 'activities',
    location: 'Barcelona, Spain',
    description: 'Early access to Gaudí\'s whimsical park with colorful mosaics and panoramic city views. Includes monumental zone access and audio guide.',
    rating: 4.7,
    reviewCount: 3890,
    cost: 25,
    pricing: '€25 per person',
    images: [
      'https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=800&h=600&fit=crop',
      'https://images.unsplash.com/photo-1571936836811-0ba4cea26c31?w=800&h=600&fit=crop'
    ],
    review: 'The mosaics are even more beautiful in person! Morning visit means fewer crowds and better photos. The city views from the terrace are spectacular.',
    tags: ['Art', 'Mosaics', 'City Views', 'Morning', 'Photography'],
    affiliateLink: 'https://tickets.example.com/park-guell',
  },
  {
    id: 'exp19',
    title: 'La Boqueria Market Food Tour',
    category: 'food',
    location: 'Barcelona, Spain',
    description: 'Guided culinary journey through Barcelona\'s most famous market. Taste jamón ibérico, fresh seafood, local cheeses, and traditional Catalan dishes.',
    rating: 4.8,
    reviewCount: 2340,
    cost: 75,
    pricing: '€75 per person',
    images: [
      'https://images.unsplash.com/photo-1559056199-641a0ac8b55e?w=800&h=600&fit=crop',
      'https://images.unsplash.com/photo-1565299507177-b0ac66763828?w=800&h=600&fit=crop'
    ],
    review: 'Incredible flavors! Our guide Carlos knew all the best stalls. The jamón tasting was divine and we learned so much about Catalan cuisine. Highly recommended!',
    tags: ['Food Tour', 'Market', 'Jamón', 'Catalan', 'Local Guide'],
    affiliateLink: 'https://foodtours.example.com/boqueria',
  },
  {
    id: 'exp20',
    title: 'Gothic Quarter Walking Tour',
    category: 'activities',
    location: 'Barcelona, Spain',
    description: 'Explore the medieval heart of Barcelona with narrow streets, hidden squares, and centuries of history.',
    rating: 4.6,
    reviewCount: 4560,
    cost: 30,
    pricing: '€30 per person',
    images: [
      'https://images.unsplash.com/photo-1558642452-9d2a7deb7f62?w=800&h=600&fit=crop'
    ],
    review: 'Fascinating history! The medieval architecture is stunning and our guide brought the stories to life.',
    tags: ['Walking Tour', 'Historic', 'Medieval', 'Architecture', 'Culture'],
    affiliateLink: 'https://tours.example.com/gothic-quarter',
  },
  {
    id: 'exp21',
    title: 'Casa Batlló Audio Tour',
    category: 'activities',
    location: 'Barcelona, Spain',
    description: 'Self-guided tour of Gaudí\'s modernist masterpiece with immersive audio experience and augmented reality.',
    rating: 4.5,
    reviewCount: 3450,
    cost: 35,
    pricing: '€35 per person',
    images: [
      'https://images.unsplash.com/photo-1539037116277-4db20889f2d4?w=800&h=600&fit=crop'
    ],
    review: 'Stunning architecture! The audio tour was excellent and the AR features made it even more interactive.',
    tags: ['Architecture', 'Gaudí', 'Audio Tour', 'Modernist', 'AR Experience'],
    affiliateLink: 'https://tickets.example.com/casa-batllo',
  },
  {
    id: 'exp22',
    title: 'Flamenco Show with Dinner',
    category: 'activities',
    location: 'Barcelona, Spain',
    description: 'Authentic flamenco performance in an intimate tablao with traditional Spanish dinner and unlimited sangria.',
    rating: 4.7,
    reviewCount: 2890,
    cost: 85,
    pricing: '€85 per person',
    images: [
      'https://images.unsplash.com/photo-1571936836811-0ba4cea26c31?w=800&h=600&fit=crop'
    ],
    review: 'Passionate and powerful performance! The dancers were incredible and the paella was delicious.',
    tags: ['Flamenco', 'Dance', 'Dinner', 'Traditional', 'Authentic'],
    affiliateLink: 'https://shows.example.com/flamenco-barcelona',
  },
  {
    id: 'exp23',
    title: 'Beach Day at Barceloneta',
    category: 'activities',
    location: 'Barcelona, Spain',
    description: 'Relax on Barcelona\'s most famous beach with golden sand, beach bars, and Mediterranean vibes.',
    rating: 4.3,
    reviewCount: 1890,
    cost: 0,
    pricing: 'Free',
    images: [
      'https://images.unsplash.com/photo-1544551763-46a013bb70d5?w=800&h=600&fit=crop'
    ],
    review: 'Perfect city beach! Great for swimming and the chiringuitos serve amazing paella by the sea.',
    tags: ['Beach', 'Swimming', 'Relaxation', 'Mediterranean', 'Chiringuitos'],
    affiliateLink: 'https://beaches.example.com/barceloneta',
  },
  {
    id: 'exp24',
    title: 'Tapas Crawl in El Born',
    category: 'food',
    location: 'Barcelona, Spain',
    description: 'Guided evening tour of the trendiest neighborhood\'s best tapas bars with wine pairings.',
    rating: 4.8,
    reviewCount: 3210,
    cost: 60,
    pricing: '€60 per person',
    images: [
      'https://images.unsplash.com/photo-1565299507177-b0ac66763828?w=800&h=600&fit=crop'
    ],
    review: 'Amazing tapas variety! Each bar had its specialty and the wine pairings were perfect. Great nightlife!',
    tags: ['Tapas', 'Wine', 'Nightlife', 'Local Bars', 'Food Tour'],
    affiliateLink: 'https://foodtours.example.com/tapas-crawl',
  },

  // Additional experiences for comprehensive content
  {
    id: 'exp25',
    title: 'Santorini Sunset Dinner Cruise',
    category: 'activities',
    location: 'Santorini, Greece',
    description: 'Romantic catamaran cruise with traditional Greek dinner and unlimited wine. Watch the famous Santorini sunset from the water with swimming stops.',
    rating: 4.9,
    reviewCount: 1560,
    cost: 120,
    pricing: '€120 per person',
    images: [
      'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=800&h=600&fit=crop',
      'https://images.unsplash.com/photo-1613395877344-13d4a8e0d49e?w=800&h=600&fit=crop'
    ],
    review: 'Pure magic! The sunset was breathtaking and the Greek dinner was delicious. Swimming in the Aegean Sea was incredible. Most romantic experience ever!',
    tags: ['Sunset', 'Cruise', 'Romantic', 'Swimming', 'Greek Cuisine'],
    affiliateLink: 'https://cruises.example.com/santorini-sunset',
  },
  {
    id: 'exp26',
    title: 'Blue Lagoon Geothermal Spa',
    category: 'activities',
    location: 'Reykjavik, Iceland',
    description: 'Relaxing geothermal spa experience with silica mud mask, algae mask, and towel rental. Includes access to sauna and in-water drink service.',
    rating: 4.6,
    reviewCount: 7890,
    cost: 95,
    pricing: '$95 per person',
    images: [
      'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=800&h=600&fit=crop',
      'https://images.unsplash.com/photo-1548624313-6de15184cbc0?w=800&h=600&fit=crop'
    ],
    review: 'So relaxing! The geothermal waters felt amazing and the silica mud mask left my skin so soft. Perfect way to recover from jet lag. Book in advance!',
    tags: ['Geothermal', 'Spa', 'Relaxation', 'Unique', 'Photography'],
    affiliateLink: 'https://bluelagoon.example.com/comfort',
  },
  {
    id: 'exp27',
    title: 'Thai Street Food Night Market',
    category: 'food',
    location: 'Bangkok, Thailand',
    description: 'Evening food tour through Bangkok\'s most authentic night markets with local guide and tastings.',
    rating: 4.7,
    reviewCount: 2340,
    cost: 35,
    pricing: '฿1050 ($35)',
    images: [
      'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=800&h=600&fit=crop'
    ],
    review: 'Incredible authentic flavors! Our guide took us to places tourists never find. The mango sticky rice was divine!',
    tags: ['Street Food', 'Night Market', 'Local Guide', 'Authentic', 'Thai Cuisine'],
    affiliateLink: 'https://foodtours.example.com/bangkok-night',
  }
];

// Experience moments data for connecting experiences with user-generated moments
export const mockExperienceMoments: ExperienceMoment[] = [
  // Ubud Jungle Villa moments
  {
    id: 'em1',
    experienceId: 'exp1',
    type: 'image',
    image: 'https://images.unsplash.com/photo-1571896349842-33c89424de2d?w=400&h=500&fit=crop',
    caption: 'Morning coffee with this incredible jungle view! 🌿☕',
    likes: 234,
    comments: 18,
    timestamp: '2 hours ago',
    userId: 'user1',
    userName: 'Wanderlust Explorer',
    userAvatar: 'https://images.unsplash.com/photo-1494790108755-2616b612c1c?w=50&h=50&fit=crop&crop=face'
  },
  {
    id: 'em2',
    experienceId: 'exp1',
    type: 'image',
    image: 'https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=400&h=500&fit=crop',
    caption: 'Floating breakfast dreams! This place is pure magic ✨',
    likes: 189,
    comments: 12,
    timestamp: '1 day ago',
    userId: 'user3',
    userName: 'Urban Wanderer',
    userAvatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=50&h=50&fit=crop&crop=face'
  },
  {
    id: 'em3',
    experienceId: 'exp2',
    type: 'image',
    image: 'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=400&h=500&fit=crop',
    caption: 'Rainbow smoothie bowl perfection! 🌈🍓',
    likes: 312,
    comments: 24,
    timestamp: '3 hours ago',
    userId: 'user2',
    userName: 'Foodie Traveler',
    userAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=50&h=50&fit=crop&crop=face'
  },
  {
    id: 'em4',
    experienceId: 'exp3',
    type: 'image',
    image: 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=400&h=500&fit=crop',
    caption: 'Worth every step! This sunrise view is unreal 🌄',
    likes: 445,
    comments: 31,
    timestamp: '4 hours ago',
    userId: 'user4',
    userName: 'Adventure Seeker',
    userAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=50&h=50&fit=crop&crop=face'
  },
  {
    id: 'em5',
    experienceId: 'exp9',
    type: 'image',
    image: 'https://images.unsplash.com/photo-1540959733332-eab4deabeeaf?w=400&h=500&fit=crop',
    caption: 'Tokyo never sleeps! This view is incredible 🏙️✨',
    likes: 523,
    comments: 42,
    timestamp: '6 hours ago',
    userId: 'user3',
    userName: 'Urban Wanderer',
    userAvatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=50&h=50&fit=crop&crop=face'
  }
];

// Enhanced Travel Cards with comprehensive experiences (8+ per card)
export const mockTravelCards: TravelCard[] = [
  // Bali Travel Card with 8 experiences
  {
    id: 'tc1',
    title: 'Ultimate Bali Island Paradise',
    description: 'Complete guide to Bali\'s best experiences from luxury jungle villas to volcanic sunrise treks and traditional cultural immersion.',
    thumbnail: 'https://images.unsplash.com/photo-1571896349842-33c89424de2d?w=800&h=1000&fit=crop',
    destination: 'Bali, Indonesia',
    images: [
      'https://images.unsplash.com/photo-1571896349842-33c89424de2d?w=800&h=1000&fit=crop',
      'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=800&h=1000&fit=crop',
      'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=800&h=1000&fit=crop'
    ],
    rating: 4.8,
    likes: 15670,
    comments: 892,
    views: 45230,
    cost: 45000,
    dates: '7 days',
    tripType: 'Adventure',
    creatorId: 'user1',
    experiences: [
      mockExperiences[0], // Ubud Jungle Villa
      mockExperiences[1], // Sisterfields Café
      mockExperiences[2], // Mount Batur Trek
      mockExperiences[3], // Tanah Lot Temple
      mockExperiences[4], // Spa Treatment
      mockExperiences[5], // Rice Terraces
      mockExperiences[6], // Cooking Class
      mockExperiences[7], // Monkey Forest
    ],
    isLive: false,
  },
  
  // Tokyo Travel Card with 8 experiences
  {
    id: 'tc2',
    title: 'Tokyo Cultural Immersion',
    description: 'Experience authentic Tokyo from traditional temples to modern observation decks, complete with cherry blossoms and robot shows.',
    thumbnail: 'https://images.unsplash.com/photo-1540959733332-eab4deabeeaf?w=800&h=1000&fit=crop',
    destination: 'Tokyo, Japan',
    images: [
      'https://images.unsplash.com/photo-1540959733332-eab4deabeeaf?w=800&h=1000&fit=crop',
      'https://images.unsplash.com/photo-1522383225653-ed111181a951?w=800&h=1000&fit=crop',
      'https://images.unsplash.com/photo-1503899036084-c55cdd92da26?w=800&h=1000&fit=crop'
    ],
    rating: 4.7,
    likes: 12340,
    comments: 567,
    views: 34560,
    cost: 65000,
    dates: '6 days',
    tripType: 'Cultural',
    creatorId: 'user12',
    experiences: [
      mockExperiences[8], // Shibuya Sky
      mockExperiences[9], // Senso-ji Temple
      mockExperiences[10], // Tsukiji Market
      mockExperiences[11], // Robot Restaurant
      mockExperiences[12], // Ryokan Stay
      mockExperiences[13], // Cherry Blossoms
      mockExperiences[14], // Meiji Shrine
      mockExperiences[15], // Harajuku
    ],
    isLive: false,
  },

  // Barcelona Travel Card with 8 experiences
  {
    id: 'tc3',
    title: 'Barcelona Architecture & Gastronomy',
    description: 'Discover Gaudí\'s masterpieces, explore Gothic quarters, and indulge in the best Catalan cuisine and flamenco culture.',
    thumbnail: 'https://images.unsplash.com/photo-1539037116277-4db20889f2d4?w=800&h=1000&fit=crop',
    destination: 'Barcelona, Spain',
    images: [
      'https://images.unsplash.com/photo-1539037116277-4db20889f2d4?w=800&h=1000&fit=crop',
      'https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=800&h=1000&fit=crop',
      'https://images.unsplash.com/photo-1559056199-641a0ac8b55e?w=800&h=1000&fit=crop'
    ],
    rating: 4.6,
    likes: 8950,
    comments: 434,
    views: 28670,
    cost: 38000,
    dates: '5 days',
    tripType: 'Cultural',
    creatorId: 'user2',
    experiences: [
      mockExperiences[16], // Sagrada Familia
      mockExperiences[17], // Park Güell
      mockExperiences[18], // La Boqueria Market
      mockExperiences[19], // Gothic Quarter
      mockExperiences[20], // Casa Batlló
      mockExperiences[21], // Flamenco Show
      mockExperiences[22], // Barceloneta Beach
      mockExperiences[23], // Tapas Crawl
    ],
    isLive: false,
  },

  // Live Travel Card
  {
    id: 'tc_live1',
    title: 'Live from Japan: Cherry Blossom Season',
    description: 'Currently exploring Tokyo and Kyoto during peak sakura season! Follow me as I discover the most beautiful hanami spots and traditional tea ceremonies. 🌸',
    thumbnail: 'https://images.unsplash.com/photo-1522383225653-ed111181a951?w=800&h=1000&fit=crop',
    destination: 'Tokyo & Kyoto, Japan',
    images: [
      'https://images.unsplash.com/photo-1522383225653-ed111181a951?w=800&h=1000&fit=crop',
      'https://images.unsplash.com/photo-1503899036084-c55cdd92da26?w=800&h=1000&fit=crop'
    ],
    rating: 4.9,
    likes: 25670,
    comments: 1234,
    views: 78230,
    cost: 55000,
    dates: '8 days',
    tripType: 'Cultural',
    creatorId: 'user12',
    experiences: [
      mockExperiences[13], // Cherry Blossoms
      mockExperiences[9], // Senso-ji Temple
      mockExperiences[14], // Meiji Shrine
      mockExperiences[10], // Tsukiji Market
      mockExperiences[8], // Shibuya Sky
      mockExperiences[12], // Ryokan Stay
      mockExperiences[15], // Harajuku
      mockExperiences[11], // Robot Restaurant
    ],
    isLive: true,
  },

  // Adventure Travel Card
  {
    id: 'tc4',
    title: 'Iceland Northern Lights Adventure',
    description: 'Chase the Aurora Borealis and experience Iceland\'s dramatic landscapes, geothermal wonders, and Nordic culture.',
    thumbnail: 'https://images.unsplash.com/photo-1483347756197-71ef80e95f73?w=800&h=1000&fit=crop',
    destination: 'Reykjavik, Iceland',
    images: [
      'https://images.unsplash.com/photo-1483347756197-71ef80e95f73?w=800&h=1000&fit=crop',
      'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=800&h=1000&fit=crop'
    ],
    rating: 4.8,
    likes: 18340,
    comments: 789,
    views: 52180,
    cost: 85000,
    dates: '6 days',
    tripType: 'Adventure',
    creatorId: 'user4',
    experiences: [
      mockExperiences[25], // Blue Lagoon
      {
        id: 'exp_iceland1',
        title: 'Northern Lights Super Jeep Tour',
        category: 'activities',
        location: 'Reykjavik, Iceland',
        description: 'Arctic adventure in modified 4x4 vehicles to hunt for Aurora Borealis.',
        rating: 4.7,
        cost: 150,
        pricing: '$150 per person',
        images: ['https://images.unsplash.com/photo-1483347756197-71ef80e95f73?w=800&h=600&fit=crop'],
        tags: ['Northern Lights', 'Adventure', 'Photography']
      },
      {
        id: 'exp_iceland2',
        title: 'Golden Circle Day Tour',
        category: 'activities',
        location: 'Iceland',
        description: 'Visit Gullfoss waterfall, Geysir geothermal area, and Þingvellir National Park.',
        rating: 4.6,
        cost: 120,
        pricing: '$120 per person',
        images: ['https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=800&h=600&fit=crop'],
        tags: ['Waterfalls', 'Geysers', 'National Park']
      },
      {
        id: 'exp_iceland3',
        title: 'Ice Cave Exploration',
        category: 'activities',
        location: 'Vatnajökull, Iceland',
        description: 'Explore natural ice caves in Europe\'s largest glacier.',
        rating: 4.8,
        cost: 200,
        pricing: '$200 per person',
        images: ['https://images.unsplash.com/photo-1548624313-6de15184cbc0?w=800&h=600&fit=crop'],
        tags: ['Ice Caves', 'Glacier', 'Adventure']
      },
      {
        id: 'exp_iceland4',
        title: 'Whale Watching Tour',
        category: 'activities',
        location: 'Reykjavik, Iceland',
        description: 'Spot humpback whales, minke whales, and dolphins in Faxaflói Bay.',
        rating: 4.5,
        cost: 90,
        pricing: '$90 per person',
        images: ['https://images.unsplash.com/photo-1544551763-46a013bb70d5?w=800&h=600&fit=crop'],
        tags: ['Whales', 'Wildlife', 'Ocean']
      },
      {
        id: 'exp_iceland5',
        title: 'Reykjavik Food Walking Tour',
        category: 'food',
        location: 'Reykjavik, Iceland',
        description: 'Taste traditional Icelandic cuisine including fermented shark and local seafood.',
        rating: 4.3,
        cost: 80,
        pricing: '$80 per person',
        images: ['https://images.unsplash.com/photo-1565299507177-b0ac66763828?w=800&h=600&fit=crop'],
        tags: ['Food Tour', 'Local Cuisine', 'Seafood']
      },
      {
        id: 'exp_iceland6',
        title: 'Hot Spring Relaxation',
        category: 'activities',
        location: 'Iceland',
        description: 'Relax in natural hot springs surrounded by stunning landscapes.',
        rating: 4.7,
        cost: 50,
        pricing: '$50 per person',
        images: ['https://images.unsplash.com/photo-1548624313-6de15184cbc0?w=800&h=600&fit=crop'],
        tags: ['Hot Springs', 'Relaxation', 'Nature']
      },
      {
        id: 'exp_iceland7',
        title: 'Helicopter Glacier Tour',
        category: 'activities',
        location: 'Iceland',
        description: 'Aerial views of Iceland\'s glaciers and volcanic landscapes.',
        rating: 4.9,
        cost: 350,
        pricing: '$350 per person',
        images: ['https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=800&h=600&fit=crop'],
        tags: ['Helicopter', 'Glaciers', 'Aerial Views']
      }
    ],
    isLive: false,
  },

  // Thailand Travel Card
  {
    id: 'tc5',
    title: 'Thailand Island Hopping Paradise',
    description: 'Explore pristine beaches, vibrant markets, and authentic Thai culture across the most beautiful islands.',
    thumbnail: 'https://images.unsplash.com/photo-1552465011-b4e21bf6e79a?w=800&h=1000&fit=crop',
    destination: 'Phuket & Phi Phi, Thailand',
    images: [
      'https://images.unsplash.com/photo-1552465011-b4e21bf6e79a?w=800&h=1000&fit=crop',
      'https://images.unsplash.com/photo-1571003123894-1f0594d2b5d9?w=800&h=1000&fit=crop'
    ],
    rating: 4.7,
    likes: 22340,
    comments: 1156,
    views: 67890,
    cost: 28000,
    dates: '8 days',
    tripType: 'Beach',
    creatorId: 'user10',
    experiences: [
      mockExperiences[26], // Thai Street Food
      {
        id: 'exp_thai1',
        title: 'Phi Phi Islands Day Trip',
        category: 'activities',
        location: 'Phuket, Thailand',
        description: 'Full-day speedboat tour to pristine beaches and crystal-clear waters.',
        rating: 4.5,
        cost: 85,
        pricing: '฿2500 ($85)',
        images: ['https://images.unsplash.com/photo-1552465011-b4e21bf6e79a?w=800&h=600&fit=crop'],
        tags: ['Island Hopping', 'Beaches', 'Snorkeling']
      },
      {
        id: 'exp_thai2',
        title: 'Thai Cooking Class',
        category: 'food',
        location: 'Bangkok, Thailand',
        description: 'Learn to prepare 5 traditional dishes including Pad Thai and Tom Yum soup.',
        rating: 4.8,
        cost: 45,
        pricing: '฿1350 ($45)',
        images: ['https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=800&h=600&fit=crop'],
        tags: ['Cooking Class', 'Pad Thai', 'Authentic']
      },
      {
        id: 'exp_thai3',
        title: 'Floating Market Tour',
        category: 'activities',
        location: 'Bangkok, Thailand',
        description: 'Traditional floating market experience with boat ride and local products.',
        rating: 4.4,
        cost: 35,
        pricing: '฿1050 ($35)',
        images: ['https://images.unsplash.com/photo-1559056199-641a0ac8b55e?w=800&h=600&fit=crop'],
        tags: ['Floating Market', 'Boat Tour', 'Traditional']
      },
      {
        id: 'exp_thai4',
        title: 'Thai Massage & Spa',
        category: 'activities',
        location: 'Phuket, Thailand',
        description: 'Traditional Thai massage and spa treatment in beachfront setting.',
        rating: 4.6,
        cost: 30,
        pricing: '฿900 ($30)',
        images: ['https://images.unsplash.com/photo-1596178060810-4d66fff7bbaf?w=800&h=600&fit=crop'],
        tags: ['Massage', 'Spa', 'Relaxation']
      },
      {
        id: 'exp_thai5',
        title: 'Elephant Sanctuary Visit',
        category: 'activities',
        location: 'Chiang Mai, Thailand',
        description: 'Ethical elephant sanctuary with feeding and bathing experience.',
        rating: 4.7,
        cost: 75,
        pricing: '฿2250 ($75)',
        images: ['https://images.unsplash.com/photo-1546587348-d12660c30c50?w=800&h=600&fit=crop'],
        tags: ['Elephants', 'Wildlife', 'Ethical Tourism']
      },
      {
        id: 'exp_thai6',
        title: 'Temples of Bangkok Tour',
        category: 'activities',
        location: 'Bangkok, Thailand',
        description: 'Visit the most sacred temples including Wat Pho and Wat Arun.',
        rating: 4.5,
        cost: 40,
        pricing: '฿1200 ($40)',
        images: ['https://images.unsplash.com/photo-1503899036084-c55cdd92da26?w=800&h=600&fit=crop'],
        tags: ['Temples', 'Cultural', 'Buddha']
      },
      {
        id: 'exp_thai7',
        title: 'Muay Thai Boxing Class',
        category: 'activities',
        location: 'Bangkok, Thailand',
        description: 'Learn the art of eight limbs from professional Muay Thai fighters.',
        rating: 4.6,
        cost: 50,
        pricing: '฿1500 ($50)',
        images: ['https://images.unsplash.com/photo-1542051841857-5f90071e7989?w=800&h=600&fit=crop'],
        tags: ['Muay Thai', 'Martial Arts', 'Fitness']
      }
    ],
    isLive: false,
  }
];

// Enhanced Stories data with more diverse travel content
export const mockStories: Story[] = [
  {
    id: 'story1',
    userId: 'user1',
    userName: 'Wanderlust Explorer',
    userAvatar: 'https://images.unsplash.com/photo-1494790108755-2616b612c1c?w=100&h=100&fit=crop&crop=face',
    preview: 'https://images.unsplash.com/photo-1571896349842-33c89424de2d?w=100&h=100&fit=crop',
    content: [
      {
        id: 'sc1',
        type: 'image',
        url: 'https://images.unsplash.com/photo-1571896349842-33c89424de2d?w=400&h=700&fit=crop',
        caption: 'Sunrise from our villa in Ubud 🌅',
        timestamp: '2 hours ago'
      }
    ],
    timestamp: '2 hours ago',
    isLive: false,
    location: 'Ubud, Bali',
    isViewed: false,
    viewCount: 1250,
    expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString()
  },
  {
    id: 'story2',
    userId: 'user2',
    userName: 'Foodie Traveler',
    userAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop&crop=face',
    preview: 'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=100&h=100&fit=crop',
    content: [
      {
        id: 'sc2',
        type: 'image',
        url: 'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=400&h=700&fit=crop',
        caption: 'Best açai bowl in Seminyak! 🍓',
        timestamp: '4 hours ago'
      }
    ],
    timestamp: '4 hours ago',
    isLive: false,
    location: 'Seminyak, Bali',
    isViewed: true,
    viewCount: 890,
    expiresAt: new Date(Date.now() + 20 * 60 * 60 * 1000).toISOString()
  },
  {
    id: 'story3',
    userId: 'user4',
    userName: 'Adventure Seeker',
    userAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&h=100&fit=crop&crop=face',
    preview: 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=100&h=100&fit=crop',
    content: [
      {
        id: 'sc3',
        type: 'image',
        url: 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=400&h=700&fit=crop',
        caption: '3:30AM wake-up call was SO worth it! 🏔️',
        timestamp: '1 hour ago'
      }
    ],
    timestamp: '1 hour ago',
    isLive: false,
    location: 'Mount Batur, Bali',
    isViewed: false,
    viewCount: 2340,
    expiresAt: new Date(Date.now() + 23 * 60 * 60 * 1000).toISOString()
  },
  {
    id: 'story4',
    userId: 'user6',
    userName: 'Solo Voyager',
    userAvatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=100&h=100&fit=crop&crop=face',
    preview: 'https://images.unsplash.com/photo-1540959733332-eab4deabeeaf?w=100&h=100&fit=crop',
    content: [
      {
        id: 'sc4',
        type: 'image',
        url: 'https://images.unsplash.com/photo-1540959733332-eab4deabeeaf?w=400&h=700&fit=crop',
        caption: 'Solo in Tokyo! Feeling fearless 🗼✨',
        timestamp: '3 hours ago'
      }
    ],
    timestamp: '3 hours ago',
    isLive: false,
    location: 'Shibuya, Tokyo',
    isViewed: false,
    viewCount: 1890,
    expiresAt: new Date(Date.now() + 21 * 60 * 60 * 1000).toISOString()
  },
  {
    id: 'story5',
    userId: 'user8',
    userName: 'Luxury Escapes',
    userAvatar: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f52?w=100&h=100&fit=crop&crop=face',
    preview: 'https://images.unsplash.com/photo-1613395877344-13d4a8e0d49e?w=100&h=100&fit=crop',
    content: [
      {
        id: 'sc5',
        type: 'image',
        url: 'https://images.unsplash.com/photo-1613395877344-13d4a8e0d49e?w=400&h=700&fit=crop',
        caption: 'Private yacht dinner in Santorini 🛥️🌅',
        timestamp: '5 hours ago'
      }
    ],
    timestamp: '5 hours ago',
    isLive: false,
    location: 'Santorini, Greece',
    isViewed: true,
    viewCount: 4560,
    expiresAt: new Date(Date.now() + 19 * 60 * 60 * 1000).toISOString()
  },
  {
    id: 'story6',
    userId: 'user10',
    userName: 'Beach Bliss',
    userAvatar: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=100&h=100&fit=crop&crop=face',
    preview: 'https://images.unsplash.com/photo-1544551763-46a013bb70d5?w=100&h=100&fit=crop',
    content: [
      {
        id: 'sc6',
        type: 'image',
        url: 'https://images.unsplash.com/photo-1544551763-46a013bb70d5?w=400&h=700&fit=crop',
        caption: 'Beach therapy session! 🏖️🌊',
        timestamp: '6 hours ago'
      }
    ],
    timestamp: '6 hours ago',
    isLive: false,
    location: 'Phi Phi Islands, Thailand',
    isViewed: false,
    viewCount: 3210,
    expiresAt: new Date(Date.now() + 18 * 60 * 60 * 1000).toISOString()
  },
  {
    id: 'story7',
    userId: 'user11',
    userName: 'Mountain Explorer',
    userAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop&crop=face',
    preview: 'https://images.unsplash.com/photo-1548624313-6de15184cbc0?w=100&h=100&fit=crop',
    content: [
      {
        id: 'sc7',
        type: 'image',
        url: 'https://images.unsplash.com/photo-1548624313-6de15184cbc0?w=400&h=700&fit=crop',
        caption: 'Ice caves in Iceland! Frozen paradise ❄️',
        timestamp: '7 hours ago'
      }
    ],
    timestamp: '7 hours ago',
    isLive: false,
    location: 'Vatnajökull, Iceland',
    isViewed: true,
    viewCount: 2780,
    expiresAt: new Date(Date.now() + 17 * 60 * 60 * 1000).toISOString()
  },
  {
    id: 'story8',
    userId: 'user12',
    userName: 'Cultural Immersion',
    userAvatar: 'https://images.unsplash.com/photo-1494790108755-2616b612c1c?w=100&h=100&fit=crop&crop=face',
    preview: 'https://images.unsplash.com/photo-1522383225653-ed111181a951?w=100&h=100&fit=crop',
    content: [
      {
        id: 'sc8',
        type: 'image',
        url: 'https://images.unsplash.com/photo-1522383225653-ed111181a951?w=400&h=700&fit=crop',
        caption: 'Hanami season in full bloom! 🌸',
        timestamp: '8 hours ago'
      }
    ],
    timestamp: '8 hours ago',
    isLive: false,
    location: 'Ueno Park, Tokyo',
    isViewed: false,
    viewCount: 5670,
    expiresAt: new Date(Date.now() + 16 * 60 * 60 * 1000).toISOString()
  },
  {
    id: 'story9',
    userId: 'user9',
    userName: 'Backpack Nomad',
    userAvatar: 'https://images.unsplash.com/photo-1531123897727-8f129e1688ce?w=100&h=100&fit=crop&crop=face',
    preview: 'https://images.unsplash.com/photo-1559056199-641a0ac8b55e?w=100&h=100&fit=crop',
    content: [
      {
        id: 'sc9',
        type: 'image',
        url: 'https://images.unsplash.com/photo-1559056199-641a0ac8b55e?w=400&h=700&fit=crop',
        caption: '$2 pad thai! Best budget meal ever 🍜',
        timestamp: '9 hours ago'
      }
    ],
    timestamp: '9 hours ago',
    isLive: false,
    location: 'Bangkok, Thailand',
    isViewed: true,
    viewCount: 1234,
    expiresAt: new Date(Date.now() + 15 * 60 * 60 * 1000).toISOString()
  },
  {
    id: 'story10',
    userId: 'user7',
    userName: 'Family Adventures',
    userAvatar: 'https://images.unsplash.com/photo-1544725176-7c40e5a71c5e?w=100&h=100&fit=crop&crop=face',
    preview: 'https://images.unsplash.com/photo-1539037116277-4db20889f2d4?w=100&h=100&fit=crop',
    content: [
      {
        id: 'sc10',
        type: 'image',
        url: 'https://images.unsplash.com/photo-1539037116277-4db20889f2d4?w=400&h=700&fit=crop',
        caption: 'Kids are loving the Sagrada Familia! 👨‍👩‍👧‍👦',
        timestamp: '10 hours ago'
      }
    ],
    timestamp: '10 hours ago',
    isLive: false,
    location: 'Barcelona, Spain',
    isViewed: false,
    viewCount: 987,
    expiresAt: new Date(Date.now() + 14 * 60 * 60 * 1000).toISOString()
  },
  {
    id: 'story11',
    userId: 'user5',
    userName: 'Relax & Recharge',
    userAvatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop&crop=face',
    preview: 'https://images.unsplash.com/photo-1596178060810-4d66fff7bbaf?w=100&h=100&fit=crop',
    content: [
      {
        id: 'sc11',
        type: 'image',
        url: 'https://images.unsplash.com/photo-1596178060810-4d66fff7bbaf?w=400&h=700&fit=crop',
        caption: 'Yoga retreat vibes in Ubud 🧘‍♀️✨',
        timestamp: '11 hours ago'
      }
    ],
    timestamp: '11 hours ago',
    isLive: false,
    location: 'Ubud, Bali',
    isViewed: true,
    viewCount: 3456,
    expiresAt: new Date(Date.now() + 13 * 60 * 60 * 1000).toISOString()
  },
  {
    id: 'story12',
    userId: 'user3',
    userName: 'Urban Wanderer',
    userAvatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop&crop=face',
    preview: 'https://images.unsplash.com/photo-1503899036084-c55cdd92da26?w=100&h=100&fit=crop',
    content: [
      {
        id: 'sc12',
        type: 'image',
        url: 'https://images.unsplash.com/photo-1503899036084-c55cdd92da26?w=400&h=700&fit=crop',
        caption: 'Street art hunting in Asakusa! 🎨',
        timestamp: '12 hours ago'
      }
    ],
    timestamp: '12 hours ago',
    isLive: false,
    location: 'Asakusa, Tokyo',
    isViewed: false,
    viewCount: 2100,
    expiresAt: new Date(Date.now() + 12 * 60 * 60 * 1000).toISOString()
  }
];

// Moments data
export const mockMoments: Moment[] = [
  {
    id: 'moment1',
    user: mockUsers[0],
    image: 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=400&h=500&fit=crop',
    caption: 'Mount Batur sunrise trek was absolutely incredible! Worth every step 🌄',
    location: 'Mount Batur, Bali',
    timestamp: '3 hours ago',
    likes: 234,
    comments: 18,
    isLiked: false
  },
  {
    id: 'moment2',
    user: mockUsers[1],
    image: 'https://images.unsplash.com/photo-1559056199-641a0ac8b55e?w=400&h=500&fit=crop',
    caption: 'La Boqueria market flavors are unreal! 🥘',
    location: 'Barcelona, Spain',
    timestamp: '5 hours ago',
    likes: 156,
    comments: 12,
    isLiked: true
  }
];

// Chat data
export const mockChats: Chat[] = [
  {
    id: 'chat1',
    participants: [mockUsers[0], mockUsers[1]],
    messages: [
      {
        id: 'msg1',
        sender: mockUsers[1],
        content: 'Hey! Love your Bali travel card! Any tips for first-time visitors?',
        timestamp: '2 hours ago',
        type: 'text'
      },
      {
        id: 'msg2',
        sender: mockUsers[0],
        content: 'Thanks! Definitely check out the Mount Batur sunrise trek - it\'s life-changing!',
        timestamp: '1 hour ago',
        type: 'text'
      }
    ],
    lastActivity: '1 hour ago',
    isGroup: false,
    unreadCount: 1
  }
];

// Helper functions
export const getCreator = (creatorId: string): User | undefined => {
  return mockUsers.find(user => user.id === creatorId);
};

export const getExperienceMoments = (experienceId: string): ExperienceMoment[] => {
  return mockExperienceMoments.filter(moment => moment.experienceId === experienceId);
};

export const getExperience = (experienceId: string): Experience | undefined => {
  return mockExperiences.find(exp => exp.id === experienceId);
};

export const getTravelCard = (travelCardId: string): TravelCard | undefined => {
  return mockTravelCards.find(card => card.id === travelCardId);
};

export const getUserById = (userId: string): User | undefined => {
  return mockUsers.find(user => user.id === userId);
};

export const getLocalGems = () => {
  // This would typically be imported from localGemsData.ts
  // For now, return empty array to prevent errors
  return [];
};