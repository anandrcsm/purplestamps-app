import { useState, useEffect, useRef } from 'react';
import { X, Heart, Share, MoreHorizontal, ChevronLeft, ChevronRight } from 'lucide-react';
import { Story } from '../types';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface StoryViewerProps {
  stories: Story[];
  initialIndex: number;
  onClose: () => void;
  onNext: () => void;
  onPrevious: () => void;
  onComplete: () => void;
  onSelectUser?: (userId: string) => void;
}

export function StoryViewer({
  stories,
  initialIndex,
  onClose,
  onNext,
  onPrevious,
  onComplete,
  onSelectUser
}: StoryViewerProps) {
  const [currentStoryIndex, setCurrentStoryIndex] = useState(initialIndex);
  const [currentContentIndex, setCurrentContentIndex] = useState(0);
  const [progress, setProgress] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  const [isLiked, setIsLiked] = useState(false);
  const progressInterval = useRef<NodeJS.Timeout | null>(null);

  const currentStory = stories[currentStoryIndex];
  const currentContent = currentStory?.content[currentContentIndex];
  const duration = currentContent?.duration || 5; // Default 5 seconds for images

  useEffect(() => {
    setCurrentStoryIndex(initialIndex);
    setCurrentContentIndex(0);
    setProgress(0);
    setIsPaused(false);
  }, [initialIndex]);

  useEffect(() => {
    if (!isPaused && currentContent) {
      progressInterval.current = setInterval(() => {
        setProgress((prev) => {
          const newProgress = prev + (100 / (duration * 10));
          if (newProgress >= 100) {
            handleNextContent();
            return 0;
          }
          return newProgress;
        });
      }, 100);
    } else {
      if (progressInterval.current) {
        clearInterval(progressInterval.current);
      }
    }

    return () => {
      if (progressInterval.current) {
        clearInterval(progressInterval.current);
      }
    };
  }, [isPaused, currentContent, duration]);

  const handleNextContent = () => {
    if (currentContentIndex < currentStory.content.length - 1) {
      setCurrentContentIndex(currentContentIndex + 1);
      setProgress(0);
    } else {
      // Move to next story
      if (currentStoryIndex < stories.length - 1) {
        setCurrentStoryIndex(currentStoryIndex + 1);
        setCurrentContentIndex(0);
        setProgress(0);
      } else {
        onComplete();
      }
    }
  };

  const handlePreviousContent = () => {
    if (currentContentIndex > 0) {
      setCurrentContentIndex(currentContentIndex - 1);
      setProgress(0);
    } else if (currentStoryIndex > 0) {
      const previousStory = stories[currentStoryIndex - 1];
      setCurrentStoryIndex(currentStoryIndex - 1);
      setCurrentContentIndex(previousStory.content.length - 1);
      setProgress(0);
    }
  };

  const handleTapLeft = () => {
    handlePreviousContent();
  };

  const handleTapRight = () => {
    handleNextContent();
  };

  const handleTapCenter = () => {
    setIsPaused(!isPaused);
  };

  const handleLike = () => {
    setIsLiked(!isLiked);
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: `${currentStory.userName}'s Story`,
        text: currentContent.caption || '',
        url: window.location.href,
      });
    } else {
      // Fallback for browsers that don't support Web Share API
      navigator.clipboard.writeText(window.location.href);
    }
  };

  const handleUserClick = () => {
    onSelectUser?.(currentStory.userId);
    onClose();
  };

  // Handle swipe down to close (touch events)
  const handleTouchStart = useRef<{ y: number } | null>(null);
  const handleTouchMove = (e: React.TouchEvent) => {
    if (!handleTouchStart.current) return;
    
    const currentY = e.touches[0].clientY;
    const deltaY = currentY - handleTouchStart.current.y;
    
    if (deltaY > 100) { // Swipe down threshold
      onClose();
    }
  };

  return (
    <div 
      className="fixed inset-0 bg-black z-50 flex items-center justify-center"
      onTouchStart={(e) => { handleTouchStart.current = { y: e.touches[0].clientY }; }}
      onTouchMove={handleTouchMove}
    >
      {/* Progress bars */}
      <div className="absolute top-4 left-4 right-4 z-20">
        <div className="flex gap-1">
          {currentStory.content.map((_, index) => (
            <div key={index} className="flex-1 h-0.5 bg-white/30 rounded-full overflow-hidden">
              <div 
                className="h-full bg-white transition-all duration-100 ease-linear rounded-full"
                style={{
                  width: index < currentContentIndex 
                    ? '100%' 
                    : index === currentContentIndex 
                      ? `${progress}%` 
                      : '0%'
                }}
              />
            </div>
          ))}
        </div>
      </div>

      {/* Header */}
      <div className="absolute top-8 left-4 right-4 z-20 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <button
            onClick={handleUserClick}
            className="flex items-center gap-3 active:scale-95 transition-transform"
          >
            <div className="w-8 h-8 rounded-full overflow-hidden border border-white/20">
              <ImageWithFallback
                src={currentStory.userAvatar}
                alt={currentStory.userName}
                className="w-full h-full object-cover"
              />
            </div>
            <div>
              <p className="text-white font-medium text-sm">{currentStory.userName}</p>
              <p className="text-white/70 text-xs">{currentStory.timestamp}</p>
            </div>
          </button>
          {currentStory.isLive && (
            <div className="bg-red-500 px-2 py-0.5 rounded text-white text-xs font-medium">
              LIVE
            </div>
          )}
        </div>

        <div className="flex items-center gap-2">
          <button 
            onClick={() => setIsPaused(!isPaused)}
            className="p-2 hover:bg-white/10 rounded-full transition-colors"
          >
            <MoreHorizontal size={20} className="text-white" />
          </button>
          <button 
            onClick={onClose}
            className="p-2 hover:bg-white/10 rounded-full transition-colors"
          >
            <X size={20} className="text-white" />
          </button>
        </div>
      </div>

      {/* Story Content */}
      <div className="relative w-full h-full flex items-center justify-center">
        {/* Navigation Areas */}
        <button 
          onClick={handleTapLeft}
          className="absolute left-0 top-0 w-1/3 h-full z-10 flex items-center justify-start pl-4"
        >
          <ChevronLeft size={32} className="text-white/50 opacity-0 group-hover:opacity-100 transition-opacity" />
        </button>
        
        <button 
          onClick={handleTapCenter}
          className="absolute left-1/3 top-0 w-1/3 h-full z-10"
        />
        
        <button 
          onClick={handleTapRight}
          className="absolute right-0 top-0 w-1/3 h-full z-10 flex items-center justify-end pr-4"
        >
          <ChevronRight size={32} className="text-white/50 opacity-0 group-hover:opacity-100 transition-opacity" />
        </button>

        {/* Content */}
        {currentContent?.type === 'image' ? (
          <ImageWithFallback
            src={currentContent.url}
            alt="Story content"
            className="max-w-full max-h-full object-contain"
          />
        ) : currentContent?.type === 'video' ? (
          <video
            src={currentContent.url}
            className="max-w-full max-h-full object-contain"
            autoPlay
            muted
            onEnded={handleNextContent}
          />
        ) : null}

        {/* Caption */}
        {currentContent?.caption && (
          <div className="absolute bottom-20 left-4 right-4">
            <p className="text-white text-sm bg-black/30 backdrop-blur-sm rounded-lg px-3 py-2">
              {currentContent.caption}
            </p>
          </div>
        )}
      </div>

      {/* Action Buttons */}
      <div className="absolute bottom-4 left-4 right-4 z-20 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <button 
            onClick={handleLike}
            className={`p-3 rounded-full transition-all duration-200 ${
              isLiked 
                ? 'bg-red-500 text-white' 
                : 'bg-white/10 text-white hover:bg-white/20'
            }`}
          >
            <Heart size={20} fill={isLiked ? 'currentColor' : 'none'} />
          </button>
          <button 
            onClick={handleShare}
            className="p-3 bg-white/10 text-white rounded-full hover:bg-white/20 transition-colors"
          >
            <Share size={20} />
          </button>
        </div>

        {/* Story location */}
        {currentContent?.location && (
          <div className="bg-white/10 backdrop-blur-sm rounded-lg px-3 py-1">
            <p className="text-white text-xs">{currentContent.location}</p>
          </div>
        )}
      </div>

      {/* Swipe down indicator */}
      <div className="absolute top-2 left-1/2 transform -translate-x-1/2">
        <div className="w-12 h-1 bg-white/30 rounded-full"></div>
      </div>
    </div>
  );
}