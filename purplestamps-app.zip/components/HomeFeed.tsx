import { useState, useEffect } from 'react';
import { MessageCircle, Search, Bell, Heart, MoreVertical, MessageSquare, Trophy, Sparkles, Target, Plus, Zap, Globe } from 'lucide-react';
import { TravelCard as TravelCardType, Story, Moment } from '../types';
import { Stories } from './Stories';
import { TravelCard } from './TravelCard';
import { MomentCard } from './MomentCard';
import { SuggestedCreatorsCarousel } from './SuggestedCreatorsCarousel';
import { SuggestedTravelCardsCarousel } from './SuggestedTravelCardsCarousel';
import { CulturalInsightsCarousel } from './CulturalInsightsCarousel';
import { TriviaQuestStrip } from './TriviaQuestStrip';
import { TriviaReminderBanner } from './TriviaReminderBanner';
import { GamificationBadges } from './GamificationBadges';
import { BrandLogo } from './BrandLogo';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { mockUsers } from '../data/mockData';

interface HomeFeedProps {
  travelCards: TravelCardType[];
  stories: Story[];
  moments: Moment[];
  onSelectTravelCard: (id: string) => void;
  onSelectUser: (userId: string) => void;
  onNavigateToMessenger: () => void;
  onNavigateToAccountDetails: () => void;
  onNavigateToTrivia: () => void;
  onNavigateToCulturalQuest: () => void;
  onNavigateToNotifications: () => void;
  unreadNotifications: number;
}

type FeedItem = {
  id: string;
  type: 'travelCard' | 'moment' | 'creators-carousel' | 'travel-cards-carousel' | 'cultural-carousel' | 'trivia-strip' | 'trivia-banner';
  data?: any;
  priority?: number;
};

export function HomeFeed({
  travelCards,
  stories,
  moments,
  onSelectTravelCard,
  onSelectUser,
  onNavigateToMessenger,
  onNavigateToAccountDetails,
  onNavigateToTrivia,
  onNavigateToCulturalQuest,
  onNavigateToNotifications,
  unreadNotifications
}: HomeFeedProps) {
  const [likedCards, setLikedCards] = useState<Set<string>>(new Set());
  const [savedCards, setSavedCards] = useState<Set<string>>(new Set());
  const [likedMoments, setLikedMoments] = useState<Set<string>>(new Set());
  const [savedMoments, setSavedMoments] = useState<Set<string>>(new Set());
  const [showTriviaStrip, setShowTriviaStrip] = useState(true);
  const [showGamificationModal, setShowGamificationModal] = useState(false);
  const [showFloatingNudge, setShowFloatingNudge] = useState(false);
  const [scrollPosition, setScrollPosition] = useState(0);

  // Get suggested creators and travel cards
  const suggestedCreators = mockUsers.filter(user => 
    user.isCreator && user.followers && user.followers > 1000
  ).slice(0, 8);

  const suggestedTravelCards = travelCards.filter(card => 
    card.rating && card.rating > 4.5
  ).slice(0, 6);

  // Enhanced mixed feed creation with better strip placement logic
  const createMixedFeed = (): FeedItem[] => {
    const contentItems: FeedItem[] = [];
    
    // Add travel cards and moments
    travelCards.forEach((card) => {
      contentItems.push({
        id: `travel-card-${card.id}`,
        type: 'travelCard',
        data: card
      });
    });

    moments.forEach((moment) => {
      contentItems.push({
        id: `moment-${moment.id}`,
        type: 'moment',
        data: moment
      });
    });

    // Shuffle content for variety
    const shuffledContent = [...contentItems].sort(() => Math.random() - 0.5);
    
    // Define our horizontal strip modules
    const stripModules = [
      {
        id: 'creators-carousel',
        type: 'creators-carousel' as const
      },
      {
        id: 'travel-cards-carousel',
        type: 'travel-cards-carousel' as const
      }
    ];

    // Other module items that appear less frequently
    const otherModules = [
      {
        id: 'cultural-carousel',
        type: 'cultural-carousel' as const
      },
      {
        id: 'trivia-banner',
        type: 'trivia-banner' as const
      }
    ];

    // Add trivia strip if enabled
    if (showTriviaStrip) {
      otherModules.push({
        id: 'trivia-strip',
        type: 'trivia-strip' as const
      });
    }

    // Create final mixed feed with strategic placement
    const finalFeed: FeedItem[] = [];
    let contentIndex = 0;
    
    // Start with some content first
    const initialContentCount = Math.min(2, shuffledContent.length);
    for (let i = 0; i < initialContentCount; i++) {
      if (shuffledContent[contentIndex]) {
        finalFeed.push(shuffledContent[contentIndex]);
        contentIndex++;
      }
    }

    // Strategically place strip modules every 5-7 posts
    let stripIndex = 0;
    const shuffledStrips = [...stripModules].sort(() => Math.random() - 0.5);
    
    while (contentIndex < shuffledContent.length || stripIndex < shuffledStrips.length) {
      // Add 5-7 content items before next strip
      const postsBeforeNextStrip = 5 + Math.floor(Math.random() * 3); // 5-7 posts
      
      for (let i = 0; i < postsBeforeNextStrip && contentIndex < shuffledContent.length; i++) {
        finalFeed.push(shuffledContent[contentIndex]);
        contentIndex++;
      }
      
      // Add a strip module if available
      if (stripIndex < shuffledStrips.length) {
        finalFeed.push(shuffledStrips[stripIndex]);
        stripIndex++;
      }
    }

    // Occasionally sprinkle in other modules
    const shuffledOtherModules = [...otherModules].sort(() => Math.random() - 0.5);
    let otherModuleIndex = 0;
    
    // Insert other modules at random positions (less frequently)
    const finalFeedWithOtherModules: FeedItem[] = [];
    for (let i = 0; i < finalFeed.length; i++) {
      finalFeedWithOtherModules.push(finalFeed[i]);
      
      // Occasionally insert other modules (roughly every 10-15 items)
      if (i > 0 && i % (10 + Math.floor(Math.random() * 6)) === 0 && otherModuleIndex < shuffledOtherModules.length) {
        finalFeedWithOtherModules.push(shuffledOtherModules[otherModuleIndex]);
        otherModuleIndex++;
      }
    }

    return finalFeedWithOtherModules;
  };

  const [mixedFeed, setMixedFeed] = useState<FeedItem[]>([]);

  useEffect(() => {
    setMixedFeed(createMixedFeed());
  }, [travelCards, moments, showTriviaStrip]);

  // Track scroll for floating nudges
  useEffect(() => {
    const handleScroll = () => {
      const position = window.pageYOffset;
      setScrollPosition(position);
      
      // Show floating nudge after scrolling past 500px
      if (position > 500 && !showFloatingNudge) {
        setShowFloatingNudge(true);
        // Auto hide after 10 seconds
        setTimeout(() => setShowFloatingNudge(false), 10000);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, [showFloatingNudge]);

  const handleLike = (cardId: string) => {
    setLikedCards(prev => {
      const newSet = new Set(prev);
      if (newSet.has(cardId)) {
        newSet.delete(cardId);
      } else {
        newSet.add(cardId);
      }
      return newSet;
    });
  };

  const handleSave = (cardId: string) => {
    setSavedCards(prev => {
      const newSet = new Set(prev);
      if (newSet.has(cardId)) {
        newSet.delete(cardId);
      } else {
        newSet.add(cardId);
      }
      return newSet;
    });
  };

  const handleFollowTrip = (tripId: string) => {
    console.log('Following trip:', tripId);
  };

  const handleFollowCreator = (creatorId: string) => {
    console.log('Following creator:', creatorId);
  };

  const renderFeedItem = (item: FeedItem, index: number) => {
    switch (item.type) {
      case 'travelCard':
        return (
          <div key={item.id} className="px-4 mb-6 animate-fadeIn">
            <TravelCard
              {...item.data}
              onSelect={onSelectTravelCard}
              onSelectUser={onSelectUser}
              onFollowTrip={handleFollowTrip}
              isLiked={likedCards.has(item.data.id)}
              isSaved={savedCards.has(item.data.id)}
              onLike={() => handleLike(item.data.id)}
              onSave={() => handleSave(item.data.id)}
              showCommentsModal={true}
            />
          </div>
        );

      case 'moment':
        return (
          <div key={item.id} className="px-4 mb-6 animate-fadeIn">
            <MomentCard
              moment={item.data}
              onSelectTravelCard={() => item.data.travelCardId && onSelectTravelCard(item.data.travelCardId)}
              onSelectUser={onSelectUser}
              showCommentsModal={true}
              onLike={() => handleLike(item.data.id)}
              onSave={() => handleSave(item.data.id)}
            />
          </div>
        );

      case 'creators-carousel':
        return (
          <div key={item.id} className="mb-8 animate-fadeIn" style={{ animationDelay: `${index * 50}ms` }}>
            <SuggestedCreatorsCarousel 
              creators={suggestedCreators}
              onSelectCreator={onSelectUser}
              onFollowCreator={handleFollowCreator}
            />
          </div>
        );

      case 'travel-cards-carousel':
        return (
          <div key={item.id} className="mb-8 animate-fadeIn" style={{ animationDelay: `${index * 50}ms` }}>
            <SuggestedTravelCardsCarousel 
              cards={suggestedTravelCards}
              onSelectTravelCard={onSelectTravelCard}
              onSelectUser={onSelectUser}
            />
          </div>
        );

      case 'cultural-carousel':
        return (
          <div key={item.id} className="mb-6 animate-fadeIn">
            <CulturalInsightsCarousel />
          </div>
        );

      case 'trivia-banner':
        return (
          <div key={item.id} className="mb-6 animate-fadeIn">
            <TriviaReminderBanner 
              onNavigateToTrivia={onNavigateToTrivia}
            />
          </div>
        );

      case 'trivia-strip':
        return (
          <div key={item.id} className="mb-6 animate-fadeIn">
            <TriviaQuestStrip 
              onNavigateToTrivia={() => {
                setShowTriviaStrip(false);
                onNavigateToTrivia();
              }}
            />
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-surface-warm to-surface-cool">
      {/* Edge-to-Edge Header - Streamlined without User Account Icon */}
      <header className="sticky top-0 z-40 bg-white/90 backdrop-blur-xl border-b border-gray-100 safe-area-inset-top">
        <div className="max-w-[428px] mx-auto flex items-center justify-between px-4 py-3">
          {/* Logo */}
          <div className="flex items-center space-x-3">
            <BrandLogo />
          </div>
          
          {/* Header Actions - Removed User Account Icon */}
          <div className="flex items-center space-x-3">
            {/* Chat Icon */}
            <button 
              onClick={onNavigateToMessenger}
              className="p-2 hover:bg-gray-100 rounded-xl transition-colors relative group"
            >
              <MessageCircle size={22} className="text-gray-700 group-hover:text-brand-primary transition-colors" />
              {/* Message indicator */}
              <div className="absolute top-1 right-1 w-2 h-2 bg-brand-secondary rounded-full"></div>
            </button>
            
            {/* Notifications Icon */}
            <button 
              onClick={onNavigateToNotifications}
              className="p-2 hover:bg-gray-100 rounded-xl transition-colors relative group"
            >
              <Bell size={22} className="text-gray-700 group-hover:text-brand-primary transition-colors" />
              {/* Notification badge with count */}
              {unreadNotifications > 0 && (
                <div className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 rounded-full flex items-center justify-center border border-white">
                  <span className="text-xs text-white font-bold">
                    {unreadNotifications > 9 ? '9+' : unreadNotifications}
                  </span>
                </div>
              )}
            </button>
            
            {/* Cultural Quest Icon */}
            <button 
              onClick={onNavigateToCulturalQuest}
              className="p-2 hover:bg-gray-100 rounded-xl transition-colors relative group"
            >
              <Globe size={22} className="text-gray-700 group-hover:text-brand-primary transition-colors" />
              {/* Quest indicator */}
              <div className="absolute top-0 right-0 w-3 h-3 bg-gradient-brand rounded-full flex items-center justify-center">
                <Sparkles size={8} className="text-white" />
              </div>
            </button>
          </div>
        </div>
      </header>

      {/* Main Feed Content - Standardized Container */}
      <main className="page-container-no-padding">
        {/* Stories Section - Keep padding for readability */}
        {/* Stories Section with Background */}
        <div className="relative">
          {/* Background Layer */}
          <div className="absolute inset-0 bg-gradient-to-r from-moodboard-cream/50 via-moodboard-warm-beige/20 to-moodboard-muted-teal/10 rounded-lg mx-2"></div>
          
          {/* Stories Content */}
          <div className="relative px-4 pt-2 pb-2">
            <Stories 
              stories={stories} 
              onSelectUser={onSelectUser} 
              currentUserId="user1"
            />
          </div>
        </div>

        {/* Mixed Feed Content - Strategically Placed Strips */}
        <div className="w-full">
          {mixedFeed.map((item, index) => renderFeedItem(item, index))}
        </div>

        {/* Load More Section */}
        <div className="px-4 py-8 text-center">
          <button className="bg-gradient-brand text-white px-8 py-4 rounded-2xl font-semibold hover:shadow-brand hover:scale-105 transition-all duration-200 active:scale-95 text-lg">
            Discover More Adventures! 🌟
          </button>
          <p className="text-sm text-gray-500 mt-4">
            You're all caught up, explorer! Check back later for fresh wanderlust content 🚀
          </p>
        </div>

        {/* Infinite Scroll Placeholder */}
        <div className="px-4 pb-8">
          <div className="grid grid-cols-2 gap-4">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="bg-gray-100 rounded-2xl aspect-square animate-pulse"></div>
            ))}
          </div>
          <div className="text-center mt-6">
            <div className="w-32 h-4 bg-gray-100 rounded-full mx-auto animate-pulse"></div>
          </div>
        </div>
      </main>

      {/* Floating Journey Nudge */}
      {showFloatingNudge && (
        <div className="fixed bottom-24 right-4 z-40 animate-slideUp">
          <div className="bg-gradient-brand text-white px-4 py-3 rounded-2xl shadow-xl max-w-xs">
            <div className="flex items-center space-x-2 mb-2">
              <Target size={16} />
              <span className="font-semibold text-sm">🌍 Just spotted a gem in Morocco?</span>
            </div>
            <p className="text-xs opacity-90 mb-3">
              Add to your draft card now and start planning your next adventure!
            </p>
            <div className="flex items-center space-x-2">
              <button 
                onClick={() => setShowFloatingNudge(false)}
                className="flex-1 bg-white/20 text-white py-1.5 px-3 rounded-lg text-xs font-medium hover:bg-white/30 transition-colors"
              >
                Later ✨
              </button>
              <button 
                onClick={() => {
                  setShowFloatingNudge(false);
                  // Navigate to create page or bucket list
                }}
                className="flex-1 bg-white text-brand-primary py-1.5 px-3 rounded-lg text-xs font-semibold hover:bg-gray-100 transition-colors flex items-center justify-center space-x-1"
              >
                <Plus size={12} />
                <span>Add Now!</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Gamification Modal */}
      <GamificationBadges 
        isOpen={showGamificationModal}
        onClose={() => setShowGamificationModal(false)}
      />
    </div>
  );
}