import { useState, useRef } from 'react';
import { ArrowLeft, Upload, Plus, ChevronDown, ChevronUp, Camera, Eye, EyeOff, Save, Send } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { CategoryTag } from './CategoryTag';

interface CreateTravelCardPageProps {
  onBack: () => void;
  onSaveDraft: (draftData: any) => void;
  onPublish: (cardData: any) => void;
  currentUserId: string;
}

interface Experience {
  id: string;
  title: string;
  category: 'stay' | 'food' | 'transport' | 'activity' | 'travel-item';
  location?: string;
  cost?: number;
  description?: string;
  affiliateLink?: string;
  rating?: number;
  moments: Moment[];
  isCollapsed: boolean;
}

interface Moment {
  id: string;
  type: 'image' | 'video';
  url: string;
  caption?: string;
  isPrivate: boolean;
}

interface Collaborator {
  id: string;
  profilePic: string;
  name: string;
}

export function CreateTravelCardPage({ onBack, onSaveDraft, onPublish, currentUserId }: CreateTravelCardPageProps) {
  // Step management
  const [currentStep, setCurrentStep] = useState(1);
  const [isLoading, setIsLoading] = useState(false);

  // Step 1: Travel Card Setup
  const [coverImage, setCoverImage] = useState<string>('');
  const [tripTitle, setTripTitle] = useState('');
  const [destination, setDestination] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [totalCost, setTotalCost] = useState<number | ''>('');
  const [collaborators, setCollaborators] = useState<Collaborator[]>([]);

  // Step 2 & 3: Experiences and Moments
  const [experiences, setExperiences] = useState<Experience[]>([]);

  // File input refs
  const coverImageInputRef = useRef<HTMLInputElement>(null);
  const momentImageInputRef = useRef<HTMLInputElement>(null);

  // Mock collaborators for demo
  const mockCollaborators = [
    { id: 'collab1', profilePic: 'https://images.unsplash.com/photo-1494790108755-2616b612c1c?w=100&h=100&fit=crop&crop=face', name: 'Sarah Chen' },
    { id: 'collab2', profilePic: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop&crop=face', name: 'Mike Johnson' },
    { id: 'collab3', profilePic: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop&crop=face', name: 'Emma Wilson' },
  ];

  const handleCoverImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        setCoverImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleMomentImageUpload = (experienceId: string, event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (files) {
      Array.from(files).forEach(file => {
        const reader = new FileReader();
        reader.onload = () => {
          const newMoment: Moment = {
            id: `moment-${Date.now()}-${Math.random()}`,
            type: file.type.startsWith('video/') ? 'video' : 'image',
            url: reader.result as string,
            caption: '',
            isPrivate: false
          };
          
          setExperiences(prev => prev.map(exp => 
            exp.id === experienceId 
              ? { ...exp, moments: [...exp.moments, newMoment] }
              : exp
          ));
        };
        reader.readAsDataURL(file);
      });
    }
  };

  const addExperience = () => {
    const newExperience: Experience = {
      id: `exp-${Date.now()}`,
      title: '',
      category: 'activity',
      location: '',
      cost: undefined,
      description: '',
      affiliateLink: '',
      rating: undefined,
      moments: [],
      isCollapsed: false
    };
    setExperiences(prev => [...prev, newExperience]);
  };

  const updateExperience = (id: string, updates: Partial<Experience>) => {
    setExperiences(prev => prev.map(exp => 
      exp.id === id ? { ...exp, ...updates } : exp
    ));
  };

  const toggleExperienceCollapse = (id: string) => {
    setExperiences(prev => prev.map(exp => 
      exp.id === id ? { ...exp, isCollapsed: !exp.isCollapsed } : exp
    ));
  };

  const updateMoment = (experienceId: string, momentId: string, updates: Partial<Moment>) => {
    setExperiences(prev => prev.map(exp => 
      exp.id === experienceId 
        ? { 
            ...exp, 
            moments: exp.moments.map(moment => 
              moment.id === momentId ? { ...moment, ...updates } : moment
            )
          }
        : exp
    ));
  };

  const deleteMoment = (experienceId: string, momentId: string) => {
    setExperiences(prev => prev.map(exp => 
      exp.id === experienceId 
        ? { ...exp, moments: exp.moments.filter(moment => moment.id !== momentId) }
        : exp
    ));
  };

  const toggleCollaborator = (collaborator: Collaborator) => {
    setCollaborators(prev => {
      const exists = prev.find(c => c.id === collaborator.id);
      if (exists) {
        return prev.filter(c => c.id !== collaborator.id);
      } else {
        return [...prev, collaborator];
      }
    });
  };

  const calculateDuration = () => {
    if (startDate && endDate) {
      const start = new Date(startDate);
      const end = new Date(endDate);
      const diffTime = Math.abs(end.getTime() - start.getTime());
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      return `${diffDays} days`;
    }
    return '';
  };

  const getCompletionPercentage = () => {
    let totalFields = 5; // title, destination, start date, end date, cover image
    let completedFields = 0;
    
    if (tripTitle.trim()) completedFields++;
    if (destination.trim()) completedFields++;
    if (startDate) completedFields++;
    if (endDate) completedFields++;
    if (coverImage) completedFields++;
    
    return Math.round((completedFields / totalFields) * 100);
  };

  const canProceedToStep2 = () => {
    return tripTitle.trim() && destination.trim() && startDate && endDate && coverImage;
  };

  const handleSaveDraft = async () => {
    setIsLoading(true);
    
    const draftData = {
      id: `draft-${Date.now()}`,
      title: tripTitle,
      destination,
      duration: calculateDuration(),
      coverImage,
      estimatedCost: totalCost || 0,
      completionPercentage: getCompletionPercentage(),
      lastUpdated: new Date().toISOString(),
      experienceCount: experiences.length,
      experiences,
      collaborators,
      isDraft: true
    };

    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    onSaveDraft(draftData);
    setIsLoading(false);
  };

  const handlePublish = async () => {
    setIsLoading(true);
    
    const cardData = {
      id: `tc-${Date.now()}`,
      title: tripTitle,
      destination,
      thumbnail: coverImage,
      images: [coverImage],
      description: `A ${calculateDuration()} journey through ${destination}`,
      rating: 4.8,
      likes: 0,
      comments: 0,
      views: 0,
      cost: totalCost || 0,
      dates: calculateDuration(),
      tripType: 'Adventure',
      creatorId: currentUserId,
      experiences: experiences.map(exp => ({
        id: exp.id,
        title: exp.title,
        category: exp.category,
        location: exp.location || destination,
        description: exp.description || '',
        rating: exp.rating || 4.5,
        cost: exp.cost || 0,
        images: exp.moments.filter(m => m.type === 'image').map(m => m.url),
        tags: [exp.category],
        affiliateLink: exp.affiliateLink
      })),
      isLive: false
    };

    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    onPublish(cardData);
    setIsLoading(false);
  };

  const renderStepIndicator = () => (
    <div className="flex items-center justify-center mb-6">
      <div className="flex items-center space-x-4">
        {[1, 2, 3].map((step) => (
          <div key={step} className="flex items-center">
            <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium transition-all duration-300 ${
              step <= currentStep 
                ? 'bg-moodboard-muted-teal text-white' 
                : 'bg-moodboard-gray-light/30 text-moodboard-gray-dark'
            }`}>
              {step}
            </div>
            {step < 3 && (
              <div className={`w-8 h-0.5 transition-all duration-300 ${
                step < currentStep ? 'bg-moodboard-muted-teal' : 'bg-moodboard-gray-light/30'
              }`} />
            )}
          </div>
        ))}
      </div>
    </div>
  );

  const renderStep1 = () => (
    <div className="space-y-6">
      <div className="text-center mb-8">
        <h2 className="text-xl font-semibold text-moodboard-deep-green mb-2">Travel Card Setup</h2>
        <p className="text-moodboard-gray-dark">Start by adding your trip details and cover photo</p>
      </div>

      {/* Cover Photo Upload */}
      <div className="space-y-3">
        <label className="block font-medium text-moodboard-deep-green">Trip Cover Photo</label>
        <div 
          onClick={() => coverImageInputRef.current?.click()}
          className="relative w-full h-48 bg-moodboard-gray-light/20 border-2 border-dashed border-moodboard-gray-light rounded-xl cursor-pointer hover:border-moodboard-muted-teal transition-colors group"
        >
          {coverImage ? (
            <ImageWithFallback 
              src={coverImage} 
              alt="Cover" 
              className="w-full h-full object-cover rounded-xl"
            />
          ) : (
            <div className="absolute inset-0 flex flex-col items-center justify-center text-moodboard-gray-dark group-hover:text-moodboard-muted-teal transition-colors">
              <Upload size={32} className="mb-2" />
              <span className="font-medium">Upload Cover Photo</span>
              <span className="text-sm">Tap to select from gallery</span>
            </div>
          )}
        </div>
        <input
          ref={coverImageInputRef}
          type="file"
          accept="image/*"
          onChange={handleCoverImageUpload}
          className="hidden"
        />
      </div>

      {/* Trip Title */}
      <div className="space-y-3">
        <label className="block font-medium text-moodboard-deep-green">Trip Title</label>
        <input
          type="text"
          value={tripTitle}
          onChange={(e) => setTripTitle(e.target.value)}
          placeholder="e.g., Ultimate Bali Adventure"
          className="w-full px-4 py-3 bg-white border border-moodboard-gray-light/30 rounded-xl focus:border-moodboard-muted-teal focus:outline-none transition-colors"
        />
      </div>

      {/* Destination */}
      <div className="space-y-3">
        <label className="block font-medium text-moodboard-deep-green">Destination</label>
        <input
          type="text"
          value={destination}
          onChange={(e) => setDestination(e.target.value)}
          placeholder="e.g., Bali, Indonesia"
          className="w-full px-4 py-3 bg-white border border-moodboard-gray-light/30 rounded-xl focus:border-moodboard-muted-teal focus:outline-none transition-colors"
        />
      </div>

      {/* Duration */}
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-3">
          <label className="block font-medium text-moodboard-deep-green">Start Date</label>
          <input
            type="date"
            value={startDate}
            onChange={(e) => setStartDate(e.target.value)}
            className="w-full px-4 py-3 bg-white border border-moodboard-gray-light/30 rounded-xl focus:border-moodboard-muted-teal focus:outline-none transition-colors"
          />
        </div>
        <div className="space-y-3">
          <label className="block font-medium text-moodboard-deep-green">End Date</label>
          <input
            type="date"
            value={endDate}
            onChange={(e) => setEndDate(e.target.value)}
            className="w-full px-4 py-3 bg-white border border-moodboard-gray-light/30 rounded-xl focus:border-moodboard-muted-teal focus:outline-none transition-colors"
          />
        </div>
      </div>

      {/* Total Cost */}
      <div className="space-y-3">
        <label className="block font-medium text-moodboard-deep-green">Total Trip Cost (Optional)</label>
        <input
          type="number"
          value={totalCost}
          onChange={(e) => setTotalCost(e.target.value ? parseInt(e.target.value) : '')}
          placeholder="e.g., 45000"
          className="w-full px-4 py-3 bg-white border border-moodboard-gray-light/30 rounded-xl focus:border-moodboard-muted-teal focus:outline-none transition-colors"
        />
      </div>

      {/* Collaborators */}
      <div className="space-y-3">
        <label className="block font-medium text-moodboard-deep-green">Collaborators (Optional)</label>
        <div className="flex flex-wrap gap-3">
          {mockCollaborators.map((collaborator) => (
            <div
              key={collaborator.id}
              onClick={() => toggleCollaborator(collaborator)}
              className={`relative cursor-pointer transition-all duration-200 ${
                collaborators.find(c => c.id === collaborator.id) 
                  ? 'scale-110 ring-2 ring-moodboard-muted-teal ring-offset-2' 
                  : 'hover:scale-105'
              }`}
            >
              <ImageWithFallback
                src={collaborator.profilePic}
                alt={collaborator.name}
                className="w-12 h-12 rounded-full object-cover"
              />
              {collaborators.find(c => c.id === collaborator.id) && (
                <div className="absolute -top-1 -right-1 w-6 h-6 bg-moodboard-muted-teal rounded-full flex items-center justify-center">
                  <div className="w-2 h-2 bg-white rounded-full" />
                </div>
              )}
            </div>
          ))}
        </div>
        {collaborators.length > 0 && (
          <p className="text-sm text-moodboard-gray-dark">
            {collaborators.length} collaborator{collaborators.length > 1 ? 's' : ''} selected
          </p>
        )}
      </div>

      {/* Next Button */}
      <div className="pt-6">
        <button
          onClick={() => setCurrentStep(2)}
          disabled={!canProceedToStep2()}
          className={`w-full py-4 rounded-xl font-medium transition-all duration-200 ${
            canProceedToStep2()
              ? 'bg-moodboard-muted-teal text-white hover:bg-moodboard-muted-teal/90 active:scale-98'
              : 'bg-moodboard-gray-light/30 text-moodboard-gray-dark cursor-not-allowed'
          }`}
        >
          Next – Add Experiences
        </button>
      </div>
    </div>
  );

  const renderStep2and3 = () => (
    <div className="space-y-6">
      <div className="text-center mb-8">
        <h2 className="text-xl font-semibold text-moodboard-deep-green mb-2">Add Experience Cards</h2>
        <p className="text-moodboard-gray-dark">Create experiences and add moments to each one</p>
      </div>

      {/* Experiences List */}
      <div className="space-y-4">
        {experiences.map((experience, index) => (
          <div key={experience.id} className="bg-white rounded-xl shadow-sm border border-moodboard-gray-light/20">
            {/* Experience Header */}
            <div 
              onClick={() => toggleExperienceCollapse(experience.id)}
              className="flex items-center justify-between p-4 cursor-pointer hover:bg-moodboard-gray-light/10 transition-colors"
            >
              <div className="flex-1">
                <input
                  type="text"
                  value={experience.title}
                  onChange={(e) => {
                    e.stopPropagation();
                    updateExperience(experience.id, { title: e.target.value });
                  }}
                  placeholder={`Experience ${index + 1} Title`}
                  className="w-full font-medium text-moodboard-deep-green bg-transparent border-none outline-none placeholder-moodboard-gray-dark"
                  onClick={(e) => e.stopPropagation()}
                />
                <div className="flex items-center space-x-2 mt-1">
                  <CategoryTag 
                    category={experience.category} 
                    size="sm"
                    onClick={(e) => e.stopPropagation()}
                  />
                  {experience.moments.length > 0 && (
                    <span className="text-xs text-moodboard-gray-dark">
                      {experience.moments.length} moment{experience.moments.length > 1 ? 's' : ''}
                    </span>
                  )}
                </div>
              </div>
              {experience.isCollapsed ? (
                <ChevronDown size={20} className="text-moodboard-gray-dark" />
              ) : (
                <ChevronUp size={20} className="text-moodboard-gray-dark" />
              )}
            </div>

            {/* Experience Details (Collapsible) */}
            {!experience.isCollapsed && (
              <div className="px-4 pb-4 space-y-4 border-t border-moodboard-gray-light/20">
                {/* Category Selection */}
                <div className="space-y-2">
                  <label className="block text-sm font-medium text-moodboard-deep-green">Category</label>
                  <div className="flex flex-wrap gap-2">
                    {(['stay', 'food', 'transport', 'activity', 'travel-item'] as const).map((category) => (
                      <button
                        key={category}
                        onClick={() => updateExperience(experience.id, { category })}
                        className={`px-3 py-1.5 rounded-lg text-sm font-medium capitalize transition-colors ${
                          experience.category === category
                            ? 'bg-moodboard-muted-teal text-white'
                            : 'bg-moodboard-gray-light/20 text-moodboard-gray-dark hover:bg-moodboard-gray-light/30'
                        }`}
                      >
                        {category.replace('-', ' ')}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Location and Cost */}
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-sm font-medium text-moodboard-deep-green mb-1">Location</label>
                    <input
                      type="text"
                      value={experience.location || ''}
                      onChange={(e) => updateExperience(experience.id, { location: e.target.value })}
                      placeholder="Optional"
                      className="w-full px-3 py-2 text-sm bg-moodboard-gray-light/10 border border-moodboard-gray-light/30 rounded-lg focus:border-moodboard-muted-teal focus:outline-none transition-colors"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-moodboard-deep-green mb-1">Cost</label>
                    <input
                      type="number"
                      value={experience.cost || ''}
                      onChange={(e) => updateExperience(experience.id, { cost: e.target.value ? parseInt(e.target.value) : undefined })}
                      placeholder="Optional"
                      className="w-full px-3 py-2 text-sm bg-moodboard-gray-light/10 border border-moodboard-gray-light/30 rounded-lg focus:border-moodboard-muted-teal focus:outline-none transition-colors"
                    />
                  </div>
                </div>

                {/* Description */}
                <div>
                  <label className="block text-sm font-medium text-moodboard-deep-green mb-1">Description</label>
                  <textarea
                    value={experience.description || ''}
                    onChange={(e) => updateExperience(experience.id, { description: e.target.value })}
                    placeholder="Tell us about this experience..."
                    rows={3}
                    className="w-full px-3 py-2 text-sm bg-moodboard-gray-light/10 border border-moodboard-gray-light/30 rounded-lg focus:border-moodboard-muted-teal focus:outline-none transition-colors resize-none"
                  />
                </div>

                {/* Affiliate Link */}
                <div>
                  <label className="block text-sm font-medium text-moodboard-deep-green mb-1">Affiliate Link (Optional)</label>
                  <input
                    type="url"
                    value={experience.affiliateLink || ''}
                    onChange={(e) => updateExperience(experience.id, { affiliateLink: e.target.value })}
                    placeholder="https://booking.example.com"
                    className="w-full px-3 py-2 text-sm bg-moodboard-gray-light/10 border border-moodboard-gray-light/30 rounded-lg focus:border-moodboard-muted-teal focus:outline-none transition-colors"
                  />
                </div>

                {/* Rating */}
                <div>
                  <label className="block text-sm font-medium text-moodboard-deep-green mb-1">Rating (Optional)</label>
                  <div className="flex space-x-1">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <button
                        key={star}
                        onClick={() => updateExperience(experience.id, { rating: star })}
                        className={`w-8 h-8 rounded ${
                          (experience.rating || 0) >= star
                            ? 'text-yellow-500'
                            : 'text-moodboard-gray-light'
                        } hover:text-yellow-400 transition-colors`}
                      >
                        ★
                      </button>
                    ))}
                  </div>
                </div>

                {/* Add Moments Section */}
                <div className="border-t border-moodboard-gray-light/20 pt-4">
                  <div className="flex items-center justify-between mb-3">
                    <h4 className="font-medium text-moodboard-deep-green">Moments</h4>
                    <button
                      onClick={() => momentImageInputRef.current?.click()}
                      className="flex items-center space-x-2 px-3 py-1.5 bg-moodboard-muted-teal text-white text-sm rounded-lg hover:bg-moodboard-muted-teal/90 transition-colors"
                    >
                      <Camera size={16} />
                      <span>Add Moments</span>
                    </button>
                  </div>

                  {/* Moments Gallery - Polaroid Style */}
                  {experience.moments.length > 0 && (
                    <div className="grid grid-cols-2 gap-3">
                      {experience.moments.map((moment) => (
                        <div key={moment.id} className="relative bg-white p-2 rounded-lg shadow-sm border border-moodboard-gray-light/20 transform rotate-1 hover:rotate-0 transition-transform">
                          <div className="aspect-square bg-moodboard-gray-light/20 rounded overflow-hidden mb-2">
                            <ImageWithFallback
                              src={moment.url}
                              alt="Moment"
                              className="w-full h-full object-cover"
                            />
                          </div>
                          
                          {/* Caption Input */}
                          <input
                            type="text"
                            value={moment.caption || ''}
                            onChange={(e) => updateMoment(experience.id, moment.id, { caption: e.target.value })}
                            placeholder="Add a caption..."
                            className="w-full text-xs bg-transparent border-none outline-none placeholder-moodboard-gray-dark handwriting-style"
                          />
                          
                          {/* Privacy Toggle */}
                          <div className="flex items-center justify-between mt-2">
                            <button
                              onClick={() => updateMoment(experience.id, moment.id, { isPrivate: !moment.isPrivate })}
                              className={`flex items-center space-x-1 text-xs ${
                                moment.isPrivate ? 'text-moodboard-gray-dark' : 'text-moodboard-muted-teal'
                              }`}
                            >
                              {moment.isPrivate ? <EyeOff size={12} /> : <Eye size={12} />}
                              <span>{moment.isPrivate ? 'Private' : 'Public'}</span>
                            </button>
                            
                            <button
                              onClick={() => deleteMoment(experience.id, moment.id)}
                              className="text-xs text-red-500 hover:text-red-700"
                            >
                              Delete
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}

                  <input
                    ref={momentImageInputRef}
                    type="file"
                    accept="image/*,video/*"
                    multiple
                    onChange={(e) => handleMomentImageUpload(experience.id, e)}
                    className="hidden"
                  />
                </div>
              </div>
            )}
          </div>
        ))}

        {/* Add Experience Button */}
        <button
          onClick={addExperience}
          className="w-full py-4 border-2 border-dashed border-moodboard-gray-light rounded-xl text-moodboard-gray-dark hover:border-moodboard-muted-teal hover:text-moodboard-muted-teal transition-colors flex items-center justify-center space-x-2"
        >
          <Plus size={20} />
          <span>Add Experience</span>
        </button>
      </div>

      {/* Action Buttons */}
      <div className="flex space-x-3 pt-6">
        <button
          onClick={() => setCurrentStep(1)}
          className="flex-1 py-4 border border-moodboard-gray-light text-moodboard-gray-dark rounded-xl hover:bg-moodboard-gray-light/10 transition-colors"
        >
          Back
        </button>
        <button
          onClick={handleSaveDraft}
          disabled={isLoading}
          className="flex-1 py-4 bg-moodboard-warm-beige text-moodboard-deep-green rounded-xl hover:bg-moodboard-warm-beige-dark transition-colors flex items-center justify-center space-x-2 disabled:opacity-50"
        >
          <Save size={20} />
          <span>{isLoading ? 'Saving...' : 'Save Draft'}</span>
        </button>
        <button
          onClick={handlePublish}
          disabled={isLoading || !tripTitle.trim() || experiences.length === 0}
          className="flex-1 py-4 bg-moodboard-muted-teal text-white rounded-xl hover:bg-moodboard-muted-teal/90 transition-colors flex items-center justify-center space-x-2 disabled:opacity-50"
        >
          <Send size={20} />
          <span>{isLoading ? 'Publishing...' : 'Publish'}</span>
        </button>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-surface-warm">
      {/* Header */}
      <div className="sticky top-0 z-50 bg-surface-warm/95 backdrop-blur-sm border-b border-moodboard-gray-light/20">
        <div className="flex items-center justify-between p-4">
          <button
            onClick={onBack}
            className="p-2 hover:bg-moodboard-gray-light/20 rounded-xl transition-colors"
          >
            <ArrowLeft size={24} className="text-moodboard-deep-green" />
          </button>
          
          <div className="text-center">
            <h1 className="font-semibold text-moodboard-deep-green">Create Travel Card</h1>
            <p className="text-sm text-moodboard-gray-dark">
              Step {currentStep} of 3
            </p>
          </div>
          
          <div className="w-10" /> {/* Spacer */}
        </div>
      </div>

      {/* Content */}
      <div className="page-container pb-8">
        {renderStepIndicator()}
        
        {currentStep === 1 ? renderStep1() : renderStep2and3()}
      </div>
    </div>
  );
}