import React from 'react';
import { 
  Heart, 
  Bookmark, 
  MessageCircle, 
  Share2, 
  Calendar,
  MapPin,
  Star,
  User,
  Search,
  Plus,
  ChevronRight,
  ExternalLink,
  Globe,
  CreditCard,
  Camera,
  Bell,
  Settings,
  ArrowLeft,
  Filter,
  Zap,
  Target,
  Trophy,
  Sparkles
} from 'lucide-react';

interface UnifiedIconProps {
  variant?: 'default' | 'brand' | 'secondary' | 'accent' | 'muted';
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl';
  filled?: boolean;
  className?: string;
}

const iconSizes = {
  xs: 14,
  sm: 16,
  md: 20,
  lg: 24,
  xl: 28
};

const iconColors = {
  default: 'text-gray-600',
  brand: 'text-brand-primary',
  secondary: 'text-brand-secondary',
  accent: 'text-brand-accent',
  muted: 'text-gray-400'
};

const BaseIcon: React.FC<{ 
  Icon: React.ComponentType<any>;
  variant?: UnifiedIconProps['variant'];
  size?: UnifiedIconProps['size'];
  filled?: boolean;
  className?: string;
}> = ({ Icon, variant = 'default', size = 'md', filled = false, className = '' }) => {
  return (
    <Icon
      size={iconSizes[size]}
      className={`${iconColors[variant]} ${filled ? 'fill-current' : ''} ${className}`}
      strokeWidth={1.5}
      style={{ 
        strokeLinecap: 'round',
        strokeLinejoin: 'round'
      }}
    />
  );
};

// Unified icon components
export const LikeIcon: React.FC<UnifiedIconProps> = (props) => (
  <BaseIcon Icon={Heart} {...props} />
);

export const SaveIcon: React.FC<UnifiedIconProps> = (props) => (
  <BaseIcon Icon={Bookmark} {...props} />
);

export const CommentIcon: React.FC<UnifiedIconProps> = (props) => (
  <BaseIcon Icon={MessageCircle} {...props} />
);

export const ShareIcon: React.FC<UnifiedIconProps> = (props) => (
  <BaseIcon Icon={Share2} {...props} />
);

export const BookNowIcon: React.FC<UnifiedIconProps> = (props) => (
  <BaseIcon Icon={ExternalLink} {...props} />
);

export const LocationIcon: React.FC<UnifiedIconProps> = (props) => (
  <BaseIcon Icon={MapPin} {...props} />
);

export const CalendarIcon: React.FC<UnifiedIconProps> = (props) => (
  <BaseIcon Icon={Calendar} {...props} />
);

export const StarIcon: React.FC<UnifiedIconProps> = (props) => (
  <BaseIcon Icon={Star} {...props} />
);

export const ProfileIcon: React.FC<UnifiedIconProps> = (props) => (
  <BaseIcon Icon={User} {...props} />
);

export const SearchIcon: React.FC<UnifiedIconProps> = (props) => (
  <BaseIcon Icon={Search} {...props} />
);

export const CreateIcon: React.FC<UnifiedIconProps> = (props) => (
  <BaseIcon Icon={Plus} {...props} />
);

export const ChevronIcon: React.FC<UnifiedIconProps> = (props) => (
  <BaseIcon Icon={ChevronRight} {...props} />
);

export const GlobeIcon: React.FC<UnifiedIconProps> = (props) => (
  <BaseIcon Icon={Globe} {...props} />
);

export const PaymentIcon: React.FC<UnifiedIconProps> = (props) => (
  <BaseIcon Icon={CreditCard} {...props} />
);

export const CameraIcon: React.FC<UnifiedIconProps> = (props) => (
  <BaseIcon Icon={Camera} {...props} />
);

export const NotificationIcon: React.FC<UnifiedIconProps> = (props) => (
  <BaseIcon Icon={Bell} {...props} />
);

export const SettingsIcon: React.FC<UnifiedIconProps> = (props) => (
  <BaseIcon Icon={Settings} {...props} />
);

export const BackIcon: React.FC<UnifiedIconProps> = (props) => (
  <BaseIcon Icon={ArrowLeft} {...props} />
);

export const FilterIcon: React.FC<UnifiedIconProps> = (props) => (
  <BaseIcon Icon={Filter} {...props} />
);

export const QuestIcon: React.FC<UnifiedIconProps> = (props) => (
  <BaseIcon Icon={Target} {...props} />
);

export const AchievementIcon: React.FC<UnifiedIconProps> = (props) => (
  <BaseIcon Icon={Trophy} {...props} />
);

export const MagicIcon: React.FC<UnifiedIconProps> = (props) => (
  <BaseIcon Icon={Sparkles} {...props} />
);

export const EnergyIcon: React.FC<UnifiedIconProps> = (props) => (
  <BaseIcon Icon={Zap} {...props} />
);

// Unified button component with consistent styling
interface UnifiedButtonProps {
  variant?: 'primary' | 'secondary' | 'outline' | 'ghost' | 'book-now';
  size?: 'sm' | 'md' | 'lg';
  icon?: React.ReactNode;
  iconPosition?: 'left' | 'right';
  children: React.ReactNode;
  onClick?: () => void;
  disabled?: boolean;
  className?: string;
}

export const UnifiedButton: React.FC<UnifiedButtonProps> = ({
  variant = 'primary',
  size = 'md',
  icon,
  iconPosition = 'left',
  children,
  onClick,
  disabled = false,
  className = ''
}) => {
  const baseClasses = 'inline-flex items-center justify-center font-medium transition-all duration-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-offset-2 active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed';
  
  const variants = {
    primary: 'bg-gradient-brand text-white hover:shadow-brand hover:scale-[1.02] focus:ring-brand-primary',
    secondary: 'bg-gradient-brand-secondary text-white hover:shadow-brand-secondary hover:scale-[1.02] focus:ring-brand-secondary',
    outline: 'border-2 border-brand-primary text-brand-primary hover:bg-brand-primary hover:text-white focus:ring-brand-primary',
    ghost: 'text-gray-600 hover:bg-gray-100 hover:text-gray-900 focus:ring-gray-500',
    'book-now': 'bg-gradient-to-r from-orange-500 to-red-500 text-white hover:from-orange-600 hover:to-red-600 hover:shadow-lg hover:scale-[1.02] focus:ring-orange-500'
  };
  
  const sizes = {
    sm: 'px-3 py-2 text-sm gap-1.5',
    md: 'px-4 py-2.5 text-sm gap-2',
    lg: 'px-6 py-3 text-base gap-2.5'
  };
  
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className={`${baseClasses} ${variants[variant]} ${sizes[size]} ${className}`}
    >
      {icon && iconPosition === 'left' && icon}
      {children}
      {icon && iconPosition === 'right' && icon}
    </button>
  );
};