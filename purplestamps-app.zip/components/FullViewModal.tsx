import { useState, useEffect } from 'react';
import { X, Heart, Bookmark, Share, MapPin, Calendar, Star, MoreHorizontal, Plane } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { CommentSection } from './CommentSection';
import { getCreator } from '../data/mockData';

interface FullViewModalProps {
  isOpen: boolean;
  onClose: () => void;
  content: {
    id: string;
    type: 'travel-card' | 'moment' | 'local-gem';
    title?: string;
    description?: string;
    images: string[];
    creatorId?: string;
    location?: string;
    timestamp?: string;
    likes: number;
    comments: number;
    isLiked: boolean;
    isSaved: boolean;
    rating?: number;
    category?: string;
    destinations?: string;
    dates?: string;
    tripType?: string;
  };
  onLike: () => void;
  onSave: () => void;
  onShare: () => void;
}

// Mock comments data
const mockComments = [
  {
    id: '1',
    userId: 'user1',
    userName: 'Sarah Chen',
    userAvatar: 'https://images.unsplash.com/photo-1494790108755-2616b612e2fa?w=50&h=50&fit=crop&crop=face',
    text: 'This looks absolutely incredible! Adding this to my bucket list right now 🌟',
    timestamp: '2h',
    likes: 12,
    isLiked: false
  },
  {
    id: '2',
    userId: 'user2',
    userName: 'Mike Rodriguez',
    userAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=50&h=50&fit=crop&crop=face',
    text: 'I went here last summer! The sunset views are even better in person. Great capture! 📸',
    timestamp: '4h',
    likes: 8,
    isLiked: true
  },
  {
    id: '3',
    userId: 'user3',
    userName: 'Emma Thompson',
    userAvatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=50&h=50&fit=crop&crop=face',
    text: 'What camera did you use for this shot? The quality is amazing!',
    timestamp: '6h',
    likes: 3,
    isLiked: false
  }
];

export function FullViewModal({
  isOpen,
  onClose,
  content,
  onLike,
  onSave,
  onShare
}: FullViewModalProps) {
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [comments, setComments] = useState(mockComments);

  const creator = content.creatorId ? getCreator(content.creatorId) : null;
  const totalComments = content.comments + comments.length;

  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isOpen]);

  const handleAddComment = (text: string) => {
    const newComment = {
      id: `comment-${Date.now()}`,
      userId: 'current-user',
      userName: 'You',
      userAvatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=50&h=50&fit=crop&crop=face',
      text,
      timestamp: 'now',
      likes: 0,
      isLiked: false
    };
    setComments(prev => [newComment, ...prev]);
  };

  const handleLikeComment = (commentId: string) => {
    setComments(prev => prev.map(comment => 
      comment.id === commentId 
        ? { 
            ...comment, 
            isLiked: !comment.isLiked,
            likes: comment.isLiked ? comment.likes - 1 : comment.likes + 1
          }
        : comment
    ));
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Escape') {
      onClose();
    }
  };

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 bg-black bg-opacity-90 z-50 flex flex-col overflow-hidden"
      onClick={(e) => e.target === e.currentTarget && onClose()}
      onKeyDown={handleKeyDown}
      tabIndex={-1}
    >
      {/* Header */}
      <div className="flex-shrink-0 bg-white/95 backdrop-blur-sm border-b border-gray-100">
        <div className="flex items-center justify-between px-4 py-3">
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-full transition-colors touch-target"
          >
            <X size={20} className="text-gray-700" />
          </button>
          
          <div className="flex-1 text-center">
            <h2 className="font-semibold text-gray-900 text-sm">
              {content.type === 'travel-card' ? 'Travel Story' : 
               content.type === 'moment' ? 'Moment' : 'Local Gem'}
            </h2>
          </div>
          
          <button
            onClick={onShare}
            className="p-2 hover:bg-gray-100 rounded-full transition-colors touch-target"
          >
            <Share size={20} className="text-gray-700" />
          </button>
        </div>
      </div>

      {/* Content Area */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Media Section */}
        <div className="flex-shrink-0 bg-white">
          {/* Creator Profile */}
          {creator && (
            <div className="px-4 py-3 border-b border-gray-100">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="relative">
                    <div className="w-10 h-10 rounded-full overflow-hidden">
                      <ImageWithFallback
                        src={creator.profilePic}
                        alt={creator.name}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    {creator.isCreator && (
                      <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-gradient-brand rounded-full flex items-center justify-center border-2 border-white">
                        <Plane size={8} className="text-white" />
                      </div>
                    )}
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900 text-sm">{creator.name}</h3>
                    <div className="flex items-center space-x-1 text-xs text-gray-600">
                      <MapPin size={10} />
                      <span>{content.location || creator.location}</span>
                      {content.timestamp && (
                        <>
                          <span>•</span>
                          <span>{content.timestamp}</span>
                        </>
                      )}
                    </div>
                  </div>
                </div>
                <button className="p-2 hover:bg-gray-100 rounded-full transition-colors">
                  <MoreHorizontal size={16} className="text-gray-600" />
                </button>
              </div>
            </div>
          )}

          {/* Image Display */}
          <div className="relative aspect-square bg-black">
            <ImageWithFallback
              src={content.images[currentImageIndex] || content.images[0]}
              alt={content.title || 'Content image'}
              className="w-full h-full object-contain"
            />
            
            {/* Image Navigation */}
            {content.images.length > 1 && (
              <>
                <div className="absolute bottom-3 left-1/2 transform -translate-x-1/2 flex space-x-2">
                  {content.images.map((_, index) => (
                    <button
                      key={index}
                      onClick={() => setCurrentImageIndex(index)}
                      className={`w-2 h-2 rounded-full transition-all ${
                        index === currentImageIndex ? 'bg-white' : 'bg-white/50'
                      }`}
                    />
                  ))}
                </div>
                {currentImageIndex > 0 && (
                  <button
                    onClick={() => setCurrentImageIndex(prev => prev - 1)}
                    className="absolute left-3 top-1/2 transform -translate-y-1/2 bg-black/50 text-white p-2 rounded-full hover:bg-black/70 transition-colors"
                  >
                    ←
                  </button>
                )}
                {currentImageIndex < content.images.length - 1 && (
                  <button
                    onClick={() => setCurrentImageIndex(prev => prev + 1)}
                    className="absolute right-3 top-1/2 transform -translate-y-1/2 bg-black/50 text-white p-2 rounded-full hover:bg-black/70 transition-colors"
                  >
                    →
                  </button>
                )}
              </>
            )}

            {/* Content Overlays */}
            {content.rating && (
              <div className="absolute top-3 right-3">
                <div className="flex items-center space-x-1 bg-black/50 backdrop-blur-sm text-white px-2 py-1 rounded-full">
                  <Star size={12} className="text-yellow-400 fill-current" />
                  <span className="text-xs font-semibold">{content.rating}</span>
                </div>
              </div>
            )}

            {content.category && (
              <div className="absolute top-3 left-3">
                <span className="bg-white/90 backdrop-blur-sm text-gray-800 px-3 py-1 rounded-full text-xs font-semibold border border-white/20">
                  {content.category}
                </span>
              </div>
            )}
          </div>

          {/* Action Buttons */}
          <div className="px-4 py-3 border-b border-gray-100">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <button
                  onClick={onLike}
                  className={`flex items-center space-x-2 ${content.isLiked ? 'text-red-500' : 'text-gray-700'} hover:text-red-500 transition-colors`}
                >
                  <Heart size={20} className={content.isLiked ? 'fill-current' : ''} />
                  <span className="text-sm font-medium">{content.likes}</span>
                </button>
              </div>

              <div className="flex items-center space-x-2">
                <button
                  onClick={onShare}
                  className="p-2 text-gray-700 hover:text-gray-900 transition-colors"
                >
                  <Share size={18} />
                </button>
                <button
                  onClick={onSave}
                  className={`p-2 transition-colors ${content.isSaved ? 'text-brand-accent' : 'text-gray-700 hover:text-gray-900'}`}
                >
                  <Bookmark size={18} className={content.isSaved ? 'fill-current' : ''} />
                </button>
              </div>
            </div>
          </div>

          {/* Content Details */}
          {(content.title || content.description) && (
            <div className="px-4 py-3 border-b border-gray-100">
              {content.title && (
                <h3 className="font-semibold text-gray-900 mb-2">{content.title}</h3>
              )}
              {content.description && (
                <p className="text-gray-700 text-sm leading-relaxed">{content.description}</p>
              )}
              
              {/* Travel Card specific details */}
              {content.type === 'travel-card' && (content.dates || content.destinations) && (
                <div className="flex items-center justify-between mt-3 text-sm text-gray-600">
                  {content.destinations && (
                    <div className="flex items-center space-x-1">
                      <MapPin size={14} />
                      <span>{content.destinations}</span>
                    </div>
                  )}
                  {content.dates && (
                    <div className="flex items-center space-x-1">
                      <Calendar size={14} />
                      <span>{content.dates}</span>
                    </div>
                  )}
                </div>
              )}
            </div>
          )}
        </div>

        {/* Comments Section */}
        <div className="flex-1 overflow-hidden">
          <CommentSection
            contentId={content.id}
            contentType={content.type}
            comments={comments}
            totalComments={totalComments}
            onAddComment={handleAddComment}
            onLikeComment={handleLikeComment}
          />
        </div>
      </div>
    </div>
  );
}