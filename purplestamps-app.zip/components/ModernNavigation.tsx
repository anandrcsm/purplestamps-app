import { useState, useEffect } from 'react';
import { Home, Search, PlusCircle, User, MapPin, Heart, Sparkles, Zap } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface NavItem {
  id: string;
  label: string;
  icon: any;
  pages: string[];
  isCenter?: boolean;
}

interface ModernNavigationProps {
  currentPage: string;
  onNavigate: (pageId: string, fromPage: string) => void;
  navItems: NavItem[];
  bucketListItems: any[];
  unreadNotifications: number;
  travelCardDrafts: any[];
}

export function ModernNavigation({
  currentPage,
  onNavigate,
  navItems,
  bucketListItems,
  unreadNotifications,
  travelCardDrafts
}: ModernNavigationProps) {
  const [activeItem, setActiveItem] = useState<string | null>(null);
  const [tapEffect, setTapEffect] = useState<string | null>(null);
  const [hoverItem, setHoverItem] = useState<string | null>(null);
  const [centerButtonBreath, setCenterButtonBreath] = useState(true);

  // Breathing animation for center button
  useEffect(() => {
    const interval = setInterval(() => {
      setCenterButtonBreath(prev => !prev);
    }, 2000);
    return () => clearInterval(interval);
  }, []);

  const handleNavClick = (item: NavItem) => {
    setActiveItem(item.id);
    setTapEffect(item.id);
    
    // Create ripple effect with haptic feedback simulation
    const rippleTime = item.isCenter ? 400 : 250;
    setTimeout(() => setTapEffect(null), rippleTime);
    
    // Add a slight delay for better visual feedback
    setTimeout(() => {
      onNavigate(item.id, currentPage);
    }, 100);
  };

  const handleMouseEnter = (itemId: string) => {
    setHoverItem(itemId);
  };

  const handleMouseLeave = () => {
    setHoverItem(null);
  };

  const totalBadgeCount = bucketListItems.length + unreadNotifications + travelCardDrafts.length;

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50">
      {/* Fixed Bottom Navigation Container */}
      <div className="relative">
        {/* Main Navigation Bar */}
        <div className="w-full bg-white/80 backdrop-blur-2xl border-t border-moodboard-gray-light/20 shadow-brand">
          {/* Navigation Items */}
          <div className="flex items-center justify-around px-4 py-2 py-[6px] px-[14px]">
            {navItems.map((item, index) => {
              const isActive = item.pages.includes(currentPage);
              const IconComponent = item.icon;
              const hasRipple = tapEffect === item.id;

              if (item.isCenter) {
                return (
                  <div key={item.id} className="relative">
                    {/* Center Button with Enhanced Design */}
                    <button
                      onClick={() => handleNavClick(item)}
                      onMouseEnter={() => handleMouseEnter(item.id)}
                      onMouseLeave={handleMouseLeave}
                      className={`relative flex items-center justify-center w-16 h-16 bg-gradient-to-br from-moodboard-muted-teal via-moodboard-muted-teal-light to-brand-accent rounded-full shadow-brand transform transition-all duration-500 hover:scale-110 active:scale-95 group ${
                        centerButtonBreath ? 'scale-105' : 'scale-100'
                      }`}
                      style={{ transition: 'all 0.5s cubic-bezier(0.68, -0.55, 0.265, 1.55)' }}
                      aria-label={item.label}
                    >
                      {/* Dynamic Breathing Ring */}
                      <div className={`absolute inset-0 rounded-full bg-gradient-to-br from-moodboard-muted-teal to-brand-accent transition-all duration-1000 ${
                        centerButtonBreath ? 'opacity-40 scale-110' : 'opacity-20 scale-100'
                      }`}></div>
                      
                      {/* Sparkle Effects with Random Animation */}
                      <div className="absolute -top-1 -right-1 w-3 h-3">
                        <Sparkles size={12} className="text-moodboard-warm-beige animate-pulse" />
                      </div>
                      <div className="absolute -bottom-1 -left-1 w-2 h-2">
                        <Zap size={8} className="text-moodboard-cream animate-bounce" style={{ animationDelay: '1s' }} />
                      </div>
                      
                      {/* Main Icon with Rotation on Hover */}
                      <IconComponent 
                        size={24} 
                        className={`text-white relative z-10 drop-shadow-sm transition-transform duration-300 ${
                          hoverItem === item.id ? 'rotate-12' : 'rotate-0'
                        }`} 
                        strokeWidth={2.5} 
                      />
                      
                      {/* Enhanced Tap Ripple Effect */}
                      {hasRipple && (
                        <>
                          <div className="absolute inset-0 rounded-full bg-white/40 animate-ping"></div>
                          <div className="absolute inset-0 rounded-full bg-moodboard-warm-beige/30 animate-ping" style={{ animationDelay: '0.1s' }}></div>
                        </>
                      )}
                      
                      {/* Multi-layer Hover Glow */}
                      <div className="absolute inset-0 rounded-full bg-gradient-to-br from-moodboard-warm-beige/30 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                      <div className="absolute inset-0 rounded-full bg-gradient-to-tr from-transparent to-white/20 opacity-0 group-hover:opacity-100 transition-opacity duration-700"></div>
                    </button>
                  </div>
                );
              }

              return (
                <div key={item.id} className="relative">
                  <button
                    onClick={() => handleNavClick(item)}
                    onMouseEnter={() => handleMouseEnter(item.id)}
                    onMouseLeave={handleMouseLeave}
                    className={`relative flex flex-col items-center justify-center w-12 h-12 rounded-2xl transition-all duration-500 transform ${
                      isActive 
                        ? 'bg-moodboard-muted-teal/15 scale-110 shadow-lg' 
                        : 'hover:bg-moodboard-gray-light/10 hover:scale-105'
                    } active:scale-95 group`}
                    style={{ transition: 'all 0.5s cubic-bezier(0.34, 1.56, 0.64, 1)' }}
                    aria-label={item.label}
                  >
                    {/* Icon Container */}
                    <div className="relative">
                      {item.id === 'profile' ? (
                        <div className="relative">
                          {/* Profile Picture */}
                          <div className={`w-8 h-8 rounded-full overflow-hidden border-2 transition-all duration-300 ${
                            isActive 
                              ? 'border-moodboard-muted-teal shadow-lg' 
                              : 'border-moodboard-gray-light group-hover:border-moodboard-muted-teal/50'
                          }`}>
                            <ImageWithFallback 
                              src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=50&h=50&fit=crop&crop=face" 
                              alt="Profile" 
                              className="w-full h-full object-cover"
                            />
                          </div>
                          
                          {/* Combined Notification Badge */}
                          {totalBadgeCount > 0 && (
                            <div className="absolute -top-1 -right-1 w-5 h-5 bg-gradient-to-br from-red-500 to-red-600 rounded-full flex items-center justify-center shadow-lg animate-pulse">
                              <span className="text-[10px] text-white font-bold">
                                {totalBadgeCount > 9 ? '9+' : totalBadgeCount}
                              </span>
                            </div>
                          )}
                        </div>
                      ) : (
                        <IconComponent 
                          size={22} 
                          strokeWidth={isActive ? 2.5 : 2} 
                          className={`transition-all duration-300 ${
                            isActive 
                              ? 'text-moodboard-muted-teal drop-shadow-sm' 
                              : 'text-moodboard-gray-dark group-hover:text-moodboard-muted-teal'
                          }`}
                        />
                      )}
                      
                      {/* Enhanced Tap Ripple Effect */}
                      {hasRipple && !item.isCenter && (
                        <>
                          <div className="absolute inset-0 rounded-2xl bg-moodboard-muted-teal/30 animate-ping"></div>
                          <div className="absolute inset-0 rounded-2xl bg-moodboard-warm-beige/20 animate-ping" style={{ animationDelay: '0.1s' }}></div>
                        </>
                      )}
                    </div>

                    {/* Enhanced Active Indicator */}
                    {isActive && (
                      <>
                        <div className="absolute -bottom-2 w-2 h-2 bg-moodboard-muted-teal rounded-full animate-scaleIn shadow-lg"></div>
                        <div className="absolute -bottom-2 w-1 h-1 bg-white rounded-full animate-pulse"></div>
                      </>
                    )}

                    {/* Dynamic Hover Effect Ring */}
                    <div className={`absolute inset-0 rounded-2xl border-2 transition-all duration-500 ${
                      isActive 
                        ? 'border-moodboard-muted-teal/40 shadow-lg' 
                        : hoverItem === item.id
                        ? 'border-moodboard-muted-teal/30 scale-105'
                        : 'border-transparent group-hover:border-moodboard-muted-teal/20'
                    }`}></div>

                    {/* Micro-interaction Glow */}
                    {hoverItem === item.id && (
                      <div className="absolute inset-0 rounded-2xl bg-moodboard-muted-teal/5 animate-pulse"></div>
                    )}
                  </button>
                </div>
              );
            })}
          </div>
        </div>

      </div>
    </nav>
  );
}