import { useState } from 'react';
import { X, Plus, Calendar, Users, DollarSign, MapPin } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { BucketListItem, TravelCardDraft } from '../types';

interface AddToExistingDraftModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedItems: BucketListItem[];
  travelCardDrafts: TravelCardDraft[];
  onAddToDraft: (draftId: string, items: BucketListItem[]) => void;
}

export function AddToExistingDraftModal({
  isOpen,
  onClose,
  selectedItems,
  travelCardDrafts,
  onAddToDraft
}: AddToExistingDraftModalProps) {
  const [selectedDraftId, setSelectedDraftId] = useState<string>('');

  if (!isOpen) return null;

  const handleConfirm = () => {
    if (selectedDraftId) {
      onAddToDraft(selectedDraftId, selectedItems);
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-black/50 backdrop-blur-sm animate-backdropFadeIn"
        onClick={onClose}
      />
      
      {/* Modal */}
      <div className="relative w-full max-w-md mx-4 bg-white rounded-t-2xl shadow-2xl animate-slideUpFromBottom max-h-[80vh] overflow-hidden">
        {/* Header */}
        <div className="sticky top-0 bg-white border-b border-moodboard-gray-light/20 p-6 pb-4">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-moodboard-deep-green">
              Add to Travel Card Draft
            </h3>
            <button
              onClick={onClose}
              className="p-2 hover:bg-moodboard-gray-light/20 rounded-xl transition-colors"
            >
              <X size={20} className="text-moodboard-gray-dark" />
            </button>
          </div>
          
          <p className="text-sm text-moodboard-gray-dark">
            Choose a draft to add {selectedItems.length} selected experience{selectedItems.length > 1 ? 's' : ''}
          </p>

          {/* Selected Items Preview */}
          <div className="mt-4 p-3 bg-moodboard-gray-light/10 rounded-xl">
            <div className="flex items-center space-x-2 text-xs text-moodboard-gray-dark">
              <Plus size={12} />
              <span>Adding {selectedItems.length} experience{selectedItems.length > 1 ? 's' : ''}</span>
            </div>
            <div className="flex -space-x-2 mt-2">
              {selectedItems.slice(0, 3).map((item, index) => (
                <div key={item.id} className="relative">
                  <ImageWithFallback
                    src={item.type === 'experience' 
                      ? (item.data as any).images?.[0] 
                      : (item.data as any).image
                    }
                    alt={item.data.title}
                    className="w-8 h-8 object-cover rounded-full border-2 border-white"
                  />
                </div>
              ))}
              {selectedItems.length > 3 && (
                <div className="w-8 h-8 bg-moodboard-muted-teal rounded-full border-2 border-white flex items-center justify-center text-xs text-white font-medium">
                  +{selectedItems.length - 3}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Draft List */}
        <div className="overflow-y-auto flex-1 p-6 pt-4">
          {travelCardDrafts.length === 0 ? (
            <div className="text-center py-8">
              <div className="w-16 h-16 bg-moodboard-gray-light/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <Plus size={24} className="text-moodboard-gray-light" />
              </div>
              <h4 className="font-medium text-moodboard-deep-green mb-2">No drafts yet</h4>
              <p className="text-sm text-moodboard-gray-dark">
                Create a new travel card to get started
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              {travelCardDrafts.map((draft) => (
                <button
                  key={draft.id}
                  onClick={() => setSelectedDraftId(draft.id)}
                  className={`w-full p-4 rounded-xl transition-all duration-200 text-left ${
                    selectedDraftId === draft.id
                      ? 'bg-moodboard-muted-teal/10 border-2 border-moodboard-muted-teal ring-2 ring-moodboard-muted-teal/20'
                      : 'bg-moodboard-gray-light/10 border-2 border-transparent hover:bg-moodboard-gray-light/20'
                  }`}
                >
                  <div className="flex items-start space-x-3">
                    {/* Cover Image */}
                    <div className="relative flex-shrink-0">
                      <ImageWithFallback
                        src={draft.coverImage}
                        alt={draft.title}
                        className="w-16 h-16 object-cover rounded-lg"
                      />
                      
                      {/* Draft Badge */}
                      <div className="absolute -top-1 -right-1 bg-moodboard-warm-beige text-moodboard-deep-green px-1.5 py-0.5 rounded-full text-xs font-medium">
                        Draft
                      </div>
                    </div>

                    {/* Content */}
                    <div className="flex-1 min-w-0">
                      <h4 className="font-medium text-moodboard-deep-green text-sm mb-1 line-clamp-1">
                        {draft.title}
                      </h4>
                      
                      <div className="flex items-center text-xs text-moodboard-gray-dark mb-2">
                        <MapPin size={10} className="mr-1" />
                        <span className="line-clamp-1">{draft.destination}</span>
                      </div>

                      {/* Stats */}
                      <div className="flex items-center justify-between text-xs text-moodboard-gray-dark">
                        <div className="flex items-center space-x-3">
                          <div className="flex items-center">
                            <Calendar size={10} className="mr-1" />
                            <span>{draft.duration}</span>
                          </div>
                          <div className="flex items-center">
                            <Users size={10} className="mr-1" />
                            <span>{draft.experienceCount}</span>
                          </div>
                        </div>
                        
                        {draft.estimatedCost > 0 && (
                          <div className="flex items-center">
                            <DollarSign size={10} className="mr-1" />
                            <span>${draft.estimatedCost.toLocaleString()}</span>
                          </div>
                        )}
                      </div>

                      {/* Progress */}
                      <div className="mt-2">
                        <div className="flex items-center justify-between text-xs text-moodboard-gray-dark mb-1">
                          <span>Progress</span>
                          <span>{draft.completionPercentage}%</span>
                        </div>
                        <div className="w-full bg-moodboard-gray-light/20 rounded-full h-1">
                          <div 
                            className="bg-moodboard-muted-teal h-1 rounded-full transition-all duration-300"
                            style={{ width: `${draft.completionPercentage}%` }}
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Actions */}
        <div className="sticky bottom-0 bg-white border-t border-moodboard-gray-light/20 p-6 pt-4">
          <div className="flex space-x-3">
            <button
              onClick={onClose}
              className="flex-1 py-3 border border-moodboard-gray-light text-moodboard-gray-dark rounded-xl hover:bg-moodboard-gray-light/10 transition-colors"
            >
              Cancel
            </button>
            <button
              onClick={handleConfirm}
              disabled={!selectedDraftId}
              className="flex-1 py-3 bg-moodboard-muted-teal text-white rounded-xl font-medium hover:bg-moodboard-muted-teal/90 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Add to Draft
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}