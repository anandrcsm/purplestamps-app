import { useState, useEffect } from 'react';
import { Trophy, Crown, Star, Globe, Camera, Heart, Users, Zap, Award, Target, Sparkles, TrendingUp } from 'lucide-react';

// Badge system for gamification
const availableBadges = [
  {
    id: 'culture-buddy',
    name: 'Culture Buddy',
    description: 'Completed 5 cultural quizzes',
    icon: Globe,
    color: 'from-blue-500 to-indigo-600',
    level: 1,
    unlocked: true,
    progress: 5,
    maxProgress: 5
  },
  {
    id: 'explorer',
    name: 'Explorer',
    description: 'Completed 15 cultural quizzes',
    icon: Zap,
    color: 'from-purple-500 to-pink-600',
    level: 2,
    unlocked: true,
    progress: 15,
    maxProgress: 15
  },
  {
    id: 'culture-master',
    name: 'Culture Master',
    description: 'Completed 50 cultural quizzes',
    icon: Crown,
    color: 'from-yellow-500 to-orange-600',
    level: 3,
    unlocked: false,
    progress: 23,
    maxProgress: 50
  },
  {
    id: 'travel-creator',
    name: 'Travel Creator',
    description: 'Published 3 Travel Cards',
    icon: Camera,
    color: 'from-green-500 to-emerald-600',
    level: 1,
    unlocked: true,
    progress: 3,
    maxProgress: 3
  },
  {
    id: 'social-butterfly',
    name: 'Social Butterfly',
    description: 'Made 10 collaborative trips',
    icon: Users,
    color: 'from-pink-500 to-rose-600',
    level: 1,
    unlocked: false,
    progress: 2,
    maxProgress: 10
  },
  {
    id: 'influencer',
    name: 'Travel Influencer',
    description: 'Got 1000+ likes on travel cards',
    icon: Heart,
    color: 'from-red-500 to-pink-600',
    level: 2,
    unlocked: false,
    progress: 450,
    maxProgress: 1000
  }
];

interface GamificationBadgesProps {
  isOpen: boolean;
  onClose: () => void;
}

export function GamificationBadges({ isOpen, onClose }: GamificationBadgesProps) {
  const [selectedBadge, setSelectedBadge] = useState<string | null>(null);
  const [showAnimation, setShowAnimation] = useState(false);

  const unlockedBadges = availableBadges.filter(badge => badge.unlocked);
  const lockedBadges = availableBadges.filter(badge => !badge.unlocked);

  useEffect(() => {
    if (isOpen) {
      setShowAnimation(true);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const BadgeCard = ({ badge, isLocked = false }: { badge: typeof availableBadges[0], isLocked?: boolean }) => {
    const IconComponent = badge.icon;
    const progressPercentage = (badge.progress / badge.maxProgress) * 100;
    
    return (
      <div 
        className={`relative p-4 rounded-2xl border transition-all duration-300 cursor-pointer hover:scale-[1.02] ${
          isLocked 
            ? 'bg-gray-50 border-gray-200 opacity-75' 
            : 'bg-white border border-gray-200 shadow-lg hover:shadow-xl'
        }`}
        onClick={() => setSelectedBadge(selectedBadge === badge.id ? null : badge.id)}
      >
        {/* Badge Icon */}
        <div className="flex items-center justify-center mb-3">
          <div className={`relative w-16 h-16 bg-gradient-to-br ${isLocked ? 'from-gray-300 to-gray-400' : badge.color} rounded-full flex items-center justify-center shadow-lg`}>
            <IconComponent size={24} className="text-white" />
            {badge.unlocked && (
              <div className="absolute -top-1 -right-1 w-6 h-6 bg-green-500 rounded-full flex items-center justify-center">
                <Star size={12} className="text-white fill-current" />
              </div>
            )}
          </div>
        </div>

        {/* Badge Info */}
        <div className="text-center">
          <h3 className={`font-bold mb-1 ${isLocked ? 'text-gray-500' : 'text-gray-900'}`}>
            {badge.name}
          </h3>
          <p className={`text-xs mb-3 ${isLocked ? 'text-gray-400' : 'text-gray-600'}`}>
            {badge.description}
          </p>

          {/* Progress Bar (for locked badges) */}
          {isLocked && (
            <div className="mb-2">
              <div className="flex items-center justify-between text-xs text-gray-500 mb-1">
                <span>Progress</span>
                <span>{badge.progress}/{badge.maxProgress}</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-1.5">
                <div 
                  className="bg-gradient-to-r from-brand-primary to-brand-secondary h-1.5 rounded-full transition-all duration-500"
                  style={{ width: `${progressPercentage}%` }}
                ></div>
              </div>
            </div>
          )}

          {/* Badge Level */}
          <div className={`inline-flex items-center space-x-1 px-2 py-1 rounded-full text-xs font-medium ${
            isLocked 
              ? 'bg-gray-200 text-gray-500' 
              : 'bg-gradient-to-r from-brand-primary/10 to-brand-secondary/10 text-brand-primary border border-brand-primary/20'
          }`}>
            <Award size={10} />
            <span>Level {badge.level}</span>
          </div>
        </div>

        {/* Unlock Animation */}
        {selectedBadge === badge.id && badge.unlocked && (
          <div className="absolute inset-0 bg-gradient-to-br from-yellow-400/20 to-orange-400/20 rounded-2xl animate-pulse"></div>
        )}
      </div>
    );
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-black/50 backdrop-blur-sm animate-backdropFadeIn"
        onClick={onClose}
      ></div>
      
      {/* Modal */}
      <div className="relative bg-white rounded-2xl max-w-md w-full max-h-[80vh] overflow-hidden animate-scaleIn shadow-2xl">
        {/* Header */}
        <div className="bg-gradient-brand text-white p-6 text-center relative overflow-hidden">
          <div className="absolute inset-0 bg-black/10"></div>
          <div className="relative">
            <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-3">
              <Trophy size={28} className="text-white" />
            </div>
            <h2 className="text-xl font-bold mb-2">Achievement Gallery 🏆</h2>
            <p className="text-sm opacity-90">
              Your wanderlust journey progress - powered by Globetrotter Buddy Mode™!
            </p>
          </div>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto max-h-96">
          {/* Stats Overview */}
          <div className="grid grid-cols-3 gap-4 mb-6">
            <div className="text-center bg-gradient-to-br from-brand-primary/5 to-brand-secondary/5 rounded-xl p-3 border border-brand-primary/10">
              <div className="font-bold text-lg text-gray-900">{unlockedBadges.length}</div>
              <div className="text-xs text-gray-600">Unlocked</div>
            </div>
            <div className="text-center bg-gradient-to-br from-brand-accent/5 to-yellow-100 rounded-xl p-3 border border-brand-accent/20">
              <div className="font-bold text-lg text-gray-900">{lockedBadges.length}</div>
              <div className="text-xs text-gray-600">In Progress</div>
            </div>
            <div className="text-center bg-gradient-to-br from-green-50 to-emerald-50 rounded-xl p-3 border border-green-200">
              <div className="font-bold text-lg text-gray-900">
                {Math.round((unlockedBadges.length / availableBadges.length) * 100)}%
              </div>
              <div className="text-xs text-gray-600">Complete</div>
            </div>
          </div>

          {/* Unlocked Badges */}
          {unlockedBadges.length > 0 && (
            <div className="mb-6">
              <div className="flex items-center space-x-2 mb-4">
                <Star size={16} className="text-yellow-500 fill-current" />
                <h3 className="font-semibold text-gray-900">Unlocked Achievements</h3>
                <div className="flex-1 h-px bg-gray-200"></div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                {unlockedBadges.map((badge) => (
                  <BadgeCard key={badge.id} badge={badge} />
                ))}
              </div>
            </div>
          )}

          {/* Locked Badges */}
          {lockedBadges.length > 0 && (
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <Target size={16} className="text-gray-500" />
                <h3 className="font-semibold text-gray-900">In Progress</h3>
                <div className="flex-1 h-px bg-gray-200"></div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                {lockedBadges.map((badge) => (
                  <BadgeCard key={badge.id} badge={badge} isLocked />
                ))}
              </div>
            </div>
          )}

          {/* Motivation Message */}
          <div className="mt-6 bg-gradient-to-r from-brand-primary/5 to-brand-secondary/5 rounded-xl p-4 border border-brand-primary/10">
            <div className="flex items-center space-x-2 mb-2">
              <Sparkles size={16} className="text-brand-primary" />
              <span className="font-semibold text-gray-900 text-sm">Keep exploring, champion! 🌟</span>
            </div>
            <p className="text-xs text-gray-600">
              Every badge tells a story of your amazing journey around the world. Keep sharing, exploring, and inspiring others!
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-gray-100 bg-gray-50">
          <button
            onClick={onClose}
            className="w-full bg-gradient-brand text-white py-3 px-4 rounded-xl font-semibold hover:shadow-brand hover:scale-[1.02] transition-all duration-200 active:scale-95"
          >
            Continue My Journey! ✈️
          </button>
        </div>
      </div>
    </div>
  );
}