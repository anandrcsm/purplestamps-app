import { useState, useEffect } from 'react';
import { ArrowLeft, Heart, Share2, Bookmark, MapPin, Calendar, Users, Star, Clock, DollarSign, ExternalLink, Plus, MoreVertical, Camera, Play, ChevronLeft, ChevronRight, Flag, Edit, BarChart3 } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { Experience } from '../types';
import { StarRating } from './StarRating';
import { CategoryTag } from './CategoryTag';
import { MomentsGallery } from './MomentsGallery';
import { getExperienceMoments, getCreator } from '../data/mockData';

interface ExperienceDetailPageProps {
  experienceId: string | null;
  allExperiences: Experience[];
  onBack: () => void;
  onAddToItinerary: (experienceId: string) => void;
}

export function ExperienceDetailPage({ 
  experienceId, 
  allExperiences, 
  onBack, 
  onAddToItinerary 
}: ExperienceDetailPageProps) {
  const [currentMediaIndex, setCurrentMediaIndex] = useState(0);
  const [isLiked, setIsLiked] = useState(false);
  const [isSaved, setIsSaved] = useState(false);
  const [showLightbox, setShowLightbox] = useState(false);
  const [isCreator, setIsCreator] = useState(false); // Mock creator status

  const experience = allExperiences.find(exp => exp.id === experienceId);
  const moments = experienceId ? getExperienceMoments(experienceId) : [];

  // Combined media array (experience images + moment images)
  const allMedia = [
    ...(experience?.images || []).map(img => ({ type: 'image' as const, url: img, source: 'experience' })),
    ...moments.map(moment => ({ type: moment.type, url: moment.image, source: 'moment', moment }))
  ];

  useEffect(() => {
    if (experience) {
      setCurrentMediaIndex(0);
    }
  }, [experience]);

  if (!experience) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-surface-warm to-surface-cool flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-xl font-semibold text-gray-900 mb-2">Experience Not Found</h2>
          <p className="text-gray-600 mb-4">The experience you're looking for doesn't exist.</p>
          <button
            onClick={onBack}
            className="bg-gradient-brand text-white px-6 py-3 rounded-xl font-medium hover:shadow-brand transition-all duration-200"
          >
            Go Back
          </button>
        </div>
      </div>
    );
  }

  const nextMedia = () => {
    if (allMedia.length > 1) {
      setCurrentMediaIndex((prev) => (prev + 1) % allMedia.length);
    }
  };

  const prevMedia = () => {
    if (allMedia.length > 1) {
      setCurrentMediaIndex((prev) => (prev - 1 + allMedia.length) % allMedia.length);
    }
  };

  const handleLike = () => {
    setIsLiked(!isLiked);
  };

  const handleSave = () => {
    setIsSaved(!isSaved);
    if (!isSaved) {
      onAddToItinerary(experience.id);
    }
  };

  const handleBookNow = () => {
    if (experience.affiliateLink) {
      // In a real app, this would track the affiliate click
      window.open(experience.affiliateLink, '_blank');
    }
  };

  const handleAddMoment = () => {
    // Mock function for creators to add moments
    console.log('Add moment to experience');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-surface-warm to-surface-cool">
      {/* Sticky Header */}
      <header className="fixed top-0 left-0 right-0 z-40 bg-white/90 backdrop-blur-xl border-b border-gray-100">
        <div className="flex items-center justify-between p-4">
          <button
            onClick={onBack}
            className="p-2 hover:bg-gray-100 rounded-xl transition-colors"
          >
            <ArrowLeft size={20} className="text-gray-700" />
          </button>
          <div className="flex-1"></div>
          <div className="flex items-center space-x-2">
            <button
              onClick={handleSave}
              className={`p-2 rounded-xl transition-all duration-200 hover:scale-110 active:scale-95 ${
                isSaved 
                  ? 'bg-brand-primary/10 text-brand-primary' 
                  : 'bg-gray-100 text-gray-600 hover:bg-brand-primary/5 hover:text-brand-primary'
              }`}
            >
              <Bookmark size={18} className={isSaved ? 'fill-current' : ''} />
            </button>
            <button className="p-2 hover:bg-gray-100 rounded-xl transition-colors">
              <MoreVertical size={20} className="text-gray-700" />
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="pt-16">
        {/* ===== TOP HALF: IMMERSIVE HERO SECTION WITH OVERLAID INFO ===== */}
        <div className="relative h-[70vh] overflow-hidden">
          {/* Hero Background Image/Media */}
          {allMedia.length > 0 ? (
            <div className="relative h-full">
              <ImageWithFallback
                src={allMedia[currentMediaIndex]?.url || 'https://images.unsplash.com/photo-1469474968028-56623f02e42e?w=800&h=600&fit=crop'}
                alt={experience.title || 'Experience'}
                className="w-full h-full object-cover"
              />
              
              {/* Media type indicator */}
              {allMedia[currentMediaIndex]?.type === 'video' && (
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="bg-black/50 rounded-full p-4">
                    <Play size={32} className="text-white" />
                  </div>
                </div>
              )}



              {/* Media count */}
              <div className="absolute top-4 left-4 bg-black/50 text-white px-3 py-1 rounded-full text-sm backdrop-blur-sm">
                {currentMediaIndex + 1} / {allMedia.length}
              </div>
            </div>
          ) : (
            <div className="h-full bg-gray-100 flex items-center justify-center">
              <div className="text-center">
                <Camera size={48} className="text-gray-400 mx-auto mb-2" />
                <p className="text-gray-500">No images available</p>
              </div>
            </div>
          )}

          {/* Triple Gradient Overlay for Better Text Readability */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
          <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-transparent to-transparent" />
          <div className="absolute inset-0 bg-black/20" />

          {/* OVERLAID CONTENT - All experience info */}
          <div className="absolute inset-0 flex flex-col justify-between p-6 text-white">
            
            {/* TOP RIGHT: Category Tag */}
            <div className="absolute top-4 right-4 z-20">
              <CategoryTag category={experience.category} className="bg-white/20 backdrop-blur-md border-white/30 text-white" />
            </div>

            {/* CENTER SECTION: Title and Description (Matching Travel Card Design) */}
            <div className="absolute inset-x-6 bottom-32 z-10">
              <div className="text-center">
                {/* Experience Title - Bold and Centered */}
                <h1 className="text-white font-bold text-3xl mb-3 leading-tight drop-shadow-lg">
                  {experience.title || 'Untitled Experience'}
                </h1>

                {/* Short Description */}
                {experience.description && (
                  <p className="text-white/90 text-sm leading-relaxed line-clamp-2 drop-shadow-md max-w-sm mx-auto">
                    {experience.description}
                  </p>
                )}
              </div>
            </div>

            {/* EXPERIENCE DETAILS: Location, Price, Duration - Centered in One Row */}
            <div className="absolute bottom-20 left-6 right-6 z-10">
              <div className="flex items-center justify-center space-x-3 flex-wrap">
                {/* Location Tag */}
                <div className="flex items-center space-x-1 bg-white/20 backdrop-blur-md rounded-full px-3 py-1.5 border border-white/30">
                  <MapPin size={12} className="text-white" />
                  <span className="text-white text-xs font-medium">{experience.location}</span>
                </div>

                {/* Price Tag */}
                {experience.pricing && (
                  <div className="flex items-center space-x-1 bg-white/20 backdrop-blur-md rounded-full px-3 py-1.5 border border-white/30">
                    <DollarSign size={12} className="text-white" />
                    <span className="text-white text-xs font-medium">{experience.pricing}</span>
                  </div>
                )}

                {/* Duration Tag (if available) */}
                {experience.duration && (
                  <div className="flex items-center space-x-1 bg-white/20 backdrop-blur-md rounded-full px-3 py-1.5 border border-white/30">
                    <Clock size={12} className="text-white" />
                    <span className="text-white text-xs font-medium">{experience.duration}</span>
                  </div>
                )}
              </div>
            </div>

            {/* BOTTOM SECTION: Action Buttons - Horizontal Layout */}
            <div className="absolute bottom-0 left-0 right-0 z-10">
              <div className="flex items-center justify-center space-x-3 px-6 py-4">
                {/* Add to Bucket List Button */}
                <button
                  onClick={handleSave}
                  className={`flex items-center space-x-2 px-4 py-2.5 rounded-xl font-medium transition-all duration-200 backdrop-blur-sm border flex-1 justify-center hover:scale-105 active:scale-95 ${
                    isSaved 
                      ? 'bg-brand-primary/30 text-white border-white/30' 
                      : 'bg-black/30 text-white border-white/20 hover:bg-brand-primary/30'
                  }`}
                >
                  <Bookmark size={16} className={isSaved ? 'fill-current' : ''} />
                  <span className="text-sm font-medium">{isSaved ? 'Saved' : 'Add to Bucket List'}</span>
                </button>
                
                {/* Book Now Button */}
                {experience.affiliateLink && (
                  <button
                    onClick={handleBookNow}
                    className="flex items-center space-x-2 px-4 py-2.5 bg-gradient-brand text-white rounded-xl font-medium hover:shadow-brand hover:scale-105 active:scale-95 transition-all duration-200 backdrop-blur-sm flex-1 justify-center"
                  >
                    <ExternalLink size={16} />
                    <span className="text-sm font-medium">Book Now</span>
                  </button>
                )}
              </div>
            </div>

            {/* Secondary Actions - Top Left */}
            <div className="absolute top-4 left-4 z-20">
              <div className="flex items-center space-x-3">
                {/* Like Button */}
                <button
                  onClick={handleLike}
                  className={`flex items-center space-x-1 transition-all duration-200 hover:scale-110 active:scale-95 ${
                    isLiked ? 'text-red-400' : 'text-white hover:text-red-400'
                  }`}
                >
                  <Heart size={18} className={isLiked ? 'fill-current' : ''} />
                  <span className="text-sm font-medium">{experience.likes || 0}</span>
                </button>

                {/* Share Button */}
                <button className="text-white hover:text-moodboard-muted-teal transition-all duration-200 hover:scale-110 active:scale-95">
                  <Share2 size={18} />
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* ===== BOTTOM HALF: CREATOR REVIEW & CONTENT ===== */}
        <div className="bg-white">
          
          {/* Creator's Review Section */}
          {experience.review && (
            <div className="px-6 py-8 border-b border-gray-100">
              <h3 className="font-semibold text-gray-900 mb-4 text-center">Creator's Review</h3>
              <div className="bg-gradient-to-r from-brand-primary/5 to-brand-secondary/5 rounded-2xl p-6 border-l-4 border-brand-primary">
                <div className="flex items-center space-x-4 mb-4">
                  {/* Mock creator info */}
                  <div className="w-12 h-12 bg-brand-primary rounded-full flex items-center justify-center">
                    <Users size={20} className="text-white" />
                  </div>
                  <div>
                    <p className="font-medium text-gray-900">Travel Creator</p>
                    <p className="text-sm text-gray-500">Verified Experience</p>
                  </div>
                </div>
                <p className="text-gray-700 italic leading-relaxed">
                  "{experience.review}"
                </p>
                <div className="flex items-center space-x-4 mt-4 pt-4 border-t border-gray-200">
                  <StarRating rating={experience.rating || 0} size="sm" />
                  <span className="text-sm text-gray-600">Rated {experience.rating || 0}/5</span>
                </div>
              </div>
            </div>
          )}



          {/* Moments Gallery */}
          {moments.length > 0 && (
            <div className="px-6 py-8">
              <MomentsGallery 
                moments={moments} 
                experienceTitle={experience.title || 'Experience'} 
              />
            </div>
          )}

          {/* Creator Actions (if applicable) */}
          {isCreator && (
            <div className="px-6 py-6 border-t border-gray-100">
              <h3 className="font-semibold text-gray-900 mb-4">Creator Actions</h3>
              <div className="flex items-center space-x-3">
                <button className="flex-1 bg-blue-500 text-white py-3 px-4 rounded-xl font-medium hover:bg-blue-600 transition-colors flex items-center justify-center space-x-2">
                  <Edit size={16} />
                  <span>Edit</span>
                </button>
                <button className="flex-1 bg-green-500 text-white py-3 px-4 rounded-xl font-medium hover:bg-green-600 transition-colors flex items-center justify-center space-x-2">
                  <BarChart3 size={16} />
                  <span>Insights</span>
                </button>
              </div>
            </div>
          )}

          {/* Report Option */}
          <div className="px-6 py-4 border-t border-gray-100">
            <button className="flex items-center space-x-2 text-gray-500 hover:text-gray-700 text-sm transition-colors">
              <Flag size={14} />
              <span>Report this experience</span>
            </button>
          </div>
        </div>
      </main>

      {/* Lightbox Modal */}
      {showLightbox && allMedia.length > 0 && (
        <div className="fixed inset-0 z-50 bg-black/95 flex items-center justify-center p-4">
          <button
            onClick={() => setShowLightbox(false)}
            className="absolute top-4 right-4 z-60 p-2 bg-white/10 hover:bg-white/20 rounded-full text-white transition-colors"
          >
            <ArrowLeft size={24} className="rotate-45" />
          </button>

          {/* Navigation */}
          {allMedia.length > 1 && (
            <>
              <button
                onClick={prevMedia}
                className="absolute left-4 top-1/2 transform -translate-y-1/2 z-60 p-2 bg-white/10 hover:bg-white/20 rounded-full text-white transition-colors"
              >
                <ChevronLeft size={24} />
              </button>
              <button
                onClick={nextMedia}
                className="absolute right-4 top-1/2 transform -translate-y-1/2 z-60 p-2 bg-white/10 hover:bg-white/20 rounded-full text-white transition-colors"
              >
                <ChevronRight size={24} />
              </button>
            </>
          )}

          {/* Main Image */}
          <div className="max-w-4xl max-h-full w-full h-full flex items-center justify-center">
            <ImageWithFallback
              src={allMedia[currentMediaIndex]?.url}
              alt={experience.title || 'Experience'}
              className="max-w-full max-h-full object-contain"
            />
          </div>

          {/* Media Info */}
          <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 text-center text-white">
            <p className="text-sm opacity-75">
              {currentMediaIndex + 1} of {allMedia.length}
            </p>
            {allMedia[currentMediaIndex]?.source === 'moment' && (
              <p className="text-xs opacity-60 mt-1">
                From user moments
              </p>
            )}
          </div>
        </div>
      )}
    </div>
  );
}