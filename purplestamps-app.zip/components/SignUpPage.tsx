import { useState, useEffect } from 'react';
import { Eye, EyeOff, ArrowRight, Users, Globe, Heart, Crown, User, Zap } from 'lucide-react';
import { BrandLogo } from './BrandLogo';
import { InstagramBusinessVerificationPage } from './InstagramBusinessVerificationPage';

interface SignUpPageProps {
  onSignUpSuccess: (accountType: 'user' | 'creator', instagramData?: any) => void;
  onNavigateToLogin: () => void;
}

// Fun onboarding messages
const onboardingMessages = [
  { text: "Join 50K+ explorers worldwide! 🌍", icon: Users },
  { text: "Discover hidden gems daily! 💎", icon: Globe },
  { text: "Connect with local culture! 🎭", icon: Heart },
  { text: "Create epic travel memories! 📸", icon: Globe }
];

// Encouraging phrases for sign up
const encouragingPhrases = [
  "Your adventure crew is waiting! 🎒",
  "Time to make some travel magic! ✨",
  "Let's turn wanderlust into reality! 🗺️",
  "Ready to explore the world together? 🌏"
];

type SignUpStep = 'accountType' | 'userForm' | 'instagramVerification' | 'creatorForm';

export function SignUpPage({ onSignUpSuccess, onNavigateToLogin }: SignUpPageProps) {
  const [currentStep, setCurrentStep] = useState<SignUpStep>('accountType');
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    confirmPassword: ''
  });
  const [accountType, setAccountType] = useState<'user' | 'creator'>('user');
  const [instagramData, setInstagramData] = useState<any>(null);
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [currentMessageIndex, setCurrentMessageIndex] = useState(0);
  const [currentPhraseIndex, setCurrentPhraseIndex] = useState(0);

  // Rotate messages every 3 seconds
  useEffect(() => {
    const messageInterval = setInterval(() => {
      setCurrentMessageIndex((prev) => (prev + 1) % onboardingMessages.length);
    }, 3000);
    return () => clearInterval(messageInterval);
  }, []);

  // Rotate phrases every 4 seconds
  useEffect(() => {
    const phraseInterval = setInterval(() => {
      setCurrentPhraseIndex((prev) => (prev + 1) % encouragingPhrases.length);
    }, 4000);
    return () => clearInterval(phraseInterval);
  }, []);

  const handleAccountTypeSelection = (type: 'user' | 'creator') => {
    setAccountType(type);
    if (type === 'user') {
      setCurrentStep('userForm');
    } else {
      setCurrentStep('instagramVerification');
    }
  };

  const handleInstagramVerificationSuccess = (igData: any) => {
    setInstagramData(igData);
    setCurrentStep('creatorForm');
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (formData.password !== formData.confirmPassword) {
      // Show friendly error message
      const toast = document.createElement('div');
      toast.className = 'fixed top-20 left-1/2 transform -translate-x-1/2 bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-xl z-50 shadow-lg';
      toast.innerHTML = `
        <div class="flex items-center space-x-2">
          <span>🔐</span>
          <span class="font-medium">Oops! Passwords don't match. Try again, explorer!</span>
        </div>
      `;
      document.body.appendChild(toast);
      setTimeout(() => document.body.removeChild(toast), 3000);
      return;
    }

    setIsLoading(true);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    setIsLoading(false);
    onSignUpSuccess(accountType, instagramData);
  };

  const currentMessage = onboardingMessages[currentMessageIndex];
  const CurrentIcon = currentMessage.icon;
  const currentPhrase = encouragingPhrases[currentPhraseIndex];

  // Instagram Verification Step
  if (currentStep === 'instagramVerification') {
    return (
      <InstagramBusinessVerificationPage
        onVerificationSuccess={handleInstagramVerificationSuccess}
        onBack={() => setCurrentStep('accountType')}
      />
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-surface-warm via-white to-surface-cool flex flex-col">
      {/* Motivational Header */}
      <div className="bg-gradient-brand-secondary text-white py-4 px-4 relative overflow-hidden">
        <div className="absolute inset-0 bg-black/10"></div>
        <div className="relative flex items-center justify-center space-x-3 animate-slideDown">
          <CurrentIcon size={18} className="animate-bounce" />
          <div className="text-center">
            <p className="text-sm font-semibold">{currentMessage.text}</p>
          </div>
        </div>
      </div>

      <div className="flex-1 flex items-center justify-center p-6">
        <div className="w-full max-w-sm">
          {/* Header */}
          <div className="text-center mb-8">
            <div className="mb-6">
              <BrandLogo />
            </div>
            
            {/* Rotating Encouraging Phrase */}
            <div className="mb-6 h-8 flex items-center justify-center">
              <p 
                key={currentPhraseIndex}
                className="text-sm font-medium text-gray-600 animate-fadeIn text-center"
              >
                {currentPhrase}
              </p>
            </div>

            <h1 className="text-2xl font-bold text-gray-900 mb-2">Welcome to the crew! 🌟</h1>
            <p className="text-gray-600 text-sm">Let's get you set up for amazing adventures</p>
          </div>

          {/* Account Type Selection Step */}
          {currentStep === 'accountType' && (
            <div className="space-y-6">
              <div className="mb-6">
                <label className="block text-sm font-medium text-gray-700 mb-3">
                  Choose your account type
                </label>
                <div className="grid grid-cols-1 gap-4">
                  {/* Traveler Option */}
                  <button
                    type="button"
                    onClick={() => handleAccountTypeSelection('user')}
                    className="p-5 rounded-xl border-2 border-gray-200 bg-white hover:border-moodboard-muted-teal hover:bg-moodboard-muted-teal/5 transition-all duration-200 text-left group"
                  >
                    <div className="flex items-center space-x-4">
                      <div className="w-12 h-12 bg-moodboard-muted-teal/10 rounded-full flex items-center justify-center group-hover:bg-moodboard-muted-teal/20 transition-colors">
                        <User size={24} className="text-moodboard-muted-teal" />
                      </div>
                      <div className="flex-1">
                        <h3 className="font-semibold text-moodboard-deep-green mb-1">Sign up as Traveler</h3>
                        <p className="text-sm text-moodboard-gray-dark">Explore & discover amazing places around the world</p>
                      </div>
                      <ArrowRight size={20} className="text-moodboard-gray-light group-hover:text-moodboard-muted-teal transition-colors" />
                    </div>
                  </button>

                  {/* Creator Option */}
                  <button
                    type="button"
                    onClick={() => handleAccountTypeSelection('creator')}
                    className="p-5 rounded-xl border-2 border-gray-200 bg-white hover:border-moodboard-warm-beige hover:bg-moodboard-warm-beige/5 transition-all duration-200 text-left group relative overflow-hidden"
                  >
                    {/* Gradient background */}
                    <div className="absolute inset-0 bg-gradient-to-r from-moodboard-warm-beige/5 to-moodboard-muted-teal/5 opacity-0 group-hover:opacity-100 transition-opacity"></div>
                    
                    <div className="relative flex items-center space-x-4">
                      <div className="w-12 h-12 bg-gradient-to-r from-moodboard-warm-beige/20 to-moodboard-muted-teal/20 rounded-full flex items-center justify-center group-hover:from-moodboard-warm-beige/30 group-hover:to-moodboard-muted-teal/30 transition-all">
                        <Crown size={24} className="text-moodboard-warm-beige-dark" />
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center space-x-2 mb-1">
                          <h3 className="font-semibold text-moodboard-deep-green">Sign up as Creator</h3>
                          <div className="inline-flex items-center space-x-1 px-2 py-1 bg-moodboard-warm-beige/20 rounded-full">
                            <Zap size={10} className="text-moodboard-warm-beige-dark" />
                            <span className="text-xs font-medium text-moodboard-warm-beige-dark">for affiliate tools</span>
                          </div>
                        </div>
                        <p className="text-sm text-moodboard-gray-dark">Share experiences & earn money through affiliate links</p>
                      </div>
                      <ArrowRight size={20} className="text-moodboard-gray-light group-hover:text-moodboard-warm-beige-dark transition-colors" />
                    </div>
                  </button>
                </div>
              </div>

              {/* Info Section */}
              <div className="bg-moodboard-cream rounded-xl p-4 border border-moodboard-muted-teal/10">
                <p className="text-xs font-medium text-moodboard-deep-green mb-2">
                  💡 What's the difference?
                </p>
                <div className="space-y-2 text-xs text-moodboard-charcoal">
                  <div><strong>Travelers:</strong> Discover, save, and plan amazing trips with our community</div>
                  <div><strong>Creators:</strong> Share your travel content and earn commissions when others book through your recommendations</div>
                </div>
              </div>
            </div>
          )}

          {/* User/Creator Form Steps */}
          {(currentStep === 'userForm' || currentStep === 'creatorForm') && (
            <>
              {/* Back Button */}
              {currentStep === 'creatorForm' && (
                <button
                  onClick={() => setCurrentStep('instagramVerification')}
                  className="flex items-center space-x-2 text-moodboard-gray-dark hover:text-moodboard-deep-green mb-6 transition-colors"
                >
                  <ArrowRight size={16} className="rotate-180" />
                  <span className="text-sm">Back to verification</span>
                </button>
              )}

              {currentStep === 'userForm' && (
                <button
                  onClick={() => setCurrentStep('accountType')}
                  className="flex items-center space-x-2 text-moodboard-gray-dark hover:text-moodboard-deep-green mb-6 transition-colors"
                >
                  <ArrowRight size={16} className="rotate-180" />
                  <span className="text-sm">Back to account type</span>
                </button>
              )}

              {/* Account Type Indicator */}
              <div className="mb-6 p-3 bg-moodboard-cream rounded-xl border border-moodboard-muted-teal/10">
                <div className="flex items-center space-x-3">
                  {accountType === 'user' ? (
                    <User size={16} className="text-moodboard-muted-teal" />
                  ) : (
                    <Crown size={16} className="text-moodboard-warm-beige-dark" />
                  )}
                  <div>
                    <p className="text-sm font-medium text-moodboard-deep-green">
                      {accountType === 'user' ? 'Traveler Account' : 'Creator Account'}
                    </p>
                    {accountType === 'creator' && instagramData && (
                      <p className="text-xs text-moodboard-gray-dark">
                        Instagram: @{instagramData.username} ✓
                      </p>
                    )}
                  </div>
                </div>
              </div>

              {/* Sign Up Form */}
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">
                    Your Travel Name
                  </label>
                  <input
                    id="name"
                    name="name"
                    type="text"
                    value={formData.name}
                    onChange={handleChange}
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-brand-secondary focus:border-transparent transition-all bg-white/80 backdrop-blur-sm"
                    placeholder="What should we call you, explorer?"
                    required
                  />
                </div>

                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                    Email Address
                  </label>
                  <input
                    id="email"
                    name="email"
                    type="email"
                    value={formData.email}
                    onChange={handleChange}
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-brand-secondary focus:border-transparent transition-all bg-white/80 backdrop-blur-sm"
                    placeholder="your@email.com"
                    required
                  />
                </div>

                <div>
                  <label htmlFor="password" className="block text-sm font-medium text-gray-700 mb-1">
                    Create Password
                  </label>
                  <div className="relative">
                    <input
                      id="password"
                      name="password"
                      type={showPassword ? 'text' : 'password'}
                      value={formData.password}
                      onChange={handleChange}
                      className="w-full px-4 py-3 pr-12 border border-gray-200 rounded-xl focus:ring-2 focus:ring-brand-secondary focus:border-transparent transition-all bg-white/80 backdrop-blur-sm"
                      placeholder="Make it strong & secure!"
                      required
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600 transition-colors"
                    >
                      {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
                    </button>
                  </div>
                </div>

                <div>
                  <label htmlFor="confirmPassword" className="block text-sm font-medium text-gray-700 mb-1">
                    Confirm Password
                  </label>
                  <div className="relative">
                    <input
                      id="confirmPassword"
                      name="confirmPassword"
                      type={showConfirmPassword ? 'text' : 'password'}
                      value={formData.confirmPassword}
                      onChange={handleChange}
                      className="w-full px-4 py-3 pr-12 border border-gray-200 rounded-xl focus:ring-2 focus:ring-brand-secondary focus:border-transparent transition-all bg-white/80 backdrop-blur-sm"
                      placeholder="One more time, explorer!"
                      required
                    />
                    <button
                      type="button"
                      onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                      className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600 transition-colors"
                    >
                      {showConfirmPassword ? <EyeOff size={20} /> : <Eye size={20} />}
                    </button>
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={isLoading}
                  className="w-full bg-gradient-brand-secondary text-white py-3 px-4 rounded-xl font-semibold hover:shadow-brand-secondary hover:scale-[1.02] transition-all duration-200 active:scale-95 disabled:opacity-50 disabled:hover:scale-100 flex items-center justify-center space-x-2"
                >
                  {isLoading ? (
                    <>
                      <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                      <span>Setting up your adventure base...</span>
                    </>
                  ) : (
                    <>
                      <span>Start My Journey! 🎒</span>
                      <ArrowRight size={18} />
                    </>
                  )}
                </button>
              </form>

              {/* Terms */}
              <p className="text-xs text-gray-500 text-center mt-4">
                By joining, you agree to our friendly{' '}
                <a href="#" className="text-brand-secondary hover:underline transition-colors">Terms</a>
                {' '}and{' '}
                <a href="#" className="text-brand-secondary hover:underline transition-colors">Privacy Policy</a>
              </p>

              {/* Divider */}
              <div className="my-6 flex items-center">
                <div className="flex-1 border-t border-gray-200"></div>
                <span className="px-3 text-sm text-gray-500">or</span>
                <div className="flex-1 border-t border-gray-200"></div>
              </div>

              {/* Login Link */}
              <div className="text-center">
                <p className="text-sm text-gray-600">
                  Already part of the crew?{' '}
                  <button
                    onClick={onNavigateToLogin}
                    className="font-semibold text-brand-secondary hover:text-brand-secondary-dark transition-colors"
                  >
                    Welcome back! 👋
                  </button>
                </p>
              </div>

              {/* Bottom Encouragement */}
              <div className="mt-8 text-center">
                <div className="bg-gradient-to-r from-brand-secondary/10 to-brand-accent/10 rounded-xl p-4 border border-brand-secondary/20">
                  <p className="text-xs text-gray-600 font-medium mb-2">
                    🎉 You're about to join an amazing community!
                  </p>
                  <p className="text-xs text-gray-500">
                    Get ready for personalized travel recommendations, cultural insights, and epic adventures!
                  </p>
                </div>
              </div>
            </>
          )}
        </div>
      </div>

      {/* Footer */}
      <div className="p-4 text-center">
        <p className="text-xs text-gray-500">
          Powered by Tryppr • Try new places, share experiences 🌍
        </p>
      </div>
    </div>
  );
}