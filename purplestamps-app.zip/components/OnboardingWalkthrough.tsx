import { useState, useRef } from 'react';
import { 
  X, 
  ArrowRight,
  MapPin,
  Camera,
  Gem,
  DollarSign,
  Calendar,
  Plane,
  Bed,
  Utensils,
  Activity,
  Star,
  Heart,
  MessageSquare,
  Share,
  Coffee,
  TreePine,
  Clock,
  Bookmark
} from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface OnboardingWalkthroughProps {
  accountType: 'user' | 'creator';
  onComplete: () => void;
}

export function OnboardingWalkthrough({ accountType, onComplete }: OnboardingWalkthroughProps) {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [isAnimating, setIsAnimating] = useState(false);
  const touchStartX = useRef<number>(0);
  const touchEndX = useRef<number>(0);

  // Calculate total slides based on account type
  const totalSlides = accountType === 'creator' ? 6 : 5;

  const handleTouchStart = (e: React.TouchEvent) => {
    touchStartX.current = e.targetTouches[0].clientX;
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    touchEndX.current = e.targetTouches[0].clientX;
  };

  const handleTouchEnd = () => {
    if (!touchStartX.current || !touchEndX.current) return;
    
    const distance = touchStartX.current - touchEndX.current;
    const isLeftSwipe = distance > 50;
    const isRightSwipe = distance < -50;

    if (isLeftSwipe && currentSlide < totalSlides - 1) {
      nextSlide();
    } else if (isRightSwipe && currentSlide > 0) {
      prevSlide();
    }
  };

  const nextSlide = () => {
    if (isAnimating) return;
    
    if (currentSlide < totalSlides - 1) {
      setIsAnimating(true);
      setCurrentSlide(prev => prev + 1);
      setTimeout(() => setIsAnimating(false), 300);
    } else {
      onComplete();
    }
  };

  const prevSlide = () => {
    if (isAnimating || currentSlide === 0) return;
    
    setIsAnimating(true);
    setCurrentSlide(prev => prev - 1);
    setTimeout(() => setIsAnimating(false), 300);
  };

  const goToSlide = (slideIndex: number) => {
    if (isAnimating || slideIndex === currentSlide) return;
    
    setIsAnimating(true);
    setCurrentSlide(slideIndex);
    setTimeout(() => setIsAnimating(false), 300);
  };

  return (
    <div 
      className="fixed inset-0 bg-moodboard-cream z-50 overflow-hidden"
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
    >
      {/* Skip Button */}
      <button
        onClick={onComplete}
        className="fixed top-6 right-6 z-20 flex items-center space-x-2 text-moodboard-gray-dark hover:text-moodboard-charcoal font-medium bg-white/80 backdrop-blur-sm px-4 py-2 rounded-xl border border-moodboard-muted-teal/20 hover:border-moodboard-muted-teal/40 transition-all duration-200 shadow-sm"
      >
        <span className="text-sm">Skip</span>
        <X size={16} />
      </button>

      {/* Slide 1: Welcome */}
      <div 
        className={`absolute inset-0 transition-all duration-500 ease-out ${
          currentSlide === 0 
            ? 'translate-x-0 opacity-100' 
            : 'translate-x-full opacity-0'
        }`}
      >
        <div className="h-full flex flex-col justify-center items-center p-8 text-center">
          {/* Animated Travel Scene */}
          <div className="relative mb-12">
            <div className="relative w-64 h-64 mx-auto">
              {/* Central globe/travel icon */}
              <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
                <div className="w-32 h-32 bg-gradient-to-br from-moodboard-muted-teal to-moodboard-muted-teal-light rounded-full flex items-center justify-center shadow-brand animate-bounceIn">
                  <div className="text-6xl">🌍</div>
                </div>
              </div>
              
              {/* Floating travel icons */}
              <div className="absolute top-4 left-8 w-12 h-12 bg-moodboard-muted-teal/20 rounded-full flex items-center justify-center animate-pulse">
                <Plane size={24} className="text-moodboard-muted-teal transform rotate-12" />
              </div>
              <div className="absolute top-16 right-12 w-10 h-10 bg-moodboard-warm-beige/30 rounded-full flex items-center justify-center animate-pulse" style={{ animationDelay: '0.5s' }}>
                <Camera size={20} className="text-moodboard-warm-beige-dark" />
              </div>
              <div className="absolute bottom-20 left-4 w-8 h-8 bg-moodboard-muted-teal/15 rounded-full flex items-center justify-center animate-pulse" style={{ animationDelay: '1s' }}>
                <MapPin size={16} className="text-moodboard-muted-teal" />
              </div>
              <div className="absolute bottom-8 right-8 w-10 h-10 bg-moodboard-warm-beige/20 rounded-full flex items-center justify-center animate-pulse" style={{ animationDelay: '1.5s' }}>
                <Heart size={20} className="text-moodboard-warm-beige-dark" />
              </div>
            </div>
          </div>

          {/* Content */}
          <div className="space-y-6 max-w-sm">
            <div>
              <h1 className="text-3xl font-bold text-moodboard-deep-green mb-4">
                Welcome to your travel companion 🌍
              </h1>
              <p className="text-moodboard-charcoal leading-relaxed">
                Discover, plan, and share unforgettable journeys.
              </p>
            </div>

            <button
              onClick={nextSlide}
              disabled={isAnimating}
              className="w-full btn-moodboard-primary text-lg py-4 flex items-center justify-center space-x-2 disabled:opacity-50"
            >
              <span>Let's Explore</span>
              <ArrowRight size={24} />
            </button>
          </div>
        </div>
      </div>

      {/* Slide 2: Travel Cards */}
      <div 
        className={`absolute inset-0 transition-all duration-500 ease-out ${
          currentSlide === 1 
            ? 'translate-x-0 opacity-100' 
            : currentSlide < 1 
              ? 'translate-x-full opacity-0'
              : '-translate-x-full opacity-0'
        }`}
      >
        <div className="h-full flex flex-col">
          {/* Visual Section */}
          <div className="flex-1 flex items-center justify-center p-8">
            <div className="w-full max-w-sm">
              {/* Header Icon */}
              <div className="text-center mb-8">
                <div className="w-20 h-20 bg-gradient-to-br from-moodboard-muted-teal to-moodboard-muted-teal-light rounded-full flex items-center justify-center shadow-brand mx-auto mb-4">
                  <span className="text-3xl">📍</span>
                </div>
                <h2 className="text-2xl font-bold text-moodboard-deep-green">
                  Build Your Trip
                </h2>
              </div>

              {/* Travel Card Layout Zoom Mockup */}
              <div className="card-modern overflow-hidden transform hover:scale-105 transition-all duration-300">
                {/* Card Cover */}
                <div className="relative aspect-[4/3] overflow-hidden">
                  <ImageWithFallback
                    src="https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=400&h=300&fit=crop"
                    alt="Bali trip cover"
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/20 to-transparent"></div>
                  <div className="absolute bottom-4 left-4 right-4">
                    <h3 className="text-white font-bold text-lg">Bali Adventure</h3>
                    <p className="text-white/90 text-sm">Indonesia • 7 days</p>
                  </div>
                </div>

                {/* Experience Categories */}
                <div className="bg-moodboard-cream/50 border-b border-moodboard-muted-teal/10">
                  <div className="flex">
                    <div className="flex-1 py-2 px-3 text-center text-xs font-medium text-moodboard-deep-green bg-white border-b-2 border-moodboard-muted-teal flex items-center justify-center space-x-1">
                      <Bed size={12} />
                      <span>Stay</span>
                    </div>
                    <div className="flex-1 py-2 px-3 text-center text-xs font-medium text-moodboard-gray-dark flex items-center justify-center space-x-1">
                      <Utensils size={12} />
                      <span>Food</span>
                    </div>
                    <div className="flex-1 py-2 px-3 text-center text-xs font-medium text-moodboard-gray-dark flex items-center justify-center space-x-1">
                      <Activity size={12} />
                      <span>Activities</span>
                    </div>
                  </div>
                </div>

                {/* Moments Preview */}
                <div className="p-4">
                  <div className="grid grid-cols-2 gap-3">
                    <div className="aspect-square rounded-xl overflow-hidden">
                      <ImageWithFallback
                        src="https://images.unsplash.com/photo-1537953773345-d172ccf13cf1?w=200&h=200&fit=crop"
                        alt="Bali villa"
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="aspect-square rounded-xl overflow-hidden">
                      <ImageWithFallback
                        src="https://images.unsplash.com/photo-1518548419970-58e3b4079ab2?w=200&h=200&fit=crop"
                        alt="Bali beach"
                        className="w-full h-full object-cover"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Content Section */}
          <div className="bg-white/95 backdrop-blur-xl border-t border-moodboard-muted-teal/20 p-8">
            <div className="text-center space-y-4 max-w-sm mx-auto">
              <div>
                <div className="space-y-3 text-left">
                  <div className="flex items-start space-x-3">
                    <div className="w-2 h-2 bg-moodboard-muted-teal rounded-full mt-2 flex-shrink-0"></div>
                    <p className="text-moodboard-charcoal">Add experiences by day or category</p>
                  </div>
                  <div className="flex items-start space-x-3">
                    <div className="w-2 h-2 bg-moodboard-muted-teal rounded-full mt-2 flex-shrink-0"></div>
                    <p className="text-moodboard-charcoal">Upload moments (photos, videos)</p>
                  </div>
                  {accountType === 'creator' && (
                    <div className="flex items-start space-x-3">
                      <div className="w-2 h-2 bg-moodboard-warm-beige rounded-full mt-2 flex-shrink-0"></div>
                      <p className="text-moodboard-charcoal">(For Creators) Add affiliate links</p>
                    </div>
                  )}
                </div>
              </div>

              <button
                onClick={nextSlide}
                disabled={isAnimating}
                className="w-full btn-moodboard-primary flex items-center justify-center space-x-2 disabled:opacity-50"
              >
                <span>Next</span>
                <ArrowRight size={20} />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Slide 3: Moments */}
      <div 
        className={`absolute inset-0 transition-all duration-500 ease-out ${
          currentSlide === 2 
            ? 'translate-x-0 opacity-100' 
            : currentSlide < 2 
              ? 'translate-x-full opacity-0'
              : '-translate-x-full opacity-0'
        }`}
      >
        <div className="h-full flex flex-col">
          {/* Visual Section */}
          <div className="flex-1 flex items-center justify-center p-8">
            <div className="w-full max-w-sm">
              {/* Header Icon */}
              <div className="text-center mb-8">
                <div className="w-20 h-20 bg-gradient-to-br from-moodboard-warm-beige to-moodboard-warm-beige-dark rounded-full flex items-center justify-center shadow-brand-secondary mx-auto mb-4">
                  <span className="text-3xl">🎞️</span>
                </div>
                <h2 className="text-2xl font-bold text-moodboard-deep-green">
                  Capture the Moments
                </h2>
              </div>

              {/* Polaroid-style Grid Layout */}
              <div className="grid grid-cols-2 gap-4">
                {/* Polaroid 1 */}
                <div className="bg-white p-3 rounded-2xl shadow-lg transform rotate-2 hover:rotate-0 transition-transform duration-300">
                  <div className="aspect-square rounded-xl overflow-hidden mb-2">
                    <ImageWithFallback
                      src="https://images.unsplash.com/photo-1571896349842-33c89424de2d?w=200&h=200&fit=crop"
                      alt="Beach moment"
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <p className="handwriting-style text-xs text-moodboard-charcoal text-center">
                    Perfect beach day! 🏖️
                  </p>
                </div>

                {/* Polaroid 2 */}
                <div className="bg-white p-3 rounded-2xl shadow-lg transform -rotate-1 hover:rotate-0 transition-transform duration-300">
                  <div className="aspect-square rounded-xl overflow-hidden mb-2">
                    <ImageWithFallback
                      src="https://images.unsplash.com/photo-1555881400-74d7acaacd8b?w=200&h=200&fit=crop"
                      alt="Hotel room"
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <p className="handwriting-style text-xs text-moodboard-charcoal text-center">
                    Cozy hotel vibes ✨
                  </p>
                </div>

                {/* Polaroid 3 */}
                <div className="bg-white p-3 rounded-2xl shadow-lg transform rotate-1 hover:rotate-0 transition-transform duration-300">
                  <div className="aspect-square rounded-xl overflow-hidden mb-2">
                    <ImageWithFallback
                      src="https://images.unsplash.com/photo-1555882932-e4e31df73640?w=200&h=200&fit=crop"
                      alt="Food moment"
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <p className="handwriting-style text-xs text-moodboard-charcoal text-center">
                    Amazing pasta! 🍝
                  </p>
                </div>

                {/* Polaroid 4 */}
                <div className="bg-white p-3 rounded-2xl shadow-lg transform -rotate-2 hover:rotate-0 transition-transform duration-300">
                  <div className="aspect-square rounded-xl overflow-hidden mb-2">
                    <ImageWithFallback
                      src="https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=200&h=200&fit=crop"
                      alt="Temple moment"
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <p className="handwriting-style text-xs text-moodboard-charcoal text-center">
                    Temple beauty 🏛️
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Content Section */}
          <div className="bg-white/95 backdrop-blur-xl border-t border-moodboard-muted-teal/20 p-8">
            <div className="text-center space-y-4 max-w-sm mx-auto">
              <div>
                <div className="space-y-3 text-left">
                  <div className="flex items-start space-x-3">
                    <div className="w-2 h-2 bg-moodboard-muted-teal rounded-full mt-2 flex-shrink-0"></div>
                    <p className="text-moodboard-charcoal">Share your stories in real time</p>
                  </div>
                  <div className="flex items-start space-x-3">
                    <div className="w-2 h-2 bg-moodboard-muted-teal rounded-full mt-2 flex-shrink-0"></div>
                    <p className="text-moodboard-charcoal">Attach photos and videos under each experience</p>
                  </div>
                  <div className="flex items-start space-x-3">
                    <div className="w-2 h-2 bg-moodboard-muted-teal rounded-full mt-2 flex-shrink-0"></div>
                    <p className="text-moodboard-charcoal">Appear on your profile and the feed</p>
                  </div>
                </div>
              </div>

              <button
                onClick={nextSlide}
                disabled={isAnimating}
                className="w-full btn-moodboard-primary flex items-center justify-center space-x-2 disabled:opacity-50"
              >
                <span>Next</span>
                <ArrowRight size={20} />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Slide 4: Local Gems */}
      <div 
        className={`absolute inset-0 transition-all duration-500 ease-out ${
          currentSlide === 3 
            ? 'translate-x-0 opacity-100' 
            : currentSlide < 3 
              ? 'translate-x-full opacity-0'
              : '-translate-x-full opacity-0'
        }`}
      >
        <div className="h-full flex flex-col">
          {/* Visual Section */}
          <div className="flex-1 flex items-center justify-center p-8">
            <div className="w-full max-w-xs">
              {/* Header Icon */}
              <div className="text-center mb-8">
                <div className="w-20 h-20 bg-gradient-to-br from-moodboard-muted-teal-light to-moodboard-muted-teal rounded-full flex items-center justify-center shadow-brand mx-auto mb-4">
                  <span className="text-3xl">✨</span>
                </div>
                <h2 className="text-2xl font-bold text-moodboard-deep-green">
                  Discover and Share Hidden Gems
                </h2>
              </div>

              {/* Reels-style Card Layout */}
              <div className="space-y-3">
                {/* Local Gem Card 1 - Café */}
                <div className="card-modern overflow-hidden transform hover:scale-105 transition-all duration-300">
                  <div className="relative">
                    <div className="aspect-[4/3] overflow-hidden">
                      <ImageWithFallback
                        src="https://images.unsplash.com/photo-1554118811-1e0d58224f24?w=300&h=200&fit=crop"
                        alt="Hidden café"
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="absolute top-3 left-3">
                      <div className="bg-moodboard-warm-beige/90 backdrop-blur-sm px-2 py-1 rounded-full border border-white/20">
                        <span className="text-moodboard-deep-green text-xs font-semibold flex items-center space-x-1">
                          <Coffee size={10} />
                          <span>Café</span>
                        </span>
                      </div>
                    </div>
                    {/* Interaction Bar */}
                    <div className="absolute bottom-3 right-3 flex flex-col space-y-2">
                      <div className="w-8 h-8 bg-white/90 rounded-full flex items-center justify-center">
                        <Heart size={14} className="text-red-500" />
                      </div>
                      <div className="w-8 h-8 bg-white/90 rounded-full flex items-center justify-center">
                        <MessageSquare size={14} className="text-moodboard-muted-teal" />
                      </div>
                      <div className="w-8 h-8 bg-white/90 rounded-full flex items-center justify-center">
                        <Bookmark size={14} className="text-moodboard-gray-dark" />
                      </div>
                    </div>
                  </div>
                  <div className="p-3">
                    <h3 className="font-semibold text-sm text-moodboard-deep-green mb-1">Hidden Rooftop Café</h3>
                    <div className="flex items-center justify-between mt-2 text-xs">
                      <span className="flex items-center space-x-1 text-moodboard-gray-dark">
                        <MapPin size={8} />
                        <span>Downtown</span>
                      </span>
                      <span className="flex items-center space-x-1 text-red-500">
                        <Heart size={8} />
                        <span>89</span>
                      </span>
                    </div>
                  </div>
                </div>

                {/* Local Gem Card 2 - Trail */}
                <div className="card-modern overflow-hidden transform hover:scale-105 transition-all duration-300">
                  <div className="relative">
                    <div className="aspect-[4/3] overflow-hidden">
                      <ImageWithFallback
                        src="https://images.unsplash.com/photo-1441974231531-c6227db76b6e?w=300&h=200&fit=crop"
                        alt="Secret trail"
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="absolute top-3 left-3">
                      <div className="bg-moodboard-warm-beige/90 backdrop-blur-sm px-2 py-1 rounded-full border border-white/20">
                        <span className="text-moodboard-deep-green text-xs font-semibold flex items-center space-x-1">
                          <TreePine size={10} />
                          <span>Trail</span>
                        </span>
                      </div>
                    </div>
                  </div>
                  <div className="p-3">
                    <h3 className="font-semibold text-sm text-moodboard-deep-green mb-1">Secret Mountain Trail</h3>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Content Section */}
          <div className="bg-white/95 backdrop-blur-xl border-t border-moodboard-muted-teal/20 p-8">
            <div className="text-center space-y-4 max-w-sm mx-auto">
              <div>
                <div className="space-y-3 text-left">
                  <div className="flex items-start space-x-3">
                    <div className="w-2 h-2 bg-moodboard-muted-teal rounded-full mt-2 flex-shrink-0"></div>
                    <p className="text-moodboard-charcoal">Post cool spots instantly</p>
                  </div>
                  <div className="flex items-start space-x-3">
                    <div className="w-2 h-2 bg-moodboard-muted-teal rounded-full mt-2 flex-shrink-0"></div>
                    <p className="text-moodboard-charcoal">Add tags and locations</p>
                  </div>
                  <div className="flex items-start space-x-3">
                    <div className="w-2 h-2 bg-moodboard-muted-teal rounded-full mt-2 flex-shrink-0"></div>
                    <p className="text-moodboard-charcoal">Others can save to their bucket list</p>
                  </div>
                </div>
              </div>

              <button
                onClick={nextSlide}
                disabled={isAnimating}
                className="w-full btn-moodboard-primary flex items-center justify-center space-x-2 disabled:opacity-50"
              >
                <span>Next</span>
                <ArrowRight size={20} />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Slide 5: Creator Monetization (Conditional) */}
      {accountType === 'creator' && (
        <div 
          className={`absolute inset-0 transition-all duration-500 ease-out ${
            currentSlide === 4 
              ? 'translate-x-0 opacity-100' 
              : currentSlide < 4 
                ? 'translate-x-full opacity-0'
                : '-translate-x-full opacity-0'
          }`}
        >
          <div className="h-full flex flex-col justify-center items-center p-8 text-center">
            {/* Money Icon */}
            <div className="relative mb-12">
              <div className="w-32 h-32 bg-gradient-to-br from-moodboard-warm-beige to-moodboard-warm-beige-dark rounded-full flex items-center justify-center shadow-brand-secondary mx-auto animate-bounceIn">
                <span className="text-6xl">💸</span>
              </div>
              
              {/* Floating elements */}
              <div className="absolute -top-4 -left-4 w-8 h-8 bg-moodboard-muted-teal/20 rounded-full flex items-center justify-center animate-pulse">
                <DollarSign size={16} className="text-moodboard-muted-teal" />
              </div>
              <div className="absolute -bottom-6 -right-2 w-10 h-10 bg-moodboard-warm-beige/20 rounded-full flex items-center justify-center animate-pulse" style={{ animationDelay: '0.5s' }}>
                <span className="text-xl">💰</span>
              </div>
            </div>

            {/* Content */}
            <div className="space-y-6 max-w-sm">
              <div>
                <h1 className="text-3xl font-bold text-moodboard-deep-green mb-4">
                  Creators Earn More
                </h1>
                <p className="text-moodboard-charcoal leading-relaxed">
                  Add 'Book Now' links to experiences and earn when people book.
                </p>
              </div>

              {/* Button Mockup Overlay */}
              <div className="bg-white/80 rounded-xl p-4 border border-moodboard-warm-beige/30">
                <div className="relative">
                  <div className="aspect-[4/3] bg-gray-200 rounded-lg mb-3 overflow-hidden">
                    <ImageWithFallback
                      src="https://images.unsplash.com/photo-1571896349842-33c89424de2d?w=300&h=200&fit=crop"
                      alt="Beach experience"
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <h3 className="font-semibold text-sm text-moodboard-deep-green mb-2">Beachside Resort Stay</h3>
                  <div className="bg-moodboard-warm-beige text-moodboard-deep-green px-4 py-2 rounded-lg font-semibold text-center">
                    Book Now - Earn 10%
                  </div>
                </div>
              </div>

              <button
                onClick={nextSlide}
                disabled={isAnimating}
                className="w-full btn-moodboard-primary text-lg py-4 flex items-center justify-center space-x-2 disabled:opacity-50"
              >
                <span>Next</span>
                <ArrowRight size={24} />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Final Slide: Start Planning */}
      <div 
        className={`absolute inset-0 transition-all duration-500 ease-out ${
          currentSlide === (accountType === 'creator' ? 5 : 4)
            ? 'translate-x-0 opacity-100' 
            : '-translate-x-full opacity-0'
        }`}
      >
        <div className="h-full flex flex-col justify-center items-center p-8 text-center">
          {/* Calendar Icon */}
          <div className="relative mb-12">
            <div className="w-32 h-32 bg-gradient-to-br from-moodboard-muted-teal to-moodboard-muted-teal-light rounded-full flex items-center justify-center shadow-brand mx-auto animate-bounceIn">
              <span className="text-6xl">📅</span>
            </div>
            
            {/* Floating success elements */}
            <div className="absolute -top-4 -left-4 w-8 h-8 bg-moodboard-warm-beige/30 rounded-full flex items-center justify-center animate-pulse">
              <span className="text-lg">✨</span>
            </div>
            <div className="absolute -top-2 -right-6 w-6 h-6 bg-moodboard-muted-teal/20 rounded-full flex items-center justify-center animate-pulse" style={{ animationDelay: '0.5s' }}>
              <span className="text-sm">🌟</span>
            </div>
            <div className="absolute -bottom-6 -right-2 w-10 h-10 bg-moodboard-warm-beige/20 rounded-full flex items-center justify-center animate-pulse" style={{ animationDelay: '1s' }}>
              <span className="text-xl">🎊</span>
            </div>
          </div>

          {/* Content */}
          <div className="space-y-6 max-w-sm">
            <div>
              <h1 className="text-3xl font-bold text-moodboard-deep-green mb-4">
                Ready to Build Your Trip?
              </h1>
              <p className="text-moodboard-charcoal leading-relaxed">
                Use your bucket list to start a new Travel Card draft. Share it when you're done.
              </p>
            </div>

            <button
              onClick={onComplete}
              disabled={isAnimating}
              className="w-full btn-moodboard-primary text-lg py-4 flex items-center justify-center space-x-2 disabled:opacity-50 shadow-brand"
            >
              <span>Get Started</span>
              <ArrowRight size={24} />
            </button>
          </div>
        </div>
      </div>

      {/* Progress Indicators */}
      <div className="fixed bottom-8 left-1/2 transform -translate-x-1/2 z-10">
        <div className="flex items-center space-x-3 bg-white/90 backdrop-blur-sm px-4 py-3 rounded-full border border-moodboard-muted-teal/20 shadow-sm">
          {Array.from({ length: totalSlides }).map((_, index) => (
            <button
              key={index}
              onClick={() => goToSlide(index)}
              disabled={isAnimating}
              className={`transition-all duration-300 ${
                index === currentSlide 
                  ? 'w-8 h-3 bg-gradient-to-r from-moodboard-muted-teal to-moodboard-muted-teal-light rounded-full' 
                  : 'w-3 h-3 bg-moodboard-gray-light/60 rounded-full hover:bg-moodboard-gray-light'
              }`}
              aria-label={`Go to slide ${index + 1}`}
            />
          ))}
        </div>
      </div>
    </div>
  );
}