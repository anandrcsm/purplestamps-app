import { useState, useEffect } from 'react';
import { ArrowLeft, Camera, MapPin, Users, Plane, Plus, Image as ImageIcon, Video, Type, Calendar, Save, Trash2, Edit3 } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface CreatePageProps {
  onBack: () => void;
  onPublish: (content: any) => void;
  onSaveDraft: (content: any) => void;
  onSaveLocalGemDraft: (draft: any) => void;
  onLoadLocalGemDraft: (draft: any) => void;
  onDeleteLocalGemDraft: (draftId: string) => void;
  userAccountType: 'user' | 'creator';
  userInstagramData?: any;
  travelCardDrafts: any[];
  localGemDrafts: any[];
  currentUserId: string;
  onCreateTravelCard?: () => void;
}

export function CreatePage({ 
  onBack, 
  onPublish, 
  onSaveDraft, 
  onSaveLocalGemDraft,
  onLoadLocalGemDraft,
  onDeleteLocalGemDraft,
  userAccountType, 
  userInstagramData, 
  travelCardDrafts,
  localGemDrafts,
  currentUserId,
  onCreateTravelCard 
}: CreatePageProps) {
  const [selectedType, setSelectedType] = useState<'travelCard' | 'localGem' | 'story' | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Local Gem creation state
  const [gemImage, setGemImage] = useState<string>('');
  const [gemTitle, setGemTitle] = useState('');
  const [gemDescription, setGemDescription] = useState('');
  const [gemLocation, setGemLocation] = useState('');
  const [gemCategory, setGemCategory] = useState('restaurant');
  const [gemTags, setGemTags] = useState<string[]>([]);

  // Story creation state
  const [storyImage, setStoryImage] = useState<string>('');
  const [storyCaption, setStoryCaption] = useState('');
  const [storyLocation, setStoryLocation] = useState('');

  const categories = [
    { id: 'restaurant', label: 'Restaurant', icon: '🍽️' },
    { id: 'cafe', label: 'Café', icon: '☕' },
    { id: 'attraction', label: 'Attraction', icon: '🏛️' },
    { id: 'nature', label: 'Nature', icon: '🌿' },
    { id: 'shopping', label: 'Shopping', icon: '🛍️' },
    { id: 'nightlife', label: 'Nightlife', icon: '🌙' },
    { id: 'activity', label: 'Activity', icon: '🎯' },
    { id: 'accommodation', label: 'Stay', icon: '🏨' },
  ];

  const popularTags = [
    'Hidden Gem', 'Local Favorite', 'Instagram Worthy', 'Budget Friendly', 
    'Family Friendly', 'Date Night', 'Solo Travel', 'Group Activity',
    'Authentic', 'Unique Experience', 'Must Visit', 'Off the Beaten Path'
  ];

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>, type: 'gem' | 'story') => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        if (type === 'gem') {
          setGemImage(reader.result as string);
        } else {
          setStoryImage(reader.result as string);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const toggleTag = (tag: string) => {
    setGemTags(prev => 
      prev.includes(tag) 
        ? prev.filter(t => t !== tag)
        : [...prev, tag]
    );
  };

  const handleSaveLocalGemDraft = async () => {
    if (!gemTitle.trim() && !gemLocation.trim() && !gemImage && !gemDescription.trim()) {
      showToast('Please add some content before saving as draft', 'error');
      return;
    }
    
    setIsSubmitting(true);
    
    const draft = {
      id: `gem-draft-${Date.now()}`,
      title: gemTitle,
      description: gemDescription,
      location: gemLocation,
      category: gemCategory,
      tags: gemTags,
      image: gemImage,
      userId: currentUserId,
      lastUpdated: new Date().toISOString(),
      isDraft: true
    };

    await new Promise(resolve => setTimeout(resolve, 500));
    onSaveLocalGemDraft(draft);
    showToast('Local gem draft saved successfully!', 'success');
    setIsSubmitting(false);
  };

  const handlePublishLocalGem = async () => {
    if (!gemImage || !gemTitle.trim() || !gemLocation.trim()) return;
    
    setIsSubmitting(true);
    
    const localGem = {
      id: `gem-${Date.now()}`,
      title: gemTitle,
      description: gemDescription,
      location: gemLocation,
      category: gemCategory,
      tags: gemTags,
      image: gemImage,
      userId: currentUserId,
      userName: 'You',
      userAvatar: 'https://images.unsplash.com/photo-1494790108755-2616b612c1c?w=100&h=100&fit=crop&crop=face',
      timestamp: 'Just now',
      likes: 0,
      comments: 0,
      isLiked: false,
      rating: 4.8,
      priceRange: '$',
      isOpen: true,
      distance: '0.1 km'
    };

    await new Promise(resolve => setTimeout(resolve, 1000));
    onPublish(localGem);
    setIsSubmitting(false);
  };

  const loadDraftData = (draft: any) => {
    setGemTitle(draft.title);
    setGemDescription(draft.description);
    setGemLocation(draft.location);
    setGemCategory(draft.category);
    setGemTags(draft.tags);
    setGemImage(draft.image);
    showToast('Draft loaded successfully!', 'success');
  };

  const clearForm = () => {
    setGemTitle('');
    setGemDescription('');
    setGemLocation('');
    setGemCategory('restaurant');
    setGemTags([]);
    setGemImage('');
  };

  const showToast = (message: string, type: 'success' | 'error' = 'success') => {
    const styles = {
      success: 'bg-moodboard-cream border-moodboard-muted-teal text-moodboard-deep-green shadow-brand',
      error: 'bg-moodboard-cream border-red-300 text-red-800 shadow-lg'
    };

    const toast = document.createElement('div');
    toast.className = `fixed top-20 left-1/2 transform -translate-x-1/2 ${styles[type]} border px-4 py-3 rounded-xl z-50 backdrop-blur-sm animate-slideDown max-w-sm`;
    toast.innerHTML = `
      <div class="flex items-center space-x-3">
        <span class="font-medium text-sm">${message}</span>
      </div>
    `;
    document.body.appendChild(toast);
    setTimeout(() => {
      toast.style.opacity = '0';
      setTimeout(() => document.body.removeChild(toast), 300);
    }, 3000);
  };

  const handlePublishStory = async () => {
    if (!storyImage || !storyCaption.trim()) return;
    
    setIsSubmitting(true);
    
    const story = {
      id: `story-${Date.now()}`,
      userId: currentUserId,
      userName: 'You',
      userAvatar: 'https://images.unsplash.com/photo-1494790108755-2616b612c1c?w=100&h=100&fit=crop&crop=face',
      preview: storyImage,
      content: [{
        id: 'sc1',
        type: 'image',
        url: storyImage,
        caption: storyCaption,
        timestamp: 'Just now'
      }],
      timestamp: 'Just now',
      isLive: false,
      location: storyLocation,
      isViewed: false,
      viewCount: 0,
      expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString()
    };

    await new Promise(resolve => setTimeout(resolve, 1000));
    onPublish(story);
    setIsSubmitting(false);
  };

  const renderTypeSelection = () => (
    <div className="space-y-6">
      <div className="text-center mb-8">
        <h2 className="text-xl font-semibold text-moodboard-deep-green mb-2">What do you want to create?</h2>
        <p className="text-moodboard-gray-dark">Choose the type of content you'd like to share</p>
      </div>

      <div className="space-y-4">
        {/* Travel Card - Featured Option */}
        <div 
          onClick={onCreateTravelCard}
          className="group p-6 bg-gradient-to-br from-moodboard-muted-teal to-moodboard-muted-teal-light rounded-2xl cursor-pointer transition-all duration-300 hover:scale-[1.02] active:scale-98 shadow-brand"
        >
          <div className="flex items-center space-x-4">
            <div className="p-3 bg-white/20 rounded-xl backdrop-blur-sm">
              <Plane size={28} className="text-white" />
            </div>
            <div className="flex-1">
              <h3 className="text-lg font-semibold text-white mb-1">Create Travel Card</h3>
              <p className="text-white/80 text-sm">Complete travel experience with itinerary, photos, and tips</p>
            </div>
            <div className="bg-white/20 backdrop-blur-sm rounded-full p-2">
              <Plus size={20} className="text-white" />
            </div>
          </div>
        </div>

        {/* Local Gem */}
        <div 
          onClick={() => setSelectedType('localGem')}
          className="group p-5 bg-white rounded-xl border border-moodboard-gray-light/20 cursor-pointer transition-all duration-300 hover:shadow-lg hover:border-moodboard-muted-teal/30 active:scale-98"
        >
          <div className="flex items-center space-x-4">
            <div className="p-3 bg-moodboard-warm-beige/20 rounded-xl">
              <MapPin size={24} className="text-moodboard-muted-teal" />
            </div>
            <div className="flex-1">
              <h3 className="font-semibold text-moodboard-deep-green mb-1">Share Local Gem</h3>
              <p className="text-moodboard-gray-dark text-sm">Recommend a hidden spot or local favorite</p>
            </div>
          </div>
        </div>

        {/* Story */}
        <div 
          onClick={() => setSelectedType('story')}
          className="group p-5 bg-white rounded-xl border border-moodboard-gray-light/20 cursor-pointer transition-all duration-300 hover:shadow-lg hover:border-moodboard-muted-teal/30 active:scale-98"
        >
          <div className="flex items-center space-x-4">
            <div className="p-3 bg-moodboard-warm-beige/20 rounded-xl">
              <Camera size={24} className="text-moodboard-muted-teal" />
            </div>
            <div className="flex-1">
              <h3 className="font-semibold text-moodboard-deep-green mb-1">Add to Story</h3>
              <p className="text-moodboard-gray-dark text-sm">Share a moment from your current adventure</p>
            </div>
          </div>
        </div>
      </div>

      {/* Draft Cards Preview */}
      {travelCardDrafts.length > 0 && (
        <div className="mt-8 p-4 bg-moodboard-warm-beige/10 rounded-xl border border-moodboard-warm-beige/30">
          <div className="flex items-center justify-between mb-3">
            <h4 className="font-medium text-moodboard-deep-green">Continue Working On</h4>
            <span className="text-sm text-moodboard-gray-dark">{travelCardDrafts.length} draft{travelCardDrafts.length > 1 ? 's' : ''}</span>
          </div>
          <div className="space-y-2">
            {travelCardDrafts.slice(0, 2).map(draft => (
              <div key={draft.id} className="flex items-center space-x-3 p-3 bg-white rounded-lg">
                <ImageWithFallback
                  src={draft.coverImage}
                  alt={draft.title}
                  className="w-12 h-12 object-cover rounded-lg"
                />
                <div className="flex-1">
                  <h5 className="font-medium text-moodboard-deep-green text-sm">{draft.title}</h5>
                  <p className="text-xs text-moodboard-gray-dark">{draft.completionPercentage}% complete</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );

  const renderLocalGemForm = () => (
    <div className="space-y-6">
      <div className="text-center mb-6">
        <h2 className="text-xl font-semibold text-moodboard-deep-green mb-2">Share a Local Gem</h2>
        <p className="text-moodboard-gray-dark">Help fellow travelers discover amazing places</p>
      </div>

      {/* Image Upload */}
      <div className="space-y-3">
        <label className="block font-medium text-moodboard-deep-green">Photo</label>
        <div 
          onClick={() => document.getElementById('gem-image-input')?.click()}
          className="relative w-full h-48 bg-moodboard-gray-light/20 border-2 border-dashed border-moodboard-gray-light rounded-xl cursor-pointer hover:border-moodboard-muted-teal transition-colors group"
        >
          {gemImage ? (
            <ImageWithFallback 
              src={gemImage} 
              alt="Local gem" 
              className="w-full h-full object-cover rounded-xl"
            />
          ) : (
            <div className="absolute inset-0 flex flex-col items-center justify-center text-moodboard-gray-dark group-hover:text-moodboard-muted-teal transition-colors">
              <ImageIcon size={32} className="mb-2" />
              <span className="font-medium">Add Photo</span>
              <span className="text-sm">Tap to select from gallery</span>
            </div>
          )}
        </div>
        <input
          id="gem-image-input"
          type="file"
          accept="image/*"
          onChange={(e) => handleImageUpload(e, 'gem')}
          className="hidden"
        />
      </div>

      {/* Title */}
      <div className="space-y-3">
        <label className="block font-medium text-moodboard-deep-green">Place Name</label>
        <input
          type="text"
          value={gemTitle}
          onChange={(e) => setGemTitle(e.target.value)}
          placeholder="e.g., Secret Garden Café"
          className="w-full px-4 py-3 bg-white border border-moodboard-gray-light/30 rounded-xl focus:border-moodboard-muted-teal focus:outline-none transition-colors"
        />
      </div>

      {/* Location */}
      <div className="space-y-3">
        <label className="block font-medium text-moodboard-deep-green">Location</label>
        <input
          type="text"
          value={gemLocation}
          onChange={(e) => setGemLocation(e.target.value)}
          placeholder="e.g., Hidden alley behind Main Street"
          className="w-full px-4 py-3 bg-white border border-moodboard-gray-light/30 rounded-xl focus:border-moodboard-muted-teal focus:outline-none transition-colors"
        />
      </div>

      {/* Category */}
      <div className="space-y-3">
        <label className="block font-medium text-moodboard-deep-green">Category</label>
        <div className="grid grid-cols-2 gap-3">
          {categories.map((category) => (
            <button
              key={category.id}
              onClick={() => setGemCategory(category.id)}
              className={`p-3 rounded-xl text-left transition-colors ${
                gemCategory === category.id
                  ? 'bg-moodboard-muted-teal text-white'
                  : 'bg-moodboard-gray-light/20 text-moodboard-gray-dark hover:bg-moodboard-gray-light/30'
              }`}
            >
              <div className="flex items-center space-x-2">
                <span className="text-lg">{category.icon}</span>
                <span className="font-medium text-sm">{category.label}</span>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Description */}
      <div className="space-y-3">
        <label className="block font-medium text-moodboard-deep-green">Description</label>
        <textarea
          value={gemDescription}
          onChange={(e) => setGemDescription(e.target.value)}
          placeholder="What makes this place special? Share your experience..."
          rows={4}
          className="w-full px-4 py-3 bg-white border border-moodboard-gray-light/30 rounded-xl focus:border-moodboard-muted-teal focus:outline-none transition-colors resize-none"
        />
      </div>

      {/* Tags */}
      <div className="space-y-3">
        <label className="block font-medium text-moodboard-deep-green">Tags (Optional)</label>
        <div className="flex flex-wrap gap-2">
          {popularTags.map((tag) => (
            <button
              key={tag}
              onClick={() => toggleTag(tag)}
              className={`px-3 py-1.5 rounded-full text-sm font-medium transition-colors ${
                gemTags.includes(tag)
                  ? 'bg-moodboard-muted-teal text-white'
                  : 'bg-moodboard-gray-light/20 text-moodboard-gray-dark hover:bg-moodboard-gray-light/30'
              }`}
            >
              {tag}
            </button>
          ))}
        </div>
      </div>

      {/* Action Buttons */}
      <div className="space-y-3 pt-6">
        {/* Primary Actions */}
        <div className="flex space-x-3">
          <button
            onClick={() => setSelectedType(null)}
            className="px-6 py-4 border border-moodboard-gray-light text-moodboard-gray-dark rounded-xl hover:bg-moodboard-gray-light/10 transition-colors"
          >
            Back
          </button>
          <button
            onClick={handleSaveLocalGemDraft}
            disabled={isSubmitting}
            className="flex items-center justify-center space-x-2 px-6 py-4 bg-moodboard-warm-beige text-moodboard-deep-green rounded-xl hover:bg-moodboard-warm-beige-dark transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <Save size={18} />
            <span>{isSubmitting ? 'Saving...' : 'Save Draft'}</span>
          </button>
          <button
            onClick={handlePublishLocalGem}
            disabled={isSubmitting || !gemImage || !gemTitle.trim() || !gemLocation.trim()}
            className="flex-1 py-4 bg-moodboard-muted-teal text-white rounded-xl hover:bg-moodboard-muted-teal/90 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isSubmitting ? 'Publishing...' : 'Publish Gem'}
          </button>
        </div>

        {/* Clear Form Button */}
        {(gemTitle || gemDescription || gemLocation || gemImage || gemTags.length > 0) && (
          <button
            onClick={clearForm}
            className="w-full py-3 text-moodboard-gray-dark border border-dashed border-moodboard-gray-light rounded-xl hover:bg-moodboard-gray-light/10 transition-colors text-sm"
          >
            Clear Form
          </button>
        )}
      </div>

      {/* Saved Local Gem Drafts Section */}
      {localGemDrafts.length > 0 && (
        <div className="mt-8 pt-6 border-t border-moodboard-gray-light/20">
          <div className="flex items-center justify-between mb-4">
            <h4 className="font-semibold text-moodboard-deep-green">Saved Local Gem Drafts</h4>
            <span className="text-sm text-moodboard-gray-dark bg-moodboard-gray-light/20 px-2 py-1 rounded-full">
              {localGemDrafts.length}
            </span>
          </div>
          <div className="space-y-3">
            {localGemDrafts.map(draft => (
              <div key={draft.id} className="group p-4 bg-white rounded-xl border border-moodboard-gray-light/20 hover:shadow-md transition-all duration-200">
                <div className="flex items-start space-x-3">
                  {/* Draft Image */}
                  <div className="w-16 h-16 bg-moodboard-gray-light/20 rounded-lg overflow-hidden flex-shrink-0">
                    {draft.image ? (
                      <ImageWithFallback
                        src={draft.image}
                        alt={draft.title}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center">
                        <MapPin size={20} className="text-moodboard-gray-light" />
                      </div>
                    )}
                  </div>

                  {/* Draft Content */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between">
                      <div className="flex-1 min-w-0">
                        <h5 className="font-medium text-moodboard-deep-green text-sm truncate">
                          {draft.title || 'Untitled Local Gem'}
                        </h5>
                        <p className="text-xs text-moodboard-gray-dark mt-1 line-clamp-2">
                          {draft.location || 'Location not specified'} • {draft.description || 'No description'}
                        </p>
                        <div className="flex items-center mt-2 space-x-2">
                          <span className="text-xs px-2 py-1 bg-moodboard-muted-teal/10 text-moodboard-muted-teal rounded-full">
                            {categories.find(cat => cat.id === draft.category)?.label || 'Category'}
                          </span>
                          {draft.tags.length > 0 && (
                            <span className="text-xs text-moodboard-gray-dark">
                              +{draft.tags.length} tag{draft.tags.length > 1 ? 's' : ''}
                            </span>
                          )}
                        </div>
                        <p className="text-xs text-moodboard-gray-light mt-1">
                          Saved {new Date(draft.lastUpdated).toLocaleDateString()}
                        </p>
                      </div>

                      {/* Draft Actions */}
                      <div className="flex items-center space-x-2 ml-3 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button
                          onClick={() => loadDraftData(draft)}
                          className="p-2 text-moodboard-muted-teal hover:bg-moodboard-muted-teal/10 rounded-lg transition-colors"
                          title="Load Draft"
                        >
                          <Edit3 size={16} />
                        </button>
                        <button
                          onClick={() => onDeleteLocalGemDraft(draft.id)}
                          className="p-2 text-red-500 hover:bg-red-50 rounded-lg transition-colors"
                          title="Delete Draft"
                        >
                          <Trash2 size={16} />
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );

  const renderStoryForm = () => (
    <div className="space-y-6">
      <div className="text-center mb-6">
        <h2 className="text-xl font-semibold text-moodboard-deep-green mb-2">Add to Your Story</h2>
        <p className="text-moodboard-gray-dark">Share a moment from your adventure</p>
      </div>

      {/* Image Upload */}
      <div className="space-y-3">
        <label className="block font-medium text-moodboard-deep-green">Photo/Video</label>
        <div 
          onClick={() => document.getElementById('story-image-input')?.click()}
          className="relative w-full h-60 bg-moodboard-gray-light/20 border-2 border-dashed border-moodboard-gray-light rounded-xl cursor-pointer hover:border-moodboard-muted-teal transition-colors group"
        >
          {storyImage ? (
            <ImageWithFallback 
              src={storyImage} 
              alt="Story" 
              className="w-full h-full object-cover rounded-xl"
            />
          ) : (
            <div className="absolute inset-0 flex flex-col items-center justify-center text-moodboard-gray-dark group-hover:text-moodboard-muted-teal transition-colors">
              <div className="flex space-x-4 mb-3">
                <ImageIcon size={28} />
                <Video size={28} />
              </div>
              <span className="font-medium">Add Photo or Video</span>
              <span className="text-sm">Tap to select from gallery</span>
            </div>
          )}
        </div>
        <input
          id="story-image-input"
          type="file"
          accept="image/*,video/*"
          onChange={(e) => handleImageUpload(e, 'story')}
          className="hidden"
        />
      </div>

      {/* Caption */}
      <div className="space-y-3">
        <label className="block font-medium text-moodboard-deep-green">Caption</label>
        <textarea
          value={storyCaption}
          onChange={(e) => setStoryCaption(e.target.value)}
          placeholder="What's happening? Share your moment..."
          rows={3}
          className="w-full px-4 py-3 bg-white border border-moodboard-gray-light/30 rounded-xl focus:border-moodboard-muted-teal focus:outline-none transition-colors resize-none"
        />
      </div>

      {/* Location */}
      <div className="space-y-3">
        <label className="block font-medium text-moodboard-deep-green">Location (Optional)</label>
        <input
          type="text"
          value={storyLocation}
          onChange={(e) => setStoryLocation(e.target.value)}
          placeholder="e.g., Bali, Indonesia"
          className="w-full px-4 py-3 bg-white border border-moodboard-gray-light/30 rounded-xl focus:border-moodboard-muted-teal focus:outline-none transition-colors"
        />
      </div>

      {/* Action Buttons */}
      <div className="flex space-x-3 pt-6">
        <button
          onClick={() => setSelectedType(null)}
          className="flex-1 py-4 border border-moodboard-gray-light text-moodboard-gray-dark rounded-xl hover:bg-moodboard-gray-light/10 transition-colors"
        >
          Back
        </button>
        <button
          onClick={handlePublishStory}
          disabled={isSubmitting || !storyImage || !storyCaption.trim()}
          className="flex-1 py-4 bg-moodboard-muted-teal text-white rounded-xl hover:bg-moodboard-muted-teal/90 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {isSubmitting ? 'Adding...' : 'Add to Story'}
        </button>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-surface-warm">
      {/* Header */}
      <div className="sticky top-0 z-50 bg-surface-warm/95 backdrop-blur-sm border-b border-moodboard-gray-light/20">
        <div className="flex items-center justify-between p-4">
          <button
            onClick={selectedType ? () => setSelectedType(null) : onBack}
            className="p-2 hover:bg-moodboard-gray-light/20 rounded-xl transition-colors"
          >
            <ArrowLeft size={24} className="text-moodboard-deep-green" />
          </button>
          
          <h1 className="font-semibold text-moodboard-deep-green">Create</h1>
          
          <div className="w-10" /> {/* Spacer */}
        </div>
      </div>

      {/* Content */}
      <div className="page-container pb-8">
        {!selectedType && renderTypeSelection()}
        {selectedType === 'localGem' && renderLocalGemForm()}
        {selectedType === 'story' && renderStoryForm()}
      </div>
    </div>
  );
}