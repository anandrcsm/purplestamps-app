import { useState } from 'react';
import { Heart, MoreHorizontal, Send } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface Comment {
  id: string;
  userId: string;
  userName: string;
  userAvatar: string;
  text: string;
  timestamp: string;
  likes: number;
  isLiked: boolean;
}

interface CommentSectionProps {
  contentId: string;
  contentType: 'travel-card' | 'moment' | 'local-gem';
  comments: Comment[];
  totalComments: number;
  onAddComment: (text: string) => void;
  onLikeComment: (commentId: string) => void;
}

export function CommentSection({
  contentId,
  contentType,
  comments = [],
  totalComments = 0,
  onAddComment,
  onLikeComment
}: CommentSectionProps) {
  const [commentText, setCommentText] = useState('');
  const [showAllComments, setShowAllComments] = useState(false);

  const handleSubmitComment = () => {
    if (commentText.trim()) {
      onAddComment(commentText.trim());
      setCommentText('');
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmitComment();
    }
  };

  const visibleComments = showAllComments ? comments : comments.slice(0, 2);
  const remainingComments = Math.max(0, totalComments - 2);

  return (
    <div className="bg-white border-t border-gray-100">
      {/* Comments Header */}
      {totalComments > 0 && (
        <div className="px-4 py-3 border-b border-gray-50">
          <div className="flex items-center justify-between">
            <span className="text-sm font-semibold text-gray-900">
              {totalComments === 1 ? '1 comment' : `${totalComments.toLocaleString()} comments`}
            </span>
            {remainingComments > 0 && !showAllComments && (
              <button
                onClick={() => setShowAllComments(true)}
                className="text-sm text-gray-600 hover:text-gray-900 transition-colors"
              >
                View all {remainingComments} comments
              </button>
            )}
          </div>
        </div>
      )}

      {/* Comments List */}
      <div className="max-h-96 overflow-y-auto">
        {visibleComments.map((comment, index) => (
          <div
            key={comment.id}
            className={`px-4 py-3 ${index !== visibleComments.length - 1 ? 'border-b border-gray-50' : ''}`}
          >
            <div className="flex items-start space-x-3">
              {/* User Avatar */}
              <div className="flex-shrink-0">
                <div className="w-8 h-8 rounded-full overflow-hidden">
                  <ImageWithFallback
                    src={comment.userAvatar}
                    alt={comment.userName}
                    className="w-full h-full object-cover"
                  />
                </div>
              </div>

              {/* Comment Content */}
              <div className="flex-1 min-w-0">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center space-x-2 mb-1">
                      <span className="text-sm font-semibold text-gray-900">
                        {comment.userName}
                      </span>
                      <span className="text-xs text-gray-500">
                        {comment.timestamp}
                      </span>
                    </div>
                    <p className="text-sm text-gray-800 leading-relaxed">
                      {comment.text}
                    </p>
                  </div>

                  {/* Comment Actions */}
                  <div className="flex items-center space-x-2 ml-3">
                    <button
                      onClick={() => onLikeComment(comment.id)}
                      className={`p-1 rounded-full transition-all duration-200 hover:bg-gray-100 ${
                        comment.isLiked ? 'text-red-500' : 'text-gray-400'
                      }`}
                    >
                      <Heart
                        size={14}
                        className={comment.isLiked ? 'fill-current' : ''}
                      />
                    </button>
                    <button className="p-1 rounded-full transition-colors hover:bg-gray-100">
                      <MoreHorizontal size={14} className="text-gray-400" />
                    </button>
                  </div>
                </div>

                {/* Like Count */}
                {comment.likes > 0 && (
                  <div className="mt-2">
                    <span className="text-xs text-gray-500">
                      {comment.likes === 1 ? '1 like' : `${comment.likes} likes`}
                    </span>
                  </div>
                )}
              </div>
            </div>
          </div>
        ))}

        {/* Empty State */}
        {comments.length === 0 && (
          <div className="px-4 py-8 text-center">
            <p className="text-sm text-gray-500">
              No comments yet. Be the first to share your thoughts!
            </p>
          </div>
        )}
      </div>

      {/* Add Comment Input - Sticky Bottom */}
      <div className="sticky bottom-0 bg-white border-t border-gray-100 px-4 py-3">
        <div className="flex items-center space-x-3">
          {/* Current User Avatar */}
          <div className="flex-shrink-0">
            <div className="w-8 h-8 rounded-full overflow-hidden">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=50&h=50&fit=crop&crop=face"
                alt="Your profile"
                className="w-full h-full object-cover"
              />
            </div>
          </div>

          {/* Comment Input */}
          <div className="flex-1 relative">
            <textarea
              value={commentText}
              onChange={(e) => setCommentText(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Add a comment..."
              className="w-full px-4 py-2.5 bg-gray-50 rounded-full border border-transparent resize-none focus:outline-none focus:ring-2 focus:ring-brand-primary focus:border-transparent placeholder-gray-500 text-sm max-h-20 scrollbar-hide"
              rows={1}
            />
          </div>

          {/* Send Button */}
          <button
            onClick={handleSubmitComment}
            disabled={!commentText.trim()}
            className={`flex-shrink-0 p-2 rounded-full transition-all duration-200 ${
              commentText.trim()
                ? 'bg-brand-primary text-white hover:bg-brand-primary-dark hover:scale-105 active:scale-95'
                : 'bg-gray-100 text-gray-400 cursor-not-allowed'
            }`}
          >
            <Send size={16} />
          </button>
        </div>

        {/* Character limit indicator (optional) */}
        {commentText.length > 200 && (
          <div className="flex justify-end mt-2">
            <span className={`text-xs ${commentText.length > 280 ? 'text-red-500' : 'text-gray-400'}`}>
              {commentText.length}/300
            </span>
          </div>
        )}
      </div>
    </div>
  );
}