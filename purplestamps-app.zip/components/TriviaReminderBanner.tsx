import { Brain, Trophy, Star, Target, ArrowRight, Zap, Clock } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface TriviaReminderBannerProps {
  onNavigateToTrivia: () => void;
}

export function TriviaReminderBanner({ onNavigateToTrivia }: TriviaReminderBannerProps) {
  const triviaStats = {
    questionsAnswered: 47,
    streak: 5,
    rank: 'Cultural Explorer',
    pointsToNext: 320
  };

  const recentAchievements = [
    { icon: '🌍', title: 'Global Explorer', description: 'Completed 10 country quizzes' },
    { icon: '🍜', title: 'Food Culture Expert', description: 'Mastered Asian cuisine trivia' },
    { icon: '🎭', title: 'Festival Scholar', description: 'Learned about 15 cultural festivals' }
  ];

  return (
    <div className="px-4">
      <div className="bg-gradient-to-br from-purple-500/10 via-brand-primary/10 to-brand-secondary/10 rounded-2xl p-6 border border-brand-primary/20 overflow-hidden relative shadow-sm hover:shadow-md transition-all duration-200">
        {/* Animated Background Elements */}
        <div className="absolute top-0 right-0 w-40 h-40 bg-gradient-to-br from-purple-500/5 to-brand-primary/5 rounded-full transform translate-x-20 -translate-y-20 animate-pulse"></div>
        <div className="absolute bottom-0 left-0 w-32 h-32 bg-gradient-brand-secondary/5 rounded-full transform -translate-x-16 translate-y-16"></div>
        
        {/* Header with Progress */}
        <div className="flex items-start justify-between mb-6 relative z-10">
          <div className="flex items-center space-x-4">
            <div className="relative">
              <div className="w-14 h-14 bg-gradient-to-br from-purple-500 to-brand-primary rounded-2xl flex items-center justify-center shadow-lg">
                <Brain size={28} className="text-white" />
              </div>
              <div className="absolute -top-1 -right-1 w-6 h-6 bg-yellow-400 rounded-full flex items-center justify-center border-2 border-white shadow-sm">
                <Zap size={12} className="text-white" />
              </div>
            </div>
            <div>
              <h2 className="text-xl font-bold text-gray-900">Cultural Quest</h2>
              <div className="flex items-center space-x-3 mt-1">
                <p className="text-sm text-gray-600">{triviaStats.questionsAnswered} questions completed</p>
                <div className="flex items-center space-x-1">
                  <Star size={14} className="text-yellow-500 fill-current" />
                  <span className="text-sm font-bold text-brand-primary">{triviaStats.streak} day streak!</span>
                </div>
              </div>
            </div>
          </div>
          <div className="text-right bg-white/50 px-3 py-2 rounded-xl backdrop-blur-sm">
            <p className="text-xs text-gray-500 font-medium">Current Rank</p>
            <p className="font-bold text-brand-primary">{triviaStats.rank}</p>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="mb-6 relative z-10">
          <div className="flex items-center justify-between mb-3">
            <p className="text-sm text-gray-700 font-medium">Progress to next level</p>
            <p className="text-sm font-bold text-gray-900">{triviaStats.pointsToNext} points to go</p>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-3 overflow-hidden shadow-inner">
            <div className="bg-gradient-to-r from-purple-500 to-brand-primary h-3 rounded-full animate-pulse shadow-sm" style={{ width: '68%' }}></div>
          </div>
        </div>

        {/* Achievement Preview */}
        <div className="bg-white/90 backdrop-blur-sm rounded-2xl p-5 mb-6 border border-white/50 relative z-10 shadow-sm">
          <div className="flex items-center space-x-2 mb-4">
            <Trophy size={18} className="text-yellow-500" />
            <span className="text-sm font-bold text-gray-900">Recent Achievements</span>
          </div>
          <div className="flex space-x-3 overflow-x-auto scrollbar-hide">
            {recentAchievements.map((achievement, index) => (
              <div
                key={index}
                className="flex-shrink-0 bg-gradient-to-br from-brand-primary/5 to-brand-secondary/5 rounded-xl p-4 min-w-[150px] border border-brand-primary/10 shadow-sm"
              >
                <div className="text-center">
                  <div className="text-3xl mb-2">{achievement.icon}</div>
                  <p className="text-xs font-bold text-gray-900 line-clamp-1 mb-1">{achievement.title}</p>
                  <p className="text-xs text-gray-600 line-clamp-2">{achievement.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Today's Challenge */}
        <div className="bg-gradient-to-r from-brand-primary/20 to-brand-secondary/20 rounded-2xl p-5 mb-6 border border-brand-primary/30 relative z-10 shadow-sm">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="w-12 h-12 bg-gradient-brand rounded-2xl flex items-center justify-center shadow-sm">
                <Target size={20} className="text-white" />
              </div>
              <div>
                <p className="font-bold text-gray-900">Today's Challenge</p>
                <p className="text-sm text-gray-600 font-medium">Asian Festival Traditions Quiz</p>
              </div>
            </div>
            <div className="text-right">
              <div className="flex items-center space-x-1 text-brand-primary mb-1">
                <Star size={16} className="fill-current" />
                <span className="text-sm font-bold">+50 XP</span>
              </div>
              <div className="flex items-center space-x-1 text-gray-600">
                <Clock size={12} />
                <p className="text-xs font-medium">5 questions</p>
              </div>
            </div>
          </div>
        </div>

        {/* Action Button */}
        <button
          onClick={onNavigateToTrivia}
          className="w-full bg-gradient-to-r from-purple-500 to-brand-primary text-white py-5 px-6 rounded-2xl font-bold text-lg hover:shadow-xl hover:scale-[1.02] transition-all duration-200 active:scale-95 flex items-center justify-center space-x-3 relative z-10 shadow-lg"
        >
          <Brain size={28} />
          <span>Continue Cultural Quest</span>
          <ArrowRight size={24} />
        </button>

        {/* Quick Stats Footer */}
        <div className="flex items-center justify-center space-x-8 mt-6 pt-6 border-t border-white/30 relative z-10">
          <div className="text-center">
            <div className="flex items-center justify-center space-x-1 mb-2">
              <Brain size={14} className="text-brand-primary" />
              <p className="text-lg font-bold text-gray-900">{triviaStats.questionsAnswered}</p>
            </div>
            <p className="text-xs text-gray-600 font-medium">Questions</p>
          </div>
          <div className="text-center">
            <div className="flex items-center justify-center space-x-1 mb-2">
              <Zap size={14} className="text-yellow-500" />
              <p className="text-lg font-bold text-gray-900">{triviaStats.streak}</p>
            </div>
            <p className="text-xs text-gray-600 font-medium">Day Streak</p>
          </div>
          <div className="text-center">
            <div className="flex items-center justify-center space-x-1 mb-2">
              <Trophy size={14} className="text-yellow-500" />
              <p className="text-lg font-bold text-gray-900">12</p>
            </div>
            <p className="text-xs text-gray-600 font-medium">Badges</p>
          </div>
        </div>
      </div>
    </div>
  );
}