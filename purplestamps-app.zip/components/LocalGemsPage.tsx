import { useState } from 'react';
import { Search, MapPin, Heart, MessageCircle, Share, Bookmark, Camera, Compass, Calendar, MoreHorizontal, ChevronDown } from 'lucide-react';
import { mockLocalGems } from '../data/localGemsData';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { SwipeUpCommentSheet } from './SwipeUpCommentSheet';

interface LocalGemsPageProps {
  onSaveToWishlist: (id: string) => void;
  onSelectUser: (userId: string) => void;
  savedGems: string[];
  localGems: any[];
}

// Mock user data for Local Gems - similar to Moments
const mockGemUsers = [
  {
    id: 'user1',
    name: 'Maria Santos',
    avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=50&h=50&fit=crop&crop=face',
    isLocal: true
  },
  {
    id: 'user2', 
    name: 'James Chen',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=50&h=50&fit=crop&crop=face',
    isLocal: true
  },
  {
    id: 'user3',
    name: 'Sophie Laurent',
    avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=50&h=50&fit=crop&crop=face',
    isLocal: false
  },
  {
    id: 'user4',
    name: 'David Kim',
    avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=50&h=50&fit=crop&crop=face',
    isLocal: true
  },
  {
    id: 'user5',
    name: 'Elena Rodriguez',
    avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612e2fa?w=50&h=50&fit=crop&crop=face',
    isLocal: true
  }
];

export function LocalGemsPage({ onSaveToWishlist, onSelectUser, savedGems, localGems }: LocalGemsPageProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [likedGems, setLikedGems] = useState<Set<string>>(new Set());
  const [selectedGemComments, setSelectedGemComments] = useState<string | null>(null);
  const [gemComments, setGemComments] = useState<{[key: string]: any[]}>({});
  const [expandedCaptions, setExpandedCaptions] = useState<Set<string>>(new Set());
  const [showSearchInput, setShowSearchInput] = useState(false);
  const [searchInput, setSearchInput] = useState('');
  const [showCitySuggestions, setShowCitySuggestions] = useState(false);

  const categories = [
    'all',
    'Restaurant',
    'Activity',
    'Viewpoint',
    'Cafe',
    'Market',
    'Shopping',
    'Bar',
    'Nature'
  ];

  // Popular cities for search suggestions
  const popularCities = [
    'Barcelona, Spain',
    'Tokyo, Japan',
    'Amsterdam, Netherlands',
    'Bali, Indonesia',
    'New York, USA',
    'Paris, France',
    'Reykjavik, Iceland',
    'London, UK',
    'Santorini, Greece',
    'Brooklyn, USA',
    'Kyoto, Japan',
    'Atacama, Chile',
    'Mexico City, Mexico',
    'Chengdu, China',
    'Berlin, Germany',
    'Helsinki, Finland',
    'Marrakech, Morocco',
    'Bogota, Colombia',
    'Ubud, Bali',
    'Mykonos, Greece',
    'Florence, Italy',
    'Vieques, Puerto Rico',
    'Prague, Czech Republic',
    'Cape Town, South Africa',
    'Mumbai, India',
    'Dubai, UAE',
    'Bangkok, Thailand',
    'Istanbul, Turkey',
    'Rome, Italy',
    'Sydney, Australia'
  ];

  const filteredGems = localGems.filter(gem => {
    const searchTerm = showSearchInput ? searchInput : searchQuery;
    const matchesSearch = gem.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         gem.location.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         gem.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || gem.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  // Filter cities based on search input
  const filteredCities = popularCities.filter(city =>
    city.toLowerCase().includes(searchInput.toLowerCase())
  ).slice(0, 6); // Limit to 6 suggestions

  const handleLike = (gemId: string) => {
    setLikedGems(prev => {
      const newSet = new Set(prev);
      if (newSet.has(gemId)) {
        newSet.delete(gemId);
      } else {
        newSet.add(gemId);
      }
      return newSet;
    });
  };

  const handleCommentClick = (gemId: string) => {
    // Initialize comments for this gem if not already done
    if (!gemComments[gemId]) {
      setGemComments(prev => ({
        ...prev,
        [gemId]: [
          {
            id: '1',
            userId: 'user1',
            userName: 'local.guide',
            userAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=50&h=50&fit=crop&crop=face',
            text: 'This place is a true hidden gem! Thanks for sharing 🙏',
            timestamp: '1h',
            likes: 3,
            isLiked: false,
            repliesCount: 0
          }
        ]
      }));
    }
    setSelectedGemComments(gemId);
  };

  const handleAddComment = (gemId: string, text: string) => {
    const newComment = {
      id: `comment-${Date.now()}`,
      userId: 'current-user',
      userName: 'you',
      userAvatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=50&h=50&fit=crop&crop=face',
      text,
      timestamp: 'now',
      likes: 0,
      isLiked: false,
      repliesCount: 0
    };
    setGemComments(prev => ({
      ...prev,
      [gemId]: [newComment, ...(prev[gemId] || [])]
    }));
  };

  const handleLikeComment = (gemId: string, commentId: string) => {
    setGemComments(prev => ({
      ...prev,
      [gemId]: (prev[gemId] || []).map(comment =>
        comment.id === commentId
          ? {
              ...comment,
              isLiked: !comment.isLiked,
              likes: comment.isLiked ? comment.likes - 1 : comment.likes + 1
            }
          : comment
      )
    }));
  };

  const handleReplyComment = (gemId: string, commentId: string, replyText: string) => {
    const newReply = {
      id: `reply-${Date.now()}`,
      userId: 'current-user',
      userName: 'you',
      userAvatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=50&h=50&fit=crop&crop=face',
      text: replyText,
      timestamp: 'now',
      likes: 0,
      isLiked: false
    };
    
    setGemComments(prev => ({
      ...prev,
      [gemId]: (prev[gemId] || []).map(comment =>
        comment.id === commentId
          ? {
              ...comment,
              replies: [...(comment.replies || []), newReply],
              repliesCount: (comment.repliesCount || 0) + 1
            }
          : comment
      )
    }));
  };

  const getUserForGem = (gemIndex: number) => {
    return mockGemUsers[gemIndex % mockGemUsers.length];
  };

  const toggleCaption = (gemId: string) => {
    setExpandedCaptions(prev => {
      const newSet = new Set(prev);
      if (newSet.has(gemId)) {
        newSet.delete(gemId);
      } else {
        newSet.add(gemId);
      }
      return newSet;
    });
  };

  const handleCardTap = (e: React.MouseEvent, gemId: string) => {
    // Don't expand if clicking on interactive elements
    const target = e.target as HTMLElement;
    if (target.closest('button') || target.closest('[role="button"]')) {
      return;
    }
    
    // Handle card expansion or navigation
    console.log('Card tapped:', gemId);
  };

  const handleSearchClick = () => {
    setShowSearchInput(!showSearchInput);
    if (showSearchInput) {
      // Reset search when closing
      setSearchInput('');
      setShowCitySuggestions(false);
    }
  };

  const handleSearchInputChange = (value: string) => {
    setSearchInput(value);
    setShowCitySuggestions(value.length > 0);
  };

  const handleCitySelect = (city: string) => {
    setSearchInput(city);
    setShowCitySuggestions(false);
  };

  const handleSearchSubmit = () => {
    setSearchQuery(searchInput);
    setShowSearchInput(false);
    setShowCitySuggestions(false);
  };

  return (
    <div className="min-h-screen bg-black">
      {/* Compact Header */}
      <header className="fixed top-0 left-0 right-0 z-40 bg-black/80 backdrop-blur-xl border-b border-white/10 safe-area-inset-top">
        <div className="page-container">
          <div className="flex items-center justify-between mb-3">
            <div>
              <h1 className="text-xl font-bold text-white">Local Gems</h1>
            </div>
            <div className="flex items-center space-x-2">
              <button 
                onClick={handleSearchClick}
                className={`p-2 hover:bg-white/10 rounded-xl transition-colors ${
                  showSearchInput ? 'bg-white/10 text-white' : 'text-white'
                }`}
              >
                <Search size={20} />
              </button>
            </div>
          </div>

          {/* Search Input */}
          {showSearchInput && (
            <div className="relative mb-3">
              <div className="relative">
                <input
                  type="text"
                  placeholder="Search cities, neighborhoods..."
                  value={searchInput}
                  onChange={(e) => handleSearchInputChange(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && handleSearchSubmit()}
                  className="w-full bg-white/10 backdrop-blur-md border border-white/20 rounded-xl px-4 py-3 text-white placeholder-white/60 focus:outline-none focus:ring-2 focus:ring-white/30 focus:border-white/40"
                  autoFocus
                />
                {searchInput && (
                  <button
                    onClick={handleSearchSubmit}
                    className="absolute right-3 top-1/2 transform -translate-y-1/2 text-white/80 hover:text-white"
                  >
                    <Search size={16} />
                  </button>
                )}
              </div>

              {/* City Suggestions */}
              {showCitySuggestions && filteredCities.length > 0 && (
                <div className="absolute top-full left-0 right-0 mt-2 bg-black/90 backdrop-blur-md rounded-xl border border-white/20 max-h-60 overflow-y-auto z-50">
                  {filteredCities.map((city, index) => (
                    <button
                      key={index}
                      onClick={() => handleCitySelect(city)}
                      className="w-full px-4 py-3 text-left text-white hover:bg-white/10 transition-colors border-b border-white/10 last:border-b-0 flex items-center space-x-3"
                    >
                      <MapPin size={14} className="text-white/60 flex-shrink-0" />
                      <span className="text-sm">{city}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Active Search Query Display */}
          {searchQuery && !showSearchInput && (
            <div className="mb-3 flex items-center justify-between bg-white/10 backdrop-blur-md rounded-lg px-3 py-2">
              <div className="flex items-center space-x-2">
                <Search size={14} className="text-white/60" />
                <span className="text-white text-sm">"{searchQuery}"</span>
              </div>
              <button
                onClick={() => {
                  setSearchQuery('');
                  setSearchInput('');
                }}
                className="text-white/60 hover:text-white text-sm"
              >
                Clear
              </button>
            </div>
          )}

          {/* Category Tabs */}
          <div className="flex overflow-x-auto scrollbar-hide space-x-2">
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => setSelectedCategory(category)}
                className={`flex-shrink-0 px-3 py-1.5 rounded-full text-sm font-medium transition-all duration-200 ${
                  selectedCategory === category
                    ? 'bg-white text-black'
                    : 'bg-white/20 text-white/80 hover:bg-white/30'
                }`}
              >
                {category === 'all' ? 'All' : category}
              </button>
            ))}
          </div>
        </div>
      </header>

      {/* Immersive Cards - Instagram Reels Style */}
      <main className="pt-24 page-container-no-padding">
        {filteredGems.length > 0 ? (
          <div className="space-y-4 pb-4">
            {filteredGems.map((gem, index) => {
              const isLiked = likedGems.has(gem.id);
              const isSaved = savedGems.includes(gem.id);
              const user = getUserForGem(index);
              const isExpanded = expandedCaptions.has(gem.id);
              
              return (
                <div
                  key={gem.id}
                  className="relative w-full mx-auto max-w-sm bg-black"
                  style={{ height: '75vh', minHeight: '500px' }}
                  onClick={(e) => handleCardTap(e, gem.id)}
                >
                  {/* Full Background Image */}
                  <div className="absolute inset-0 rounded-2xl overflow-hidden">
                    <ImageWithFallback 
                      src={gem.image} 
                      alt={gem.title} 
                      className="w-full h-full object-cover object-center" 
                    />
                    {/* Dark overlay for better text readability */}
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-black/40" />
                  </div>

                  {/* Top-Left: Profile Section */}
                  <div className="absolute top-6 left-6 flex items-center space-x-3 z-10">
                    <button 
                      onClick={(e) => {
                        e.stopPropagation();
                        onSelectUser(user.id);
                      }}
                      className="flex items-center space-x-3 hover:bg-white/10 rounded-xl p-2 -m-2 transition-colors"
                    >
                      <div className="w-8 h-8 rounded-full overflow-hidden border-2 border-white/20 hover:border-white/40 transition-colors">
                        <ImageWithFallback 
                          src={user.avatar} 
                          alt={user.name} 
                          className="w-full h-full object-cover" 
                        />
                      </div>
                      <div className="flex items-center space-x-2">
                        <span className="text-white font-semibold text-sm drop-shadow-lg">
                          {user.name}
                        </span>
                        {user.isLocal && (
                          <span className="text-xs bg-brand-secondary/80 text-white px-2 py-0.5 rounded-full font-medium backdrop-blur-sm">
                            Local
                          </span>
                        )}
                      </div>
                    </button>
                  </div>

                  {/* Category Badge */}
                  <div className="absolute top-6 right-6 z-10">
                    <span className="bg-black/60 backdrop-blur-md text-white px-3 py-1.5 rounded-full text-xs font-medium border border-white/20">
                      {gem.category}
                    </span>
                  </div>

                  {/* Bottom-Right: Action Icons (Vertical Stack) */}
                  <div className="absolute bottom-6 right-6 z-10">
                    <div className="flex flex-col items-center space-y-4">
                      {/* Like Button */}
                      <div className="flex flex-col items-center">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            handleLike(gem.id);
                          }}
                          className={`p-3 rounded-full backdrop-blur-sm border border-white/20 transition-all duration-200 hover:scale-110 active:scale-95 touch-target ${
                            isLiked 
                              ? 'bg-red-500/20 text-red-400 border-red-400/40' 
                              : 'bg-black/40 text-white hover:bg-white/20'
                          }`}
                        >
                          <Heart size={20} className={isLiked ? 'fill-current' : ''} />
                        </button>
                        <span className="text-xs text-white/80 font-medium mt-1 drop-shadow">
                          {gem.likes + (isLiked ? 1 : 0)}
                        </span>
                      </div>

                      {/* Comment Button */}
                      <div className="flex flex-col items-center">
                        <button 
                          onClick={(e) => {
                            e.stopPropagation();
                            handleCommentClick(gem.id);
                          }}
                          className="p-3 rounded-full bg-black/40 backdrop-blur-sm border border-white/20 text-white hover:bg-white/20 transition-all duration-200 hover:scale-110 active:scale-95 touch-target"
                        >
                          <MessageCircle size={20} />
                        </button>
                        <span className="text-xs text-white/80 font-medium mt-1 drop-shadow">
                          {gem.reviews || 0}
                        </span>
                      </div>

                      {/* Share Button */}
                      <button className="p-3 rounded-full bg-black/40 backdrop-blur-sm border border-white/20 text-white hover:bg-white/20 transition-all duration-200 hover:scale-110 active:scale-95 touch-target">
                        <Share size={20} />
                      </button>

                      {/* Save Button */}
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onSaveToWishlist(gem.id);
                        }}
                        className={`p-3 rounded-full backdrop-blur-sm border border-white/20 transition-all duration-200 hover:scale-110 active:scale-95 touch-target ${
                          isSaved 
                            ? 'bg-brand-accent/20 text-brand-accent border-brand-accent/40' 
                            : 'bg-black/40 text-white hover:bg-white/20'
                        }`}
                      >
                        <Bookmark size={20} className={isSaved ? 'fill-current' : ''} />
                      </button>
                    </div>
                  </div>

                  {/* Bottom-Left: Content Overlay */}
                  <div className="absolute bottom-6 left-6 right-24 z-10">
                    {/* Location */}
                    <div className="flex items-center space-x-2 mb-2">
                      <MapPin size={14} className="text-white/80" />
                      <span className="text-white/80 text-sm font-medium drop-shadow">
                        {gem.location}
                      </span>
                    </div>

                    {/* Title and Caption */}
                    <div className="mb-3">
                      <h3 className="text-white font-bold text-lg drop-shadow-lg mb-1">
                        {gem.title}
                      </h3>
                      
                      <div className="text-white/90 text-sm leading-relaxed drop-shadow">
                        <p className={`${!isExpanded ? 'line-clamp-2' : ''}`}>
                          {gem.description}
                        </p>
                        
                        {gem.description.length > 100 && (
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              toggleCaption(gem.id);
                            }}
                            className="text-white/70 hover:text-white text-sm font-medium mt-1 flex items-center space-x-1"
                          >
                            <span>{isExpanded ? 'Show less' : 'See more'}</span>
                            <ChevronDown 
                              size={14} 
                              className={`transition-transform duration-200 ${isExpanded ? 'rotate-180' : ''}`} 
                            />
                          </button>
                        )}
                      </div>
                    </div>

                    {/* Local Tip */}
                    {gem.localTip && (
                      <div className="bg-black/40 backdrop-blur-sm rounded-xl p-3 border border-white/20 mb-3">
                        <p className="text-xs text-white/90 font-medium italic">
                          💡 {gem.localTip}
                        </p>
                      </div>
                    )}

                    {/* Tag Chips */}
                    <div className="flex items-center space-x-2">
                      {gem.price && (
                        <span className="text-xs font-semibold text-white bg-brand-primary/80 px-2 py-1 rounded-full backdrop-blur-sm">
                          {gem.price}
                        </span>
                      )}
                      <span className="text-xs text-white/60 font-medium">
                        {gem.timestamp.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                      </span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="flex items-center justify-center h-96 text-center">
            <div>
              <div className="w-16 h-16 bg-white/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <Camera size={24} className="text-white/60" />
              </div>
              <h3 className="text-lg font-semibold text-white mb-2">
                {searchQuery || searchInput ? 'No gems found' : 'Discover Local Gems'}
              </h3>
              <p className="text-white/60 max-w-sm mx-auto text-sm">
                {searchQuery || searchInput 
                  ? 'Try searching for a different city or explore different categories to discover hidden local treasures.'
                  : 'Search for cities above or browse categories to discover amazing local spots and hidden gems.'
                }
              </p>
            </div>
          </div>
        )}
      </main>

      {/* Comment Sheet */}
      {selectedGemComments && (
        <SwipeUpCommentSheet
          isOpen={!!selectedGemComments}
          onClose={() => setSelectedGemComments(null)}
          contentId={selectedGemComments}
          contentType="local-gem"
          comments={gemComments[selectedGemComments] || []}
          totalComments={(gemComments[selectedGemComments] || []).length}
          onAddComment={(text) => handleAddComment(selectedGemComments, text)}
          onLikeComment={(commentId) => handleLikeComment(selectedGemComments, commentId)}
          onReplyComment={(commentId, replyText) => handleReplyComment(selectedGemComments, commentId, replyText)}
        />
      )}
    </div>
  );
}