import { useState } from 'react';
import { X, Calendar, MapPin, DollarSign, Clock, Users, Camera } from 'lucide-react';
import { TravelCardDraft } from '../types';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { Button } from './ui/button';

interface EditDraftDetailsModalProps {
  isOpen: boolean;
  onClose: () => void;
  draftData: TravelCardDraft;
  onSave: (updatedData: Partial<TravelCardDraft>) => void;
}

export function EditDraftDetailsModal({
  isOpen,
  onClose,
  draftData,
  onSave
}: EditDraftDetailsModalProps) {
  const [formData, setFormData] = useState({
    title: draftData.title || '',
    description: draftData.description || '',
    destination: draftData.destination || '',
    duration: draftData.duration || '',
    startDate: draftData.startDate || '',
    endDate: draftData.endDate || '',
    estimatedCost: draftData.estimatedCost || 0,
    coverImage: draftData.coverImage || ''
  });

  const [errors, setErrors] = useState<Record<string, string>>({});

  if (!isOpen) return null;

  const validateForm = () => {
    const newErrors: Record<string, string> = {};
    
    if (!formData.title.trim()) {
      newErrors.title = 'Title is required';
    }
    
    if (!formData.destination.trim()) {
      newErrors.destination = 'Destination is required';
    }
    
    if (!formData.duration.trim()) {
      newErrors.duration = 'Duration is required';
    }

    if (formData.startDate && formData.endDate && new Date(formData.startDate) >= new Date(formData.endDate)) {
      newErrors.endDate = 'End date must be after start date';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSave = () => {
    if (!validateForm()) return;

    onSave({
      ...formData,
      lastUpdated: new Date().toISOString()
    });
    onClose();
  };

  const handleInputChange = (field: string, value: string | number) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl w-full max-w-md max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="sticky top-0 bg-white border-b border-moodboard-gray-light/20 p-6 rounded-t-2xl">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-bold text-moodboard-deep-green">Edit Travel Card Details</h2>
            <button
              onClick={onClose}
              className="p-2 hover:bg-moodboard-gray-light/20 rounded-xl transition-colors"
            >
              <X size={20} className="text-moodboard-gray-dark" />
            </button>
          </div>
        </div>

        {/* Form Content */}
        <div className="p-6 space-y-6">
          {/* Title */}
          <div className="space-y-2">
            <label className="text-sm font-medium text-moodboard-deep-green flex items-center space-x-2">
              <span>Travel Card Title</span>
            </label>
            <Input
              value={formData.title}
              onChange={(e) => handleInputChange('title', e.target.value)}
              placeholder="e.g., Spiti Valley Adventure"
              className={`${errors.title ? 'border-red-300' : ''}`}
            />
            {errors.title && <p className="text-red-500 text-xs">{errors.title}</p>}
          </div>

          {/* Description */}
          <div className="space-y-2">
            <label className="text-sm font-medium text-moodboard-deep-green">
              Description
            </label>
            <Textarea
              value={formData.description}
              onChange={(e) => handleInputChange('description', e.target.value)}
              placeholder="Describe your travel experience..."
              rows={3}
              className="resize-none"
            />
          </div>

          {/* Destination */}
          <div className="space-y-2">
            <label className="text-sm font-medium text-moodboard-deep-green flex items-center space-x-2">
              <MapPin size={16} className="text-moodboard-muted-teal" />
              <span>Destination</span>
            </label>
            <Input
              value={formData.destination}
              onChange={(e) => handleInputChange('destination', e.target.value)}
              placeholder="e.g., Spiti Valley, Himachal Pradesh"
              className={`${errors.destination ? 'border-red-300' : ''}`}
            />
            {errors.destination && <p className="text-red-500 text-xs">{errors.destination}</p>}
          </div>

          {/* Duration */}
          <div className="space-y-2">
            <label className="text-sm font-medium text-moodboard-deep-green flex items-center space-x-2">
              <Clock size={16} className="text-moodboard-muted-teal" />
              <span>Duration</span>
            </label>
            <Input
              value={formData.duration}
              onChange={(e) => handleInputChange('duration', e.target.value)}
              placeholder="e.g., 6 Days, 1 Week"
              className={`${errors.duration ? 'border-red-300' : ''}`}
            />
            {errors.duration && <p className="text-red-500 text-xs">{errors.duration}</p>}
          </div>

          {/* Dates */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium text-moodboard-deep-green flex items-center space-x-2">
                <Calendar size={16} className="text-moodboard-muted-teal" />
                <span>Start Date</span>
              </label>
              <Input
                type="date"
                value={formData.startDate}
                onChange={(e) => handleInputChange('startDate', e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-moodboard-deep-green">
                End Date
              </label>
              <Input
                type="date"
                value={formData.endDate}
                onChange={(e) => handleInputChange('endDate', e.target.value)}
                className={`${errors.endDate ? 'border-red-300' : ''}`}
              />
              {errors.endDate && <p className="text-red-500 text-xs">{errors.endDate}</p>}
            </div>
          </div>

          {/* Estimated Cost */}
          <div className="space-y-2">
            <label className="text-sm font-medium text-moodboard-deep-green flex items-center space-x-2">
              <DollarSign size={16} className="text-moodboard-muted-teal" />
              <span>Estimated Cost (₹)</span>
            </label>
            <Input
              type="number"
              value={formData.estimatedCost}
              onChange={(e) => handleInputChange('estimatedCost', parseInt(e.target.value) || 0)}
              placeholder="25000"
              min="0"
            />
          </div>

          {/* Cover Image URL */}
          <div className="space-y-2">
            <label className="text-sm font-medium text-moodboard-deep-green flex items-center space-x-2">
              <Camera size={16} className="text-moodboard-muted-teal" />
              <span>Cover Image URL</span>
            </label>
            <Input
              value={formData.coverImage}
              onChange={(e) => handleInputChange('coverImage', e.target.value)}
              placeholder="https://images.unsplash.com/photo-..."
            />
            {formData.coverImage && (
              <div className="mt-2">
                <img
                  src={formData.coverImage}
                  alt="Cover preview"
                  className="w-full h-32 object-cover rounded-lg"
                />
              </div>
            )}
          </div>
        </div>

        {/* Footer Actions */}
        <div className="sticky bottom-0 bg-white border-t border-moodboard-gray-light/20 p-6 rounded-b-2xl">
          <div className="flex space-x-3">
            <Button
              onClick={onClose}
              variant="outline"
              className="flex-1"
            >
              Cancel
            </Button>
            <Button
              onClick={handleSave}
              className="flex-1 bg-moodboard-muted-teal hover:bg-moodboard-muted-teal/90 text-white"
            >
              Save Changes
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}