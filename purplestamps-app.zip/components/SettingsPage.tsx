import { useState } from 'react';
import { 
  ArrowLeft, 
  User, 
  Bell, 
  Shield, 
  Globe, 
  Palette, 
  HelpCircle, 
  LogOut,
  ChevronRight,
  Moon,
  Sun,
  Languages,
  Lock,
  Eye,
  Smartphone,
  Download
} from 'lucide-react';

interface SettingsPageProps {
  onBack: () => void;
  onNavigateToAccountDetails: () => void;
  onLogout: () => void;
}

export function SettingsPage({ onBack, onNavigateToAccountDetails, onLogout }: SettingsPageProps) {
  const [darkMode, setDarkMode] = useState(false);
  const [notifications, setNotifications] = useState({
    push: true,
    email: true,
    cultural: true,
    social: true
  });
  const [privacy, setPrivacy] = useState({
    publicProfile: true,
    showLocation: true,
    shareTrips: true
  });

  const settingSections = [
    {
      title: 'Account',
      items: [
        {
          icon: User,
          label: 'Edit Profile',
          description: 'Name, bio, profile picture',
          action: onNavigateToAccountDetails
        },
        {
          icon: Shield,
          label: 'Privacy & Security',
          description: 'Account privacy, password',
          action: () => console.log('Privacy settings')
        },
        {
          icon: Lock,
          label: 'Two-Factor Authentication',
          description: 'Add extra security to your account',
          action: () => console.log('2FA settings')
        }
      ]
    },
    {
      title: 'Preferences',
      items: [
        {
          icon: Bell,
          label: 'Notifications',
          description: 'Push notifications, email alerts',
          action: () => console.log('Notification settings'),
          toggle: true,
          value: notifications.push,
          onChange: (value: boolean) => setNotifications(prev => ({ ...prev, push: value }))
        },
        {
          icon: Languages,
          label: 'Language',
          description: 'English (US)',
          action: () => console.log('Language settings')
        },
        {
          icon: Globe,
          label: 'Cultural Insights',
          description: 'Personalized cultural tips',
          toggle: true,
          value: notifications.cultural,
          onChange: (value: boolean) => setNotifications(prev => ({ ...prev, cultural: value }))
        },
        {
          icon: darkMode ? Sun : Moon,
          label: 'Theme',
          description: darkMode ? 'Switch to light mode' : 'Switch to dark mode',
          toggle: true,
          value: darkMode,
          onChange: setDarkMode
        }
      ]
    },
    {
      title: 'Privacy',
      items: [
        {
          icon: Eye,
          label: 'Profile Visibility',
          description: 'Who can see your profile',
          toggle: true,
          value: privacy.publicProfile,
          onChange: (value: boolean) => setPrivacy(prev => ({ ...prev, publicProfile: value }))
        },
        {
          icon: Globe,
          label: 'Location Sharing',
          description: 'Share location in travel cards',
          toggle: true,
          value: privacy.showLocation,
          onChange: (value: boolean) => setPrivacy(prev => ({ ...prev, showLocation: value }))
        },
        {
          icon: User,
          label: 'Trip Sharing',
          description: 'Allow others to see your trips',
          toggle: true,
          value: privacy.shareTrips,
          onChange: (value: boolean) => setPrivacy(prev => ({ ...prev, shareTrips: value }))
        }
      ]
    },
    {
      title: 'Data & Storage',
      items: [
        {
          icon: Download,
          label: 'Download Data',
          description: 'Export your travel data',
          action: () => console.log('Download data')
        },
        {
          icon: Smartphone,
          label: 'Storage Usage',
          description: '2.4 GB used',
          action: () => console.log('Storage settings')
        }
      ]
    },
    {
      title: 'Support',
      items: [
        {
          icon: HelpCircle,
          label: 'Help Center',
          description: 'FAQs and support articles',
          action: () => console.log('Help center')
        },
        {
          icon: Globe,
          label: 'Cultural Guidelines',
          description: 'Learn about respectful travel',
          action: () => console.log('Cultural guidelines')
        }
      ]
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-surface-warm to-surface-cool">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-white/90 backdrop-blur-xl border-b border-gray-100">
        <div className="flex items-center justify-between p-4">
          <div className="flex items-center space-x-4">
            <button onClick={onBack} className="p-2 hover:bg-gray-100 rounded-xl transition-colors">
              <ArrowLeft size={24} className="text-gray-700" />
            </button>
            <div>
              <h1 className="text-xl font-bold text-gray-900">Settings</h1>
              <p className="text-sm text-gray-600">Manage your account and preferences</p>
            </div>
          </div>
        </div>
      </header>

      {/* Settings Content */}
      <main className="pb-24">
        {settingSections.map((section, sectionIndex) => (
          <div key={sectionIndex} className="mb-8">
            <div className="px-4 py-2">
              <h2 className="text-sm font-semibold text-gray-500 uppercase tracking-wide">
                {section.title}
              </h2>
            </div>
            
            <div className="bg-white/80 backdrop-blur-sm mx-4 rounded-2xl border border-gray-100 overflow-hidden">
              {section.items.map((item, itemIndex) => (
                <div
                  key={itemIndex}
                  className={`flex items-center justify-between p-4 hover:bg-gray-50 transition-colors ${
                    itemIndex !== section.items.length - 1 ? 'border-b border-gray-100' : ''
                  }`}
                >
                  <button
                    onClick={item.action}
                    className="flex items-center space-x-4 flex-1 text-left"
                    disabled={item.toggle}
                  >
                    <div className="w-10 h-10 bg-gradient-to-br from-brand-primary/10 to-brand-secondary/10 rounded-xl flex items-center justify-center">
                      <item.icon size={20} className="text-brand-primary" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <h3 className="font-semibold text-gray-900 text-base">{item.label}</h3>
                      <p className="text-sm text-gray-600 line-clamp-1">{item.description}</p>
                    </div>
                  </button>

                  {item.toggle ? (
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input
                        type="checkbox"
                        checked={item.value}
                        onChange={(e) => item.onChange?.(e.target.checked)}
                        className="sr-only peer"
                      />
                      <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-brand-primary/20 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-gradient-brand"></div>
                    </label>
                  ) : (
                    <ChevronRight size={20} className="text-gray-400" />
                  )}
                </div>
              ))}
            </div>
          </div>
        ))}

        {/* Cultural Context Section */}
        <div className="mx-4 mb-8">
          <div className="bg-gradient-to-br from-brand-secondary/10 to-brand-primary/10 rounded-2xl p-6 border border-brand-primary/20">
            <div className="flex items-center space-x-3 mb-4">
              <div className="w-12 h-12 bg-gradient-brand rounded-2xl flex items-center justify-center">
                <Globe size={24} className="text-white" />
              </div>
              <div>
                <h3 className="font-bold text-gray-900">Cultural Ambassador</h3>
                <p className="text-sm text-gray-600">Help make travel more respectful</p>
              </div>
            </div>
            <p className="text-sm text-gray-700 leading-relaxed mb-4">
              As a Wandr traveler, you're part of a community that values cultural respect and education. 
              Your contributions help others travel more thoughtfully.
            </p>
            <button className="bg-gradient-brand text-white px-4 py-2 rounded-xl font-semibold hover:shadow-brand hover:scale-105 transition-all duration-200 active:scale-95">
              Learn More
            </button>
          </div>
        </div>

        {/* Logout Section */}
        <div className="mx-4">
          <div className="bg-white/80 backdrop-blur-sm rounded-2xl border border-gray-100 overflow-hidden">
            <button
              onClick={onLogout}
              className="w-full flex items-center space-x-4 p-4 hover:bg-red-50 transition-colors text-left"
            >
              <div className="w-10 h-10 bg-red-100 rounded-xl flex items-center justify-center">
                <LogOut size={20} className="text-red-600" />
              </div>
              <div>
                <h3 className="font-semibold text-red-600 text-base">Log Out</h3>
                <p className="text-sm text-gray-600">Sign out of your account</p>
              </div>
            </button>
          </div>
        </div>

        {/* App Info */}
        <div className="text-center py-8 px-4">
          <p className="text-sm text-gray-500 mb-2">Wandr Version 2.1.0</p>
          <p className="text-xs text-gray-400">
            Made with ❤️ for conscious travelers
          </p>
        </div>
      </main>
    </div>
  );
}