import { useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight, Brain, Sparkles, Globe, BookOpen, Lightbulb } from 'lucide-react';

// Cultural insights with playful intros
const culturalInsights = [
  {
    id: 1,
    title: "Trivia Time! 🌍",
    insight: "In New Zealand, it's common to go barefoot in public - even in shops and restaurants!",
    country: "New Zealand",
    emoji: "🇳🇿",
    category: "Social Norms",
    funFact: "Kiwis love their freedom - literally and figuratively! 🦶"
  },
  {
    id: 2,
    title: "Culture Hack of the Day 🧠",
    insight: "In India, eating with your left hand is considered impolite - always use your right!",
    country: "India",
    emoji: "🇮🇳",
    category: "Dining Etiquette",
    funFact: "Pro tip: Master the art of eating with your hands - it's actually more hygienic! 🍽️"
  },
  {
    id: 3,
    title: "Passport to Perspective ✈️",
    insight: "Germans have a word 'Verschlimmbessern' - to make something worse by trying to improve it!",
    country: "Germany",
    emoji: "🇩🇪",
    category: "Language",
    funFact: "We've all been there - that DIY project that went wrong! 😅"
  },
  {
    id: 4,
    title: "Wanderer's Wisdom 💡",
    insight: "In Denmark, there's a concept called 'Hygge' - cozy contentment and well-being through simple pleasures.",
    country: "Denmark",
    emoji: "🇩🇰",
    category: "Lifestyle",
    funFact: "Think warm blankets, candles, and good friends - pure Danish bliss! ☕"
  },
  {
    id: 5,
    title: "Globe Trotter Tip 🌏",
    insight: "In Japan, tipping is actually considered rude - excellent service is just expected!",
    country: "Japan",
    emoji: "🇯🇵",
    category: "Service Culture",
    funFact: "Omotenashi (hospitality) is a way of life, not a business transaction! 🙏"
  },
  {
    id: 6,
    title: "Cultural Compass 🧭",
    insight: "Brazilians typically greet with air kisses - even meeting someone for the first time!",
    country: "Brazil",
    emoji: "🇧🇷",
    category: "Greetings",
    funFact: "Get ready for the warmest welcomes on Earth! 💋"
  }
];

export function CulturalInsightsCarousel() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isAutoPlaying, setIsAutoPlaying] = useState(true);

  // Auto-play every 6 seconds
  useEffect(() => {
    if (!isAutoPlaying) return;
    
    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % culturalInsights.length);
    }, 6000);
    
    return () => clearInterval(interval);
  }, [isAutoPlaying]);

  const goToPrevious = () => {
    setIsAutoPlaying(false);
    setCurrentIndex((prev) => (prev - 1 + culturalInsights.length) % culturalInsights.length);
    setTimeout(() => setIsAutoPlaying(true), 10000); // Resume auto-play after 10s
  };

  const goToNext = () => {
    setIsAutoPlaying(false);
    setCurrentIndex((prev) => (prev + 1) % culturalInsights.length);
    setTimeout(() => setIsAutoPlaying(true), 10000); // Resume auto-play after 10s
  };

  const currentInsight = culturalInsights[currentIndex];

  return (
    <div className="mx-4 mb-6">
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-brand-primary/5 to-brand-secondary/5 border border-brand-primary/10 shadow-lg">
        {/* Decorative Background Elements */}
        <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-bl from-brand-accent/10 to-transparent rounded-full -translate-y-16 translate-x-16"></div>
        <div className="absolute bottom-0 left-0 w-24 h-24 bg-gradient-to-tr from-brand-secondary/10 to-transparent rounded-full translate-y-12 -translate-x-12"></div>
        
        <div className="relative p-6">
          <div className="flex items-start justify-between mb-4">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-gradient-brand rounded-full flex items-center justify-center">
                <Brain size={16} className="text-white" />
              </div>
              <div>
                <h3 className="font-bold text-gray-900">{currentInsight.title}</h3>
                <div className="flex items-center space-x-2 mt-1">
                  <span className="text-lg">{currentInsight.emoji}</span>
                  <span className="text-xs font-medium text-brand-primary bg-brand-primary/10 px-2 py-1 rounded-full">
                    {currentInsight.category}
                  </span>
                </div>
              </div>
            </div>
            
            {/* Navigation Buttons */}
            <div className="flex items-center space-x-1">
              <button
                onClick={goToPrevious}
                className="p-1.5 hover:bg-white/50 rounded-full transition-colors"
                aria-label="Previous insight"
              >
                <ChevronLeft size={16} className="text-gray-600" />
              </button>
              <button
                onClick={goToNext}
                className="p-1.5 hover:bg-white/50 rounded-full transition-colors"
                aria-label="Next insight"
              >
                <ChevronRight size={16} className="text-gray-600" />
              </button>
            </div>
          </div>

          <div className="mb-4">
            <p className="text-gray-700 font-medium leading-relaxed mb-2">
              {currentInsight.insight}
            </p>
            <div className="flex items-start space-x-2 bg-brand-accent/10 rounded-xl p-3 border border-brand-accent/20">
              <Lightbulb size={14} className="text-brand-accent mt-0.5 flex-shrink-0" />
              <p className="text-xs text-gray-600 font-medium">
                {currentInsight.funFact}
              </p>
            </div>
          </div>

          {/* Progress Indicators */}
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-1">
              {culturalInsights.map((_, index) => (
                <button
                  key={index}
                  onClick={() => {
                    setCurrentIndex(index);
                    setIsAutoPlaying(false);
                    setTimeout(() => setIsAutoPlaying(true), 10000);
                  }}
                  className={`w-2 h-2 rounded-full transition-all duration-300 ${
                    index === currentIndex 
                      ? 'bg-brand-primary w-6' 
                      : 'bg-gray-300 hover:bg-brand-primary/50'
                  }`}
                  aria-label={`Go to insight ${index + 1}`}
                />
              ))}
            </div>
            
            <div className="flex items-center space-x-2 text-xs text-gray-500">
              <Globe size={12} />
              <span>Learn More • Explore More</span>
              <Sparkles size={12} className="text-brand-accent" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}