import { useState } from 'react';
import { ArrowLeft, Edit3, Trash2, Clock, MapPin, Calendar, FileText, Plus, Star, Heart, MessageCircle, Share2, Target, Zap, Sparkles, TrendingUp } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

// Mock draft travel cards data
const mockDraftTravelCards = [
  {
    id: 'draft-1',
    title: 'Bali Paradise Adventure',
    destination: 'Bali, Indonesia',
    coverImage: 'https://images.unsplash.com/photo-1537953773345-d172ccf13cf1?w=400&h=300&fit=crop',
    travelDates: 'Dec 15-25, 2024',
    lastEdited: '2 hours ago',
    experienceCount: 8,
    description: 'Discovering hidden waterfalls, ancient temples, and pristine beaches across the Island of Gods.',
    completionPercentage: 75,
    budget: 'Mid-range',
    tripType: 'Adventure'
  },
  {
    id: 'draft-2',
    title: 'Japanese Cultural Immersion',
    destination: 'Tokyo & Kyoto, Japan',
    coverImage: 'https://images.unsplash.com/photo-1513407030348-c983a97b98d8?w=400&h=300&fit=crop',
    travelDates: 'March 1-14, 2025',
    lastEdited: '1 day ago',
    experienceCount: 12,
    description: 'From bustling Tokyo streets to serene Kyoto temples, exploring the perfect blend of modern and traditional Japan.',
    completionPercentage: 45,
    budget: 'Luxury',
    tripType: 'Cultural'
  },
  {
    id: 'draft-3',
    title: 'Patagonia Hiking Expedition',
    destination: 'Patagonia, Chile & Argentina',
    coverImage: 'https://images.unsplash.com/photo-1518611012118-696072aa579a?w=400&h=300&fit=crop',
    travelDates: 'Jan 20 - Feb 5, 2025',
    lastEdited: '3 days ago',
    experienceCount: 6,
    description: 'Epic trekking adventure through Torres del Paine and glacial landscapes.',
    completionPercentage: 30,
    budget: 'Mid-range',
    tripType: 'Adventure'
  },
  {
    id: 'draft-4',
    title: 'European Art & History Tour',
    destination: 'Paris, Rome, Florence',
    coverImage: 'https://images.unsplash.com/photo-1502602898536-47ad22581b52?w=400&h=300&fit=crop',
    travelDates: 'May 10-25, 2025',
    lastEdited: '1 week ago',
    experienceCount: 15,
    description: 'Museums, galleries, and historic landmarks across Europe\'s cultural capitals.',
    completionPercentage: 60,
    budget: 'Luxury',
    tripType: 'Cultural'
  }
];

// Journey encouragement messages
const journeyMessages = [
  "🎯 All set to make this real? Let's craft your journey into something epic! ✨",
  "📸 Time to flex those amazing moments! Your travel card is almost ready to shine 🌟",
  "🚀 You're in the Document phase - where dreams become detailed adventures! 💫",
  "💎 These drafts are pure gold! Time to polish them into masterpieces 🎨"
];

// Completion encouragement
const completionMessages = {
  low: "🌱 Great start! Every epic journey begins with a single step 👟",
  medium: "🔥 You're on fire! This travel card is shaping up beautifully 🎨",
  high: "⚡ Almost there! This is going to inspire so many fellow wanderers 🌟",
  complete: "🎉 Ready to share your masterpiece with the world? Let's publish! 🚀"
};

interface SavedTravelCardDraftsPageProps {
  onBack: () => void;
}

export function SavedTravelCardDraftsPage({ onBack }: SavedTravelCardDraftsPageProps) {
  const [draftCards, setDraftCards] = useState(mockDraftTravelCards);
  const [showDeleteModal, setShowDeleteModal] = useState<string | null>(null);

  const handleResumeEditing = (draftId: string) => {
    // Show encouraging toast
    const toast = document.createElement('div');
    toast.className = 'fixed top-20 left-1/2 transform -translate-x-1/2 bg-gradient-brand text-white px-4 py-3 rounded-xl z-50 shadow-lg backdrop-blur-sm';
    toast.innerHTML = `
      <div class="flex items-center space-x-3">
        <svg class="w-4 h-4 animate-spin" fill="none" viewBox="0 0 24 24">
          <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
          <path class="opacity-75" fill="currentColor" d="m4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
        </svg>
        <span class="font-medium">🎨 Loading your creative studio... Time to make magic!</span>
      </div>
    `;
    document.body.appendChild(toast);
    setTimeout(() => {
      if (document.body.contains(toast)) {
        document.body.removeChild(toast);
      }
    }, 3000);

    // TODO: Navigate to travel card creation flow with pre-filled data
    console.log('Resume editing draft:', draftId);
  };

  const handleDeleteDraft = (draftId: string) => {
    setDraftCards(prev => prev.filter(draft => draft.id !== draftId));
    setShowDeleteModal(null);
    
    // Show friendly success toast
    const toast = document.createElement('div');
    toast.className = 'fixed top-20 left-1/2 transform -translate-x-1/2 bg-gray-800 text-white px-4 py-3 rounded-xl z-50 shadow-lg';
    toast.innerHTML = `
      <div class="flex items-center space-x-3">
        <svg class="w-4 h-4 text-green-400" fill="currentColor" viewBox="0 0 20 20">
          <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"></path>
        </svg>
        <span class="font-medium">📝 Draft cleared! More room for new adventures! ✨</span>
      </div>
    `;
    document.body.appendChild(toast);
    setTimeout(() => {
      if (document.body.contains(toast)) {
        document.body.removeChild(toast);
      }
    }, 3000);
  };

  const getCompletionMessage = (percentage: number) => {
    if (percentage >= 90) return completionMessages.complete;
    if (percentage >= 60) return completionMessages.high;
    if (percentage >= 30) return completionMessages.medium;
    return completionMessages.low;
  };

  const DraftCard = ({ draft }: { draft: typeof mockDraftTravelCards[0] }) => {
    return (
      <div className="card-standard hover:scale-[1.02] transition-all duration-300 overflow-hidden">
        {/* Cover Image with Draft Tag */}
        <div className="relative aspect-[16/10] media-standard -mx-4 mb-4 overflow-hidden">
          <ImageWithFallback 
            src={draft.coverImage} 
            alt={draft.title}
            className="w-full h-full object-cover"
          />
          
          {/* Gradient Overlay */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/20 to-transparent"></div>
          
          {/* Draft Tag */}
          <div className="absolute top-3 left-3">
            <div className="bg-brand-primary text-white px-3 py-1 rounded-full text-xs font-semibold shadow-lg flex items-center space-x-1">
              <FileText size={10} />
              <span>DRAFT</span>
            </div>
          </div>

          {/* Completion Percentage */}
          <div className="absolute top-3 right-3">
            <div className="bg-white/20 backdrop-blur-sm px-2 py-1 rounded-full border border-white/20">
              <span className="text-white text-xs font-medium">{draft.completionPercentage}% Complete</span>
            </div>
          </div>

          {/* Bottom Info Overlay */}
          <div className="absolute bottom-3 left-3 right-3">
            <div className="flex items-center space-x-1 mb-1">
              <MapPin size={10} className="text-white/90 flex-shrink-0" />
              <span className="text-white font-medium text-xs truncate">
                {draft.destination}
              </span>
            </div>
            <h3 className="text-white font-bold text-sm line-clamp-2 leading-tight">
              {draft.title}
            </h3>
          </div>
        </div>

        {/* Card Content */}
        <div>
          {/* Stats Row */}
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center space-x-2 text-xs text-gray-600">
              <div className="flex items-center space-x-1">
                <Calendar size={10} className="text-brand-primary" />
                <span className="font-medium">{draft.travelDates}</span>
              </div>
              <span className="w-1 h-1 bg-gray-300 rounded-full"></span>
              <span>{draft.experienceCount} experiences</span>
            </div>
            <div className="flex items-center space-x-1">
              <span className="text-xs px-2 py-1 bg-gray-100 rounded-full font-medium text-gray-700">
                {draft.tripType}
              </span>
            </div>
          </div>

          {/* Description */}
          <p className="text-xs text-gray-600 line-clamp-2 leading-relaxed mb-3">
            {draft.description}
          </p>

          {/* Last Edited Info */}
          <div className="flex items-center space-x-1 mb-4 text-xs text-gray-500">
            <Clock size={10} />
            <span>Last edited {draft.lastEdited}</span>
          </div>

          {/* Progress Bar with Encouragement */}
          <div className="mb-4">
            <div className="flex items-center justify-between mb-1">
              <span className="text-xs font-medium text-gray-700">Journey Progress</span>
              <span className="text-xs text-gray-500">{draft.completionPercentage}%</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-1.5 mb-2">
              <div 
                className="bg-gradient-to-r from-brand-primary to-brand-secondary h-1.5 rounded-full transition-all duration-300"
                style={{ width: `${draft.completionPercentage}%` }}
              ></div>
            </div>
            <p className="text-xs text-gray-600 font-medium">
              {getCompletionMessage(draft.completionPercentage)}
            </p>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center space-x-2">
            <button
              onClick={() => handleResumeEditing(draft.id)}
              className="flex-1 bg-gradient-brand text-white py-2.5 px-4 rounded-lg font-medium hover:shadow-brand hover:scale-[1.02] transition-all duration-200 active:scale-95 flex items-center justify-center space-x-2"
            >
              <Edit3 size={14} />
              <span>Keep Creating! ✨</span>
            </button>
            <button
              onClick={() => setShowDeleteModal(draft.id)}
              className="p-2.5 bg-gray-100 text-gray-500 rounded-lg hover:bg-red-50 hover:text-red-500 transition-colors"
            >
              <Trash2 size={14} />
            </button>
          </div>
        </div>
      </div>
    );
  };

  const EmptyState = () => (
    <div className="text-center py-12">
      <div className="w-24 h-24 bg-gradient-to-br from-brand-primary/10 to-brand-secondary/10 rounded-full flex items-center justify-center mx-auto mb-6">
        <FileText size={32} className="text-brand-primary" />
      </div>
      <h3 className="text-lg font-semibold text-gray-900 mb-3">No drafts saved yet 📝</h3>
      <p className="text-gray-600 mb-6 max-w-sm mx-auto">
        Start building your next Travel Card! Create amazing travel experiences and save them as drafts. 
        <span className="block mt-2 font-medium text-brand-primary">🎨 Your creative studio awaits!</span>
      </p>

      {/* Journey Progress Indicator */}
      <div className="bg-gradient-to-r from-brand-primary/5 to-brand-secondary/5 rounded-2xl p-6 border border-brand-primary/10 max-w-md mx-auto mb-8">
        <div className="flex items-center justify-center space-x-2 mb-3">
          <Target size={20} className="text-brand-primary" />
          <span className="font-semibold text-gray-900">Journey Progress</span>
        </div>
        <div className="flex items-center justify-between text-sm">
          <div className="flex flex-col items-center">
            <div className="w-8 h-8 bg-gradient-brand rounded-full flex items-center justify-center mb-1">
              <span className="text-white text-xs font-bold">✓</span>
            </div>
            <span className="text-brand-primary font-medium">Explore</span>
          </div>
          <div className="flex-1 h-0.5 bg-gradient-brand mx-3"></div>
          <div className="flex flex-col items-center">
            <div className="w-8 h-8 bg-gradient-brand rounded-full flex items-center justify-center mb-1">
              <span className="text-white text-xs font-bold">✓</span>
            </div>
            <span className="text-brand-primary font-medium">Plan</span>
          </div>
          <div className="flex-1 h-0.5 bg-brand-primary mx-3"></div>
          <div className="flex flex-col items-center">
            <div className="w-8 h-8 bg-brand-primary rounded-full flex items-center justify-center mb-1">
              <span className="text-white text-xs font-bold">3</span>
            </div>
            <span className="text-brand-primary font-medium">Document</span>
          </div>
          <div className="flex-1 h-0.5 bg-gray-200 mx-3"></div>
          <div className="flex flex-col items-center">
            <div className="w-8 h-8 bg-gray-200 rounded-full flex items-center justify-center mb-1">
              <span className="text-gray-500 text-xs font-bold">4</span>
            </div>
            <span className="text-gray-500">Share</span>
          </div>
        </div>
        <p className="text-xs text-gray-600 mt-4 text-center">
          📸 You're in the Documentation phase! Time to create amazing travel cards!
        </p>
      </div>

      <button
        onClick={() => {
          // Navigate to create page
          const toast = document.createElement('div');
          toast.className = 'fixed top-20 left-1/2 transform -translate-x-1/2 bg-gradient-brand text-white px-4 py-3 rounded-xl z-50 shadow-lg';
          toast.innerHTML = `
            <div class="flex items-center space-x-3">
              <svg class="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                <path fill-rule="evenodd" d="M10 3a1 1 0 011 1v5h5a1 1 0 110 2h-5v5a1 1 0 11-2 0v-5H4a1 1 0 110-2h5V4a1 1 0 011-1z" clip-rule="evenodd"></path>
              </svg>
              <span class="font-medium">🎨 Opening your creative playground... Let's make something epic!</span>
            </div>
          `;
          document.body.appendChild(toast);
          setTimeout(() => {
            if (document.body.contains(toast)) {
              document.body.removeChild(toast);
            }
          }, 3000);
        }}
        className="bg-gradient-brand text-white py-3 px-6 rounded-xl font-semibold hover:shadow-brand hover:scale-[1.02] transition-all duration-200 active:scale-95 flex items-center space-x-2 mx-auto"
      >
        <Plus size={16} />
        <span>Start Creating Magic! ✨</span>
      </button>
    </div>
  );

  return (
    <div className="min-h-screen bg-surface-warm">
      {/* Header */}
      <div className="sticky top-0 z-50 bg-white/95 backdrop-blur-xl border-b border-gray-100">
        <div className="flex items-center justify-between p-4">
          <div className="flex items-center space-x-3">
            <button 
              onClick={onBack}
              className="flex items-center space-x-2 text-brand-primary hover:text-brand-primary-dark transition-colors"
            >
              <ArrowLeft size={20} />
            </button>
            <div>
              <h1 className="text-lg font-bold text-gray-900">Creative Studio 🎨</h1>
              <p className="text-xs text-gray-500">
                {draftCards.length} masterpiece{draftCards.length !== 1 ? 's' : ''} in progress
              </p>
            </div>
          </div>
          <div className="w-10 h-10 bg-gradient-to-br from-brand-primary/10 to-brand-secondary/10 rounded-full flex items-center justify-center">
            <FileText size={18} className="text-brand-primary" />
          </div>
        </div>
      </div>

      {/* Journey Encouragement Banner */}
      {draftCards.length > 0 && (
        <div className="px-4 py-4">
          <div className="bg-gradient-to-r from-brand-primary/10 to-brand-secondary/10 rounded-xl p-4 border border-brand-primary/20">
            <div className="flex items-center space-x-3 mb-2">
              <Zap size={16} className="text-brand-primary animate-pulse" />
              <span className="font-semibold text-gray-900 text-sm">You're in the zone! 🔥</span>
            </div>
            <p className="text-xs text-gray-600 font-medium">
              {journeyMessages[Math.floor(Math.random() * journeyMessages.length)]}
            </p>
          </div>
        </div>
      )}

      {/* Description */}
      <div className="px-4 pb-4">
        <div className="bg-white/60 backdrop-blur-sm rounded-xl p-4 border border-gray-100">
          <p className="text-sm text-gray-700 text-center">
            These are Travel Cards you've started but not yet published. Continue editing to add more experiences and publish when ready.
            <span className="block mt-2 font-medium text-brand-primary">📸 Time to document those amazing moments!</span>
          </p>
        </div>
      </div>

      {/* Content */}
      <div className="px-4 pb-24">
        {draftCards.length === 0 ? (
          <EmptyState />
        ) : (
          <>
            <div className="space-y-4">
              {draftCards.map((draft) => (
                <DraftCard key={draft.id} draft={draft} />
              ))}
            </div>

            {/* Bottom Motivation */}
            <div className="mt-8 text-center">
              <div className="bg-gradient-to-r from-brand-primary/5 to-brand-secondary/5 rounded-2xl p-6 border border-brand-primary/10">
                <h3 className="font-bold text-gray-900 mb-2">Almost ready to inspire the world? 🌟</h3>
                <p className="text-sm text-gray-600 mb-4">
                  Your travel cards are looking amazing! Add those final touches and share your adventures with fellow wanderers.
                </p>
                <div className="flex items-center justify-center space-x-2 text-xs text-gray-500">
                  <TrendingUp size={12} />
                  <span>Travel cards get 3x more engagement when fully completed!</span>
                  <Sparkles size={12} className="text-brand-accent" />
                </div>
              </div>
            </div>
          </>
        )}
      </div>

      {/* Delete Confirmation Modal */}
      {showDeleteModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          {/* Backdrop */}
          <div 
            className="absolute inset-0 bg-black/50 backdrop-blur-sm animate-backdropFadeIn"
            onClick={() => setShowDeleteModal(null)}
          ></div>
          
          {/* Modal */}
          <div className="relative bg-white rounded-2xl p-6 max-w-sm w-full animate-scaleIn shadow-xl">
            <div className="text-center mb-6">
              <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Trash2 size={24} className="text-red-500" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Delete Draft? 🗑️</h3>
              <p className="text-sm text-gray-600">
                This action cannot be undone. Your draft Travel Card and all its content will be permanently deleted.
                <span className="block mt-2 font-medium text-gray-700">💡 Maybe save it for later inspiration?</span>
              </p>
            </div>
            
            <div className="flex space-x-3">
              <button
                onClick={() => setShowDeleteModal(null)}
                className="flex-1 py-3 px-4 bg-gray-100 text-gray-700 rounded-xl font-medium hover:bg-gray-200 transition-colors"
              >
                Keep It! 💖
              </button>
              <button
                onClick={() => handleDeleteDraft(showDeleteModal)}
                className="flex-1 py-3 px-4 bg-red-500 text-white rounded-xl font-medium hover:bg-red-600 hover:scale-[1.02] transition-all duration-200 active:scale-95"
              >
                Delete 🗑️
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}