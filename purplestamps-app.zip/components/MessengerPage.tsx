import { useState, useEffect, useRef } from 'react';
import { ArrowLeft, Search, Plus, Users, MessageCircle, MapPin, Calendar, MoreHorizontal, Send, Smile, Paperclip, Phone, Video, Info } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { BucketListItem, User as UserType } from '../types';

interface MessengerPageProps {
  onBack: () => void;
  bucketListItems: BucketListItem[];
  selectedChatUserId?: string | null;
  onSelectUser: (userId: string) => void;
  onClearChatSelection: () => void;
  allUsers: UserType[];
  currentUser: UserType;
}

interface Message {
  id: string;
  senderId: string;
  text: string;
  timestamp: string;
  isRead: boolean;
  type: 'text' | 'image' | 'travel_card';
  data?: any;
}

interface ChatData {
  userId: string;
  messages: Message[];
  isTyping: boolean;
  lastSeen: string;
}

interface TravelBuddy {
  id: string;
  name: string;
  avatar: string;
  lastMessage: string;
  timestamp: string;
  isOnline: boolean;
  unreadCount?: number;
  location?: string;
  mutualTrips?: number;
}

interface TravelGroup {
  id: string;
  name: string;
  avatar: string;
  destination: string;
  lastMessage: string;
  timestamp: string;
  memberCount: number;
  unreadCount?: number;
  tripDate: string;
  members: { name: string; avatar: string }[];
}

export function MessengerPage({ 
  onBack, 
  bucketListItems, 
  selectedChatUserId, 
  onSelectUser, 
  onClearChatSelection,
  allUsers,
  currentUser 
}: MessengerPageProps) {
  const [activeTab, setActiveTab] = useState<'buddies' | 'groups'>('buddies');
  const [currentView, setCurrentView] = useState<'list' | 'chat'>('list');
  const [selectedChatUser, setSelectedChatUser] = useState<UserType | null>(null);
  const [messageText, setMessageText] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  // Mock chat data - in real app this would come from backend
  const [chatsData, setChatsData] = useState<ChatData[]>([
    {
      userId: 'user2',
      isTyping: false,
      lastSeen: '2 min ago',
      messages: [
        {
          id: '1',
          senderId: currentUser.id,
          text: "Hey! I saw your food travel card for Bangkok. Looks amazing!",
          timestamp: new Date(Date.now() - 3600000).toISOString(),
          isRead: true,
          type: 'text'
        },
        {
          id: '2',
          senderId: 'user2',
          text: "Thank you! It was such an incredible culinary journey. The street food scene there is unmatched!",
          timestamp: new Date(Date.now() - 3000000).toISOString(),
          isRead: true,
          type: 'text'
        },
        {
          id: '3',
          senderId: 'user2',
          text: "Are you planning any food-focused trips soon?",
          timestamp: new Date(Date.now() - 1800000).toISOString(),
          isRead: true,
          type: 'text'
        },
        {
          id: '4',
          senderId: currentUser.id,
          text: "Actually yes! I'm thinking about visiting Italy next month. Any recommendations?",
          timestamp: new Date(Date.now() - 900000).toISOString(),
          isRead: true,
          type: 'text'
        },
        {
          id: '5',
          senderId: 'user2',
          text: "Oh perfect! I have a Tuscany travel card that might interest you. Would love to share some insider tips!",
          timestamp: new Date(Date.now() - 300000).toISOString(),
          isRead: false,
          type: 'text'
        }
      ]
    },
    {
      userId: 'user4',
      isTyping: false,
      lastSeen: '1 hour ago',
      messages: [
        {
          id: '1',
          senderId: 'user4',
          text: "That Patagonia expedition was life-changing! 🏔️",
          timestamp: new Date(Date.now() - 7200000).toISOString(),
          isRead: true,
          type: 'text'
        },
        {
          id: '2',
          senderId: currentUser.id,
          text: "Wow, the photos look incredible! How challenging was the trek?",
          timestamp: new Date(Date.now() - 6900000).toISOString(),
          isRead: true,
          type: 'text'
        },
        {
          id: '3',
          senderId: 'user4',
          text: "It's definitely for experienced hikers, but the views are worth every step. Would you be interested in joining a group trip next year?",
          timestamp: new Date(Date.now() - 3600000).toISOString(),
          isRead: false,
          type: 'text'
        }
      ]
    }
  ]);

  // Auto-scroll to bottom when new messages arrive
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [chatsData, selectedChatUser]);

  // Handle incoming selectedChatUserId from props
  useEffect(() => {
    if (selectedChatUserId) {
      const user = allUsers.find(u => u.id === selectedChatUserId);
      if (user) {
        setSelectedChatUser(user);
        setCurrentView('chat');
        
        // Create chat data if it doesn't exist
        if (!chatsData.find(chat => chat.userId === selectedChatUserId)) {
          setChatsData(prev => [...prev, {
            userId: selectedChatUserId,
            messages: [],
            isTyping: false,
            lastSeen: 'Online'
          }]);
        }
      }
    }
  }, [selectedChatUserId, allUsers]);

  const handleBackToList = () => {
    setCurrentView('list');
    setSelectedChatUser(null);
    onClearChatSelection();
  };

  const handleSelectChat = (user: UserType) => {
    setSelectedChatUser(user);
    setCurrentView('chat');
    
    // Create chat data if it doesn't exist
    if (!chatsData.find(chat => chat.userId === user.id)) {
      setChatsData(prev => [...prev, {
        userId: user.id,
        messages: [],
        isTyping: false,
        lastSeen: 'Online'
      }]);
    }
  };

  const handleSendMessage = () => {
    if (!messageText.trim() || !selectedChatUser) return;

    const newMessage: Message = {
      id: `msg-${Date.now()}`,
      senderId: currentUser.id,
      text: messageText.trim(),
      timestamp: new Date().toISOString(),
      isRead: false,
      type: 'text'
    };

    setChatsData(prev => prev.map(chat => 
      chat.userId === selectedChatUser.id 
        ? { ...chat, messages: [...chat.messages, newMessage] }
        : chat
    ));

    setMessageText('');

    // Simulate typing indicator and response
    setTimeout(() => {
      setChatsData(prev => prev.map(chat => 
        chat.userId === selectedChatUser.id 
          ? { ...chat, isTyping: true }
          : chat
      ));
    }, 500);

    // Simulate response after typing
    setTimeout(() => {
      const responses = [
        "That sounds great! 🎉",
        "Thanks for sharing that with me!",
        "I'll definitely check that out.",
        "Can't wait to hear more about it!",
        "That's so exciting! ✈️"
      ];
      
      const responseMessage: Message = {
        id: `msg-${Date.now() + 1}`,
        senderId: selectedChatUser.id,
        text: responses[Math.floor(Math.random() * responses.length)],
        timestamp: new Date().toISOString(),
        isRead: false,
        type: 'text'
      };

      setChatsData(prev => prev.map(chat => 
        chat.userId === selectedChatUser.id 
          ? { ...chat, messages: [...chat.messages, responseMessage], isTyping: false }
          : chat
      ));
    }, 2000);
  };

  const formatMessageTime = (timestamp: string) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffInMinutes = Math.floor((now.getTime() - date.getTime()) / (1000 * 60));
    
    if (diffInMinutes < 1) return 'Just now';
    if (diffInMinutes < 60) return `${diffInMinutes}m ago`;
    if (diffInMinutes < 1440) return `${Math.floor(diffInMinutes / 60)}h ago`;
    return date.toLocaleDateString();
  };

  const getCurrentChat = () => {
    return chatsData.find(chat => chat.userId === selectedChatUser?.id);
  };

  // Get users with chat data for display
  const getUsersWithChats = () => {
    return allUsers.filter(user => user.id !== currentUser.id).map(user => {
      const chatData = chatsData.find(chat => chat.userId === user.id);
      const lastMessage = chatData?.messages[chatData.messages.length - 1];
      const unreadCount = chatData?.messages.filter(msg => 
        msg.senderId !== currentUser.id && !msg.isRead
      ).length || 0;
      
      return {
        ...user,
        lastMessage: lastMessage?.text || "Start a conversation...",
        timestamp: lastMessage ? formatMessageTime(lastMessage.timestamp) : '',
        unreadCount,
        isOnline: Math.random() > 0.5, // Mock online status
        mutualTrips: Math.floor(Math.random() * 5) + 1 // Mock mutual trips
      };
    });
  };

  // Mock travel groups data
  const travelGroups: TravelGroup[] = [
    {
      id: '1',
      name: 'Tokyo Adventure Squad',
      avatar: 'https://images.unsplash.com/photo-1540959733332-eab4deabeeaf?w=50&h=50&fit=crop',
      destination: 'Tokyo, Japan',
      lastMessage: "Sarah: Found some great cherry blossom spots!",
      timestamp: '15m ago',
      memberCount: 4,
      unreadCount: 5,
      tripDate: 'March 15-25, 2024',
      members: [
        { name: 'Sarah', avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b5bb?w=30&h=30&fit=crop&crop=face' },
        { name: 'Alex', avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=30&h=30&fit=crop&crop=face' },
        { name: 'You', avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=30&h=30&fit=crop&crop=face' }
      ]
    },
    {
      id: '2',
      name: 'European Explorer',
      avatar: 'https://images.unsplash.com/photo-1467269204594-9661b134dd2b?w=50&h=50&fit=crop',
      destination: 'Multiple Cities',
      lastMessage: "Emily: Should we add Prague to the itinerary?",
      timestamp: '1h ago',
      memberCount: 6,
      unreadCount: 2,
      tripDate: 'June 1-20, 2024',
      members: [
        { name: 'Emily', avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=30&h=30&fit=crop&crop=face' },
        { name: 'Marcus', avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=30&h=30&fit=crop&crop=face' },
        { name: 'Lisa', avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=30&h=30&fit=crop&crop=face' }
      ]
    },
    {
      id: '3',
      name: 'Bali Beach Retreat',
      avatar: 'https://images.unsplash.com/photo-1537953773345-d172ccf13cf1?w=50&h=50&fit=crop',
      destination: 'Bali, Indonesia',
      lastMessage: "Zara: Booked the villa in Ubud! 🏡",
      timestamp: '4h ago',
      memberCount: 3,
      tripDate: 'April 10-17, 2024',
      members: [
        { name: 'Zara', avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=30&h=30&fit=crop&crop=face' },
        { name: 'Alex', avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=30&h=30&fit=crop&crop=face' }
      ]
    }
  ];

  const handleCreateGroup = () => {
    // Mock group creation functionality
    console.log('Create new travel group');
  };

  const handleStartChat = () => {
    // Mock start new chat functionality
    console.log('Start new chat');
  };

  if (currentView === 'chat' && selectedChatUser) {
    const currentChat = getCurrentChat();
    
    return (
      <div className="min-h-screen bg-gradient-to-br from-surface-warm to-surface-cool flex flex-col">
        {/* Chat Header */}
        <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-xl border-b border-gray-100">
          <div className="flex items-center justify-between p-4">
            <div className="flex items-center space-x-3">
              <button 
                onClick={handleBackToList} 
                className="p-2 hover:bg-gray-100 rounded-xl transition-colors"
              >
                <ArrowLeft size={24} className="text-gray-700" />
              </button>
              
              {/* User Avatar and Info */}
              <div className="flex items-center space-x-3">
                <div className="relative">
                  <div className="w-10 h-10 rounded-full overflow-hidden border-2 border-gray-100">
                    <ImageWithFallback
                      src={selectedChatUser.profilePic}
                      alt={selectedChatUser.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 border-2 border-white rounded-full"></div>
                </div>
                
                <div>
                  <h3 className="font-semibold text-gray-900">{selectedChatUser.name}</h3>
                  <p className="text-xs text-gray-500">
                    {currentChat?.isTyping ? 'Typing...' : `Last seen ${currentChat?.lastSeen}`}
                  </p>
                </div>
              </div>
            </div>
            
            {/* Action Buttons */}
            <div className="flex items-center space-x-2">
              <button className="p-2 hover:bg-gray-100 rounded-xl transition-colors">
                <Phone size={20} className="text-gray-700" />
              </button>
              <button className="p-2 hover:bg-gray-100 rounded-xl transition-colors">
                <Video size={20} className="text-gray-700" />
              </button>
              <button className="p-2 hover:bg-gray-100 rounded-xl transition-colors">
                <Info size={20} className="text-gray-700" />
              </button>
            </div>
          </div>
        </header>

        {/* Messages Area */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {currentChat?.messages.map((message) => (
            <div
              key={message.id}
              className={`flex ${message.senderId === currentUser.id ? 'justify-end' : 'justify-start'}`}
            >
              <div className={`max-w-[75%] ${message.senderId === currentUser.id ? 'order-1' : 'order-2'}`}>
                {/* Message Bubble */}
                <div
                  className={`px-4 py-3 rounded-2xl ${
                    message.senderId === currentUser.id
                      ? 'bg-moodboard-muted-teal text-white ml-auto'
                      : 'bg-white border border-gray-100 text-gray-900'
                  }`}
                >
                  <p className="text-sm leading-relaxed">{message.text}</p>
                </div>
                
                {/* Message Time */}
                <p className={`text-xs text-gray-500 mt-1 ${
                  message.senderId === currentUser.id ? 'text-right' : 'text-left'
                }`}>
                  {formatMessageTime(message.timestamp)}
                </p>
              </div>
              
              {/* Avatar for received messages */}
              {message.senderId !== currentUser.id && (
                <div className="w-8 h-8 rounded-full overflow-hidden mr-3 order-1 flex-shrink-0">
                  <ImageWithFallback
                    src={selectedChatUser.profilePic}
                    alt={selectedChatUser.name}
                    className="w-full h-full object-cover"
                  />
                </div>
              )}
            </div>
          ))}
          
          {/* Typing Indicator */}
          {currentChat?.isTyping && (
            <div className="flex justify-start">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 rounded-full overflow-hidden">
                  <ImageWithFallback
                    src={selectedChatUser.profilePic}
                    alt={selectedChatUser.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="bg-white border border-gray-100 px-4 py-3 rounded-2xl">
                  <div className="flex space-x-1">
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                  </div>
                </div>
              </div>
            </div>
          )}
          
          <div ref={messagesEndRef} />
        </div>

        {/* Message Input */}
        <div className="border-t border-gray-100 bg-white/95 backdrop-blur-xl p-4">
          <div className="flex items-center space-x-3">
            <button className="p-2 hover:bg-gray-100 rounded-xl transition-colors">
              <Paperclip size={20} className="text-gray-500" />
            </button>
            
            <div className="flex-1 relative">
              <input
                type="text"
                value={messageText}
                onChange={(e) => setMessageText(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                placeholder="Type a message..."
                className="w-full bg-gray-100 border-0 rounded-2xl px-4 py-3 pr-12 focus:ring-2 focus:ring-moodboard-muted-teal focus:bg-white transition-all"
              />
              <button className="absolute right-3 top-1/2 transform -translate-y-1/2 p-1 hover:bg-gray-200 rounded-lg transition-colors">
                <Smile size={18} className="text-gray-500" />
              </button>
            </div>
            
            <button
              onClick={handleSendMessage}
              disabled={!messageText.trim()}
              className={`p-3 rounded-xl transition-all duration-200 ${
                messageText.trim()
                  ? 'bg-moodboard-muted-teal text-white hover:bg-moodboard-muted-teal-light hover:scale-105 active:scale-95'
                  : 'bg-gray-200 text-gray-400 cursor-not-allowed'
              }`}
            >
              <Send size={18} />
            </button>
          </div>
        </div>
      </div>
    );
  }

  // Chat List View
  const usersWithChats = getUsersWithChats();

  return (
    <div className="min-h-screen bg-gradient-to-br from-surface-warm to-surface-cool">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-white/90 backdrop-blur-xl border-b border-gray-100">
        <div className="flex items-center justify-between p-4">
          <div className="flex items-center space-x-4">
            <button onClick={onBack} className="p-2 hover:bg-gray-100 rounded-xl transition-colors">
              <ArrowLeft size={24} className="text-gray-700" />
            </button>
            <div>
              <h1 className="text-xl font-bold text-gray-900">Messages</h1>
              <p className="text-sm text-gray-600">
                {activeTab === 'buddies' 
                  ? `${usersWithChats.filter(u => u.unreadCount > 0).length} new messages`
                  : `${travelGroups.filter(g => g.unreadCount).length} active groups`
                }
              </p>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <button className="p-2 hover:bg-gray-100 rounded-xl transition-colors">
              <Search size={20} className="text-gray-700" />
            </button>
            <button 
              onClick={activeTab === 'buddies' ? handleStartChat : handleCreateGroup}
              className="p-2 hover:bg-gray-100 rounded-xl transition-colors"
            >
              <Plus size={20} className="text-gray-700" />
            </button>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-gray-100">
          <button
            onClick={() => setActiveTab('buddies')}
            className={`flex-1 py-4 px-4 text-center relative transition-all duration-200 ${
              activeTab === 'buddies'
                ? 'text-brand-primary font-semibold'
                : 'text-gray-600 hover:text-gray-800'
            }`}
          >
            <div className="flex items-center justify-center space-x-2">
              <MessageCircle size={18} />
              <span>Travel Buddies</span>
              {usersWithChats.filter(u => u.unreadCount > 0).length > 0 && (
                <div className="w-2 h-2 bg-brand-primary rounded-full"></div>
              )}
            </div>
            {activeTab === 'buddies' && (
              <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-brand-primary"></div>
            )}
          </button>
          <button
            onClick={() => setActiveTab('groups')}
            className={`flex-1 py-4 px-4 text-center relative transition-all duration-200 ${
              activeTab === 'groups'
                ? 'text-brand-primary font-semibold'
                : 'text-gray-600 hover:text-gray-800'
            }`}
          >
            <div className="flex items-center justify-center space-x-2">
              <Users size={18} />
              <span>Travel Groups</span>
              {travelGroups.filter(g => g.unreadCount).length > 0 && (
                <div className="w-2 h-2 bg-brand-secondary rounded-full"></div>
              )}
            </div>
            {activeTab === 'groups' && (
              <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-brand-primary"></div>
            )}
          </button>
        </div>
      </header>

      {/* Content */}
      <main className="pb-24">
        {activeTab === 'buddies' ? (
          /* Travel Buddies List */
          <div className="divide-y divide-gray-100">
            {usersWithChats.map((user) => (
              <div
                key={user.id}
                onClick={() => handleSelectChat(user)}
                className="p-4 hover:bg-white/50 transition-colors cursor-pointer active:bg-white/70"
              >
                <div className="flex items-start space-x-3">
                  {/* Avatar */}
                  <div className="relative flex-shrink-0">
                    <div className="w-14 h-14 rounded-full overflow-hidden border-2 border-gray-100">
                      <ImageWithFallback
                        src={user.profilePic}
                        alt={user.name}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    {/* Online Status */}
                    {user.isOnline && (
                      <div className="absolute bottom-0 right-0 w-4 h-4 bg-green-500 border-2 border-white rounded-full"></div>
                    )}
                  </div>

                  {/* Chat Info */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between mb-1">
                      <h3 className="font-semibold text-gray-900 truncate">
                        {user.name}
                      </h3>
                      <div className="flex items-center space-x-2">
                        <span className="text-xs text-gray-500">{user.timestamp}</span>
                        {user.unreadCount > 0 && (
                          <div className="w-5 h-5 bg-brand-primary rounded-full flex items-center justify-center">
                            <span className="text-xs text-white font-medium">
                              {user.unreadCount}
                            </span>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Location & Mutual Trips */}
                    <div className="flex items-center space-x-3 mb-2">
                      <div className="flex items-center space-x-1 text-xs text-gray-500">
                        <MapPin size={10} />
                        <span>{user.location || 'Unknown'}</span>
                      </div>
                      <div className="flex items-center space-x-1 text-xs text-brand-secondary">
                        <Users size={10} />
                        <span>{user.mutualTrips} mutual trips</span>
                      </div>
                    </div>

                    {/* Last Message */}
                    <p className="text-sm text-gray-600 line-clamp-2 leading-relaxed">
                      {user.lastMessage}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          /* Travel Groups List */
          <div className="divide-y divide-gray-100">
            {travelGroups.map((group) => (
              <div
                key={group.id}
                className="p-4 hover:bg-white/50 transition-colors cursor-pointer active:bg-white/70"
              >
                <div className="flex items-start space-x-3">
                  {/* Group Avatar */}
                  <div className="w-14 h-14 rounded-full overflow-hidden border-2 border-gray-100 flex-shrink-0">
                    <ImageWithFallback
                      src={group.avatar}
                      alt={group.name}
                      className="w-full h-full object-cover"
                    />
                  </div>

                  {/* Group Info */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between mb-1">
                      <div className="flex items-center space-x-2 min-w-0">
                        <h3 className="font-semibold text-gray-900 truncate">
                          {group.name}
                        </h3>
                        <div className="flex items-center space-x-1 text-xs text-gray-500">
                          <Users size={10} />
                          <span>{group.memberCount}</span>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <span className="text-xs text-gray-500">{group.timestamp}</span>
                        {group.unreadCount && (
                          <div className="w-5 h-5 bg-brand-secondary rounded-full flex items-center justify-center">
                            <span className="text-xs text-white font-medium">
                              {group.unreadCount}
                            </span>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Destination & Trip Date */}
                    <div className="flex items-center space-x-3 mb-2">
                      <div className="flex items-center space-x-1 text-xs text-gray-500">
                        <MapPin size={10} />
                        <span className="truncate">{group.destination}</span>
                      </div>
                      <div className="flex items-center space-x-1 text-xs text-brand-accent">
                        <Calendar size={10} />
                        <span className="truncate">{group.tripDate}</span>
                      </div>
                    </div>

                    {/* Members Preview */}
                    <div className="flex items-center space-x-2 mb-2">
                      <div className="flex -space-x-2">
                        {group.members.slice(0, 3).map((member, index) => (
                          <div
                            key={index}
                            className="w-6 h-6 rounded-full overflow-hidden border-2 border-white"
                          >
                            <ImageWithFallback
                              src={member.avatar}
                              alt={member.name}
                              className="w-full h-full object-cover"
                            />
                          </div>
                        ))}
                        {group.memberCount > 3 && (
                          <div className="w-6 h-6 bg-gray-200 rounded-full border-2 border-white flex items-center justify-center">
                            <span className="text-xs text-gray-600 font-medium">
                              +{group.memberCount - 3}
                            </span>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Last Message */}
                    <p className="text-sm text-gray-600 line-clamp-2 leading-relaxed">
                      {group.lastMessage}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Create New Section */}
        <div className="p-4 border-t border-gray-100 bg-white/30">
          <button
            onClick={activeTab === 'buddies' ? handleStartChat : handleCreateGroup}
            className="w-full bg-gradient-brand text-white py-4 px-6 rounded-2xl font-semibold hover:shadow-brand hover:scale-[1.02] transition-all duration-200 active:scale-95 flex items-center justify-center space-x-2"
          >
            <Plus size={20} />
            <span>
              {activeTab === 'buddies' 
                ? 'Start New Conversation' 
                : 'Create Travel Group'
              }
            </span>
          </button>
          <p className="text-center text-xs text-gray-500 mt-3">
            {activeTab === 'buddies' 
              ? 'Connect with fellow travelers and share experiences'
              : 'Plan your next adventure with friends'
            }
          </p>
        </div>
      </main>
    </div>
  );
}