import { 
  ArrowLeft,
  User, 
  DollarSign, 
  TrendingUp, 
  BookOpen, 
  Settings,
  LogOut,
  ChevronRight,
  Crown,
  MapPin
} from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface AccountDetailsPageProps {
  onNavigate: (page: string) => void;
}

export function AccountDetailsPage({ onNavigate }: AccountDetailsPageProps) {
  const handleBack = () => {
    onNavigate('profile');
  };

  const handleLogout = () => {
    const toast = document.createElement('div');
    toast.className = 'fixed top-20 left-1/2 transform -translate-x-1/2 bg-moodboard-charcoal text-moodboard-cream px-4 py-3 rounded-xl z-50 shadow-brand font-medium';
    toast.textContent = 'Logging out...';
    document.body.appendChild(toast);
    setTimeout(() => {
      document.body.removeChild(toast);
      onNavigate('login');
    }, 2000);
  };

  const showToast = (message: string) => {
    const toast = document.createElement('div');
    toast.className = 'fixed top-20 left-1/2 transform -translate-x-1/2 bg-moodboard-warm-beige text-moodboard-deep-green px-4 py-3 rounded-xl z-50 shadow-brand font-medium';
    toast.textContent = message;
    document.body.appendChild(toast);
    setTimeout(() => document.body.removeChild(toast), 3000);
  };

  // Mock user data (would come from context/props in real app)
  const user = {
    name: 'Alex Johnson',
    username: 'alexjohnson',
    email: 'alex@example.com',
    profilePic: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=50&h=50&fit=crop&crop=face',
    location: 'San Francisco, CA',
    memberSince: 'January 2023',
    isCreator: true
  };

  const accountOptions = [
    {
      id: 'profile',
      title: 'Profile Information',
      subtitle: 'Update your personal details',
      icon: User,
      color: 'muted-teal',
      action: () => showToast('Opening profile editor...')
    },
    {
      id: 'wallet',
      title: 'Wallet & Payments',
      subtitle: 'Manage payment methods',
      icon: DollarSign,
      color: 'warm-beige',
      action: () => showToast('Opening wallet...')
    },
    {
      id: 'earnings',
      title: 'Creator Earnings',
      subtitle: 'View your affiliate income',
      icon: TrendingUp,
      color: 'muted-teal',
      action: () => showToast('Opening earnings dashboard...')
    },
    {
      id: 'bookmarks',
      title: 'Saved & Bookmarks',
      subtitle: 'Your saved travel content',
      icon: BookOpen,
      color: 'warm-beige',
      action: () => showToast('Opening saved items...')
    },
    {
      id: 'settings',
      title: 'Settings & Privacy',
      subtitle: 'App preferences and privacy',
      icon: Settings,
      color: 'muted-teal',
      action: () => onNavigate('settings')
    }
  ];

  return (
    <div className="min-h-screen bg-moodboard-cream pb-20">
      {/* Instagram-Style Header */}
      <div className="sticky top-0 z-50 bg-white/95 backdrop-blur-xl border-b border-moodboard-muted-teal/10">
        <div className="flex items-center justify-between h-14 px-4">
          {/* Left: Back arrow */}
          <button 
            onClick={handleBack}
            className="p-1 hover:bg-moodboard-gray-light/20 rounded-full transition-colors"
          >
            <ArrowLeft size={20} className="text-moodboard-deep-green" />
          </button>

          {/* Center: Title */}
          <div className="text-center">
            <h1 className="font-semibold text-moodboard-deep-green">
              Account
            </h1>
          </div>

          {/* Right: Empty space for balance */}
          <div className="w-6"></div>
        </div>
      </div>

      {/* Profile Info Section */}
      <div className="px-4 py-6 bg-white">
        {/* Profile Picture and Info */}
        <div className="flex items-center space-x-4 mb-6">
          {/* Profile Picture */}
          <div className="relative">
            <div className="w-20 h-20 rounded-full overflow-hidden border-2 border-moodboard-muted-teal/20">
              <ImageWithFallback 
                src={user.profilePic} 
                alt={user.name}
                className="w-full h-full object-cover" 
              />
            </div>
            {/* Creator Badge */}
            {user.isCreator && (
              <div className="absolute -bottom-1 -right-1 w-6 h-6 bg-moodboard-warm-beige rounded-full flex items-center justify-center border-2 border-white shadow-sm">
                <Crown size={12} className="text-moodboard-deep-green" />
              </div>
            )}
          </div>

          {/* User Info */}
          <div className="flex-1">
            <h2 className="font-semibold text-lg text-moodboard-deep-green">{user.name}</h2>
            <p className="text-sm text-moodboard-gray-dark">@{user.username}</p>
            <div className="flex items-center mt-1 text-xs text-moodboard-gray-dark">
              <MapPin size={10} className="mr-1" />
              <span>{user.location}</span>
            </div>
          </div>
        </div>

        {/* Quick Stats */}
        <div className="bg-moodboard-cream/50 rounded-xl p-4 mb-6">
          <div className="grid grid-cols-2 gap-4 text-center">
            <div>
              <div className="font-semibold text-moodboard-deep-green">18</div>
              <div className="text-xs text-moodboard-gray-dark">Travel Cards</div>
            </div>
            <div>
              <div className="font-semibold text-moodboard-deep-green">{user.memberSince}</div>
              <div className="text-xs text-moodboard-gray-dark">Member Since</div>
            </div>
          </div>
        </div>
      </div>

      {/* Account Options */}
      <div className="px-4 space-y-3">
        {accountOptions.map((option) => {
          const IconComponent = option.icon;
          const colorClass = option.color === 'muted-teal' 
            ? 'text-moodboard-muted-teal bg-moodboard-muted-teal/10' 
            : 'text-moodboard-warm-beige-dark bg-moodboard-warm-beige/20';
          
          return (
            <button
              key={option.id}
              onClick={option.action}
              className="w-full bg-white rounded-xl p-4 flex items-center space-x-4 hover:scale-[1.02] transition-all duration-200 shadow-sm border border-moodboard-muted-teal/5"
            >
              {/* Icon */}
              <div className={`w-10 h-10 rounded-full flex items-center justify-center ${colorClass}`}>
                <IconComponent size={18} />
              </div>

              {/* Content */}
              <div className="flex-1 text-left">
                <h3 className="font-medium text-moodboard-deep-green">{option.title}</h3>
                <p className="text-sm text-moodboard-gray-dark">{option.subtitle}</p>
              </div>

              {/* Arrow */}
              <ChevronRight size={16} className="text-moodboard-gray-light" />
            </button>
          );
        })}
      </div>

      {/* Logout Section */}
      <div className="px-4 mt-8">
        <button
          onClick={handleLogout}
          className="w-full bg-white rounded-xl p-4 flex items-center space-x-4 hover:scale-[1.02] transition-all duration-200 shadow-sm border border-red-100"
        >
          {/* Logout Icon */}
          <div className="w-10 h-10 rounded-full flex items-center justify-center text-red-500 bg-red-50">
            <LogOut size={18} />
          </div>

          {/* Content */}
          <div className="flex-1 text-left">
            <h3 className="font-medium text-red-600">Log Out</h3>
            <p className="text-sm text-moodboard-gray-dark">Sign out of your account</p>
          </div>

          {/* Arrow */}
          <ChevronRight size={16} className="text-moodboard-gray-light" />
        </button>
      </div>

      {/* App Info */}
      <div className="px-4 mt-8 text-center">
        <p className="text-xs text-moodboard-gray-dark">
          Wandr v1.0.0 • Powered by Globetrotter Buddy Mode™
        </p>
      </div>
    </div>
  );
}