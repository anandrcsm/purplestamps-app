import { User } from '../types';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { UserPlus, CheckCircle, Users } from 'lucide-react';
import { useState } from 'react';

interface SuggestedCreatorsCarouselProps {
  creators: User[];
  onSelectCreator: (id: string) => void;
  onFollowCreator?: (id: string) => void;
}

export function SuggestedCreatorsCarousel({ 
  creators, 
  onSelectCreator, 
  onFollowCreator 
}: SuggestedCreatorsCarouselProps) {
  const [followedCreators, setFollowedCreators] = useState<Set<string>>(new Set());

  const handleFollow = (creatorId: string, event: React.MouseEvent) => {
    event.stopPropagation();
    setFollowedCreators(prev => {
      const newSet = new Set(prev);
      if (newSet.has(creatorId)) {
        newSet.delete(creatorId);
      } else {
        newSet.add(creatorId);
      }
      return newSet;
    });
    onFollowCreator?.(creatorId);
  };

  const formatFollowerCount = (count: number) => {
    if (count >= 1000000) {
      return `${(count / 1000000).toFixed(1)}M`;
    } else if (count >= 1000) {
      return `${(count / 1000).toFixed(1)}k`;
    }
    return count.toString();
  };

  return (
    <div className="w-full">
      {/* Clean Section Label - Instagram Style */}
      <div className="px-4 pt-4 pb-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Users size={14} className="text-moodboard-gray-dark" />
            <span className="text-xs font-semibold text-moodboard-deep-green uppercase tracking-wide">
              Suggested for you
            </span>
          </div>
          <button className="text-xs font-medium text-moodboard-muted-teal">
            See All
          </button>
        </div>
      </div>

      {/* Horizontal Scrollable Creator Cards - Clean & Transparent */}
      <div className="overflow-x-auto scrollbar-hide pb-4">
        <div 
          className="flex space-x-2 px-4"
          style={{
            scrollSnapType: 'x mandatory',
            scrollBehavior: 'smooth'
          }}
        >
          {creators.slice(0, 8).map((creator, index) => {
            const isFollowed = followedCreators.has(creator.id);
            
            return (
              <div
                key={creator.id}
                className="flex-shrink-0 w-28 group cursor-pointer animate-fadeIn"
                style={{
                  scrollSnapAlign: 'start',
                  animationDelay: `${index * 100}ms`
                }}
                onClick={() => onSelectCreator(creator.id)}
              >
                {/* Clean Creator Card - Semi-Transparent */}
                <div className="text-center p-3 bg-white/40 backdrop-blur-sm rounded-xl border border-white/30 shadow-sm hover:bg-white/50 hover:shadow-md transition-all duration-200 group-active:scale-95">
                  {/* Larger Profile Photo */}
                  <div className="relative mb-3">
                    <div className="w-24 h-24 mx-auto rounded-full overflow-hidden ring-2 ring-moodboard-gray-light/30 group-hover:ring-moodboard-muted-teal/50 transition-all duration-200 shadow-lg">
                      <ImageWithFallback 
                        src={creator.profilePic} 
                        alt={creator.name} 
                        className="w-full h-full object-cover" 
                      />
                    </div>
                    
                    {/* Follower Count Badge - Top Right */}
                    {creator.followers && creator.followers > 0 && (
                      <div className="absolute -top-1 -right-1 bg-moodboard-muted-teal text-white rounded-full px-1.5 py-0.5 shadow-md">
                        <span className="text-[9px] font-bold">
                          {formatFollowerCount(creator.followers)}
                        </span>
                      </div>
                    )}
                  </div>
                  
                  {/* Username - Clean Style */}
                  <div className="mb-2">
                    <h3 className="text-xs font-semibold text-moodboard-deep-green line-clamp-1 leading-tight">
                      {creator.username?.toLowerCase() || creator.name.toLowerCase().replace(' ', '')}
                    </h3>
                    {creator.location && (
                      <p className="text-[10px] text-moodboard-gray-dark line-clamp-1 mt-0.5">
                        {creator.location}
                      </p>
                    )}
                  </div>
                  
                  {/* Small Follow Button Below Username */}
                  <button
                    onClick={(e) => handleFollow(creator.id, e)}
                    className={`px-3 py-1 rounded-md text-[9px] font-semibold transition-all duration-200 hover:scale-105 active:scale-95 flex items-center justify-center space-x-1 mx-auto ${
                      isFollowed 
                        ? 'bg-moodboard-gray-light/20 text-moodboard-gray-dark border border-moodboard-gray-light/30' 
                        : 'bg-moodboard-muted-teal text-white hover:bg-moodboard-muted-teal/90 shadow-sm'
                    }`}
                  >
                    {isFollowed ? (
                      <>
                        <CheckCircle size={7} />
                        <span>Following</span>
                      </>
                    ) : (
                      <>
                        <UserPlus size={7} />
                        <span>Follow</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}