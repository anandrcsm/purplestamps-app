import { useState } from 'react';
import { Plus } from 'lucide-react';
import { Story } from '../types';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { StoryViewer } from './StoryViewer';
import { AddStoryModal } from './AddStoryModal';

interface StoriesProps {
  stories: Story[];
  onSelectUser?: (userId: string) => void;
  currentUserId?: string;
}

export function Stories({ stories, onSelectUser, currentUserId = 'user1' }: StoriesProps) {
  const [selectedStoryIndex, setSelectedStoryIndex] = useState<number | null>(null);
  const [showAddStoryModal, setShowAddStoryModal] = useState(false);

  const handleStoryClick = (index: number) => {
    setSelectedStoryIndex(index);
  };

  const handleAddStory = () => {
    setShowAddStoryModal(true);
  };

  const handleCloseViewer = () => {
    setSelectedStoryIndex(null);
  };

  const handleNextStory = () => {
    if (selectedStoryIndex !== null && selectedStoryIndex < stories.length - 1) {
      setSelectedStoryIndex(selectedStoryIndex + 1);
    } else {
      setSelectedStoryIndex(null);
    }
  };

  const handlePreviousStory = () => {
    if (selectedStoryIndex !== null && selectedStoryIndex > 0) {
      setSelectedStoryIndex(selectedStoryIndex - 1);
    }
  };

  const handleStoryComplete = () => {
    handleNextStory();
  };

  const handlePublishStory = (storyData: any) => {
    // Here you would typically send the story data to your backend
    console.log('Publishing story:', storyData);
    setShowAddStoryModal(false);
    // TODO: Add the new story to the stories array
  };

  return (
    <>
      <div className="flex overflow-x-auto gap-3 py-4 scrollbar-hide">
        {/* Add Story Button (First Position) */}
        <div className="flex-shrink-0 flex flex-col items-center">
          <button
            onClick={handleAddStory}
            className="w-16 h-16 rounded-full border-2 border-dashed border-gray-300 bg-gray-50 flex items-center justify-center hover:border-brand-primary hover:bg-brand-primary/5 transition-all duration-200 active:scale-95"
          >
            <Plus size={24} className="text-gray-400 hover:text-brand-primary transition-colors" />
          </button>
          <p className="text-xs text-gray-500 mt-1 text-center">Add Story</p>
        </div>

        {/* Stories */}
        {stories.length > 0 ? (
          stories.map((story, index) => (
            <div
              key={story.id}
              className="flex-shrink-0 flex flex-col items-center cursor-pointer"
              onClick={() => handleStoryClick(index)}
            >
              <div className="relative">
                <div className={`w-16 h-16 rounded-full flex items-center justify-center transition-all duration-200 hover:scale-105 ${
                  !story.isViewed 
                    ? 'bg-gradient-to-tr from-brand-primary to-brand-secondary p-0.5' 
                    : 'bg-gray-200 p-0.5'
                }`}>
                  <ImageWithFallback
                    src={story.userAvatar}
                    alt={story.userName}
                    className="w-full h-full rounded-full object-cover border-2 border-white"
                  />
                </div>
                {/* Live Indicator */}
                {story.isLive && (
                  <div className="absolute -bottom-1 left-1/2 transform -translate-x-1/2">
                    <div className="bg-red-500 text-white text-xs px-2 py-0.5 rounded-full border-2 border-white">
                      <span className="flex items-center gap-1">
                        <div className="w-1.5 h-1.5 bg-white rounded-full animate-pulse"></div>
                        LIVE
                      </span>
                    </div>
                  </div>
                )}
              </div>
              <p className="text-xs text-gray-700 mt-1 truncate w-16 text-center">
                {story.userName}
              </p>
            </div>
          ))
        ) : (
          // No Stories Placeholder
          <div className="flex items-center justify-center w-full py-4">
            <div className="text-center">
              <div className="flex space-x-2 mb-2">
                {[1, 2, 3].map((i) => (
                  <div key={i} className="w-12 h-12 rounded-full bg-gray-200 animate-pulse"></div>
                ))}
              </div>
              <p className="text-sm text-gray-400">No Stories Yet</p>
              <p className="text-xs text-gray-300">Be the first to share your adventure!</p>
            </div>
          </div>
        )}
      </div>

      {/* Story Viewer */}
      {selectedStoryIndex !== null && (
        <StoryViewer
          stories={stories}
          initialIndex={selectedStoryIndex}
          onClose={handleCloseViewer}
          onNext={handleNextStory}
          onPrevious={handlePreviousStory}
          onComplete={handleStoryComplete}
          onSelectUser={onSelectUser}
        />
      )}

      {/* Add Story Modal */}
      <AddStoryModal
        isOpen={showAddStoryModal}
        onClose={() => setShowAddStoryModal(false)}
        onPublish={handlePublishStory}
      />
    </>
  );
}