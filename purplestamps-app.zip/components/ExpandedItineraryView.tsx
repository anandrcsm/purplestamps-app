import { useState } from 'react';
import { 
  ArrowLeft, 
  Edit2,
  Plus,
  Trash2,
  Clock,
  MapPin,
  ExternalLink,
  MoreHorizontal,
  Calendar,
  List
} from 'lucide-react';
import { TravelItinerary, Experience, BucketListItem } from '../types';
import { CategoryTag } from './CategoryTag';
import { AddExperienceModal } from './AddExperienceModal';

interface ExpandedItineraryViewProps {
  itinerary: TravelItinerary;
  onBack: () => void;
  onUpdateItinerary: (updatedItinerary: TravelItinerary) => void;
  bucketListItems?: BucketListItem[];
}

interface DayGroup {
  day: number;
  date: string;
  experiences: Experience[];
}

interface LocationGroup {
  location: string;
  experiences: Experience[];
}

export function ExpandedItineraryView({ 
  itinerary, 
  onBack, 
  onUpdateItinerary,
  bucketListItems = []
}: ExpandedItineraryViewProps) {
  const [activeDay, setActiveDay] = useState(1);
  const [viewMode, setViewMode] = useState<'day' | 'destination'>('day');
  const [showAddModal, setShowAddModal] = useState(false);
  const [selectedDayForAdd, setSelectedDayForAdd] = useState(1);

  // Calculate days and group experiences
  const startDate = new Date(itinerary.startDate);
  const endDate = new Date(itinerary.endDate);
  const totalDays = Math.ceil((endDate.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24)) + 1;

  const dayGroups: DayGroup[] = [];
  for (let i = 0; i < totalDays; i++) {
    const date = new Date(startDate);
    date.setDate(startDate.getDate() + i);
    
    dayGroups.push({
      day: i + 1,
      date: date.toISOString().split('T')[0],
      experiences: itinerary.experiences?.filter(exp => exp.scheduledDate === date.toISOString().split('T')[0]) || []
    });
  }

  // Group by location for destination view
  const locationGroups: LocationGroup[] = [];
  const locationMap = new Map<string, Experience[]>();
  
  itinerary.experiences?.forEach(exp => {
    const location = exp.location.split(',')[0].trim(); // Take first part of location
    if (!locationMap.has(location)) {
      locationMap.set(location, []);
    }
    locationMap.get(location)!.push(exp);
  });

  locationMap.forEach((experiences, location) => {
    locationGroups.push({ location, experiences });
  });

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
      weekday: 'short', 
      month: 'short', 
      day: 'numeric' 
    });
  };

  const formatDateRange = () => {
    const start = new Date(itinerary.startDate);
    const end = new Date(itinerary.endDate);
    
    const startFormatted = start.toLocaleDateString('en-US', { 
      month: 'short', 
      day: 'numeric'
    });
    
    const endFormatted = end.toLocaleDateString('en-US', { 
      month: 'short', 
      day: 'numeric',
      year: 'numeric'
    });
    
    return `${startFormatted} - ${endFormatted}`;
  };

  const handleAddExperience = () => {
    setSelectedDayForAdd(activeDay);
    setShowAddModal(true);
  };

  const handleDeleteExperience = (experienceId: string) => {
    const updatedExperiences = itinerary.experiences?.filter(exp => exp.id !== experienceId) || [];
    onUpdateItinerary({ ...itinerary, experiences: updatedExperiences });
  };

  const handleEditExperience = (experienceId: string) => {
    // TODO: Implement edit modal
    console.log('Edit experience:', experienceId);
  };

  const handleBookNow = (bookingUrl: string) => {
    window.open(bookingUrl, '_blank');
  };

  const handleAddNewExperience = (experience: Experience) => {
    const dayDate = dayGroups[selectedDayForAdd - 1]?.date;
    const newExperience = { ...experience, scheduledDate: dayDate };
    const updatedExperiences = [...(itinerary.experiences || []), newExperience];
    onUpdateItinerary({ ...itinerary, experiences: updatedExperiences });
  };

  const handleAddFromBucketList = (bucketListItem: BucketListItem) => {
    if (bucketListItem.type === 'experience') {
      const dayDate = dayGroups[selectedDayForAdd - 1]?.date;
      const experience = { 
        ...(bucketListItem.data as Experience), 
        scheduledDate: dayDate,
        timeFrom: '09:00',
        timeTo: '10:00'
      };
      const updatedExperiences = [...(itinerary.experiences || []), experience];
      onUpdateItinerary({ ...itinerary, experiences: updatedExperiences });
    }
  };

  const renderExperienceCard = (experience: Experience) => (
    <div
      key={experience.id}
      className="bg-white border border-gray-100 rounded-xl p-4 mb-3"
    >
      <div className="flex items-start justify-between mb-3">
        <div className="flex-1">
          <h4 className="font-semibold text-gray-900 mb-1">{experience.title}</h4>
          <div className="flex items-center space-x-2 mb-2">
            <CategoryTag category={experience.category} size="sm" />
          </div>
          <div className="flex items-center text-sm text-gray-500 mb-2">
            <MapPin size={14} className="mr-1" />
            <span>{experience.location}</span>
          </div>
          {(experience.timeFrom && experience.timeTo) && (
            <div className="flex items-center text-sm text-gray-600 mb-2">
              <Clock size={14} className="mr-1" />
              <span>{experience.timeFrom} - {experience.timeTo}</span>
            </div>
          )}
          {experience.description && (
            <p className="text-sm text-gray-600 mb-3 line-clamp-2">{experience.description}</p>
          )}
        </div>
        
        <div className="flex items-center space-x-1 ml-2">
          <button
            onClick={() => handleEditExperience(experience.id)}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <Edit2 size={16} className="text-gray-500" />
          </button>
          <button
            onClick={() => handleDeleteExperience(experience.id)}
            className="p-2 hover:bg-red-50 rounded-lg transition-colors"
          >
            <Trash2 size={16} className="text-gray-500 hover:text-red-500" />
          </button>
        </div>
      </div>

      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <span className="text-sm font-medium text-gray-900">
            {experience.cost === 0 ? 'Free' : `₹${experience.cost}`}
          </span>
        </div>
        
        {experience.bookingUrl && (
          <button
            onClick={() => handleBookNow(experience.bookingUrl!)}
            className="flex items-center px-3 py-1.5 bg-brand-primary text-white text-sm font-medium rounded-lg hover:bg-brand-primary-dark transition-colors"
          >
            <ExternalLink size={14} className="mr-1" />
            Book Now
          </button>
        )}
      </div>
    </div>
  );

  const currentDayGroup = dayGroups[activeDay - 1];

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      {/* Fixed Header */}
      <div className="sticky top-0 bg-white border-b border-gray-200 z-10">
        <div className="flex items-center justify-between p-4">
          <button 
            onClick={onBack}
            className="flex items-center text-brand-primary hover:text-brand-primary-dark transition-colors"
          >
            <ArrowLeft size={20} className="mr-2" />
            <span>Back</span>
          </button>
          
          <button className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
            <Edit2 size={18} className="text-gray-600" />
          </button>
        </div>
        
        <div className="px-4 pb-4">
          <h1 className="text-xl font-bold text-gray-900 mb-1">{itinerary.title}</h1>
          <p className="text-gray-600 text-sm mb-3">
            {itinerary.destination} • {formatDateRange()}
          </p>
          <p className="text-gray-700 text-sm font-medium">Plan your day-wise experiences</p>
        </div>

        {/* View Toggle */}
        <div className="px-4 pb-3">
          <div className="flex items-center justify-between">
            <div className="flex bg-gray-100 rounded-lg p-1">
              <button
                onClick={() => setViewMode('day')}
                className={`px-3 py-1.5 text-sm font-medium rounded-md transition-colors ${
                  viewMode === 'day' 
                    ? 'bg-white text-gray-900 shadow-sm' 
                    : 'text-gray-600'
                }`}
              >
                Day View
              </button>
              <button
                onClick={() => setViewMode('destination')}
                className={`px-3 py-1.5 text-sm font-medium rounded-md transition-colors ${
                  viewMode === 'destination' 
                    ? 'bg-white text-gray-900 shadow-sm' 
                    : 'text-gray-600'
                }`}
              >
                Destination View
              </button>
            </div>
          </div>
        </div>

        {/* Day Tabs (only show in day view) */}
        {viewMode === 'day' && (
          <div className="px-4 pb-4">
            <div className="flex space-x-2 overflow-x-auto scrollbar-hide">
              {dayGroups.map((dayGroup) => (
                <button
                  key={dayGroup.day}
                  onClick={() => setActiveDay(dayGroup.day)}
                  className={`flex-shrink-0 px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                    activeDay === dayGroup.day
                      ? 'bg-brand-primary text-white'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  Day {dayGroup.day}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Content */}
      <div className="flex-1 p-4 pb-24">
        {viewMode === 'day' ? (
          <>
            {/* Day Header */}
            <div className="mb-4">
              <h2 className="text-lg font-semibold text-gray-900">Day {activeDay}</h2>
              <p className="text-sm text-gray-500">{formatDate(currentDayGroup?.date || '')}</p>
            </div>

            {/* Experiences for Current Day */}
            {currentDayGroup?.experiences && currentDayGroup.experiences.length > 0 ? (
              <div>
                {currentDayGroup.experiences.map(renderExperienceCard)}
              </div>
            ) : (
              <div className="text-center py-16">
                <Calendar size={48} className="mx-auto text-gray-300 mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">No plans yet for Day {activeDay}</h3>
                <p className="text-gray-500 mb-6">Add experiences from your bucket list or create new ones.</p>
                <button
                  onClick={handleAddExperience}
                  className="bg-brand-primary text-white px-6 py-3 rounded-xl font-medium hover:bg-brand-primary-dark transition-colors"
                >
                  Add Experience
                </button>
              </div>
            )}
          </>
        ) : (
          <>
            {/* Destination View */}
            {locationGroups.length > 0 ? (
              <div className="space-y-6">
                {locationGroups.map((locationGroup) => (
                  <div key={locationGroup.location}>
                    <h2 className="text-lg font-semibold text-gray-900 mb-3 flex items-center">
                      <MapPin size={18} className="mr-2" />
                      {locationGroup.location}
                    </h2>
                    <div>
                      {locationGroup.experiences.map(renderExperienceCard)}
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-16">
                <List size={48} className="mx-auto text-gray-300 mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">No experiences yet</h3>
                <p className="text-gray-500 mb-6">Add experiences to see them organized by destination.</p>
                <button
                  onClick={handleAddExperience}
                  className="bg-brand-primary text-white px-6 py-3 rounded-xl font-medium hover:bg-brand-primary-dark transition-colors"
                >
                  Add Experience
                </button>
              </div>
            )}
          </>
        )}
      </div>

      {/* Sticky Add Experience Button */}
      {viewMode === 'day' && currentDayGroup?.experiences && currentDayGroup.experiences.length > 0 && (
        <div className="fixed bottom-0 left-0 right-0 p-4 bg-white border-t border-gray-200">
          <button
            onClick={handleAddExperience}
            className="w-full bg-brand-primary text-white py-3 rounded-xl font-semibold hover:bg-brand-primary-dark transition-colors flex items-center justify-center"
          >
            <Plus size={20} className="mr-2" />
            Add Experience
          </button>
        </div>
      )}

      {/* Add Experience Modal */}
      <AddExperienceModal
        isOpen={showAddModal}
        onClose={() => setShowAddModal(false)}
        dayNumber={selectedDayForAdd}
        bucketListItems={bucketListItems}
        onAddFromBucketList={handleAddFromBucketList}
        onAddNewExperience={handleAddNewExperience}
      />
    </div>
  );
}