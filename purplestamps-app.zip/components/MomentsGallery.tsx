import { useState } from 'react';
import { Heart, MessageCircle, ChevronLeft, ChevronRight, X } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface MomentData {
  id: string;
  userId: string;
  userName: string;
  userAvatar: string;
  image: string;
  caption: string;
  likes: number;
  comments: number;
  timestamp: string;
  type: 'image' | 'video';
}

interface MomentsGalleryProps {
  moments: MomentData[];
  experienceTitle: string;
}

export function MomentsGallery({ moments, experienceTitle }: MomentsGalleryProps) {
  const [selectedMoment, setSelectedMoment] = useState<MomentData | null>(null);
  const [likedMoments, setLikedMoments] = useState<Set<string>>(new Set());

  const handleLike = (momentId: string, event: React.MouseEvent) => {
    event.stopPropagation();
    setLikedMoments(prev => {
      const newSet = new Set(prev);
      if (newSet.has(momentId)) {
        newSet.delete(momentId);
      } else {
        newSet.add(momentId);
      }
      return newSet;
    });
  };

  const openLightbox = (moment: MomentData) => {
    setSelectedMoment(moment);
  };

  const closeLightbox = () => {
    setSelectedMoment(null);
  };

  const navigateMoment = (direction: 'prev' | 'next') => {
    if (!selectedMoment) return;
    
    const currentIndex = moments.findIndex(m => m.id === selectedMoment.id);
    let newIndex;
    
    if (direction === 'prev') {
      newIndex = currentIndex > 0 ? currentIndex - 1 : moments.length - 1;
    } else {
      newIndex = currentIndex < moments.length - 1 ? currentIndex + 1 : 0;
    }
    
    setSelectedMoment(moments[newIndex]);
  };

  if (moments.length === 0) {
    return (
      <div className="text-center py-8">
        <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-3">
          <MessageCircle size={24} className="text-gray-400" />
        </div>
        <h3 className="font-medium text-gray-900 mb-1">No moments yet</h3>
        <p className="text-sm text-gray-500">Be the first to share a moment from this experience!</p>
      </div>
    );
  }

  return (
    <>
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="font-semibold text-gray-900">
            Moments from {experienceTitle}
          </h3>
          <span className="text-sm text-gray-500">{moments.length} moments</span>
        </div>

        {/* Moments Grid - Clean Gallery Format */}
        <div className="grid grid-cols-3 gap-2">
          {moments.map((moment) => (
            <div
              key={moment.id}
              className="relative group cursor-pointer"
              onClick={() => openLightbox(moment)}
            >
              {/* Clean grid image */}
              <div className="aspect-square rounded-lg overflow-hidden bg-gray-100 border border-gray-200">
                <ImageWithFallback
                  src={moment.image}
                  alt={moment.caption}
                  className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110"
                />
                
                {/* Subtle hover overlay */}
                <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity duration-200 rounded-lg"></div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Expanded Moment View - Polaroid Style */}
      {selectedMoment && (
        <div className="fixed inset-0 z-50 bg-moodboard-deep-green flex items-center justify-center p-4">
          {/* Close button */}
          <button
            onClick={closeLightbox}
            className="absolute top-6 right-6 z-60 w-10 h-10 bg-white/10 hover:bg-white/20 rounded-full flex items-center justify-center text-white transition-all duration-200 backdrop-blur-sm"
          >
            <X size={20} />
          </button>

          {/* Navigation buttons */}
          {moments.length > 1 && (
            <>
              <button
                onClick={() => navigateMoment('prev')}
                className="absolute left-6 top-1/2 transform -translate-y-1/2 z-60 w-12 h-12 bg-white/10 hover:bg-white/20 rounded-full flex items-center justify-center text-white transition-all duration-200 backdrop-blur-sm"
              >
                <ChevronLeft size={24} />
              </button>
              <button
                onClick={() => navigateMoment('next')}
                className="absolute right-6 top-1/2 transform -translate-y-1/2 z-60 w-12 h-12 bg-white/10 hover:bg-white/20 rounded-full flex items-center justify-center text-white transition-all duration-200 backdrop-blur-sm"
              >
                <ChevronRight size={24} />
              </button>
            </>
          )}

          {/* Polaroid-style Moment Card */}
          <div className="max-w-sm w-full transform transition-all duration-300 hover:scale-105">
            {/* Polaroid Container */}
            <div className="bg-white p-4 rounded-2xl shadow-2xl">
              {/* Image */}
              <div className="aspect-square rounded-xl overflow-hidden mb-4 bg-gray-100">
                <ImageWithFallback
                  src={selectedMoment.image}
                  alt={selectedMoment.caption}
                  className="w-full h-full object-cover"
                />
              </div>

              {/* Polaroid Caption Area */}
              <div className="space-y-3">
                {/* Caption in handwriting style */}
                <p className="text-moodboard-deep-green handwriting-style text-center leading-relaxed">
                  {selectedMoment.caption}
                </p>

                {/* User info */}
                <div className="flex items-center justify-center space-x-2 pt-2">
                  <div className="w-6 h-6 rounded-full overflow-hidden border border-moodboard-muted-teal/30">
                    <ImageWithFallback
                      src={selectedMoment.userAvatar}
                      alt={selectedMoment.userName}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <span className="text-moodboard-gray-dark text-sm font-medium">
                    {selectedMoment.userName}
                  </span>
                  <span className="text-moodboard-gray-light text-xs">
                    • {selectedMoment.timestamp}
                  </span>
                </div>

                {/* Interaction stats */}
                <div className="flex items-center justify-center space-x-6 pt-2">
                  <button
                    onClick={(e) => handleLike(selectedMoment.id, e)}
                    className={`flex items-center space-x-1 transition-colors ${
                      likedMoments.has(selectedMoment.id) ? 'text-red-500' : 'text-moodboard-gray-dark hover:text-red-500'
                    }`}
                  >
                    <Heart size={16} className={likedMoments.has(selectedMoment.id) ? 'fill-current' : ''} />
                    <span className="text-sm font-medium">
                      {selectedMoment.likes + (likedMoments.has(selectedMoment.id) ? 1 : 0)}
                    </span>
                  </button>
                  <div className="flex items-center space-x-1 text-moodboard-gray-dark">
                    <MessageCircle size={16} />
                    <span className="text-sm font-medium">{selectedMoment.comments}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Moment counter */}
            <div className="text-center mt-4">
              <span className="text-white/70 text-sm">
                {moments.findIndex(m => m.id === selectedMoment.id) + 1} of {moments.length}
              </span>
            </div>
          </div>
        </div>
      )}
    </>
  );
}