import { Brain, ArrowRight } from 'lucide-react';

interface TriviaQuestStripProps {
  onNavigateToTrivia: () => void;
}

export function TriviaQuestStrip({ onNavigateToTrivia }: TriviaQuestStripProps) {
  const challenges = [
    { emoji: '🌍', title: 'World Capitals' },
    { emoji: '🍜', title: 'Food Culture' },
    { emoji: '🎭', title: 'Festivals' },
    { emoji: '🏛️', title: 'Ancient History' }
  ];

  const todayChallenge = challenges[Math.floor(Math.random() * challenges.length)];

  return (
    <div className="px-4">
      <div className="bg-gradient-to-r from-moodboard-muted-teal/10 to-moodboard-warm-beige/10 backdrop-blur-sm rounded-xl p-3 border border-moodboard-muted-teal/20 shadow-sm hover:shadow-md transition-all duration-200">
        {/* Compact Challenge Row */}
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-gradient-to-br from-moodboard-muted-teal/20 to-moodboard-warm-beige/20 rounded-lg flex items-center justify-center">
              <Brain size={16} className="text-moodboard-muted-teal" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="text-base">{todayChallenge.emoji}</span>
                <p className="text-sm font-semibold text-moodboard-deep-green">Cultural Quest</p>
              </div>
              <p className="text-xs text-moodboard-gray-dark">{todayChallenge.title}</p>
            </div>
          </div>
          
          {/* Play Now CTA */}
          <button
            onClick={onNavigateToTrivia}
            className="bg-gradient-brand text-white px-4 py-2 rounded-xl font-semibold hover:shadow-brand hover:scale-105 transition-all duration-200 active:scale-95 flex items-center space-x-1"
          >
            <span className="text-sm">Play Now</span>
            <ArrowRight size={14} />
          </button>
        </div>
      </div>
    </div>
  );
}