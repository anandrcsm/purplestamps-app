import { Globe, ArrowRight, BookOpen } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface CulturalInsightsStripProps {
  onViewInsights?: () => void;
  onNavigateToTrivia?: () => void;
}

export function CulturalInsightsStrip({ 
  onViewInsights, 
  onNavigateToTrivia 
}: CulturalInsightsStripProps) {
  const culturalFacts = [
    {
      id: 1,
      country: 'Japan',
      flag: '🇯🇵',
      fact: 'Slurping noodles shows appreciation to the chef',
      category: 'Etiquette',
      image: 'https://images.unsplash.com/photo-1478436127897-769e1b3f0f36?w=300&h=150&fit=crop'
    },
    {
      id: 2,
      country: 'India',
      flag: '🇮🇳',
      fact: 'Namaste recognizes the divine in others',
      category: 'Greeting',
      image: 'https://images.unsplash.com/photo-1524492412937-b28074a5d7da?w=300&h=150&fit=crop'
    },
    {
      id: 3,
      country: 'Morocco',
      flag: '🇲🇦',
      fact: 'Refusing mint tea can be considered impolite',
      category: 'Hospitality',
      image: 'https://images.unsplash.com/photo-1539650116574-75c0c6d00b62?w=300&h=150&fit=crop'
    },
    {
      id: 4,
      country: 'Thailand',
      flag: '🇹🇭',
      fact: 'Never point your feet toward a Buddha statue',
      category: 'Respect',
      image: 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=300&h=150&fit=crop'
    },
    {
      id: 5,
      country: 'Iceland',
      flag: '🇮🇸',
      fact: 'Taking off shoes when entering homes is essential',
      category: 'Tradition',
      image: 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=300&h=150&fit=crop'
    },
    {
      id: 6,
      country: 'Brazil',
      flag: '🇧🇷',
      fact: 'Eye contact during toasts is considered very important',
      category: 'Social',
      image: 'https://images.unsplash.com/photo-1483729558449-99ef09a8c325?w=300&h=150&fit=crop'
    }
  ];

  const currentFact = culturalFacts[Math.floor(Math.random() * culturalFacts.length)];

  return (
    <div className="px-4">
      <div className="card-standard">
        {/* Header Row */}
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-gradient-to-br from-brand-secondary/20 to-brand-primary/20 rounded-xl flex items-center justify-center">
              <Globe size={16} className="text-brand-primary" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-gray-900">Cultural Insight</h3>
              <p className="text-xs text-gray-500">Learn something new</p>
            </div>
          </div>
          <button 
            onClick={onViewInsights}
            className="text-xs text-brand-primary hover:text-brand-primary-dark font-medium flex items-center space-x-1 bg-brand-primary/10 px-2 py-1 rounded-lg"
          >
            <span>More</span>
            <ArrowRight size={10} />
          </button>
        </div>

        {/* Cultural Fact Content */}
        <div className="flex items-center space-x-3">
          <div className="w-12 h-12 rounded-xl overflow-hidden flex-shrink-0">
            <ImageWithFallback
              src={currentFact.image}
              alt={currentFact.country}
              className="w-full h-full object-cover"
            />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center space-x-2 mb-1">
              <span className="text-base">{currentFact.flag}</span>
              <span className="font-semibold text-gray-900 text-sm">{currentFact.country}</span>
              <span className="text-xs bg-brand-secondary/10 text-brand-secondary px-2 py-0.5 rounded-full">
                {currentFact.category}
              </span>
            </div>
            <p className="text-xs text-gray-700 leading-relaxed line-clamp-2">
              {currentFact.fact}
            </p>
          </div>
          <button
            onClick={onNavigateToTrivia}
            className="flex-shrink-0 bg-brand-primary/10 hover:bg-brand-primary/20 text-brand-primary p-2 rounded-xl transition-colors duration-200"
          >
            <BookOpen size={14} />
          </button>
        </div>
      </div>
    </div>
  );
}