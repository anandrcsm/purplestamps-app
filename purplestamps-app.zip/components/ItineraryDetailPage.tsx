import { useState } from 'react';
import { 
  ArrowLeft, 
  Plus, 
  Calendar, 
  MapPin, 
  Users, 
  Share2, 
  Edit, 
  Clock,
  Target,
  DollarSign,
  Star,
  Heart,
  MessageCircle,
  Trash2,
  Link,
  Mail,
  UserPlus
} from 'lucide-react';
import { ItineraryCard, Experience, LocalGem, Collaborator } from '../types';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { CategoryTag } from './CategoryTag';
import { StarRating } from './StarRating';

interface ItineraryDetailPageProps {
  itinerary: ItineraryCard;
  onBack: () => void;
  onEdit: () => void;
  onAddItems: () => void;
  onRemoveItem: (itemId: string, type: 'experience' | 'localGem') => void;
  onShareWithFriends: (itineraryId: string) => void;
}

export function ItineraryDetailPage({ 
  itinerary, 
  onBack, 
  onEdit, 
  onAddItems,
  onRemoveItem,
  onShareWithFriends
}: ItineraryDetailPageProps) {
  const [activeTab, setActiveTab] = useState('overview');
  const [showShareModal, setShowShareModal] = useState(false);
  const [shareMethod, setShareMethod] = useState<'link' | 'email' | 'username'>('link');
  const [shareValue, setShareValue] = useState('');

  const totalItems = itinerary.experiences.length + itinerary.localGems.length;
  const daysCount = Math.ceil((new Date(itinerary.endDate).getTime() - new Date(itinerary.startDate).getTime()) / (1000 * 60 * 60 * 24));

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'planning': return 'bg-gray-100 text-gray-700 border-gray-200';
      case 'upcoming': return 'bg-blue-100 text-blue-700 border-blue-200';
      case 'active': return 'bg-green-100 text-green-700 border-green-200';
      case 'completed': return 'bg-purple-100 text-purple-700 border-purple-200';
      default: return 'bg-gray-100 text-gray-700 border-gray-200';
    }
  };

  const handleShare = () => {
    if (shareMethod === 'link') {
      const shareableLink = `https://wandr.app/itinerary/${itinerary.id}`;
      navigator.clipboard.writeText(shareableLink);
      
      const toast = document.createElement('div');
      toast.className = 'fixed top-20 left-1/2 transform -translate-x-1/2 bg-brand-primary text-white px-4 py-2 rounded-xl z-50 shadow-lg';
      toast.textContent = 'Link copied to clipboard!';
      document.body.appendChild(toast);
      setTimeout(() => document.body.removeChild(toast), 3000);
    } else {
      onShareWithFriends(itinerary.id);
    }
    setShowShareModal(false);
    setShareValue('');
  };

  const renderOverview = () => (
    <div className="space-y-6">
      {/* Trip Info */}
      <div className="bg-white rounded-2xl p-6 border border-white/20">
        <div className="flex items-start justify-between mb-4">
          <div className="flex-grow">
            <h2 className="text-2xl text-gray-900 mb-2">{itinerary.title}</h2>
            <p className="text-gray-600 leading-relaxed mb-4">{itinerary.description}</p>
            
            <div className="grid grid-cols-2 gap-4 mb-4">
              <div className="flex items-center text-gray-600">
                <MapPin size={16} className="mr-2" />
                <span>{itinerary.destination}</span>
              </div>
              <div className="flex items-center text-gray-600">
                <Calendar size={16} className="mr-2" />
                <span>{daysCount} days</span>
              </div>
              <div className="flex items-center text-gray-600">
                <Target size={16} className="mr-2" />
                <span>{totalItems} items planned</span>
              </div>
              {itinerary.budget && (
                <div className="flex items-center text-gray-600">
                  <DollarSign size={16} className="mr-2" />
                  <span>{itinerary.budget.currency} {itinerary.budget.estimated}</span>
                </div>
              )}
            </div>
          </div>
          
          <div className={`px-3 py-1 rounded-xl text-sm border ${getStatusColor(itinerary.status)}`}>
            {itinerary.status.charAt(0).toUpperCase() + itinerary.status.slice(1)}
          </div>
        </div>

        {/* Tags */}
        {itinerary.tags && itinerary.tags.length > 0 && (
          <div className="flex flex-wrap gap-2 mb-4">
            {itinerary.tags.map((tag, idx) => (
              <span 
                key={idx}
                className="bg-gray-100 text-gray-600 px-3 py-1 rounded-xl text-sm"
              >
                #{tag}
              </span>
            ))}
          </div>
        )}

        {/* Collaborators */}
        {itinerary.collaborators.length > 0 && (
          <div>
            <h4 className="text-gray-900 mb-3">Collaborators ({itinerary.collaborators.length + 1})</h4>
            <div className="flex flex-wrap gap-3">
              {/* Owner */}
              <div className="flex items-center bg-gray-50 rounded-xl p-2">
                <ImageWithFallback
                  src="https://images.unsplash.com/photo-1494790108755-2616b612bb44?w=32&h=32&fit=crop&crop=face"
                  alt="Owner"
                  className="w-8 h-8 rounded-full mr-2"
                />
                <div>
                  <span className="text-sm text-gray-800">You</span>
                  <div className="text-xs text-gray-500">Owner</div>
                </div>
              </div>
              
              {itinerary.collaborators.map((collaborator) => (
                <div key={collaborator.userId} className="flex items-center bg-gray-50 rounded-xl p-2">
                  <ImageWithFallback
                    src={collaborator.profilePic}
                    alt={collaborator.name}
                    className="w-8 h-8 rounded-full mr-2"
                  />
                  <div>
                    <span className="text-sm text-gray-800">{collaborator.name}</span>
                    <div className="text-xs text-gray-500">@{collaborator.username}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-2 gap-4">
        <div className="bg-white rounded-2xl p-4 border border-white/20 text-center">
          <div className="text-2xl text-brand-primary mb-1">{itinerary.experiences.length}</div>
          <div className="text-sm text-gray-600">Experiences</div>
        </div>
        <div className="bg-white rounded-2xl p-4 border border-white/20 text-center">
          <div className="text-2xl text-brand-secondary mb-1">{itinerary.localGems.length}</div>
          <div className="text-sm text-gray-600">Local Gems</div>
        </div>
      </div>
    </div>
  );

  const renderExperiences = () => (
    <div className="space-y-4">
      {itinerary.experiences.length > 0 ? (
        itinerary.experiences.map((experience) => (
          <div
            key={experience.id}
            className="bg-white rounded-2xl shadow-sm overflow-hidden border border-white/20"
          >
            <div className="flex">
              <div className="w-20 h-20 flex-shrink-0">
                <ImageWithFallback 
                  src={experience.media[0]} 
                  alt={experience.title}
                  className="w-full h-full object-cover"
                />
              </div>
              
              <div className="flex-grow p-4">
                <div className="flex items-start justify-between mb-2">
                  <div className="flex-grow">
                    <div className="flex items-center mb-1">
                      <CategoryTag category={experience.category} size="sm" />
                    </div>
                    <h4 className="text-gray-900 text-sm line-clamp-1 mb-1">
                      {experience.title}
                    </h4>
                    <div className="flex items-center text-xs text-gray-500 mb-1">
                      <MapPin size={10} className="mr-1" />
                      <span className="line-clamp-1">{experience.location}</span>
                    </div>
                    <StarRating rating={experience.rating} size="xs" />
                  </div>
                  
                  <button
                    onClick={() => onRemoveItem(experience.id, 'experience')}
                    className="p-1 hover:bg-red-50 rounded-lg transition-colors text-gray-400 hover:text-red-500 ml-2"
                  >
                    <Trash2 size={12} />
                  </button>
                </div>
                
                <div className="flex items-center justify-between">
                  <span className="text-gray-900 text-xs">
                    {experience.cost > 0 ? `$${experience.cost}` : 'Free'}
                  </span>
                </div>
              </div>
            </div>
          </div>
        ))
      ) : (
        <div className="text-center py-8">
          <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-3">
            <Target size={24} className="text-gray-400" />
          </div>
          <p className="text-gray-600 mb-2">No experiences added yet</p>
          <button
            onClick={onAddItems}
            className="text-brand-primary hover:text-brand-primary-dark text-sm"
          >
            Add from bucket list
          </button>
        </div>
      )}
    </div>
  );

  const renderLocalGems = () => (
    <div className="space-y-4">
      {itinerary.localGems.length > 0 ? (
        itinerary.localGems.map((gem) => (
          <div
            key={gem.id}
            className="bg-white rounded-2xl shadow-sm overflow-hidden border border-white/20"
          >
            <div className="flex">
              <div className="w-20 h-20 flex-shrink-0">
                <ImageWithFallback 
                  src={gem.image} 
                  alt={gem.title}
                  className="w-full h-full object-cover"
                />
              </div>
              
              <div className="flex-grow p-4">
                <div className="flex items-start justify-between mb-2">
                  <div className="flex-grow">
                    <div className="flex items-center mb-1">
                      <span className="bg-green-100 text-green-700 px-2 py-1 rounded-lg text-xs">
                        {gem.category}
                      </span>
                    </div>
                    <h4 className="text-gray-900 text-sm line-clamp-1 mb-1">
                      {gem.title}
                    </h4>
                    <div className="flex items-center text-xs text-gray-500 mb-1">
                      <MapPin size={10} className="mr-1" />
                      <span className="line-clamp-1">{gem.location}</span>
                    </div>
                    {gem.rating && (
                      <div className="flex items-center">
                        <Star size={10} className="text-yellow-400 fill-current mr-1" />
                        <span className="text-xs text-gray-600">{gem.rating}</span>
                      </div>
                    )}
                  </div>
                  
                  <button
                    onClick={() => onRemoveItem(gem.id, 'localGem')}
                    className="p-1 hover:bg-red-50 rounded-lg transition-colors text-gray-400 hover:text-red-500 ml-2"
                  >
                    <Trash2 size={12} />
                  </button>
                </div>
              </div>
            </div>
          </div>
        ))
      ) : (
        <div className="text-center py-8">
          <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-3">
            <MapPin size={24} className="text-gray-400" />
          </div>
          <p className="text-gray-600 mb-2">No local gems added yet</p>
          <button
            onClick={onAddItems}
            className="text-brand-primary hover:text-brand-primary-dark text-sm"
          >
            Add from bucket list
          </button>
        </div>
      )}
    </div>
  );

  return (
    <div className="min-h-screen bg-surface-warm pb-20">
      {/* Header */}
      <div className="relative">
        <ImageWithFallback 
          src={itinerary.thumbnail} 
          alt={itinerary.title}
          className="w-full h-48 object-cover" 
        />
        
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-black/30">
          <div className="flex items-center justify-between p-4">
            <button 
              onClick={onBack}
              className="p-2 bg-black/30 backdrop-blur-md rounded-full text-white hover:bg-black/50 transition-colors"
            >
              <ArrowLeft size={20} />
            </button>
            
            <div className="flex items-center space-x-2">
              <button 
                onClick={() => setShowShareModal(true)}
                className="p-2 bg-black/30 backdrop-blur-md rounded-full text-white hover:bg-black/50 transition-colors"
              >
                <Share2 size={20} />
              </button>
              <button 
                onClick={onEdit}
                className="p-2 bg-black/30 backdrop-blur-md rounded-full text-white hover:bg-black/50 transition-colors"
              >
                <Edit size={20} />
              </button>
            </div>
          </div>
          
          <div className="absolute bottom-4 left-4 right-4">
            <h1 className="text-white text-xl mb-2 leading-tight">{itinerary.title}</h1>
            <div className="flex items-center text-white/90 text-sm">
              <MapPin size={16} className="mr-1" />
              <span>{itinerary.destination}</span>
              <span className="mx-2">•</span>
              <Calendar size={16} className="mr-1" />
              <span>
                {new Date(itinerary.startDate).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })} - 
                {new Date(itinerary.endDate).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="bg-white border-b border-gray-200 sticky top-0 z-40">
        <div className="flex">
          {['overview', 'experiences', 'localGems'].map(tab => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`flex-1 py-4 px-4 text-sm transition-colors ${
                activeTab === tab
                  ? 'text-brand-primary border-b-2 border-brand-primary'
                  : 'text-gray-600'
              }`}
            >
              {tab === 'overview' ? 'Overview' : 
               tab === 'experiences' ? `Experiences (${itinerary.experiences.length})` : 
               `Local Gems (${itinerary.localGems.length})`}
            </button>
          ))}
        </div>
      </div>

      {/* Content */}
      <div className="p-4">
        {activeTab === 'overview' && renderOverview()}
        {activeTab === 'experiences' && renderExperiences()}
        {activeTab === 'localGems' && renderLocalGems()}
      </div>

      {/* Add Items Button */}
      <div className="fixed bottom-24 right-4 z-40">
        <button
          onClick={onAddItems}
          className="bg-gradient-brand p-4 rounded-full shadow-brand hover:shadow-xl hover:scale-110 transition-all duration-200 active:scale-95"
        >
          <Plus size={24} className="text-white" />
        </button>
      </div>

      {/* Share Modal */}
      {showShareModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl p-6 w-full max-w-sm">
            <h3 className="text-lg text-gray-900 mb-4">Share Itinerary</h3>
            
            <div className="flex space-x-2 mb-4">
              {[
                { id: 'link', label: 'Link', icon: Link },
                { id: 'email', label: 'Email', icon: Mail },
                { id: 'username', label: 'Username', icon: UserPlus }
              ].map(({ id, label, icon: Icon }) => (
                <button
                  key={id}
                  onClick={() => setShareMethod(id as any)}
                  className={`flex-1 flex items-center justify-center p-3 rounded-xl transition-colors ${
                    shareMethod === id 
                      ? 'bg-brand-primary text-white' 
                      : 'bg-gray-100 text-gray-700'
                  }`}
                >
                  <Icon size={16} className="mr-1" />
                  {label}
                </button>
              ))}
            </div>

            {shareMethod !== 'link' && (
              <input
                type={shareMethod === 'email' ? 'email' : 'text'}
                placeholder={shareMethod === 'email' ? 'friend@example.com' : '@username'}
                className="w-full p-3 border border-gray-300 rounded-xl mb-4 focus:ring-2 focus:ring-brand-primary focus:border-transparent"
                value={shareValue}
                onChange={(e) => setShareValue(e.target.value)}
              />
            )}

            <div className="flex space-x-3">
              <button
                onClick={() => setShowShareModal(false)}
                className="flex-1 bg-gray-200 text-gray-800 py-3 rounded-xl"
              >
                Cancel
              </button>
              <button
                onClick={handleShare}
                className="flex-1 bg-gradient-brand text-white py-3 rounded-xl"
              >
                {shareMethod === 'link' ? 'Copy Link' : 'Send Invite'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}