import { useState, useEffect } from 'react';
import { Sparkles, MapPin, Heart, Zap, Target, Compass } from 'lucide-react';

interface BookNowNudgeProps {
  cardId: string;
  location?: string;
  onDismiss?: () => void;
}

// Fun nudge messages with cultural flair
const nudgeMessages = [
  {
    message: "Still thinking? Just go already! 😜",
    icon: Zap,
    style: "from-orange-400 to-red-500"
  },
  {
    message: "This place is calling your name! 🌍",
    icon: Compass,
    style: "from-blue-400 to-indigo-500"
  },
  {
    message: "Trip not booked? Adventure delayed! 🧭",
    icon: Target,
    style: "from-purple-400 to-pink-500"
  },
  {
    message: "Your passport is getting lonely... ✈️",
    icon: Heart,
    style: "from-green-400 to-teal-500"
  },
  {
    message: "The locals are waiting to meet you! 👋",
    icon: MapPin,
    style: "from-yellow-400 to-orange-500"
  },
  {
    message: "FOMO alert: Book before someone else does! 🚨",
    icon: Sparkles,
    style: "from-red-400 to-pink-500"
  }
];

// Session storage key for tracking shown nudges
const NUDGE_STORAGE_KEY = 'wandr_book_now_nudges_shown';

export function BookNowNudge({ cardId, location, onDismiss }: BookNowNudgeProps) {
  const [showNudge, setShowNudge] = useState(false);
  const [selectedNudge, setSelectedNudge] = useState(nudgeMessages[0]);
  const [isAnimating, setIsAnimating] = useState(false);

  useEffect(() => {
    // Check if nudge has been shown for this card in current session
    const shownNudges = JSON.parse(sessionStorage.getItem(NUDGE_STORAGE_KEY) || '[]');
    
    if (!shownNudges.includes(cardId)) {
      // Random delay between 2-5 seconds before showing nudge
      const delay = Math.random() * 3000 + 2000;
      
      setTimeout(() => {
        // Select random nudge message
        const randomNudge = nudgeMessages[Math.floor(Math.random() * nudgeMessages.length)];
        setSelectedNudge(randomNudge);
        setShowNudge(true);
        setIsAnimating(true);
        
        // Mark as shown for this session
        const updatedShown = [...shownNudges, cardId];
        sessionStorage.setItem(NUDGE_STORAGE_KEY, JSON.stringify(updatedShown));
        
        // Auto-hide after 8 seconds
        setTimeout(() => {
          handleDismiss();
        }, 8000);
      }, delay);
    }
  }, [cardId]);

  const handleDismiss = () => {
    setIsAnimating(false);
    setTimeout(() => {
      setShowNudge(false);
      onDismiss?.();
    }, 300);
  };

  if (!showNudge) return null;

  const IconComponent = selectedNudge.icon;

  return (
    <div className={`mt-3 transition-all duration-300 ${isAnimating ? 'animate-slideUp opacity-100' : 'opacity-0 translate-y-2'}`}>
      <div className={`bg-gradient-to-r ${selectedNudge.style} text-white px-4 py-3 rounded-2xl shadow-lg relative overflow-hidden`}>
        {/* Background pattern */}
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-1 right-1 w-8 h-8 border border-white rounded-full"></div>
          <div className="absolute bottom-1 left-1 w-6 h-6 border border-white rounded-full"></div>
        </div>
        
        <div className="relative flex items-center space-x-3">
          <div className="w-8 h-8 bg-white/20 rounded-full flex items-center justify-center flex-shrink-0">
            <IconComponent size={16} className="text-white" />
          </div>
          <div className="flex-1">
            <p className="font-medium text-sm leading-relaxed">
              {selectedNudge.message}
            </p>
            {location && (
              <p className="text-xs opacity-90 mt-1">
                📍 Adventure awaits in {location}!
              </p>
            )}
          </div>
          <button
            onClick={handleDismiss}
            className="w-6 h-6 bg-white/20 rounded-full flex items-center justify-center hover:bg-white/30 transition-colors flex-shrink-0"
            aria-label="Dismiss nudge"
          >
            <span className="text-white text-xs">×</span>
          </button>
        </div>
        
        {/* Animated pulse effect */}
        <div className="absolute inset-0 border-2 border-white/30 rounded-2xl animate-pulse"></div>
      </div>
    </div>
  );
}

// Hook for managing nudge state across components
export function useBookNowNudge(cardId: string) {
  const [nudgeShown, setNudgeShown] = useState(false);
  
  useEffect(() => {
    const shownNudges = JSON.parse(sessionStorage.getItem(NUDGE_STORAGE_KEY) || '[]');
    setNudgeShown(shownNudges.includes(cardId));
  }, [cardId]);
  
  const markNudgeAsShown = () => {
    const shownNudges = JSON.parse(sessionStorage.getItem(NUDGE_STORAGE_KEY) || '[]');
    if (!shownNudges.includes(cardId)) {
      const updatedShown = [...shownNudges, cardId];
      sessionStorage.setItem(NUDGE_STORAGE_KEY, JSON.stringify(updatedShown));
      setNudgeShown(true);
    }
  };
  
  return { nudgeShown, markNudgeAsShown };
}