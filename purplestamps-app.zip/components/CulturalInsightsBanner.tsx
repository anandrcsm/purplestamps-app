import { useState, useEffect, useRef } from 'react';
import { Globe, ArrowRight, MapPin } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface CulturalInsightsBannerProps {
  onViewInsights?: () => void;
  onNavigateToTrivia?: () => void;
}

interface CulturalInsight {
  id: string;
  country: string;
  flag: string;
  region: string;
  fact: string;
  image: string;
  accentColor: string;
}

export function CulturalInsightsBanner({ 
  onViewInsights, 
  onNavigateToTrivia 
}: CulturalInsightsBannerProps) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isAutoRotating, setIsAutoRotating] = useState(true);
  const autoRotateRef = useRef<NodeJS.Timeout | null>(null);

  // Cultural insights optimized for card format
  const culturalInsights: CulturalInsight[] = [
    {
      id: 'insight-1',
      country: 'Japan',
      flag: '🇯🇵',
      region: 'East Asia',
      fact: 'In Japan, slurping noodles shows appreciation to the chef',
      image: 'https://images.unsplash.com/photo-1478436127897-769e1b3f0f36?w=600&h=300&fit=crop&auto=format',
      accentColor: '#E91E63'
    },
    {
      id: 'insight-2',
      country: 'India',
      flag: '🇮🇳',
      region: 'South Asia', 
      fact: 'Namaste greeting recognizes the divine spirit in others',
      image: 'https://images.unsplash.com/photo-1524492412937-b28074a5d7da?w=600&h=300&fit=crop&auto=format',
      accentColor: '#FF9800'
    },
    {
      id: 'insight-3',
      country: 'Morocco',
      flag: '🇲🇦',
      region: 'North Africa',
      fact: 'Refusing mint tea hospitality can be considered impolite',
      image: 'https://images.unsplash.com/photo-1539650116574-75c0c6d00b62?w=600&h=300&fit=crop&auto=format',
      accentColor: '#9C27B0'
    },
    {
      id: 'insight-4',
      country: 'Brazil',
      flag: '🇧🇷',
      region: 'South America',
      fact: 'Saudade describes a uniquely Brazilian bittersweet longing',
      image: 'https://images.unsplash.com/photo-1483729558449-99ef09a8c325?w=600&h=300&fit=crop&auto=format',
      accentColor: '#4CAF50'
    },
    {
      id: 'insight-5',
      country: 'Denmark',
      flag: '🇩🇰',
      region: 'Northern Europe',
      fact: 'Hygge represents the Danish art of cozy contentment',
      image: 'https://images.unsplash.com/photo-1448375240586-882707db888b?w=600&h=300&fit=crop&auto=format',
      accentColor: '#2196F3'
    }
  ];

  const currentInsight = culturalInsights[currentIndex];

  // Auto-rotation logic
  useEffect(() => {
    if (isAutoRotating) {
      autoRotateRef.current = setInterval(() => {
        setCurrentIndex(prev => (prev + 1) % culturalInsights.length);
      }, 8000);
    }

    return () => {
      if (autoRotateRef.current) {
        clearInterval(autoRotateRef.current);
      }
    };
  }, [isAutoRotating, culturalInsights.length]);

  const handleCardClick = () => {
    onNavigateToTrivia?.();
  };

  const handleMoreClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    onNavigateToTrivia?.();
  };

  return (
    <div className="px-4">
      <div 
        className="card-standard relative overflow-hidden cursor-pointer group hover:shadow-brand transition-all duration-300 animate-fadeIn"
        style={{ height: '160px' }}
        onClick={handleCardClick}
      >
        {/* Background Image with Overlay */}
        <div className="absolute inset-0 -m-4">
          <ImageWithFallback
            src={currentInsight.image}
            alt={currentInsight.country}
            className="w-full h-full object-cover filter brightness-75 saturate-75"
          />
          {/* Dark Overlay for Text Readability */}
          <div className="absolute inset-0 bg-black/45"></div>
        </div>

        {/* Content Layer */}
        <div className="relative z-10 h-full flex flex-col justify-between">
          {/* Header Section */}
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div 
                className="w-10 h-10 rounded-full flex items-center justify-center shadow-lg backdrop-blur-sm border border-white/20"
                style={{ backgroundColor: `${currentInsight.accentColor}E6` }}
              >
                <Globe size={18} className="text-white" />
              </div>
              <div>
                <h3 className="font-bold text-white text-lg tracking-tight drop-shadow-lg">
                  🌍 Cultural Insight
                </h3>
              </div>
            </div>

            {/* Navigation Dots */}
            <div className="flex items-center space-x-1">
              {culturalInsights.map((_, index) => (
                <div
                  key={index}
                  className={`transition-all duration-300 ${
                    index === currentIndex 
                      ? 'w-6 h-2 bg-white rounded-full shadow-sm' 
                      : 'w-2 h-2 bg-white/60 rounded-full'
                  }`}
                />
              ))}
            </div>
          </div>

          {/* Main Content Section */}
          <div className="space-y-3">
            {/* Country Information */}
            <div className="flex items-center space-x-2">
              <span className="text-2xl drop-shadow-lg">{currentInsight.flag}</span>
              <span className="font-semibold text-white text-lg drop-shadow-lg">
                {currentInsight.country}
              </span>
              <div className="flex items-center space-x-1 bg-white/20 backdrop-blur-sm px-2 py-1 rounded-full border border-white/30">
                <MapPin size={12} className="text-white/90" />
                <span className="text-xs font-medium text-white/90">
                  {currentInsight.region}
                </span>
              </div>
            </div>

            {/* Cultural Fact */}
            <div className="bg-black/40 backdrop-blur-sm rounded-xl px-4 py-3 border border-white/20">
              <p className="text-white font-semibold text-base leading-relaxed drop-shadow-sm">
                {currentInsight.fact}
              </p>
            </div>

            {/* Bottom Action Row */}
            <div className="flex items-center justify-between">
              <div 
                className="px-3 py-1.5 rounded-full text-xs font-bold text-white shadow-sm border border-white/30"
                style={{ backgroundColor: `${currentInsight.accentColor}CC` }}
              >
                Cultural Knowledge
              </div>
              
              <button
                onClick={handleMoreClick}
                className="flex items-center space-x-2 bg-white/90 backdrop-blur-sm text-gray-900 px-4 py-2 rounded-full text-sm font-semibold hover:bg-white hover:scale-105 transition-all duration-200 active:scale-95 shadow-lg group"
              >
                <span>More</span>
                <ArrowRight size={14} className="group-hover:translate-x-0.5 transition-transform duration-200" />
              </button>
            </div>
          </div>
        </div>

        {/* Subtle Gradient Overlay for Visual Polish */}
        <div className="absolute inset-0 -m-4 bg-gradient-to-br from-transparent via-transparent to-black/20 pointer-events-none"></div>
      </div>
    </div>
  );
}