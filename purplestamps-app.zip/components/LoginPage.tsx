import { useState, useEffect } from 'react';
import { Eye, EyeOff, ArrowRight, Globe, Sparkles } from 'lucide-react';
import { BrandLogo } from './BrandLogo';

interface LoginPageProps {
  onLoginSuccess: () => void;
  onNavigateToSignUp: () => void;
}

// Cultural facts for login screen
const culturalFacts = [
  { fact: "Did you know? In Japan, slurping noodles is a compliment! 🍜", emoji: "🇯🇵" },
  { fact: "Fun fact: Touching someone's head in Thailand is considered rude! 🙏", emoji: "🇹🇭" },
  { fact: "Cool tip: In Italy, cappuccino is only drunk in the morning! ☕", emoji: "🇮🇹" },
  { fact: "Amazing: Iceland has no mosquitoes - perfect for camping! 🏕️", emoji: "🇮🇸" },
  { fact: "Wow: In Morocco, mint tea is served 3 times - each tastes different! 🫖", emoji: "🇲🇦" },
  { fact: "Incredible: Finland has more saunas than cars! 🧖‍♂️", emoji: "🇫🇮" }
];

// Rotating taglines
const taglines = [
  "Explore More • Learn More • Earn More 🌏✈️",
  "Your Next Adventure Awaits • Start Wandering 🗺️",
  "Discover Hidden Gems • Create Epic Memories 💎",
  "Connect Cultures • Share Stories • Inspire Others 🌍"
];

export function LoginPage({ onLoginSuccess, onNavigateToSignUp }: LoginPageProps) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [currentFactIndex, setCurrentFactIndex] = useState(0);
  const [currentTaglineIndex, setCurrentTaglineIndex] = useState(0);

  // Rotate cultural facts every 4 seconds
  useEffect(() => {
    const factInterval = setInterval(() => {
      setCurrentFactIndex((prev) => (prev + 1) % culturalFacts.length);
    }, 4000);
    return () => clearInterval(factInterval);
  }, []);

  // Rotate taglines every 3 seconds
  useEffect(() => {
    const taglineInterval = setInterval(() => {
      setCurrentTaglineIndex((prev) => (prev + 1) % taglines.length);
    }, 3000);
    return () => clearInterval(taglineInterval);
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    setIsLoading(false);
    onLoginSuccess();
  };

  const currentFact = culturalFacts[currentFactIndex];
  const currentTagline = taglines[currentTaglineIndex];

  return (
    <div className="min-h-screen bg-gradient-to-br from-surface-warm via-white to-surface-cool flex flex-col">
      {/* Cultural Fact Banner */}
      <div className="bg-gradient-brand text-white py-3 px-4 relative overflow-hidden">
        <div className="absolute inset-0 bg-black/10"></div>
        <div className="relative flex items-center justify-center space-x-2 animate-slideDown">
          <Globe size={16} className="animate-pulse" />
          <div className="text-center">
            <p className="text-sm font-medium">
              <span className="mr-2">{currentFact.emoji}</span>
              {currentFact.fact}
            </p>
          </div>
          <Sparkles size={14} className="animate-pulse" />
        </div>
      </div>

      <div className="flex-1 flex items-center justify-center p-6">
        <div className="w-full max-w-sm">
          {/* Header */}
          <div className="text-center mb-8">
            <div className="mb-6">
              <BrandLogo />
            </div>
            
            {/* Rotating Tagline */}
            <div className="mb-6 h-8 flex items-center justify-center">
              <p 
                key={currentTaglineIndex}
                className="text-sm font-medium text-gray-600 animate-fadeIn text-center"
              >
                {currentTagline}
              </p>
            </div>

            <h1 className="text-2xl font-bold text-gray-900 mb-2">Welcome back, explorer! 🌍</h1>
            <p className="text-gray-600 text-sm">Ready to continue your wandering journey?</p>
          </div>

          {/* Login Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                Email Address
              </label>
              <input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-brand-primary focus:border-transparent transition-all bg-white/80 backdrop-blur-sm"
                placeholder="your@email.com"
                required
              />
            </div>

            <div>
              <label htmlFor="password" className="block text-sm font-medium text-gray-700 mb-1">
                Password
              </label>
              <div className="relative">
                <input
                  id="password"
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full px-4 py-3 pr-12 border border-gray-200 rounded-xl focus:ring-2 focus:ring-brand-primary focus:border-transparent transition-all bg-white/80 backdrop-blur-sm"
                  placeholder="Enter your password"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600 transition-colors"
                >
                  {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full bg-gradient-brand text-white py-3 px-4 rounded-xl font-semibold hover:shadow-brand hover:scale-[1.02] transition-all duration-200 active:scale-95 disabled:opacity-50 disabled:hover:scale-100 flex items-center justify-center space-x-2"
            >
              {isLoading ? (
                <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
              ) : (
                <>
                  <span>Let's Explore! 🚀</span>
                  <ArrowRight size={18} />
                </>
              )}
            </button>
          </form>

          {/* Divider */}
          <div className="my-6 flex items-center">
            <div className="flex-1 border-t border-gray-200"></div>
            <span className="px-3 text-sm text-gray-500">or</span>
            <div className="flex-1 border-t border-gray-200"></div>
          </div>

          {/* Sign Up Link */}
          <div className="text-center">
            <p className="text-sm text-gray-600">
              New to the wandering crew?{' '}
              <button
                onClick={onNavigateToSignUp}
                className="font-semibold text-brand-primary hover:text-brand-primary-dark transition-colors"
              >
                Join the adventure! ✈️
              </button>
            </p>
          </div>

          {/* Bottom Fun Message */}
          <div className="mt-8 text-center">
            <div className="bg-gradient-to-r from-brand-primary/10 to-brand-secondary/10 rounded-xl p-4 border border-brand-primary/20">
              <p className="text-xs text-gray-600 font-medium">
                💡 Pro tip: Your next amazing adventure is just one login away!
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className="p-4 text-center">
        <p className="text-xs text-gray-500">
          Powered by Globetrotter Buddy Mode™ • Making travel social since 2024 🌍
        </p>
      </div>
    </div>
  );
}