import { useState } from 'react';
import { X, Plus, MapPin, DollarSign, Clock, Star, Camera, Link } from 'lucide-react';
import { Bed, Utensils, Car, Mountain, ShoppingBag, Zap } from 'lucide-react';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { Button } from './ui/button';

interface Experience {
  id: string;
  title: string;
  category: 'stay' | 'food' | 'transport' | 'activities' | 'travel-items';
  description: string;
  cost: number;
  location: string;
  media: string[];
  images?: string[];
  rating?: number;
  pricing?: string;
  affiliateLink?: string;
  hasBookingLink?: boolean;
}

interface AddExperienceToTravelCardModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAdd: (experience: Experience) => void;
  selectedCategory?: 'stay' | 'food' | 'transport' | 'activities' | 'travel-items';
}

const categoryLabels = {
  stay: 'Stay',
  food: 'Food',
  transport: 'Transport',
  activities: 'Activities',
  'travel-items': 'Travel Items'
};

const categoryIcons = {
  stay: Bed,
  food: Utensils,
  transport: Car,
  activities: Mountain,
  'travel-items': ShoppingBag
};

export function AddExperienceToTravelCardModal({
  isOpen,
  onClose,
  onAdd,
  selectedCategory = 'activities'
}: AddExperienceToTravelCardModalProps) {
  const [formData, setFormData] = useState({
    title: '',
    category: selectedCategory,
    description: '',
    cost: 0,
    location: '',
    rating: 4.5,
    affiliateLink: '',
    images: ['']
  });

  const [errors, setErrors] = useState<Record<string, string>>({});

  if (!isOpen) return;

  const validateForm = () => {
    const newErrors: Record<string, string> = {};
    
    if (!formData.title.trim()) {
      newErrors.title = 'Experience title is required';
    }
    
    if (!formData.description.trim()) {
      newErrors.description = 'Description is required';
    }
    
    if (!formData.location.trim()) {
      newErrors.location = 'Location is required';
    }

    if (formData.cost < 0) {
      newErrors.cost = 'Cost cannot be negative';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSave = () => {
    if (!validateForm()) return;

    const newExperience: Experience = {
      id: `exp-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      title: formData.title,
      category: formData.category as any,
      description: formData.description,
      cost: formData.cost,
      location: formData.location,
      media: formData.images.filter(img => img.trim()),
      images: formData.images.filter(img => img.trim()),
      rating: formData.rating,
      pricing: formData.cost > 0 ? `₹${formData.cost}` : 'Free',
      affiliateLink: formData.affiliateLink || undefined,
      hasBookingLink: !!formData.affiliateLink
    };

    onAdd(newExperience);
    onClose();
    
    // Reset form
    setFormData({
      title: '',
      category: selectedCategory,
      description: '',
      cost: 0,
      location: '',
      rating: 4.5,
      affiliateLink: '',
      images: ['']
    });
  };

  const handleInputChange = (field: string, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  const addImageField = () => {
    setFormData(prev => ({ ...prev, images: [...prev.images, ''] }));
  };

  const updateImageField = (index: number, value: string) => {
    setFormData(prev => ({
      ...prev,
      images: prev.images.map((img, i) => i === index ? value : img)
    }));
  };

  const removeImageField = (index: number) => {
    if (formData.images.length > 1) {
      setFormData(prev => ({
        ...prev,
        images: prev.images.filter((_, i) => i !== index)
      }));
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl w-full max-w-md max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="sticky top-0 bg-white border-b border-moodboard-gray-light/20 p-6 rounded-t-2xl">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-bold text-moodboard-deep-green">Add New Experience</h2>
            <button
              onClick={onClose}
              className="p-2 hover:bg-moodboard-gray-light/20 rounded-xl transition-colors"
            >
              <X size={20} className="text-moodboard-gray-dark" />
            </button>
          </div>
        </div>

        {/* Form Content */}
        <div className="p-6 space-y-6">
          {/* Category Selection */}
          <div className="space-y-3">
            <label className="text-sm font-medium text-moodboard-deep-green">
              Category
            </label>
            <div className="grid grid-cols-3 gap-2">
              {(Object.keys(categoryLabels) as Array<keyof typeof categoryLabels>).map((category) => {
                const IconComponent = categoryIcons[category];
                const isSelected = formData.category === category;
                
                return (
                  <button
                    key={category}
                    onClick={() => handleInputChange('category', category)}
                    className={`flex flex-col items-center justify-center p-3 rounded-xl transition-all duration-200 ${
                      isSelected
                        ? 'bg-moodboard-muted-teal text-white shadow-md'
                        : 'bg-moodboard-gray-light/10 text-moodboard-gray-dark hover:bg-moodboard-gray-light/20'
                    }`}
                  >
                    <IconComponent size={20} className="mb-1" />
                    <span className="text-xs font-medium">{categoryLabels[category]}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Title */}
          <div className="space-y-2">
            <label className="text-sm font-medium text-moodboard-deep-green">
              Experience Title
            </label>
            <Input
              value={formData.title}
              onChange={(e) => handleInputChange('title', e.target.value)}
              placeholder="e.g., Zostel Kaza Stay"
              className={`${errors.title ? 'border-red-300' : ''}`}
            />
            {errors.title && <p className="text-red-500 text-xs">{errors.title}</p>}
          </div>

          {/* Description */}
          <div className="space-y-2">
            <label className="text-sm font-medium text-moodboard-deep-green">
              Description
            </label>
            <Textarea
              value={formData.description}
              onChange={(e) => handleInputChange('description', e.target.value)}
              placeholder="Describe this experience..."
              rows={3}
              className={`resize-none ${errors.description ? 'border-red-300' : ''}`}
            />
            {errors.description && <p className="text-red-500 text-xs">{errors.description}</p>}
          </div>

          {/* Location */}
          <div className="space-y-2">
            <label className="text-sm font-medium text-moodboard-deep-green flex items-center space-x-2">
              <MapPin size={16} className="text-moodboard-muted-teal" />
              <span>Location</span>
            </label>
            <Input
              value={formData.location}
              onChange={(e) => handleInputChange('location', e.target.value)}
              placeholder="e.g., Kaza, Spiti Valley"
              className={`${errors.location ? 'border-red-300' : ''}`}
            />
            {errors.location && <p className="text-red-500 text-xs">{errors.location}</p>}
          </div>

          {/* Cost and Rating */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium text-moodboard-deep-green flex items-center space-x-2">
                <DollarSign size={16} className="text-moodboard-muted-teal" />
                <span>Cost (₹)</span>
              </label>
              <Input
                type="number"
                value={formData.cost}
                onChange={(e) => handleInputChange('cost', parseInt(e.target.value) || 0)}
                placeholder="1200"
                min="0"
                className={`${errors.cost ? 'border-red-300' : ''}`}
              />
              {errors.cost && <p className="text-red-500 text-xs">{errors.cost}</p>}
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-moodboard-deep-green flex items-center space-x-2">
                <Star size={16} className="text-moodboard-muted-teal" />
                <span>Rating</span>
              </label>
              <Input
                type="number"
                value={formData.rating}
                onChange={(e) => handleInputChange('rating', parseFloat(e.target.value) || 0)}
                placeholder="4.5"
                min="0"
                max="5"
                step="0.1"
              />
            </div>
          </div>

          {/* Affiliate Link */}
          <div className="space-y-2">
            <label className="text-sm font-medium text-moodboard-deep-green flex items-center space-x-2">
              <Link size={16} className="text-moodboard-muted-teal" />
              <span>Booking/Affiliate Link (Optional)</span>
            </label>
            <Input
              value={formData.affiliateLink}
              onChange={(e) => handleInputChange('affiliateLink', e.target.value)}
              placeholder="https://booking.com/..."
            />
          </div>

          {/* Images */}
          <div className="space-y-3">
            <label className="text-sm font-medium text-moodboard-deep-green flex items-center space-x-2">
              <Camera size={16} className="text-moodboard-muted-teal" />
              <span>Images</span>
            </label>
            {formData.images.map((image, index) => (
              <div key={index} className="flex space-x-2">
                <Input
                  value={image}
                  onChange={(e) => updateImageField(index, e.target.value)}
                  placeholder="https://images.unsplash.com/photo-..."
                  className="flex-1"
                />
                {formData.images.length > 1 && (
                  <Button
                    onClick={() => removeImageField(index)}
                    variant="outline"
                    size="sm"
                    className="px-3 text-red-500 hover:text-red-600"
                  >
                    <X size={16} />
                  </Button>
                )}
              </div>
            ))}
            <Button
              onClick={addImageField}
              variant="outline"
              size="sm"
              className="w-full text-moodboard-muted-teal border-moodboard-muted-teal hover:bg-moodboard-muted-teal hover:text-white"
            >
              <Plus size={16} className="mr-2" />
              Add Another Image
            </Button>
          </div>

          {/* Image Previews */}
          {formData.images.some(img => img.trim()) && (
            <div className="space-y-2">
              <span className="text-sm font-medium text-moodboard-deep-green">Preview</span>
              <div className="grid grid-cols-2 gap-2">
                {formData.images
                  .filter(img => img.trim())
                  .map((image, index) => (
                    <img
                      key={index}
                      src={image}
                      alt={`Preview ${index + 1}`}
                      className="w-full h-24 object-cover rounded-lg"
                    />
                  ))
                }
              </div>
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="sticky bottom-0 bg-white border-t border-moodboard-gray-light/20 p-6 rounded-b-2xl">
          <div className="flex space-x-3">
            <Button
              onClick={onClose}
              variant="outline"
              className="flex-1"
            >
              Cancel
            </Button>
            <Button
              onClick={handleSave}
              className="flex-1 bg-moodboard-muted-teal hover:bg-moodboard-muted-teal/90 text-white"
            >
              Add Experience
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}