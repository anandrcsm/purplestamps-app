import { useState } from 'react';
import { MapPin, DollarSign, Compass, Clock, Star, Plane } from 'lucide-react';
import { TravelCard } from '../types';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { getCreator } from '../data/mockData';

interface SuggestedTravelCardsCarouselProps {
  cards: TravelCard[];
  onSelectTravelCard: (id: string) => void;
  onSelectUser?: (userId: string) => void;
}

export function SuggestedTravelCardsCarousel({ 
  cards, 
  onSelectTravelCard,
  onSelectUser
}: SuggestedTravelCardsCarouselProps) {

  const formatCost = (cost?: number) => {
    if (!cost || cost === 0) return 'Free';
    if (cost >= 100000) {
      return `₹${(cost / 100000).toFixed(1)}L`;
    } else if (cost >= 1000) {
      return `₹${(cost / 1000).toFixed(1)}k`;
    }
    return `₹${cost}`;
  };

  const getEstimatedCost = (card: TravelCard) => {
    // Calculate estimated cost from experiences if available
    if (card.experiences && card.experiences.length > 0) {
      const totalCost = card.experiences.reduce((sum, exp) => sum + (exp.cost || 0), 0);
      return totalCost;
    }
    // Fallback based on trip type and budget
    if (card.budget === 'Luxury') return 85000;
    if (card.budget === 'Mid-range') return 35000;
    if (card.budget === 'Budget') return 15000;
    return 25000; // Default estimate
  };

  return (
    <div className="w-full bg-white">
      {/* Minimal Section Label */}
      <div className="px-4 pt-6 pb-4">
        <div className="flex items-center space-x-2">
          <Compass size={14} className="text-moodboard-gray-dark" />
          <span className="text-xs font-medium text-moodboard-gray-dark uppercase tracking-wide">
            SUGGESTED TRAVEL CARDS
          </span>
        </div>
      </div>

      {/* Horizontal Scrollable Travel Cards */}
      <div className="overflow-x-auto scrollbar-hide pb-6">
        <div 
          className="flex space-x-4 px-4"
          style={{
            scrollSnapType: 'x mandatory',
            scrollBehavior: 'smooth'
          }}
        >
          {cards.slice(0, 6).map((card, index) => {
            const creator = card.creatorId ? getCreator(card.creatorId) : null;
            const estimatedCost = getEstimatedCost(card);
            
            return (
              <div
                key={card.id}
                className="flex-shrink-0 w-64 group cursor-pointer animate-fadeIn"
                style={{
                  scrollSnapAlign: 'start',
                  animationDelay: `${index * 100}ms`
                }}
                onClick={() => onSelectTravelCard(card.id)}
              >
                {/* Modern Vertical Travel Card Container - Compact */}
                <div 
                  className="relative bg-white rounded-2xl shadow-lg border border-moodboard-gray-light/10 overflow-hidden transition-all duration-300 hover:shadow-xl hover:scale-[1.02] group-active:scale-[0.98]"
                  style={{ height: '320px' }}
                >
                  {/* Full-Bleed Cover Photo Background - Edge to Edge */}
                  <div className="absolute inset-0 overflow-hidden">
                    <ImageWithFallback
                      src={card.thumbnail || card.images?.[0] || 'https://images.unsplash.com/photo-1469474968028-56623f02e42e?w=600&h=800&fit=crop'}
                      alt={card.title || card.destination || 'Travel destination'}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                    />
                    
                    {/* Gradient Overlay - Dark to Transparent */}
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent"></div>
                  </div>

                  {/* Profile Stamp - Top Right Corner */}
                  {creator && (
                    <div className="absolute top-3 right-3 z-20">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onSelectUser?.(creator.id);
                        }}
                        className="flex items-center space-x-1.5 bg-white/20 backdrop-blur-md rounded-full pr-2 pl-1 py-1 border border-white/30 hover:bg-white/30 transition-all duration-200"
                      >
                        {/* Circular Profile Photo */}
                        <div className="w-6 h-6 rounded-full overflow-hidden border border-white/50 relative">
                          <ImageWithFallback
                            src={creator.profilePic}
                            alt={creator.name}
                            className="w-full h-full object-cover"
                          />
                          {creator.isCreator && (
                            <div className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 bg-gradient-brand rounded-full flex items-center justify-center border border-white">
                              <Plane size={4} className="text-white" />
                            </div>
                          )}
                        </div>
                        
                        {/* Username */}
                        <span className="text-xs font-medium text-white/90">
                          @{creator.username || creator.name.toLowerCase().replace(' ', '')}
                        </span>
                      </button>
                    </div>
                  )}

                  {/* Trip Type Badge - Top Left */}
                  {card.tripType && (
                    <div className="absolute top-3 left-3 z-20">
                      <div className="bg-moodboard-warm-beige/90 backdrop-blur-sm text-moodboard-deep-green px-2 py-1 rounded-full text-xs font-semibold border border-white/20">
                        {card.tripType}
                      </div>
                    </div>
                  )}

                  {/* Caption Text Overlay - Center */}
                  <div className="absolute inset-x-3 bottom-16 z-10">
                    <div className="text-center">
                      {/* Trip Title - Bold */}
                      <h3 className="text-white font-bold text-base mb-1 leading-tight drop-shadow-lg line-clamp-2">
                        {card.title || `Adventure in ${card.destination}`}
                      </h3>
                      
                      {/* Location */}
                      <div className="flex items-center justify-center space-x-1 mb-2">
                        <MapPin size={10} className="text-white/80 flex-shrink-0" />
                        <span className="text-white/80 text-xs truncate">
                          {card.destination}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Trip Details Overlay - Bottom Layer */}
                  <div className="absolute bottom-6 left-3 right-3 z-10">
                    <div className="flex items-center justify-center">
                      {/* Budget Tag Only */}
                      <div className="flex items-center space-x-1 bg-white/20 backdrop-blur-md rounded-full px-2 py-1 border border-white/30">
                        <DollarSign size={10} className="text-white" />
                        <span className="text-white text-xs font-medium">{formatCost(estimatedCost)}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}