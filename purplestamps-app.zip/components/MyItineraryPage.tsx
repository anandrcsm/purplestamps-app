import { useState } from 'react';
import { 
  ArrowLeft, 
  Calendar, 
  MapPin, 
  Edit, 
  Plus,
  Clock,
  Users,
  Share
} from 'lucide-react';
import { TravelItinerary } from '../types';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface MyItineraryPageProps {
  itineraries: TravelItinerary[];
  onBack: () => void;
  onSelectItinerary: (itineraryId: string) => void;
  onCreateNewItinerary: () => void;
}

export function MyItineraryPage({ 
  itineraries, 
  onBack, 
  onSelectItinerary,
  onCreateNewItinerary
}: MyItineraryPageProps) {
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');

  const calculateDays = (startDate: string, endDate: string) => {
    const start = new Date(startDate);
    const end = new Date(endDate);
    const diffTime = Math.abs(end.getTime() - start.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays + 1;
  };

  const formatDateRange = (startDate: string, endDate: string) => {
    const start = new Date(startDate);
    const end = new Date(endDate);
    
    const startMonth = start.toLocaleDateString('en-US', { month: 'short' });
    const endMonth = end.toLocaleDateString('en-US', { month: 'short' });
    
    if (startMonth === endMonth) {
      return `${startMonth} ${start.getDate()}-${end.getDate()}, ${start.getFullYear()}`;
    } else {
      return `${startMonth} ${start.getDate()} - ${endMonth} ${end.getDate()}, ${start.getFullYear()}`;
    }
  };

  return (
    <div className="min-h-screen bg-surface-warm pb-20">
      {/* Header */}
      <div className="sticky top-0 bg-white/95 backdrop-blur-xl border-b border-gray-100 shadow-sm z-10">
        <div className="flex items-center justify-between p-4">
          <button 
            onClick={onBack}
            className="flex items-center text-brand-primary hover:text-brand-primary-dark transition-colors"
          >
            <ArrowLeft size={20} className="mr-2" />
            <span>Back</span>
          </button>
          
          <button
            onClick={onCreateNewItinerary}
            className="flex items-center bg-brand-primary text-white px-4 py-2 rounded-xl hover:bg-brand-primary-dark transition-colors"
          >
            <Plus size={16} className="mr-1" />
            New
          </button>
        </div>
        
        <div className="px-4 pb-4">
          <div className="flex items-center justify-between mb-2">
            <div>
              <h1 className="text-2xl text-gray-900">My Itineraries</h1>
              <p className="text-gray-600 text-sm">
                {itineraries.length} {itineraries.length === 1 ? 'itinerary' : 'itineraries'} planned
              </p>
            </div>
            <div className="w-12 h-12 bg-gradient-brand-secondary rounded-2xl flex items-center justify-center">
              <Calendar size={24} className="text-white" />
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="p-4">
        {itineraries.length > 0 ? (
          <div className="grid grid-cols-1 gap-6">
            {itineraries.map((itinerary) => (
              <div
                key={itinerary.id}
                className="bg-white rounded-2xl shadow-sm overflow-hidden border border-gray-100 hover:shadow-md transition-all duration-200 cursor-pointer"
                onClick={() => onSelectItinerary(itinerary.id)}
              >
                {/* Cover Image */}
                <div className="relative h-48">
                  {itinerary.coverImage ? (
                    <ImageWithFallback 
                      src={itinerary.coverImage} 
                      alt={itinerary.title}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="w-full h-full bg-gradient-to-br from-brand-primary to-brand-secondary flex items-center justify-center">
                      <MapPin size={48} className="text-white" />
                    </div>
                  )}
                  
                  {/* Edit Icon */}
                  <button 
                    className="absolute top-4 right-4 w-10 h-10 bg-white/90 backdrop-blur-sm rounded-full flex items-center justify-center hover:bg-white transition-colors"
                    onClick={(e) => {
                      e.stopPropagation();
                      // Handle edit functionality
                    }}
                  >
                    <Edit size={16} className="text-gray-600" />
                  </button>

                  {/* Trip Status Badge */}
                  <div className="absolute top-4 left-4">
                    <span className="px-3 py-1 bg-white/90 backdrop-blur-sm text-xs font-medium text-gray-700 rounded-full">
                      {new Date(itinerary.startDate) > new Date() ? 'Planned' : 
                       new Date(itinerary.endDate) < new Date() ? 'Completed' : 'In Progress'}
                    </span>
                  </div>
                </div>

                {/* Content */}
                <div className="p-6">
                  {/* Title and Destination */}
                  <div className="mb-4">
                    <h3 className="text-xl font-semibold text-gray-900 mb-2">{itinerary.title}</h3>
                    <div className="flex items-center text-gray-500 text-sm mb-3">
                      <MapPin size={16} className="mr-2" />
                      <span>{itinerary.destination}</span>
                    </div>
                  </div>

                  {/* Trip Details */}
                  <div className="grid grid-cols-2 gap-4 mb-4">
                    <div className="flex items-center text-sm text-gray-600">
                      <Calendar size={16} className="mr-2 text-gray-400" />
                      <div>
                        <div className="font-medium">{formatDateRange(itinerary.startDate, itinerary.endDate)}</div>
                      </div>
                    </div>
                    
                    <div className="flex items-center text-sm text-gray-600">
                      <Clock size={16} className="mr-2 text-gray-400" />
                      <div>
                        <div className="font-medium">{calculateDays(itinerary.startDate, itinerary.endDate)} days</div>
                      </div>
                    </div>
                  </div>

                  {/* Experience Count */}
                  <div className="flex items-center justify-between pt-4 border-t border-gray-100">
                    <div className="text-sm text-gray-500">
                      {itinerary.experiences?.length || 0} experiences planned
                    </div>
                    
                    <div className="flex items-center space-x-3">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          // Handle share functionality
                        }}
                        className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
                      >
                        <Share size={16} className="text-gray-500" />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          /* Empty State */
          <div className="text-center py-16">
            <div className="w-32 h-32 bg-gradient-to-br from-brand-secondary/10 to-brand-primary/10 rounded-full flex items-center justify-center mx-auto mb-6">
              <Calendar size={48} className="text-brand-secondary" />
            </div>
            <h3 className="text-xl text-gray-900 mb-2">No itineraries yet</h3>
            <p className="text-gray-500 mb-6 max-w-sm mx-auto">
              Create your first travel itinerary to organize your bucket list experiences.
            </p>
            <button
              onClick={onCreateNewItinerary}
              className="bg-gradient-brand text-white py-3 px-6 rounded-xl font-semibold hover:shadow-brand transition-all duration-200 flex items-center mx-auto"
            >
              <Plus size={20} className="mr-2" />
              Create Itinerary
            </button>
          </div>
        )}
      </div>
    </div>
  );
}