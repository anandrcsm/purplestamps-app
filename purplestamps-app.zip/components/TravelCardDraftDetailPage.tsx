import { useState, useEffect } from 'react';
import { 
  ArrowLeft, 
  Edit3, 
  Save, 
  Send, 
  Plus, 
  MapPin, 
  Calendar, 
  DollarSign, 
  Users, 
  Camera, 
  ExternalLink, 
  Trash2, 
  Clock, 
  Star,
  ChevronLeft,
  ChevronRight,
  X,
  MoreVertical,
  Heart,
  MessageCircle,
  Share2,
  Bookmark,
  UserPlus,
  Bed,
  Utensils,
  Car,
  Mountain,
  ShoppingBag,
  Zap
} from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { CategoryTag } from './CategoryTag';
import { StarRating } from './StarRating';
import { TravelCardDraft } from '../types';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { EditDraftDetailsModal } from './EditDraftDetailsModal';
import { AddExperienceToTravelCardModal } from './AddExperienceToTravelCardModal';
import { AddMomentModal } from './AddMomentModal';

interface TravelCardDraftDetailPageProps {
  draftData: TravelCardDraft;
  onBack: () => void;
  onPublish: (draftData: any) => void;
  onSaveDraft: (draftData: any) => void;
  onSelectExperience?: (id: string) => void;
  onSelectProduct?: (id: string) => void;
}

interface Experience {
  id: string;
  title: string;
  category: 'stay' | 'food' | 'activity' | 'transport' | 'travel-items';
  description: string;
  cost: number;
  location: string;
  day?: string;
  timeFrom?: string;
  timeTo?: string;
  media: string[];
  images?: string[];
  hasBookingLink?: boolean;
  bookingUrl?: string;
  affiliateLink?: string;
  rating?: number;
  reviewCount?: number;
  pricing?: string;
}

type TabType = 'gallery' | 'experiences' | 'travel-items';
type ExperienceFilterType = 'all' | 'stay' | 'food' | 'transport' | 'activities';

const tabLabels: Record<TabType, string> = {
  gallery: 'Gallery',
  experiences: 'Experiences',
  'travel-items': 'Travel Items'
};

const tabIcons: Record<TabType, React.ComponentType<{ size?: number; className?: string }>> = {
  gallery: Camera,
  experiences: Mountain,
  'travel-items': ShoppingBag
};

const experienceFilterLabels: Record<ExperienceFilterType, string> = {
  all: 'All',
  stay: 'Stay',
  food: 'Food',
  transport: 'Transport',
  activities: 'Activities'
};

const experienceFilterIcons: Record<ExperienceFilterType, React.ComponentType<{ size?: number; className?: string }>> = {
  all: Mountain,
  stay: Bed,
  food: Utensils,
  transport: Car,
  activities: Zap
};

// Enhanced Gallery View Component - Matching TravelCardPage design
interface DraftGalleryViewProps {
  moments: Array<{ 
    id: string; 
    image: string; 
    experienceTitle: string; 
    experienceLocation: string; 
    experienceCategory: string 
  }>;
  onSelectExperience?: (id: string) => void;
}

// Day-wise Experiences View with filtering
interface DraftExperiencesViewProps {
  experiences: Experience[];
  onSelectExperience?: (id: string) => void;
  onAddToItinerary?: (id: string) => void;
  onEditExperience?: (id: string) => void;
  onRemoveExperience?: (id: string) => void;
  savedExperiences: Set<string>;
  onSaveExperience: (id: string, event: React.MouseEvent) => void;
}

// Travel Items View Component
interface DraftTravelItemsViewProps {
  travelItems: Experience[];
  onSelectProduct?: (id: string) => void;
  onAddTravelItem?: () => void;
}

function DraftGalleryView({ moments, onSelectExperience }: DraftGalleryViewProps) {
  const [selectedMoment, setSelectedMoment] = useState<string | null>(null);

  if (moments.length === 0) {
    return (
      <div className="text-center py-16 px-4">
        <div className="w-20 h-20 bg-moodboard-gray-light/30 rounded-2xl flex items-center justify-center mx-auto mb-4">
          <Camera size={32} className="text-moodboard-gray-dark" />
        </div>
        <h3 className="font-semibold text-moodboard-deep-green mb-2">No moments yet</h3>
        <p className="text-moodboard-gray-dark text-sm">
          Moments will appear here as you add images to your experiences.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Gallery Grid */}
      <div className="grid grid-cols-2 gap-3 p-4">
        {moments.map((moment, index) => (
          <div 
            key={moment.id}
            className="break-inside-avoid animate-fadeIn"
            style={{ animationDelay: `${index * 50}ms` }}
          >
            <div 
              className="relative aspect-square rounded-xl overflow-hidden bg-moodboard-gray-light/10 cursor-pointer group hover:scale-[1.02] transition-all duration-300 shadow-md hover:shadow-lg"
              onClick={() => setSelectedMoment(moment.id)}
            >
              <ImageWithFallback
                src={moment.image}
                alt={moment.experienceTitle}
                className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110"
              />
              
              {/* Subtle overlay on hover */}
              <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-all duration-300"></div>
              
              {/* Experience title overlay */}
              <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-3">
                <p className="text-white text-xs font-medium line-clamp-1">
                  {moment.experienceTitle}
                </p>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Expanded Moment View Modal */}
      {selectedMoment && (
        <ExpandedMomentView
          moments={moments}
          currentMomentId={selectedMoment}
          onClose={() => setSelectedMoment(null)}
          onNavigate={setSelectedMoment}
          onSelectExperience={onSelectExperience}
        />
      )}
    </div>
  );
}

// Day-wise Experiences View with filtering
function DraftExperiencesView({ 
  experiences, 
  onSelectExperience, 
  onAddToItinerary,
  onEditExperience,
  onRemoveExperience,
  savedExperiences,
  onSaveExperience 
}: DraftExperiencesViewProps) {
  const [selectedFilter, setSelectedFilter] = useState<ExperienceFilterType>('all');
  
  // Filter experiences based on selected filter
  const filteredExperiences = selectedFilter === 'all' 
    ? experiences 
    : experiences.filter(exp => exp.category === selectedFilter);

  // Group experiences by day (mock implementation)
  const groupExperiencesByDay = (experiences: Experience[]) => {
    const grouped: { [key: string]: Experience[] } = {};
    
    experiences.forEach((exp, index) => {
      const dayNumber = Math.floor(index / 3) + 1;
      const dayKey = `Day ${dayNumber}`;
      
      if (!grouped[dayKey]) {
        grouped[dayKey] = [];
      }
      grouped[dayKey].push(exp);
    });
    
    return grouped;
  };

  const groupedExperiences = groupExperiencesByDay(filteredExperiences);

  if (experiences.length === 0) {
    return (
      <div className="text-center py-16 px-4">
        <div className="w-20 h-20 bg-moodboard-gray-light/30 rounded-2xl flex items-center justify-center mx-auto mb-4">
          <Mountain size={32} className="text-moodboard-gray-dark" />
        </div>
        <h3 className="font-semibold text-moodboard-deep-green mb-2">No experiences yet</h3>
        <p className="text-moodboard-gray-dark text-sm">
          Experiences will appear here as they are added to this travel card.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Filter Bar */}
      <div className="px-4 pt-4">
        <div className="flex justify-evenly pb-2">
          {(Object.keys(experienceFilterLabels) as ExperienceFilterType[]).map((filter) => {
            const FilterIcon = experienceFilterIcons[filter];
            const isActive = selectedFilter === filter;
            
            return (
              <button
                key={filter}
                onClick={() => setSelectedFilter(filter)}
                className={`flex items-center justify-center p-3 rounded-full transition-all duration-200 ${
                  isActive
                    ? 'bg-moodboard-muted-teal text-white shadow-md'
                    : 'bg-gray-100 text-moodboard-gray-dark hover:bg-gray-200'
                }`}
              >
                <FilterIcon size={20} />
              </button>
            );
          })}
        </div>
      </div>

      {/* Day-wise Experience Groups */}
      <div className="px-4 space-y-6">
        {Object.entries(groupedExperiences).map(([day, dayExperiences]) => (
          <div key={day} className="space-y-4">
            {/* Day Header */}
            <div className="flex items-center gap-3">
              <div className="flex items-center justify-center w-10 h-10 bg-moodboard-muted-teal rounded-full">
                <span className="text-white font-semibold text-sm">{day.split(' ')[1]}</span>
              </div>
              <div>
                <h3 className="font-semibold text-moodboard-deep-green">{day}</h3>
                <p className="text-moodboard-gray-dark text-sm">{dayExperiences.length} experiences</p>
              </div>
            </div>

            {/* Day's Experiences */}
            <div className="space-y-3 ml-13">
              {dayExperiences.map((experience) => (
                <div
                  key={experience.id}
                  className="relative h-40 overflow-hidden rounded-xl hover:scale-[1.01] transition-all duration-300 cursor-pointer group shadow-md hover:shadow-lg"
                  onClick={() => onSelectExperience?.(experience.id)}
                  style={{
                    backgroundImage: experience.images && experience.images[0]
                      ? `url(${experience.images[0]})` 
                      : 'linear-gradient(135deg, #4A9B8E 0%, #6BBAB0 100%)',
                    backgroundSize: 'cover',
                    backgroundPosition: 'center'
                  }}
                >
                  {/* Lighter Gradient Overlay for Better Readability */}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/35 via-black/10 to-transparent"></div>
                  
                  {/* Content Overlay */}
                  <div className="absolute inset-0 flex flex-col items-center justify-center text-center p-4">
                    {/* Top Action Buttons */}
                    <div className="absolute top-3 right-3 flex items-center space-x-2">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onSaveExperience(experience.id, e);
                        }}
                        className={`p-2 rounded-lg backdrop-blur-sm transition-all duration-200 ${
                          savedExperiences.has(experience.id)
                            ? 'bg-moodboard-warm-beige/90 text-moodboard-deep-green'
                            : 'bg-white/20 text-white hover:bg-white/30'
                        }`}
                      >
                        <Bookmark size={16} className={savedExperiences.has(experience.id) ? 'fill-current' : ''} />
                      </button>
                      
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onEditExperience?.(experience.id);
                        }}
                        className="p-2 rounded-lg backdrop-blur-sm bg-white/20 text-white hover:bg-white/30 transition-colors"
                      >
                        <Edit3 size={16} />
                      </button>
                      
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onRemoveExperience?.(experience.id);
                        }}
                        className="p-2 rounded-lg backdrop-blur-sm bg-white/20 text-red-400 hover:bg-white/30 transition-colors"
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>

                    {/* Main Content */}
                    <div className="flex-1 flex flex-col items-center justify-center">
                      {/* Category */}
                      <div className="mb-2">
                        <CategoryTag category={experience.category || 'activity'} />
                      </div>
                      
                      {/* Title */}
                      <h4 className="font-semibold text-white text-center mb-2 line-clamp-2 group-hover:text-moodboard-warm-beige transition-colors">
                        {experience.title || 'Untitled Experience'}
                      </h4>
                      
                      {/* Rating */}
                      {experience.rating && (
                        <div className="flex items-center gap-1 mb-3">
                          <Star size={14} className="fill-yellow-400 text-yellow-400" />
                          <span className="text-sm font-medium text-white">{experience.rating}</span>
                        </div>
                      )}
                      
                      {/* Location and Cost */}
                      <div className="flex items-center justify-center gap-4 text-white/90">
                        <div className="flex items-center gap-1">
                          <MapPin size={12} />
                          <span className="text-xs">{experience.location || 'Location not specified'}</span>
                        </div>
                        {experience.cost && (
                          <span className="font-semibold text-moodboard-warm-beige">
                            ${experience.cost}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// Travel Items View
function DraftTravelItemsView({ travelItems, onSelectProduct, onAddTravelItem }: DraftTravelItemsViewProps) {
  if (travelItems.length === 0) {
    return (
      <div className="text-center py-16 px-4">
        <div className="w-20 h-20 bg-moodboard-gray-light/30 rounded-2xl flex items-center justify-center mx-auto mb-4">
          <ShoppingBag size={32} className="text-moodboard-gray-dark" />
        </div>
        <h3 className="font-semibold text-moodboard-deep-green mb-2">No travel items yet</h3>
        <p className="text-moodboard-gray-dark text-sm">
          Travel essentials and gear recommendations will appear here.
        </p>
        <button
          onClick={onAddTravelItem}
          className="mt-4 px-6 py-3 bg-moodboard-muted-teal text-white rounded-xl font-medium hover:bg-moodboard-muted-teal/90 transition-colors"
        >
          Add Travel Item
        </button>
      </div>
    );
  }

  return (
    <div className="px-4 py-4 space-y-4">
      {travelItems.map((item) => (
        <div
          key={item.id}
          className="bg-white rounded-xl p-4 shadow-sm border border-gray-100 hover:shadow-md transition-all duration-200 cursor-pointer"
          onClick={() => onSelectProduct?.(item.id)}
        >
          <div className="flex gap-4">
            {/* Item Image */}
            <div className="w-20 h-20 flex-shrink-0 rounded-lg overflow-hidden bg-gray-50">
              {item.images?.[0] && (
                <ImageWithFallback
                  src={item.images[0]}
                  alt={item.title}
                  className="w-full h-full object-cover"
                />
              )}
            </div>
            
            {/* Item Details */}
            <div className="flex-1">
              <div className="flex items-start justify-between mb-2">
                <div>
                  <h4 className="font-medium text-moodboard-deep-green mb-1">{item.title}</h4>
                  <p className="text-xs text-moodboard-gray-dark mb-2 line-clamp-2">{item.description}</p>
                </div>
              </div>
              
              {/* Rating and Category */}
              <div className="flex items-center gap-3 mb-2">
                {item.rating && (
                  <div className="flex items-center gap-1">
                    <Star size={12} className="fill-yellow-400 text-yellow-400" />
                    <span className="text-xs text-moodboard-gray-dark">{item.rating}</span>
                  </div>
                )}
                <span className="text-xs bg-moodboard-gray-light/30 text-moodboard-gray-dark px-2 py-1 rounded-full">
                  {item.category}
                </span>
              </div>
              
              {/* Price and Link */}
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="font-semibold text-moodboard-muted-teal">
                    ${item.cost}
                  </span>
                </div>
                <ExternalLink size={16} className="text-moodboard-gray-dark" />
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}

// Expanded Moment View Component
function ExpandedMomentView({
  moments,
  currentMomentId,
  onClose,
  onNavigate,
  onSelectExperience
}: {
  moments: Array<{
    id: string;
    image: string;
    experienceTitle: string;
    experienceLocation: string;
    experienceCategory: string;
  }>;
  currentMomentId: string;
  onClose: () => void;
  onNavigate: (id: string) => void;
  onSelectExperience?: (id: string) => void;
}) {
  const handleBackdropClick = (e: React.MouseEvent) => {
    if (e.target === e.currentTarget) {
      onClose();
    }
  };

  return (
    <div 
      className="fixed inset-0 bg-moodboard-deep-green/95 backdrop-blur-sm z-50 animate-backdropFadeIn overflow-y-auto"
      onClick={handleBackdropClick}
    >
      {/* Close Button */}
      <button
        onClick={onClose}
        className="fixed top-6 right-6 w-10 h-10 bg-white/90 backdrop-blur-sm rounded-full flex items-center justify-center text-moodboard-deep-green hover:scale-110 transition-all duration-200 z-20 shadow-lg"
      >
        <X size={20} />
      </button>

      {/* Moments Feed */}
      <div className="min-h-screen py-16">
        <div className="w-full">
          {moments.map((moment, index) => (
            <div 
              key={moment.id} 
              className="mb-3 animate-fadeIn"
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <div className="max-w-4xl mx-auto px-4">
                <ImageWithFallback
                  src={moment.image}
                  alt={moment.experienceTitle}
                  className="w-full h-auto max-h-[80vh] object-contain rounded-2xl shadow-2xl"
                />
                
                <div className="mt-4 text-center">
                  <h3 className="text-white font-semibold mb-1">{moment.experienceTitle}</h3>
                  <p className="text-white/70 text-sm">{moment.experienceLocation}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export function TravelCardDraftDetailPage({ 
  draftData: initialDraftData, 
  onBack, 
  onPublish, 
  onSaveDraft,
  onSelectExperience,
  onSelectProduct 
}: TravelCardDraftDetailPageProps) {
  // Use the real draft data passed from App.tsx
  const [draftData, setDraftData] = useState({
    ...initialDraftData,
    // Ensure we have images array
    images: initialDraftData.coverImage ? [initialDraftData.coverImage] : [],
    // Add default experiences if none exist
    experiences: initialDraftData.experiences?.length ? initialDraftData.experiences : [
      {
        id: 'exp-1',
        title: 'Sample Experience',
        category: 'activities' as const,
        description: 'Add your first experience to this travel card',
        cost: 0,
        location: initialDraftData.destination || 'Location',
        media: [],
        images: [],
        rating: 4.5,
        pricing: 'Free'
      }
    ],
    // Ensure we have collaborators array
    collaborators: initialDraftData.collaborators || [],
    // Add other required fields
    likes: 0,
    comments: 0,
    views: 0,
    dates: `${initialDraftData.startDate || 'TBD'} - ${initialDraftData.endDate || 'TBD'}`
  });

  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [selectedTab, setSelectedTab] = useState<TabType>('gallery');
  const [savedExperiences, setSavedExperiences] = useState<Set<string>>(new Set());
  const [isLiked, setIsLiked] = useState(false);
  const [isSaved, setIsSaved] = useState(false);
  
  // Edit mode states
  const [isEditingTitle, setIsEditingTitle] = useState(false);
  const [isEditingDescription, setIsEditingDescription] = useState(false);
  const [isEditingDestination, setIsEditingDestination] = useState(false);
  const [editMode, setEditMode] = useState(false);
  
  // Modal states
  const [showEditDetailsModal, setShowEditDetailsModal] = useState(false);
  const [showAddExperienceModal, setShowAddExperienceModal] = useState(false);
  const [showAddMomentModal, setShowAddMomentModal] = useState(false);
  const [addExperienceCategory, setAddExperienceCategory] = useState<'stay' | 'food' | 'transport' | 'activities' | 'travel-items'>('activities');

  const safeImages = draftData.images && draftData.images.length > 0 
    ? draftData.images 
    : [draftData.coverImage];

  const safeExperiences = draftData.experiences || [];

  // Mock creator data
  const mockCreator = {
    id: 'current-user',
    name: 'You',
    username: 'your_username',
    profilePic: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=50&h=50&fit=crop&crop=face',
    isCreator: false
  };

  useEffect(() => {
    setCurrentImageIndex(0);
  }, [draftData]);

  const nextImage = () => {
    if (safeImages.length > 1) {
      setCurrentImageIndex((prev) => (prev + 1) % safeImages.length);
    }
  };

  const prevImage = () => {
    if (safeImages.length > 1) {
      setCurrentImageIndex((prev) => (prev - 1 + safeImages.length) % safeImages.length);
    }
  };

  const handleSaveExperience = (experienceId: string, event: React.MouseEvent) => {
    event.stopPropagation();
    setSavedExperiences(prev => {
      const newSet = new Set(prev);
      if (newSet.has(experienceId)) {
        newSet.delete(experienceId);
      } else {
        newSet.add(experienceId);
      }
      return newSet;
    });
  };

  const handleBookNow = (experience: Experience, event: React.MouseEvent) => {
    event.stopPropagation();
    if (experience.affiliateLink) {
      window.open(experience.affiliateLink, '_blank');
    }
  };

  const handlePublishDraft = () => {
    const publishData = {
      ...draftData,
      isDraft: false,
      publishedAt: new Date().toISOString(),
      creatorId: mockCreator.id,
      creator: mockCreator,
      rating: 4.8
    };
    onPublish(publishData);
  };

  const handleSaveDraft = () => {
    onSaveDraft(draftData);
    showToast('Draft saved successfully!');
  };

  // Edit handlers
  const handleUpdateTitle = (newTitle: string) => {
    setDraftData(prev => ({ ...prev, title: newTitle }));
    setIsEditingTitle(false);
  };

  const handleUpdateDescription = (newDescription: string) => {
    setDraftData(prev => ({ ...prev, description: newDescription }));
    setIsEditingDescription(false);
  };

  const handleUpdateDestination = (newDestination: string) => {
    setDraftData(prev => ({ ...prev, destination: newDestination }));
    setIsEditingDestination(false);
  };

  const handleEditExperience = (experienceId: string) => {
    showToast('Opening experience editor...');
    // This would open an experience editing modal
  };

  const handleAddExperience = () => {
    setAddExperienceCategory(selectedTab === 'gallery' ? 'activities' : selectedTab === 'travel-items' ? 'travel-items' : 'activities');
    setShowAddExperienceModal(true);
  };

  const handleRemoveExperience = (experienceId: string) => {
    setDraftData(prev => ({
      ...prev,
      experiences: prev.experiences?.filter(exp => exp.id !== experienceId) || []
    }));
    showToast('Experience removed from draft');
  };

  const handleSaveExperienceToCard = (newExperience: any) => {
    setDraftData(prev => ({
      ...prev,
      experiences: [...(prev.experiences || []), newExperience],
      experienceCount: (prev.experienceCount || 0) + 1,
      lastUpdated: new Date().toISOString()
    }));
    showToast(`"${newExperience.title}" added to travel card!`);
  };

  const handleSaveMomentToCard = (newMoment: any) => {
    // For now, we'll add the moment's image to the first matching experience
    // In a real app, you'd have a more sophisticated gallery system
    setDraftData(prev => {
      const updatedExperiences = [...(prev.experiences || [])];
      
      // Try to find an experience that matches the moment's details
      const matchingExpIndex = updatedExperiences.findIndex(exp => 
        exp.title.toLowerCase().includes(newMoment.experienceTitle.toLowerCase()) ||
        exp.category === newMoment.experienceCategory
      );
      
      if (matchingExpIndex >= 0) {
        // Add to existing experience
        updatedExperiences[matchingExpIndex] = {
          ...updatedExperiences[matchingExpIndex],
          images: [...(updatedExperiences[matchingExpIndex].images || []), newMoment.image],
          media: [...(updatedExperiences[matchingExpIndex].media || []), newMoment.image]
        };
      } else {
        // Create a new experience for this moment
        const newExperience = {
          id: `exp-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
          title: newMoment.experienceTitle,
          category: newMoment.experienceCategory as any,
          description: newMoment.caption || `Experience at ${newMoment.experienceLocation}`,
          cost: 0,
          location: newMoment.experienceLocation,
          images: [newMoment.image],
          media: [newMoment.image],
          rating: 4.5,
          pricing: 'Free'
        };
        updatedExperiences.push(newExperience);
      }
      
      return {
        ...prev,
        experiences: updatedExperiences,
        lastUpdated: new Date().toISOString()
      };
    });
    showToast('Moment added to gallery!');
  };

  const handleUpdateDraftDetails = (updatedDetails: any) => {
    setDraftData(prev => ({ ...prev, ...updatedDetails }));
    showToast('Draft details updated successfully!');
  };

  // Get experiences based on tab
  const getExperiencesForTab = () => {
    switch (selectedTab) {
      case 'experiences':
        return safeExperiences.filter(exp => exp.category !== 'travel-items');
      case 'travel-items':
        return safeExperiences.filter(exp => exp.category === 'travel-items');
      default:
        return [];
    }
  };

  // Collect all images/moments from all experiences for gallery
  const getAllMoments = () => {
    const allMoments: Array<{ id: string; image: string; experienceTitle: string; experienceLocation: string; experienceCategory: string }> = [];
    
    safeExperiences.forEach(experience => {
      if (experience.images && experience.images.length > 0) {
        experience.images.forEach((image, index) => {
          allMoments.push({
            id: `${experience.id}-img-${index}`,
            image: image,
            experienceTitle: experience.title || 'Untitled Experience',
            experienceLocation: experience.location || 'Unknown Location',
            experienceCategory: experience.category || 'activity'
          });
        });
      }
      if (experience.media && experience.media.length > 0) {
        experience.media.forEach((media, index) => {
          if (!allMoments.some(moment => moment.image === media)) {
            allMoments.push({
              id: `${experience.id}-media-${index}`,
              image: media,
              experienceTitle: experience.title || 'Untitled Experience',
              experienceLocation: experience.location || 'Unknown Location',
              experienceCategory: experience.category || 'activity'
            });
          }
        });
      }
    });
    
    return allMoments;
  };

  const calculateTotalCost = () => {
    const total = safeExperiences.reduce((sum, exp) => sum + (exp.cost || 0), 0);
    return total > 0 ? `$${total}` : null;
  };

  const calculateDuration = () => {
    return draftData.duration || '6 days';
  };

  const showToast = (message: string, type: 'success' | 'info' = 'success') => {
    const styles = {
      success: 'bg-moodboard-cream border-moodboard-muted-teal text-moodboard-deep-green shadow-brand',
      info: 'bg-moodboard-cream border-moodboard-warm-beige text-moodboard-charcoal shadow-brand-secondary'
    };

    const toast = document.createElement('div');
    toast.className = `fixed top-20 left-1/2 transform -translate-x-1/2 ${styles[type]} border px-4 py-3 rounded-xl z-50 backdrop-blur-sm animate-slideDown max-w-sm`;
    toast.innerHTML = `
      <div class="flex items-center space-x-3">
        <span class="font-medium text-sm">${message}</span>
      </div>
    `;
    document.body.appendChild(toast);
    setTimeout(() => {
      toast.style.opacity = '0';
      setTimeout(() => document.body.removeChild(toast), 300);
    }, 3000);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-surface-warm to-surface-cool">
      {/* Sticky Header - Same as TravelCardPage */}
      <header className="fixed top-0 left-0 right-0 z-40 bg-white/90 backdrop-blur-xl border-b border-gray-100">
        <div className="flex items-center justify-between p-4">
          <button
            onClick={onBack}
            className="p-2 hover:bg-gray-100 rounded-xl transition-colors"
          >
            <ArrowLeft size={20} className="text-gray-700" />
          </button>
          <div className="flex-1"></div>
          
          {/* Edit Details Button */}
          <button 
            onClick={() => setShowEditDetailsModal(true)}
            className="p-2 hover:bg-gray-100 rounded-xl transition-colors"
            title="Edit Details"
          >
            <Edit3 size={20} className="text-gray-700" />
          </button>
          
          <button className="p-2 hover:bg-gray-100 rounded-xl transition-colors">
            <MoreVertical size={20} className="text-gray-700" />
          </button>
        </div>
      </header>

      {/* Main Content - Exactly matching TravelCardPage structure */}
      <main className="pt-16">
        {/* ===== TOP HALF: HERO SECTION WITH ALL INFO OVERLAID ===== */}
        <div className="relative h-[85vh] overflow-hidden">
          {/* Hero Background Image */}
          <ImageWithFallback
            src={safeImages[currentImageIndex] || 'https://images.unsplash.com/photo-1469474968028-56623f02e42e?w=800&h=600&fit=crop'}
            alt={draftData.destination || draftData.title || 'Travel destination'}
            className="w-full h-full object-cover"
          />
          
          {/* Image Navigation Controls */}
          {safeImages.length > 1 && (
            <>
              <button
                onClick={prevImage}
                className="absolute left-4 top-1/2 transform -translate-y-1/2 p-3 bg-black/50 text-white rounded-full hover:bg-black/70 transition-colors backdrop-blur-sm"
              >
                <ChevronLeft size={24} />
              </button>
              <button
                onClick={nextImage}
                className="absolute right-4 top-1/2 transform -translate-y-1/2 p-3 bg-black/50 text-white rounded-full hover:bg-black/70 transition-colors backdrop-blur-sm"
              >
                <ChevronRight size={24} />
              </button>
              
              {/* Image Indicators */}
              <div className="absolute top-20 left-1/2 transform -translate-x-1/2 flex space-x-2">
                {safeImages.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => setCurrentImageIndex(index)}
                    className={`w-2 h-2 rounded-full transition-all duration-200 ${
                      index === currentImageIndex ? 'bg-white' : 'bg-white/50'
                    }`}
                  />
                ))}
              </div>
            </>
          )}

          {/* Triple Gradient Overlay for Better Text Readability */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
          <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-transparent to-transparent" />
          <div className="absolute inset-0 bg-black/20" />

          {/* OVERLAID CONTENT - All travel card info */}
          <div className="absolute inset-0 flex flex-col justify-between p-6 text-white">
            
            {/* TOP SECTION: Profile Stamp with Draft Badge */}
            <div className="absolute top-4 right-4 z-20">
              <div className="flex flex-col items-end space-y-2">
                {/* Creator Profile Button */}
                <button className="flex items-center space-x-2 bg-white/20 backdrop-blur-md rounded-full pr-3 pl-1 py-1 border border-white/30">
                  <div className="w-8 h-8 rounded-full overflow-hidden border-2 border-white/50 relative">
                    <ImageWithFallback
                      src={mockCreator.profilePic}
                      alt={mockCreator.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <span className="text-xs font-medium text-white/90">
                    @{mockCreator.username}
                  </span>
                </button>

                {/* Draft Badge */}
                <div className="bg-moodboard-warm-beige/90 backdrop-blur-sm text-moodboard-deep-green px-3 py-1 rounded-full text-xs font-semibold border border-white/30">
                  DRAFT ({draftData.completionPercentage}%)
                </div>
              </div>
            </div>

            {/* TOP LEFT: Small Collaborators Section */}
            {draftData.collaborators.length > 0 && (
              <div className="absolute top-4 left-4 z-20">
                <div className="flex items-center space-x-2 overflow-x-auto scrollbar-hide">
                  <div className="w-7 h-7 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center border border-white/30 flex-shrink-0">
                    <Users size={12} className="text-white" />
                  </div>
                  {draftData.collaborators.slice(0, 3).map((collaborator) => (
                    <button
                      key={collaborator.id}
                      className="flex-shrink-0 hover:scale-110 transition-transform duration-200"
                    >
                      <div className="w-7 h-7 rounded-full overflow-hidden border-2 border-white/40 shadow-lg">
                        <ImageWithFallback
                          src={collaborator.avatar}
                          alt={collaborator.name}
                          className="w-full h-full object-cover"
                        />
                      </div>
                    </button>
                  ))}
                  {draftData.collaborators.length > 3 && (
                    <div className="w-7 h-7 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center border border-white/30 text-xs font-bold text-white">
                      +{draftData.collaborators.length - 3}
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* CENTER SECTION: Title and Caption - With Edit Functionality */}
            <div className="absolute inset-x-6 bottom-32 z-10">
              <div className="text-center">
                {/* Editable Title */}
                {isEditingTitle ? (
                  <div className="mb-3">
                    <Input
                      value={draftData.title}
                      onChange={(e) => setDraftData(prev => ({ ...prev, title: e.target.value }))}
                      onBlur={() => setIsEditingTitle(false)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') {
                          handleUpdateTitle(e.currentTarget.value);
                        }
                        if (e.key === 'Escape') {
                          setIsEditingTitle(false);
                        }
                      }}
                      className="w-full text-white text-3xl font-bold bg-black/20 border border-white/30 rounded-lg px-3 py-2 text-center backdrop-blur-sm"
                      autoFocus
                    />
                  </div>
                ) : (
                  <h1 
                    className="text-white font-bold text-3xl mb-3 leading-tight drop-shadow-lg cursor-pointer hover:bg-black/20 rounded-lg px-2 py-1 transition-colors"
                    onClick={() => setIsEditingTitle(true)}
                  >
                    {draftData.title || `Adventure in ${draftData.destination}`}
                    <Edit3 size={20} className="inline ml-2 opacity-70" />
                  </h1>
                )}
                
                {/* Editable Description */}
                {isEditingDescription ? (
                  <div className="mb-4">
                    <Textarea
                      value={draftData.description || ''}
                      onChange={(e) => setDraftData(prev => ({ ...prev, description: e.target.value }))}
                      onBlur={() => setIsEditingDescription(false)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter' && e.ctrlKey) {
                          handleUpdateDescription(e.currentTarget.value);
                        }
                        if (e.key === 'Escape') {
                          setIsEditingDescription(false);
                        }
                      }}
                      className="w-full text-white/90 text-sm bg-black/20 border border-white/30 rounded-lg px-3 py-2 backdrop-blur-sm resize-none"
                      rows={3}
                      autoFocus
                    />
                    <p className="text-white/60 text-xs mt-1">Press Ctrl+Enter to save, Esc to cancel</p>
                  </div>
                ) : (
                  <div>
                    {draftData.description ? (
                      <p 
                        className="text-white/90 text-sm leading-relaxed line-clamp-2 drop-shadow-md max-w-sm mx-auto mb-4 cursor-pointer hover:bg-black/20 rounded-lg px-2 py-1 transition-colors"
                        onClick={() => setIsEditingDescription(true)}
                      >
                        {draftData.description}
                        <Edit3 size={14} className="inline ml-1 opacity-70" />
                      </p>
                    ) : (
                      <p 
                        className="text-white/70 text-sm italic leading-relaxed max-w-sm mx-auto mb-4 cursor-pointer hover:bg-black/20 rounded-lg px-2 py-1 transition-colors border border-dashed border-white/30"
                        onClick={() => setIsEditingDescription(true)}
                      >
                        + Add description
                      </p>
                    )}
                  </div>
                )}
              </div>
            </div>

            {/* TRIP DETAILS: Location, Date, Duration and Cost - Centered with Edit */}
            <div className="absolute bottom-16 left-6 right-6 z-10">
              <div className="flex items-center justify-center space-x-2 flex-wrap">
                {/* Editable Location Tag */}
                {isEditingDestination ? (
                  <div className="bg-white/20 backdrop-blur-md rounded-full px-3 py-1.5 border border-white/30">
                    <Input
                      value={draftData.destination}
                      onChange={(e) => setDraftData(prev => ({ ...prev, destination: e.target.value }))}
                      onBlur={() => setIsEditingDestination(false)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') {
                          handleUpdateDestination(e.currentTarget.value);
                        }
                        if (e.key === 'Escape') {
                          setIsEditingDestination(false);
                        }
                      }}
                      className="text-white text-xs font-medium bg-transparent border-none p-0 h-auto w-32"
                      autoFocus
                    />
                  </div>
                ) : (
                  <div 
                    className="flex items-center space-x-1 bg-white/20 backdrop-blur-md rounded-full px-3 py-1.5 border border-white/30 cursor-pointer hover:bg-white/30 transition-colors"
                    onClick={() => setIsEditingDestination(true)}
                  >
                    <MapPin size={12} className="text-white" />
                    <span className="text-white text-xs font-medium">{draftData.destination}</span>
                    <Edit3 size={10} className="text-white/70" />
                  </div>
                )}

                {/* Date Tag */}
                {draftData.dates && (
                  <div className="flex items-center space-x-1 bg-white/20 backdrop-blur-md rounded-full px-3 py-1.5 border border-white/30">
                    <Calendar size={12} className="text-white" />
                    <span className="text-white text-xs font-medium">{draftData.dates}</span>
                  </div>
                )}
                
                {/* Duration Tag */}
                <div className="flex items-center space-x-1 bg-white/20 backdrop-blur-md rounded-full px-3 py-1.5 border border-white/30">
                  <Clock size={12} className="text-white" />
                  <span className="text-white text-xs font-medium">{calculateDuration()}</span>
                </div>
                
                {/* Cost Tag */}
                {calculateTotalCost() && (
                  <div className="flex items-center space-x-1 bg-white/20 backdrop-blur-md rounded-full px-3 py-1.5 border border-white/30">
                    <DollarSign size={12} className="text-white" />
                    <span className="text-white text-xs font-medium">{calculateTotalCost()}</span>
                  </div>
                )}
              </div>
            </div>

            {/* BOTTOM SECTION: Action Buttons with Draft Actions */}
            <div className="absolute bottom-0 left-0 right-0 z-10">
              <div className="flex items-center justify-between px-6 py-3 bg-[rgba(0,0,0,0)]">
                {/* Left Side Actions */}
                <div className="flex items-center space-x-4">
                  {/* Like Button */}
                  <button
                    onClick={() => setIsLiked(!isLiked)}
                    className={`flex items-center space-x-1 transition-all duration-200 hover:scale-110 active:scale-95 touch-target ${
                      isLiked ? 'text-red-400' : 'text-white hover:text-red-400'
                    }`}
                  >
                    <Heart size={20} className={isLiked ? 'fill-current' : ''} />
                    <span className="text-sm font-medium">{draftData.likes || 0}</span>
                  </button>

                  {/* Comment Button */}
                  <button
                    onClick={() => window.scrollTo({ top: document.body.scrollHeight, behavior: 'smooth' })}
                    className="flex items-center space-x-1 text-white hover:text-moodboard-muted-teal transition-all duration-200 hover:scale-110 active:scale-95 touch-target"
                  >
                    <MessageCircle size={20} />
                    <span className="text-sm font-medium">{draftData.comments || 0}</span>
                  </button>

                  {/* Share Button */}
                  <button
                    onClick={() => console.log('Share')}
                    className="text-white hover:text-moodboard-muted-teal transition-all duration-200 hover:scale-110 active:scale-95 touch-target"
                  >
                    <Share2 size={20} />
                  </button>
                </div>

                {/* Save Button - Right Side */}
                <button
                  onClick={() => setIsSaved(!isSaved)}
                  className={`transition-all duration-200 hover:scale-110 active:scale-95 touch-target ${
                    isSaved ? 'text-moodboard-warm-beige' : 'text-white hover:text-moodboard-warm-beige'
                  }`}
                >
                  <Bookmark size={20} className={isSaved ? 'fill-current' : ''} />
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* ===== BOTTOM HALF: TABBED CONTENT SECTION ===== */}
        <div className="bg-white min-h-screen pb-20">
          {/* Tab Navigation */}
          <div className="sticky top-[72px] z-30 bg-white border-b border-gray-100 px-4 pt-6 pb-4">
            <div className="flex space-x-1">
              {(Object.keys(tabLabels) as TabType[]).map((tab) => {
                const TabIcon = tabIcons[tab];
                const isActive = selectedTab === tab;
                
                return (
                  <button
                    key={tab}
                    onClick={() => setSelectedTab(tab)}
                    className={`flex items-center justify-center p-3 rounded-xl font-medium text-sm transition-all duration-200 flex-1 ${
                      isActive
                        ? 'bg-moodboard-muted-teal text-white shadow-lg'
                        : 'bg-gray-50 text-moodboard-gray-dark hover:bg-gray-100'
                    }`}
                  >
                    <TabIcon size={20} />
                  </button>
                );
              })}
            </div>
          </div>

          {/* Content Area */}
          <div>
            {selectedTab === 'gallery' && (
              <DraftGalleryView 
                moments={getAllMoments()} 
                onSelectExperience={onSelectExperience}
              />
            )}

            {selectedTab === 'experiences' && (
              <DraftExperiencesView
                experiences={getExperiencesForTab()}
                onSelectExperience={onSelectExperience}
                onAddToItinerary={() => {}}
                onEditExperience={handleEditExperience}
                onRemoveExperience={handleRemoveExperience}
                savedExperiences={savedExperiences}
                onSaveExperience={handleSaveExperience}
              />
            )}

            {selectedTab === 'travel-items' && (
              <DraftTravelItemsView
                travelItems={getExperiencesForTab()}
                onSelectProduct={onSelectProduct}
                onAddTravelItem={handleAddExperience}
              />
            )}
          </div>
        </div>
      </main>

      {/* Draft Action Bar - Fixed at Bottom */}
      <div className="fixed bottom-0 left-0 right-0 z-50 bg-white border-t border-moodboard-gray-light/20 p-4 safe-area-inset-bottom">
        <div className="flex space-x-3">
          {/* Edit Mode Toggle */}
          <button
            onClick={() => setEditMode(!editMode)}
            className={`px-4 py-3 rounded-xl font-medium transition-colors flex items-center justify-center space-x-2 ${
              editMode 
                ? 'bg-moodboard-muted-teal text-white' 
                : 'bg-moodboard-gray-light/20 text-moodboard-deep-green hover:bg-moodboard-gray-light/30'
            }`}
          >
            <Edit3 size={18} />
          </button>
          
          <button
            onClick={handleSaveDraft}
            className="flex-1 py-3 bg-moodboard-warm-beige text-moodboard-deep-green rounded-xl font-medium hover:bg-moodboard-warm-beige-dark transition-colors flex items-center justify-center space-x-2"
          >
            <Save size={18} />
            <span>Save Draft</span>
          </button>
          <button
            onClick={handlePublishDraft}
            className="flex-1 py-3 bg-moodboard-muted-teal text-white rounded-xl font-medium hover:bg-moodboard-muted-teal/90 transition-colors flex items-center justify-center space-x-2"
          >
            <Send size={18} />
            <span>Publish</span>
          </button>
        </div>
      </div>

      {/* Edit Details Modal */}
      <EditDraftDetailsModal
        isOpen={showEditDetailsModal}
        onClose={() => setShowEditDetailsModal(false)}
        draftData={draftData}
        onSave={handleUpdateDraftDetails}
      />

      {/* Add Experience Modal */}
      <AddExperienceToTravelCardModal
        isOpen={showAddExperienceModal}
        onClose={() => setShowAddExperienceModal(false)}
        onAdd={handleSaveExperienceToCard}
        selectedCategory={addExperienceCategory}
      />

      {/* Add Moment Modal */}
      <AddMomentModal
        isOpen={showAddMomentModal}
        onClose={() => setShowAddMomentModal(false)}
        onAdd={handleSaveMomentToCard}
      />
    </div>
  );
}