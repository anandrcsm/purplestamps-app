import { useState } from 'react';
import { Heart, MessageCircle, Share, MapPin, Bookmark, Plane } from 'lucide-react';
import { Moment } from '../types';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { SwipeUpCommentSheet } from './SwipeUpCommentSheet';
import { getCreator } from '../data/mockData';

interface MomentCardProps {
  moment: Moment;
  onLike: () => void;
  onSave: () => void;
  onSelectUser?: (userId: string) => void;
  showCommentsModal?: boolean;
}

export function MomentCard({
  moment,
  onLike,
  onSave,
  onSelectUser,
  showCommentsModal = false
}: MomentCardProps) {
  const [isCommentSheetOpen, setIsCommentSheetOpen] = useState(false);
  const [commentsList, setCommentsList] = useState([
    {
      id: '1',
      userId: 'user1',
      userName: 'alex.explorer',
      userAvatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=50&h=50&fit=crop&crop=face',
      text: 'What an amazing capture! 📸✨',
      timestamp: '1h',
      likes: 5,
      isLiked: false,
      repliesCount: 0
    }
  ]);

  const creator = moment.creatorId ? getCreator(moment.creatorId) : null;

  const handleCommentClick = () => {
    if (showCommentsModal) {
      setIsCommentSheetOpen(true);
    }
  };

  const handleAddComment = (text: string) => {
    const newComment = {
      id: `comment-${Date.now()}`,
      userId: 'current-user',
      userName: 'you',
      userAvatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=50&h=50&fit=crop&crop=face',
      text,
      timestamp: 'now',
      likes: 0,
      isLiked: false,
      repliesCount: 0
    };
    setCommentsList(prev => [newComment, ...prev]);
  };

  const handleLikeComment = (commentId: string) => {
    setCommentsList(prev => prev.map(comment => 
      comment.id === commentId 
        ? {
            ...comment,
            isLiked: !comment.isLiked,
            likes: comment.isLiked ? comment.likes - 1 : comment.likes + 1
          }
        : comment
    ));
  };

  const handleReplyComment = (commentId: string, replyText: string) => {
    // Implementation for reply functionality
  };

  return (
    <article className="w-full animate-fadeIn cursor-pointer group">
      {/* Polaroid Container - Reduced Padding */}
      <div className="bg-white rounded-2xl shadow-lg border border-moodboard-gray-light/10 overflow-hidden transition-all duration-300 hover:shadow-xl hover:scale-[1.01] group-active:scale-[0.99] p-2">
        
        {/* Polaroid Photo Container - Edge to Edge */}
        <div className="bg-white rounded-lg overflow-hidden shadow-sm">
          
          {/* Main Photo - Longer Format, Edge to Edge */}
          <div className="relative aspect-[3/4] overflow-hidden">
            <ImageWithFallback
              src={moment.image}
              alt={moment.caption || 'Travel moment'}
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
            />
            
            {/* User Info Overlay - On Image, Top Area */}
            {creator && (
              <div className="absolute top-3 left-3 right-3">
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onSelectUser?.(creator.id);
                  }}
                  className="flex items-center space-x-2 bg-black/30 backdrop-blur-md rounded-full pr-3 pl-1 py-1 border border-white/20 hover:bg-black/40 transition-all duration-200 max-w-fit"
                >
                  {/* Profile Photo */}
                  <div className="w-8 h-8 rounded-full overflow-hidden border-2 border-white/50 relative">
                    <ImageWithFallback
                      src={creator.profilePic}
                      alt={creator.name}
                      className="w-full h-full object-cover"
                    />
                    {creator.isCreator && (
                      <div className="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-gradient-brand rounded-full flex items-center justify-center border border-white">
                        <Plane size={6} className="text-white" />
                      </div>
                    )}
                  </div>
                  
                  {/* Name and Location */}
                  <div className="text-left">
                    <p className="text-white text-sm font-semibold leading-tight">
                      {creator.name}
                    </p>
                    <div className="flex items-center space-x-1">
                      <MapPin size={10} className="text-white/80" />
                      <span className="text-white/80 text-xs">
                        {moment.location || creator.location || 'Unknown Location'}
                      </span>
                    </div>
                  </div>
                </button>
              </div>
            )}
          </div>
          
          {/* Polaroid White Bottom Strip with Caption and Actions */}
          <div className="bg-white px-4 py-4">
            {/* Caption - In White Space */}
            <div className="mb-4">
              <p className="handwriting-style text-moodboard-deep-green text-sm leading-relaxed line-clamp-2">
                {moment.caption || 'A beautiful moment captured'}
              </p>
            </div>

            {/* Action Buttons */}
            <div className="flex items-center justify-between">
              {/* Left Side Actions */}
              <div className="flex items-center space-x-4">
                {/* Like Button */}
                <button 
                  onClick={onLike}
                  className={`flex items-center space-x-1 transition-all duration-200 hover:scale-110 active:scale-95 touch-target ${
                    moment.isLiked ? 'text-red-500' : 'text-moodboard-gray-dark hover:text-red-500'
                  }`}
                >
                  <Heart size={20} className={moment.isLiked ? 'fill-current' : ''} />
                  <span className="text-sm font-medium">{moment.likes || 0}</span>
                </button>

                {/* Comment Button */}
                <button 
                  onClick={handleCommentClick}
                  className="flex items-center space-x-1 text-moodboard-gray-dark hover:text-moodboard-muted-teal transition-all duration-200 hover:scale-110 active:scale-95 touch-target"
                >
                  <MessageCircle size={20} />
                  <span className="text-sm font-medium">{moment.comments || 0}</span>
                </button>

                {/* Share Button */}
                <button 
                  className="text-moodboard-gray-dark hover:text-moodboard-muted-teal transition-all duration-200 hover:scale-110 active:scale-95 touch-target"
                >
                  <Share size={20} />
                </button>
              </div>

              {/* Save Button - Right Side */}
              <button 
                onClick={onSave}
                className={`transition-all duration-200 hover:scale-110 active:scale-95 touch-target ${
                  moment.isSaved ? 'text-moodboard-warm-beige-dark' : 'text-moodboard-gray-dark hover:text-moodboard-warm-beige-dark'
                }`}
              >
                <Bookmark size={20} className={moment.isSaved ? 'fill-current' : ''} />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Swipe Up Comment Sheet */}
      <SwipeUpCommentSheet
        isOpen={isCommentSheetOpen}
        onClose={() => setIsCommentSheetOpen(false)}
        contentId={moment.id}
        contentType="moment"
        comments={commentsList}
        totalComments={commentsList.length + commentsList.reduce((sum, c) => sum + (c.repliesCount || 0), 0)}
        onAddComment={handleAddComment}
        onLikeComment={handleLikeComment}
        onReplyComment={handleReplyComment}
      />
    </article>
  );
}