import { useState, useEffect, useRef } from 'react';
import { X, Heart, MoreHorizontal, Smile, Image as ImageIcon, Send, ArrowLeft } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface Comment {
  id: string;
  userId: string;
  userName: string;
  userAvatar: string;
  text: string;
  timestamp: string;
  likes: number;
  isLiked: boolean;
  replies?: Comment[];
  repliesCount?: number;
}

interface SwipeUpCommentSheetProps {
  isOpen: boolean;
  onClose: () => void;
  contentId: string;
  contentType: 'travel-card' | 'moment' | 'local-gem';
  comments: Comment[];
  totalComments: number;
  onAddComment: (text: string) => void;
  onLikeComment: (commentId: string) => void;
  onReplyComment: (commentId: string, replyText: string) => void;
}

// Enhanced emoji reactions for Instagram-style experience
const EMOJI_REACTIONS = ['❤️', '😍', '🔥', '👏', '😂', '😮', '🙌', '✨'];

// Content-specific dummy comments
const getDummyComments = (contentType: string): Comment[] => {
  const baseComments = {
    'travel-card': [
      {
        id: 'tc-1',
        userId: 'user1',
        userName: 'wanderlust_sara',
        userAvatar: 'https://images.unsplash.com/photo-1494790108755-2616b612e2fa?w=50&h=50&fit=crop&crop=face',
        text: 'Was this trip expensive to plan? 💰 Your itinerary looks amazing!',
        timestamp: '2h',
        likes: 23,
        isLiked: false,
        repliesCount: 4,
        replies: [
          {
            id: 'tc-1-1',
            userId: 'user2',
            userName: 'budget_backpacker',
            userAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=50&h=50&fit=crop&crop=face',
            text: 'I spent around $2k for 10 days including flights!',
            timestamp: '1h',
            likes: 8,
            isLiked: false
          }
        ]
      },
      {
        id: 'tc-2',
        userId: 'user3',
        userName: 'travel_addict_jen',
        userAvatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=50&h=50&fit=crop&crop=face',
        text: 'Loved this destination, going this winter! ❄️ Would you recommend staying near the old town?',
        timestamp: '4h',
        likes: 15,
        isLiked: true,
        repliesCount: 2
      },
      {
        id: 'tc-3',
        userId: 'user4',
        userName: 'solo_explorer',
        userAvatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=50&h=50&fit=crop&crop=face',
        text: 'This is giving me major FOMO! 😭 Adding to my bucket list right now',
        timestamp: '6h',
        likes: 31,
        isLiked: false,
        repliesCount: 0
      }
    ],
    'moment': [
      {
        id: 'm-1',
        userId: 'user1',
        userName: 'photo_wanderer',
        userAvatar: 'https://images.unsplash.com/photo-1494790108755-2616b612e2fa?w=50&h=50&fit=crop&crop=face',
        text: 'This photo\'s giving Pinterest vibes 😍 The lighting is absolutely perfect!',
        timestamp: '1h',
        likes: 42,
        isLiked: false,
        repliesCount: 3,
        replies: [
          {
            id: 'm-1-1',
            userId: 'user2',
            userName: 'golden_hour_lover',
            userAvatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=50&h=50&fit=crop&crop=face',
            text: 'Golden hour hits different! 🌅',
            timestamp: '45m',
            likes: 12,
            isLiked: true
          }
        ]
      },
      {
        id: 'm-2',
        userId: 'user3',
        userName: 'travel_photographer',
        userAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=50&h=50&fit=crop&crop=face',
        text: 'Where was this taken exactly? 📍 Need to add this spot to my photography list!',
        timestamp: '3h',
        likes: 18,
        isLiked: false,
        repliesCount: 1
      },
      {
        id: 'm-3',
        userId: 'user4',
        userName: 'adventure_seeker',
        userAvatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=50&h=50&fit=crop&crop=face',
        text: 'Solo or with a group? This looks like such a peaceful moment ✨',
        timestamp: '5h',
        likes: 7,
        isLiked: false,
        repliesCount: 0
      }
    ],
    'local-gem': [
      {
        id: 'lg-1',
        userId: 'user1',
        userName: 'local_foodie',
        userAvatar: 'https://images.unsplash.com/photo-1494790108755-2616b612e2fa?w=50&h=50&fit=crop&crop=face',
        text: 'Hidden gem! Any food nearby? 🍕 This spot looks incredible for photos too!',
        timestamp: '1h',
        likes: 28,
        isLiked: false,
        repliesCount: 2,
        replies: [
          {
            id: 'lg-1-1',
            userId: 'user2',
            userName: 'street_food_hunter',
            userAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=50&h=50&fit=crop&crop=face',
            text: 'There\'s an amazing taco truck 2 blocks away! 🌮',
            timestamp: '30m',
            likes: 9,
            isLiked: false
          }
        ]
      },
      {
        id: 'lg-2',
        userId: 'user3',
        userName: 'pet_parent_travels',
        userAvatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=50&h=50&fit=crop&crop=face',
        text: 'Dog-friendly? 🐕 Planning to bring my golden retriever on our next trip!',
        timestamp: '2h',
        likes: 12,
        isLiked: true,
        repliesCount: 1
      },
      {
        id: 'lg-3',
        userId: 'user4',
        userName: 'practical_traveler',
        userAvatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=50&h=50&fit=crop&crop=face',
        text: 'Parking available? 🚗 Or is it better to take public transport?',
        timestamp: '4h',
        likes: 15,
        isLiked: false,
        repliesCount: 0
      }
    ]
  };

  return baseComments[contentType] || [];
};

export function SwipeUpCommentSheet({
  isOpen,
  onClose,
  contentId,
  contentType,
  comments = [],
  totalComments = 0,
  onAddComment,
  onLikeComment,
  onReplyComment
}: SwipeUpCommentSheetProps) {
  const [commentText, setCommentText] = useState('');
  const [replyingTo, setReplyingTo] = useState<string | null>(null);
  const [startY, setStartY] = useState(0);
  const [currentY, setCurrentY] = useState(0);
  const [isDragging, setIsDragging] = useState(false);
  const [keyboardHeight, setKeyboardHeight] = useState(0);
  const [showAllComments, setShowAllComments] = useState(false);
  const [expandedReplies, setExpandedReplies] = useState<Set<string>>(new Set());

  const sheetRef = useRef<HTMLDivElement>(null);
  const backdropRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Use dummy comments if no comments provided
  const displayComments = comments.length > 0 ? comments : getDummyComments(contentType);

  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
      // Auto-focus input after a slight delay for better UX
      setTimeout(() => {
        inputRef.current?.focus();
      }, 300);
    } else {
      document.body.style.overflow = 'unset';
    }
    
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isOpen]);

  // Handle keyboard visibility on mobile
  useEffect(() => {
    const handleResize = () => {
      const windowHeight = window.innerHeight;
      const documentHeight = document.documentElement.clientHeight;
      const heightDifference = documentHeight - windowHeight;
      
      if (heightDifference > 150) {
        setKeyboardHeight(heightDifference);
      } else {
        setKeyboardHeight(0);
      }
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const handleTouchStart = (e: React.TouchEvent) => {
    setStartY(e.touches[0].clientY);
    setIsDragging(true);
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (!isDragging) return;
    
    const deltaY = e.touches[0].clientY - startY;
    if (deltaY > 0) {
      setCurrentY(Math.min(deltaY, 200)); // Limit drag distance
    }
  };

  const handleTouchEnd = () => {
    setIsDragging(false);
    
    // Close if dragged down more than 80px
    if (currentY > 80) {
      onClose();
    }
    
    setCurrentY(0);
  };

  const handleBackdropClick = (e: React.MouseEvent) => {
    if (e.target === backdropRef.current) {
      onClose();
    }
  };

  const handleSubmitComment = () => {
    if (commentText.trim()) {
      if (replyingTo) {
        onReplyComment(replyingTo, commentText.trim());
        setReplyingTo(null);
      } else {
        onAddComment(commentText.trim());
      }
      setCommentText('');
    }
  };

  const handleEmojiReaction = (emoji: string) => {
    setCommentText(prev => prev + emoji);
    inputRef.current?.focus();
  };

  const toggleReplies = (commentId: string) => {
    setExpandedReplies(prev => {
      const newSet = new Set(prev);
      if (newSet.has(commentId)) {
        newSet.delete(commentId);
      } else {
        newSet.add(commentId);
      }
      return newSet;
    });
  };

  const formatTimestamp = (timestamp: string) => {
    return timestamp.toLowerCase();
  };

  const visibleComments = showAllComments ? displayComments : displayComments.slice(0, 3);

  if (!isOpen) return null;

  return (
    <>
      {/* Backdrop */}
      <div
        ref={backdropRef}
        className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 transition-opacity duration-300 animate-backdropFadeIn"
        onClick={handleBackdropClick}
      />

      {/* Full-Screen Comment Modal */}
      <div
        ref={sheetRef}
        className={`fixed inset-0 z-50 bg-gray-900 text-white transition-transform duration-300 ease-out ${
          isOpen ? 'translate-y-0' : 'translate-y-full'
        }`}
        style={{
          transform: `translateY(${currentY}px)`,
          marginBottom: keyboardHeight > 0 ? `${keyboardHeight}px` : '0',
        }}
      >
        {/* Header with drag handle */}
        <div 
          className="sticky top-0 z-10 bg-gray-900/95 backdrop-blur-xl border-b border-gray-700"
          onTouchStart={handleTouchStart}
          onTouchMove={handleTouchMove}
          onTouchEnd={handleTouchEnd}
        >
          {/* Drag Handle */}
          <div className="flex justify-center pt-3 pb-2">
            <div className="w-12 h-1 bg-gray-600 rounded-full"></div>
          </div>

          {/* Header Controls */}
          <div className="px-4 pb-4">
            <div className="flex items-center justify-between">
              <button
                onClick={onClose}
                className="p-2 hover:bg-gray-800 rounded-full transition-colors touch-target"
                aria-label="Close"
              >
                <ArrowLeft size={24} />
              </button>
              
              <h2 className="text-lg font-semibold">
                Comments
                {totalComments > 0 && (
                  <span className="text-gray-400 font-normal ml-2">
                    ({totalComments})
                  </span>
                )}
              </h2>
              
              <button
                className="p-2 hover:bg-gray-800 rounded-full transition-colors touch-target"
                aria-label="More options"
              >
                <MoreHorizontal size={20} />
              </button>
            </div>
          </div>
        </div>

        {/* Comments List - Scrollable */}
        <div 
          className="flex-1 overflow-y-auto px-4 pb-4"
          style={{ 
            maxHeight: keyboardHeight > 0 
              ? `calc(100vh - 200px - ${keyboardHeight}px)` 
              : 'calc(100vh - 200px)' 
          }}
        >
          {visibleComments.map((comment) => (
            <div key={comment.id} className="mb-6">
              {/* Main Comment */}
              <div className="flex items-start space-x-3">
                {/* User Avatar */}
                <div className="flex-shrink-0">
                  <div className="w-10 h-10 rounded-full overflow-hidden border border-gray-700">
                    <ImageWithFallback
                      src={comment.userAvatar}
                      alt={comment.userName}
                      className="w-full h-full object-cover"
                    />
                  </div>
                </div>

                {/* Comment Content */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center space-x-2 mb-2">
                        <span className="font-semibold text-white">
                          {comment.userName}
                        </span>
                        <span className="text-sm text-gray-400">
                          {formatTimestamp(comment.timestamp)}
                        </span>
                      </div>
                      <p className="text-white leading-relaxed mb-3">
                        {comment.text}
                      </p>
                      
                      {/* Comment Actions */}
                      <div className="flex items-center space-x-6">
                        <button
                          onClick={() => setReplyingTo(comment.id)}
                          className="text-sm text-gray-400 hover:text-white transition-colors font-medium"
                        >
                          Reply
                        </button>
                        {comment.likes > 0 && (
                          <span className="text-sm text-gray-400">
                            {comment.likes} {comment.likes === 1 ? 'like' : 'likes'}
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Like Button */}
                    <div className="flex flex-col items-center ml-4">
                      <button
                        onClick={() => onLikeComment(comment.id)}
                        className={`p-2 rounded-full transition-all duration-200 touch-target ${
                          comment.isLiked 
                            ? 'text-red-500 bg-red-500/10' 
                            : 'text-gray-400 hover:text-white hover:bg-gray-800'
                        }`}
                      >
                        <Heart
                          size={18}
                          className={comment.isLiked ? 'fill-current' : ''}
                        />
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              {/* Replies */}
              {comment.repliesCount && comment.repliesCount > 0 && (
                <div className="ml-13 mt-4">
                  <button
                    onClick={() => toggleReplies(comment.id)}
                    className="text-sm text-gray-400 hover:text-white transition-colors mb-4 font-medium"
                  >
                    {expandedReplies.has(comment.id) 
                      ? `Hide ${comment.repliesCount} ${comment.repliesCount === 1 ? 'reply' : 'replies'}`
                      : `View ${comment.repliesCount} ${comment.repliesCount === 1 ? 'reply' : 'replies'}`
                    }
                  </button>

                  {/* Expanded Replies */}
                  {expandedReplies.has(comment.id) && comment.replies && (
                    <div className="space-y-4">
                      {comment.replies.map((reply) => (
                        <div key={reply.id} className="flex items-start space-x-3">
                          <div className="flex-shrink-0">
                            <div className="w-8 h-8 rounded-full overflow-hidden border border-gray-700">
                              <ImageWithFallback
                                src={reply.userAvatar}
                                alt={reply.userName}
                                className="w-full h-full object-cover"
                              />
                            </div>
                          </div>
                          <div className="flex-1">
                            <div className="flex items-center space-x-2 mb-1">
                              <span className="font-semibold text-sm text-white">
                                {reply.userName}
                              </span>
                              <span className="text-xs text-gray-400">
                                {formatTimestamp(reply.timestamp)}
                              </span>
                            </div>
                            <p className="text-sm text-gray-200 leading-relaxed">
                              {reply.text}
                            </p>
                          </div>
                          <div className="flex flex-col items-center">
                            <button
                              onClick={() => onLikeComment(reply.id)}
                              className={`p-1 rounded-full transition-all duration-200 ${
                                reply.isLiked ? 'text-red-500' : 'text-gray-400 hover:text-white'
                              }`}
                            >
                              <Heart
                                size={14}
                                className={reply.isLiked ? 'fill-current' : ''}
                              />
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>
          ))}

          {/* Show More Comments Button */}
          {!showAllComments && displayComments.length > 3 && (
            <button
              onClick={() => setShowAllComments(true)}
              className="w-full text-center text-gray-400 hover:text-white transition-colors py-4 font-medium"
            >
              View all {displayComments.length} comments
            </button>
          )}

          {/* Empty State */}
          {displayComments.length === 0 && (
            <div className="text-center py-12">
              <p className="text-gray-400">
                No comments yet. Be the first to share your thoughts!
              </p>
            </div>
          )}
        </div>

        {/* Fixed Bottom Section */}
        <div className="sticky bottom-0 bg-gray-900 border-t border-gray-700">
          {/* Emoji Reaction Tray */}
          <div className={`px-4 py-3 transition-all duration-200 ${keyboardHeight > 0 ? 'opacity-50 scale-95' : ''}`}>
            <div className="flex items-center space-x-2 overflow-x-auto scrollbar-hide">
              {EMOJI_REACTIONS.map((emoji, index) => (
                <button
                  key={index}
                  onClick={() => handleEmojiReaction(emoji)}
                  className="flex-shrink-0 w-10 h-10 rounded-full bg-gray-800 hover:bg-gray-700 transition-all duration-200 hover:scale-110 active:scale-95 flex items-center justify-center text-lg touch-target"
                >
                  {emoji}
                </button>
              ))}
            </div>
          </div>

          {/* Comment Input */}
          <div className="px-4 pb-4">
            {replyingTo && (
              <div className="mb-3 flex items-center justify-between bg-gray-800 rounded-lg p-3">
                <span className="text-sm text-gray-300">
                  Replying to {displayComments.find(c => c.id === replyingTo)?.userName}
                </span>
                <button
                  onClick={() => setReplyingTo(null)}
                  className="text-sm text-gray-400 hover:text-white transition-colors"
                >
                  Cancel
                </button>
              </div>
            )}
            
            <div className="flex items-center space-x-3">
              {/* Current User Avatar */}
              <div className="flex-shrink-0">
                <div className="w-10 h-10 rounded-full overflow-hidden border border-gray-700">
                  <ImageWithFallback
                    src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=50&h=50&fit=crop&crop=face"
                    alt="Your profile"
                    className="w-full h-full object-cover"
                  />
                </div>
              </div>

              {/* Comment Input Field */}
              <div className="flex-1 relative">
                <input
                  ref={inputRef}
                  type="text"
                  value={commentText}
                  onChange={(e) => setCommentText(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && handleSubmitComment()}
                  placeholder="Add a comment..."
                  className="w-full bg-gray-800 text-white placeholder-gray-400 border border-gray-700 rounded-full px-4 py-3 focus:outline-none focus:ring-2 focus:ring-white/20 focus:border-white/30 transition-all duration-200"
                />
              </div>

              {/* Action Buttons */}
              <div className="flex items-center space-x-2">
                {/* GIF Button */}
                <button className="p-2 text-gray-400 hover:text-white transition-colors rounded-full hover:bg-gray-800 touch-target">
                  <ImageIcon size={20} />
                </button>

                {/* Send Button */}
                <button
                  onClick={handleSubmitComment}
                  disabled={!commentText.trim()}
                  className={`p-2 rounded-full transition-all duration-200 touch-target ${
                    commentText.trim()
                      ? 'text-white bg-blue-600 hover:bg-blue-700 shadow-lg'
                      : 'text-gray-600 bg-gray-800 cursor-not-allowed'
                  }`}
                >
                  <Send size={18} />
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}