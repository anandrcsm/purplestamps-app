import { useState } from 'react';
import { 
  ArrowLeft, 
  Search, 
  MessageCircle, 
  Heart, 
  Pin, 
  TrendingUp, 
  Users, 
  Clock,
  MapPin,
  Flag,
  Plus,
  Flame
} from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface ForumExplorePage {
  onBack: () => void;
}

interface ForumPost {
  id: string;
  title: string;
  content: string;
  author: {
    id: string;
    name: string;
    username: string;
    avatar: string;
    isCreator?: boolean;
  };
  category: string;
  location?: string;
  timestamp: Date;
  replies: number;
  likes: number;
  isLiked: boolean;
  isPinned?: boolean;
  isTrending?: boolean;
  tags: string[];
  image?: string;
}

export function ForumExplorePage({ onBack }: ForumExplorePage) {
  const [activeTab, setActiveTab] = useState('trending');
  const [searchQuery, setSearchQuery] = useState('');

  const mockForumPosts: ForumPost[] = [
    {
      id: 'forum1',
      title: 'Best hidden gems in Tokyo for first-time visitors?',
      content: 'Planning my first trip to Tokyo and looking for authentic local experiences beyond the typical tourist spots. Any recommendations for hidden gems?',
      author: {
        id: 'user1',
        name: 'Sarah Chen',
        username: 'sarahwanders',
        avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612bb44?w=50&h=50&fit=crop&crop=face'
      },
      category: 'Travel Tips',
      location: 'Tokyo, Japan',
      timestamp: new Date('2024-01-20T14:30:00'),
      replies: 23,
      likes: 45,
      isLiked: false,
      isTrending: true,
      tags: ['Tokyo', 'Hidden Gems', 'First Time'],
      image: 'https://images.unsplash.com/photo-1540959733332-eab4deabeeaf?w=400&h=200&fit=crop'
    },
    {
      id: 'forum2',
      title: 'Solo female travel safety tips for Southeast Asia',
      content: 'Sharing my experience and tips for solo female travelers in SEA. What are your must-know safety tips?',
      author: {
        id: 'user2',
        name: 'Emma Rodriguez',
        username: 'solo_emma',
        avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=50&h=50&fit=crop&crop=face',
        isCreator: true
      },
      category: 'Safety & Tips',
      location: 'Southeast Asia',
      timestamp: new Date('2024-01-20T12:15:00'),
      replies: 56,
      likes: 128,
      isLiked: true,
      isPinned: true,
      tags: ['Solo Travel', 'Safety', 'Southeast Asia', 'Female Travel'],
      image: 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=400&h=200&fit=crop'
    },
    {
      id: 'forum3',
      title: 'Budget backpacking through Europe: €30/day challenge',
      content: 'Just completed a month-long backpacking trip through 8 European countries on €30/day. AMA!',
      author: {
        id: 'user3',
        name: 'Mike Thompson',
        username: 'budget_mike',
        avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=50&h=50&fit=crop&crop=face'
      },
      category: 'Budget Travel',
      location: 'Europe',
      timestamp: new Date('2024-01-20T10:45:00'),
      replies: 89,
      likes: 234,
      isLiked: false,
      isTrending: true,
      tags: ['Budget Travel', 'Europe', 'Backpacking', 'AMA'],
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545d1a?w=400&h=200&fit=crop'
    },
    {
      id: 'forum4',
      title: 'Digital nomad visa updates 2024',
      content: 'Comprehensive list of countries offering digital nomad visas and recent updates to requirements.',
      author: {
        id: 'user4',
        name: 'Alex Kim',
        username: 'nomad_alex',
        avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=50&h=50&fit=crop&crop=face',
        isCreator: true
      },
      category: 'Digital Nomad',
      timestamp: new Date('2024-01-20T09:20:00'),
      replies: 34,
      likes: 87,
      isLiked: false,
      tags: ['Digital Nomad', 'Visa', '2024', 'Remote Work']
    },
    {
      id: 'forum5',
      title: 'Cultural etiquette mistakes to avoid in India',
      content: 'Learning from my cultural faux pas during my recent India trip. What are some important cultural norms travelers should know?',
      author: {
        id: 'user5',
        name: 'Lisa Park',
        username: 'culturelisa',
        avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=50&h=50&fit=crop&crop=face'
      },
      category: 'Cultural Tips',
      location: 'India',
      timestamp: new Date('2024-01-19T16:30:00'),
      replies: 67,
      likes: 156,
      isLiked: true,
      tags: ['Cultural Tips', 'India', 'Etiquette', 'Travel Mistakes'],
      image: 'https://images.unsplash.com/photo-1524492412937-b28074a5d7da?w=400&h=200&fit=crop'
    }
  ];

  const categories = [
    { id: 'trending', label: 'Trending', icon: TrendingUp },
    { id: 'recent', label: 'Recent', icon: Clock },
    { id: 'travel-tips', label: 'Travel Tips', icon: MapPin },
    { id: 'safety', label: 'Safety', icon: Flag },
    { id: 'budget', label: 'Budget', icon: Users }
  ];

  const filteredPosts = mockForumPosts.filter(post => {
    const matchesSearch = searchQuery === '' || 
      post.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      post.content.toLowerCase().includes(searchQuery.toLowerCase()) ||
      post.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()));
    
    if (activeTab === 'trending') return matchesSearch && post.isTrending;
    if (activeTab === 'recent') return matchesSearch;
    return matchesSearch && post.category.toLowerCase().includes(activeTab.replace('-', ' '));
  });

  const handleLike = (postId: string) => {
    // Handle like functionality
    const toast = document.createElement('div');
    toast.className = 'fixed top-20 left-1/2 transform -translate-x-1/2 bg-brand-primary text-white px-4 py-2 rounded-xl z-50 shadow-lg';
    toast.textContent = 'Post liked!';
    document.body.appendChild(toast);
    setTimeout(() => document.body.removeChild(toast), 2000);
  };

  const handleReply = (postId: string) => {
    // Handle reply functionality
    const toast = document.createElement('div');
    toast.className = 'fixed top-20 left-1/2 transform -translate-x-1/2 bg-brand-secondary text-white px-4 py-2 rounded-xl z-50 shadow-lg';
    toast.textContent = 'Opening discussion...';
    document.body.appendChild(toast);
    setTimeout(() => document.body.removeChild(toast), 2000);
  };

  return (
    <div className="min-h-screen bg-surface-warm pb-20">
      {/* Header */}
      <div className="sticky top-0 bg-white/90 backdrop-blur-xl border-b border-gray-200/50 shadow-sm z-10">
        <div className="flex items-center justify-between p-4">
          <button 
            onClick={onBack}
            className="flex items-center text-brand-primary hover:text-brand-primary-dark transition-colors"
          >
            <ArrowLeft size={20} className="mr-2" />
            <span>Back</span>
          </button>
          
          <div className="flex items-center">
            <Flame size={20} className="text-brand-primary mr-2" />
            <h1 className="text-xl text-gray-900">Forum</h1>
          </div>
          
          <button className="p-2 bg-brand-primary text-white rounded-full hover:bg-brand-primary-dark transition-colors">
            <Plus size={20} />
          </button>
        </div>
        
        {/* Search Bar */}
        <div className="px-4 pb-4">
          <div className="relative">
            <Search size={18} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              placeholder="Search discussions..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-3 bg-gray-50 rounded-2xl border-0 focus:ring-2 focus:ring-brand-primary focus:bg-white transition-all"
            />
          </div>
        </div>
        
        {/* Category Tabs */}
        <div className="flex space-x-1 overflow-x-auto scrollbar-hide px-4 pb-4">
          {categories.map(category => {
            const IconComponent = category.icon;
            return (
              <button
                key={category.id}
                onClick={() => setActiveTab(category.id)}
                className={`flex items-center px-4 py-2 rounded-xl text-sm whitespace-nowrap transition-colors ${
                  activeTab === category.id
                    ? 'bg-brand-primary text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                <IconComponent size={16} className="mr-2" />
                {category.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* Forum Posts */}
      <div className="p-4 space-y-4">
        {filteredPosts.map((post) => (
          <div
            key={post.id}
            className="bg-white rounded-2xl p-6 border border-white/20 shadow-sm hover:shadow-md transition-all duration-200"
          >
            {/* Post Header */}
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center">
                <ImageWithFallback
                  src={post.author.avatar}
                  alt={post.author.name}
                  className="w-10 h-10 rounded-full mr-3"
                />
                <div>
                  <div className="flex items-center">
                    <span className="text-gray-900 mr-2">{post.author.name}</span>
                    {post.author.isCreator && (
                      <div className="w-4 h-4 bg-gradient-brand rounded-full flex items-center justify-center">
                        <div className="w-2 h-2 bg-white rounded-full"></div>
                      </div>
                    )}
                  </div>
                  <div className="flex items-center text-sm text-gray-500">
                    <span>@{post.author.username}</span>
                    <span className="mx-1">•</span>
                    <span>{post.timestamp.toLocaleDateString()}</span>
                    {post.location && (
                      <>
                        <span className="mx-1">•</span>
                        <MapPin size={12} className="mr-1" />
                        <span>{post.location}</span>
                      </>
                    )}
                  </div>
                </div>
              </div>
              
              <div className="flex items-center space-x-2">
                {post.isPinned && (
                  <Pin size={16} className="text-brand-secondary" />
                )}
                {post.isTrending && (
                  <TrendingUp size={16} className="text-brand-primary" />
                )}
              </div>
            </div>

            {/* Post Content */}
            <div className="mb-4">
              <h3 className="text-lg text-gray-900 mb-2">{post.title}</h3>
              <p className="text-gray-700 leading-relaxed mb-3">{post.content}</p>
              
              {/* Post Image */}
              {post.image && (
                <div className="rounded-xl overflow-hidden mb-3">
                  <ImageWithFallback
                    src={post.image}
                    alt="Post image"
                    className="w-full h-48 object-cover"
                  />
                </div>
              )}
              
              {/* Tags */}
              <div className="flex flex-wrap gap-2 mb-4">
                {post.tags.map((tag, index) => (
                  <span
                    key={index}
                    className="bg-brand-primary/10 text-brand-primary px-3 py-1 rounded-full text-sm"
                  >
                    #{tag}
                  </span>
                ))}
              </div>
            </div>

            {/* Post Actions */}
            <div className="flex items-center justify-between pt-4 border-t border-gray-100">
              <div className="flex items-center space-x-6">
                <button
                  onClick={() => handleLike(post.id)}
                  className={`flex items-center space-x-2 transition-colors ${
                    post.isLiked ? 'text-red-500' : 'text-gray-500 hover:text-red-500'
                  }`}
                >
                  <Heart size={18} className={post.isLiked ? 'fill-current' : ''} />
                  <span className="text-sm">{post.likes}</span>
                </button>
                
                <button
                  onClick={() => handleReply(post.id)}
                  className="flex items-center space-x-2 text-gray-500 hover:text-brand-primary transition-colors"
                >
                  <MessageCircle size={18} />
                  <span className="text-sm">{post.replies}</span>
                </button>
              </div>
              
              <span className="bg-gray-100 text-gray-600 px-3 py-1 rounded-full text-sm">
                {post.category}
              </span>
            </div>
          </div>
        ))}
        
        {filteredPosts.length === 0 && (
          <div className="text-center py-12">
            <div className="w-24 h-24 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <MessageCircle size={32} className="text-gray-400" />
            </div>
            <p className="text-gray-600 mb-2">No discussions found</p>
            <p className="text-sm text-gray-500">Try adjusting your search or category filter</p>
          </div>
        )}
      </div>
    </div>
  );
}