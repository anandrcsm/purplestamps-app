import { useState, useEffect } from 'react';
import { ArrowLeft, Heart, Share2, Bookmark, MapPin, Calendar, Users, Star, ChevronLeft, ChevronRight, Plus, ExternalLink, MoreVertical, Clock, DollarSign, UserPlus, MessageCircle, Bed, Utensils, Car, Mountain, ShoppingBag, Zap, Camera, X, Filter, Package } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { TravelCard, Experience } from '../types';
import { StarRating } from './StarRating';
import { CategoryTag } from './CategoryTag';
import { UnifiedButton, BookNowIcon } from './ui/unified-icons';
import { BookNowNudge } from './BookNowNudge';
import { MomentCard } from './MomentCard';
import { getCreator } from '../data/mockData';
import { travelProducts } from '../data/travelProducts';

interface TravelCardPageProps {
  travelCardId: string | null;
  allTravelCards: TravelCard[];
  onBack: () => void;
  onSelectExperience: (id: string) => void;
  onSelectUser?: (userId: string) => void;
  onAddToItinerary: (experienceId: string) => void;
  onSelectProduct: (id: string) => void;
  onCreateItinerary: () => void;
  onAddToDraft?: (experienceId: string) => void;
}

type TabType = 'gallery' | 'experiences' | 'travel-items';
type ExperienceFilterType = 'all' | 'stay' | 'food' | 'transport' | 'activities';

const tabLabels: Record<TabType, string> = {
  gallery: 'Gallery',
  experiences: 'Experiences',
  'travel-items': 'Travel Items'
};

const tabIcons: Record<TabType, React.ComponentType<{ size?: number; className?: string }>> = {
  gallery: Camera,
  experiences: Mountain,
  'travel-items': ShoppingBag
};

const experienceFilterLabels: Record<ExperienceFilterType, string> = {
  all: 'All',
  stay: 'Stay',
  food: 'Food',
  transport: 'Transport',
  activities: 'Activities'
};

const experienceFilterIcons: Record<ExperienceFilterType, React.ComponentType<{ size?: number; className?: string }>> = {
  all: Filter,
  stay: Bed,
  food: Utensils,
  transport: Car,
  activities: Mountain
};

// Enhanced Gallery View with grid layout
interface GalleryViewProps {
  moments: Array<{ 
    id: string; 
    image: string; 
    experienceTitle: string; 
    experienceLocation: string; 
    experienceCategory: string 
  }>;
}

function GalleryView({ 
  moments, 
  onSelectExperience 
}: GalleryViewProps & { 
  onSelectExperience: (id: string) => void 
}) {
  const [selectedMoment, setSelectedMoment] = useState<string | null>(null);

  if (moments.length === 0) {
    return (
      <div className="text-center py-16 px-4">
        <div className="w-20 h-20 bg-moodboard-gray-light/30 rounded-2xl flex items-center justify-center mx-auto mb-4">
          <Camera size={32} className="text-moodboard-gray-dark" />
        </div>
        <h3 className="font-semibold text-moodboard-deep-green mb-2">No moments yet</h3>
        <p className="text-moodboard-gray-dark text-sm">
          Moments will appear here as you add images to your experiences.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Gallery Grid */}
      <div className="grid grid-cols-2 gap-3 p-4">
        {moments.map((moment, index) => (
          <div 
            key={moment.id}
            className="break-inside-avoid animate-fadeIn"
            style={{ animationDelay: `${index * 50}ms` }}
          >
            <div 
              className="relative aspect-square rounded-xl overflow-hidden bg-moodboard-gray-light/10 cursor-pointer group hover:scale-[1.02] transition-all duration-300 shadow-md hover:shadow-lg"
              onClick={() => setSelectedMoment(moment.id)}
            >
              <ImageWithFallback
                src={moment.image}
                alt={moment.experienceTitle}
                className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110"
              />
              
              {/* Subtle overlay on hover */}
              <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-all duration-300"></div>
              
              {/* Experience title overlay */}
              <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-3">
                <p className="text-white text-xs font-medium line-clamp-1">
                  {moment.experienceTitle}
                </p>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Expanded Moment View Modal */}
      {selectedMoment && (
        <ExpandedMomentView
          moments={moments}
          currentMomentId={selectedMoment}
          onClose={() => setSelectedMoment(null)}
          onNavigate={setSelectedMoment}
          onSelectExperience={onSelectExperience}
        />
      )}
    </div>
  );
}

// Day-wise Experiences View with filtering
interface ExperiencesViewProps {
  experiences: Experience[];
  onSelectExperience: (id: string) => void;
  onAddToItinerary: (id: string) => void;
  savedExperiences: Set<string>;
  onSaveExperience: (id: string, event: React.MouseEvent) => void;
  onAddToDraft?: (experienceId: string) => void;
}

function ExperiencesView({ 
  experiences, 
  onSelectExperience, 
  onAddToItinerary,
  savedExperiences,
  onSaveExperience,
  onAddToDraft 
}: ExperiencesViewProps) {
  const [selectedFilter, setSelectedFilter] = useState<ExperienceFilterType>('all');
  
  // Filter experiences based on selected filter
  const filteredExperiences = selectedFilter === 'all' 
    ? experiences 
    : experiences.filter(exp => exp.category === selectedFilter);

  // Group experiences by day (mock implementation - in real app this would use actual dates)
  const groupExperiencesByDay = (experiences: Experience[]) => {
    const grouped: { [key: string]: Experience[] } = {};
    
    experiences.forEach((exp, index) => {
      const dayNumber = Math.floor(index / 3) + 1; // Group every 3 experiences into a day
      const dayKey = `Day ${dayNumber}`;
      
      if (!grouped[dayKey]) {
        grouped[dayKey] = [];
      }
      grouped[dayKey].push(exp);
    });
    
    return grouped;
  };

  const groupedExperiences = groupExperiencesByDay(filteredExperiences);

  if (experiences.length === 0) {
    return (
      <div className="text-center py-16 px-4">
        <div className="w-20 h-20 bg-moodboard-gray-light/30 rounded-2xl flex items-center justify-center mx-auto mb-4">
          <Mountain size={32} className="text-moodboard-gray-dark" />
        </div>
        <h3 className="font-semibold text-moodboard-deep-green mb-2">No experiences yet</h3>
        <p className="text-moodboard-gray-dark text-sm">
          Experiences will appear here as they are added to this travel card.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Filter Bar */}
      <div className="px-4 pt-4">
        <div className="flex justify-evenly pb-2">
          {(Object.keys(experienceFilterLabels) as ExperienceFilterType[]).map((filter) => {
            const FilterIcon = experienceFilterIcons[filter];
            const isActive = selectedFilter === filter;
            const count = filter === 'all' ? experiences.length : experiences.filter(exp => exp.category === filter).length;
            
            return (
              <button
                key={filter}
                onClick={() => setSelectedFilter(filter)}
                className={`flex items-center justify-center p-3 rounded-full transition-all duration-200 ${
                  isActive
                    ? 'bg-moodboard-muted-teal text-white shadow-md'
                    : 'bg-gray-100 text-moodboard-gray-dark hover:bg-gray-200'
                }`}
              >
                <FilterIcon size={20} />
              </button>
            );
          })}
        </div>
      </div>

      {/* Day-wise Experience Groups */}
      <div className="px-4 space-y-6">
        {Object.entries(groupedExperiences).map(([day, dayExperiences]) => (
          <div key={day} className="space-y-4">
            {/* Day Header */}
            <div className="flex items-center gap-3">
              <div className="flex items-center justify-center w-10 h-10 bg-moodboard-muted-teal rounded-full">
                <span className="text-white font-semibold text-sm">{day.split(' ')[1]}</span>
              </div>
              <div>
                <h3 className="font-semibold text-moodboard-deep-green">{day}</h3>
                <p className="text-moodboard-gray-dark text-sm">{dayExperiences.length} experiences</p>
              </div>
            </div>

            {/* Day's Experiences */}
            <div className="space-y-3 -mx-4">
              {dayExperiences.map((experience) => (
                <div
                  key={experience.id}
                  className="relative h-32 overflow-hidden rounded-xl hover:scale-[1.02] transition-all duration-300 cursor-pointer group shadow-md hover:shadow-lg mx-4"
                  onClick={() => onSelectExperience(experience.id)}
                  style={{
                    backgroundImage: experience.images && experience.images[0] 
                      ? `url(${experience.images[0]})` 
                      : 'linear-gradient(135deg, #4A9B8E 0%, #6BBAB0 100%)',
                    backgroundSize: 'cover',
                    backgroundPosition: 'center'
                  }}
                >
                  {/* Lighter Gradient Overlay for Better Readability */}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-black/10 to-transparent"></div>
                  
                  {/* Content Overlay */}
                  <div className="absolute inset-0 flex flex-col items-center justify-center text-center p-4 m-[10px] mx-[0px] my-[10px]">
                    {/* Top Action Buttons */}
                    <div className="absolute top-3 right-3 flex items-center space-x-2">
                      {/* Save Button */}
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onSaveExperience(experience.id, e);
                        }}
                        className={`p-2 rounded-lg backdrop-blur-sm transition-all duration-200 ${
                          savedExperiences.has(experience.id)
                            ? 'bg-moodboard-warm-beige/90 text-moodboard-deep-green'
                            : 'bg-white/20 text-white hover:bg-white/30'
                        }`}
                      >
                        <Bookmark size={16} className={savedExperiences.has(experience.id) ? 'fill-current' : ''} />
                      </button>

                      {/* Save to Draft Button */}
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onAddToDraft?.(experience.id);
                        }}
                        className="w-10 h-10 rounded-full backdrop-blur-sm bg-moodboard-muted-teal/90 text-white hover:bg-moodboard-muted-teal transition-all duration-200 flex items-center justify-center border border-moodboard-muted-teal shadow-lg hover:scale-110"
                      >
                        <Plus size={18} />
                      </button>
                    </div>

                    {/* Main Content */}
                    <div className="flex-1 flex flex-col items-center justify-center">
                      {/* Category */}
                      <div className="mb-2">
                        <CategoryTag category={experience.category || 'activity'} />
                      </div>
                      
                      {/* Title */}
                      <h4 className="font-semibold text-white text-center mb-2 line-clamp-2 group-hover:text-moodboard-warm-beige transition-colors">
                        {experience.title || 'Untitled Experience'}
                      </h4>
                      
                      {/* Location and Cost */}
                      <div className="flex items-center justify-center gap-4 text-white/90">
                        <div className="flex items-center gap-1">
                          <MapPin size={12} />
                          <span className="text-xs">{experience.location || 'Location not specified'}</span>
                        </div>
                        {experience.cost && (
                          <span className="font-semibold text-moodboard-warm-beige">
                            ${experience.cost}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// Travel Items View
function TravelItemsView({ onSelectProduct }: { onSelectProduct: (id: string) => void }) {
  if (travelProducts.length === 0) {
    return (
      <div className="text-center py-16 px-4">
        <div className="w-20 h-20 bg-moodboard-gray-light/30 rounded-2xl flex items-center justify-center mx-auto mb-4">
          <Package size={32} className="text-moodboard-gray-dark" />
        </div>
        <h3 className="font-semibold text-moodboard-deep-green mb-2">No travel items yet</h3>
        <p className="text-moodboard-gray-dark text-sm">
          Travel essentials and gear recommendations will appear here.
        </p>
      </div>
    );
  }

  return (
    <div className="px-4 py-4 space-y-4">
      {travelProducts.slice(0, 6).map((product) => (
        <div
          key={product.id}
          className="bg-white rounded-xl p-4 shadow-sm border border-gray-100 hover:shadow-md transition-all duration-200 cursor-pointer"
          onClick={() => onSelectProduct(product.id)}
        >
          <div className="flex gap-4">
            {/* Product Image */}
            <div className="w-20 h-20 flex-shrink-0 rounded-lg overflow-hidden bg-gray-50">
              <ImageWithFallback
                src={product.images[0]}
                alt={product.name}
                className="w-full h-full object-cover"
              />
            </div>
            
            {/* Product Details */}
            <div className="flex-1">
              <div className="flex items-start justify-between mb-2">
                <div>
                  <h4 className="font-medium text-moodboard-deep-green mb-1">{product.name}</h4>
                  <p className="text-xs text-moodboard-gray-dark mb-2 line-clamp-2">{product.description}</p>
                </div>
              </div>
              
              {/* Rating and Category */}
              <div className="flex items-center gap-3 mb-2">
                <div className="flex items-center gap-1">
                  <Star size={12} className="fill-yellow-400 text-yellow-400" />
                  <span className="text-xs text-moodboard-gray-dark">
                    {product.rating} ({product.reviewCount})
                  </span>
                </div>
                <span className="text-xs bg-moodboard-gray-light/30 text-moodboard-gray-dark px-2 py-1 rounded-full">
                  {product.category}
                </span>
              </div>
              
              {/* Price and Discount */}
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="font-semibold text-moodboard-muted-teal">
                    ${product.price}
                  </span>
                  {product.originalPrice && (
                    <span className="text-xs text-gray-400 line-through">
                      ${product.originalPrice}
                    </span>
                  )}
                  {product.discount && (
                    <span className="text-xs bg-red-100 text-red-600 px-2 py-0.5 rounded-full">
                      -{product.discount}%
                    </span>
                  )}
                </div>
                <ExternalLink size={16} className="text-moodboard-gray-dark" />
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}

// Expanded Moment View Component
function ExpandedMomentView({
  moments,
  currentMomentId,
  onClose,
  onNavigate,
  onSelectExperience
}: {
  moments: Array<{
    id: string;
    image: string;
    experienceTitle: string;
    experienceLocation: string;
    experienceCategory: string;
  }>;
  currentMomentId: string;
  onClose: () => void;
  onNavigate: (id: string) => void;
  onSelectExperience: (id: string) => void;
}) {
  const [likedMoments, setLikedMoments] = useState<Set<string>>(new Set());
  const [savedMoments, setSavedMoments] = useState<Set<string>>(new Set());

  const handleBackdropClick = (e: React.MouseEvent) => {
    if (e.target === e.currentTarget) {
      onClose();
    }
  };

  const handleExperienceRedirect = (moment: any) => {
    const experienceId = moment.id.split('-')[0];
    onClose();
    onSelectExperience(experienceId);
  };

  const transformMomentData = (moment: any) => ({
    id: moment.id,
    image: moment.image,
    caption: `A beautiful moment captured at this amazing location ✨`,
    location: moment.experienceLocation,
    creatorId: 'user1',
    likes: Math.floor(Math.random() * 50) + 10,
    comments: Math.floor(Math.random() * 20) + 2,
    isLiked: likedMoments.has(moment.id),
    isSaved: savedMoments.has(moment.id),
    timestamp: '2h'
  });

  return (
    <div 
      className="fixed inset-0 bg-moodboard-deep-green/95 backdrop-blur-sm z-50 animate-backdropFadeIn overflow-y-auto"
      onClick={handleBackdropClick}
    >
      {/* Close Button */}
      <button
        onClick={onClose}
        className="fixed top-6 right-6 w-10 h-10 bg-white/90 backdrop-blur-sm rounded-full flex items-center justify-center text-moodboard-deep-green hover:scale-110 transition-all duration-200 z-20 shadow-lg"
      >
        <X size={20} />
      </button>

      {/* Moments Feed */}
      <div className="min-h-screen py-16">
        <div className="w-full">
          {moments.map((moment, index) => {
            const transformedMoment = transformMomentData(moment);
            
            return (
              <div 
                key={moment.id} 
                className="mb-3 animate-fadeIn"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <div className="relative">
                  <button
                    onClick={() => handleExperienceRedirect(moment)}
                    className="absolute top-6 right-6 w-8 h-8 bg-white/90 backdrop-blur-sm rounded-full flex items-center justify-center shadow-lg hover:scale-110 transition-all duration-200 z-10"
                  >
                    <ExternalLink size={14} className="text-moodboard-muted-teal" />
                  </button>
                  
                  <MomentCard
                    moment={transformedMoment}
                    onLike={() => {}}
                    onSave={() => {}}
                    onSelectUser={(userId) => console.log('User selected:', userId)}
                    showCommentsModal={true}
                  />
                </div>
              </div>
            );
          })}
        </div>
        <div className="h-16"></div>
      </div>
    </div>
  );
}

export function TravelCardPage({ 
  travelCardId, 
  allTravelCards, 
  onBack, 
  onSelectExperience,
  onSelectUser, 
  onAddToItinerary, 
  onSelectProduct, 
  onCreateItinerary,
  onAddToDraft 
}: TravelCardPageProps) {
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [isLiked, setIsLiked] = useState(false);
  const [isSaved, setIsSaved] = useState(false);
  const [isFollowing, setIsFollowing] = useState(false);
  const [selectedTab, setSelectedTab] = useState<TabType>('gallery');
  const [savedExperiences, setSavedExperiences] = useState<Set<string>>(new Set());

  const travelCard = allTravelCards.find(card => card.id === travelCardId);
  const creator = travelCard?.creatorId ? getCreator(travelCard.creatorId) : null;

  // Create safe images array with fallback
  const safeImages = travelCard?.images && travelCard.images.length > 0 
    ? travelCard.images 
    : travelCard?.thumbnail 
      ? [travelCard.thumbnail]
      : ['https://images.unsplash.com/photo-1469474968028-56623f02e42e?w=800&h=600&fit=crop'];

  const safeExperiences = travelCard?.experiences || [];

  // Mock collaborators data
  const mockCollaborators = [
    {
      id: 'collab1',
      name: 'Sarah Chen',
      username: 'sarah_travels',
      profilePic: 'https://images.unsplash.com/photo-1494790108755-2616b612c1c?w=50&h=50&fit=crop&crop=face'
    },
    {
      id: 'collab2', 
      name: 'Mike Rodriguez',
      username: 'mike_explores',
      profilePic: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=50&h=50&fit=crop&crop=face'
    }
  ];

  useEffect(() => {
    if (travelCard) {
      setCurrentImageIndex(0);
    }
  }, [travelCard]);

  if (!travelCard) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-surface-warm to-surface-cool flex items-center justify-center">
        <div className="text-center">
          <h2 className="font-semibold text-gray-900 mb-2">Travel Card Not Found</h2>
          <p className="text-gray-600 mb-4">The travel card you're looking for doesn't exist.</p>
          <button
            onClick={onBack}
            className="bg-gradient-brand text-white px-6 py-3 rounded-xl font-medium hover:shadow-brand transition-all duration-200"
          >
            Go Back
          </button>
        </div>
      </div>
    );
  }

  const nextImage = () => {
    if (safeImages.length > 1) {
      setCurrentImageIndex((prev) => (prev + 1) % safeImages.length);
    }
  };

  const prevImage = () => {
    if (safeImages.length > 1) {
      setCurrentImageIndex((prev) => (prev - 1 + safeImages.length) % safeImages.length);
    }
  };

  const handleSaveExperience = (experienceId: string, event: React.MouseEvent) => {
    event.stopPropagation();
    setSavedExperiences(prev => {
      const newSet = new Set(prev);
      if (newSet.has(experienceId)) {
        newSet.delete(experienceId);
      } else {
        newSet.add(experienceId);
        onAddToItinerary(experienceId);
      }
      return newSet;
    });
  };

  // Collect all images/moments from all experiences for gallery
  const getAllMoments = () => {
    const allMoments: Array<{ id: string; image: string; experienceTitle: string; experienceLocation: string; experienceCategory: string }> = [];
    
    safeExperiences.forEach(experience => {
      if (experience.images && experience.images.length > 0) {
        experience.images.forEach((image, index) => {
          allMoments.push({
            id: `${experience.id}-img-${index}`,
            image: image,
            experienceTitle: experience.title || 'Untitled Experience',
            experienceLocation: experience.location || 'Unknown Location',
            experienceCategory: experience.category || 'activity'
          });
        });
      }
      if (experience.media && experience.media.length > 0) {
        experience.media.forEach((media, index) => {
          if (!allMoments.some(moment => moment.image === media)) {
            allMoments.push({
              id: `${experience.id}-media-${index}`,
              image: media,
              experienceTitle: experience.title || 'Untitled Experience',
              experienceLocation: experience.location || 'Unknown Location',
              experienceCategory: experience.category || 'activity'
            });
          }
        });
      }
    });
    
    return allMoments;
  };

  const calculateTotalCost = () => {
    const total = safeExperiences.reduce((sum, exp) => sum + (exp.cost || 0), 0);
    return total > 0 ? `$${total}` : null;
  };

  const calculateDuration = () => {
    if (travelCard.dates) {
      try {
        const dates = travelCard.dates.split('-');
        if (dates.length === 2) {
          const start = new Date(dates[0].trim() + ', 2024');
          const end = new Date(dates[1].trim() + ', 2024');
          const diffTime = Math.abs(end.getTime() - start.getTime());
          const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)) + 1;
          return `${diffDays} days`;
        }
      } catch (e) {
        return '7 days';
      }
    }
    return null;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-surface-warm to-surface-cool">
      {/* Sticky Header */}
      <header className="fixed top-0 left-0 right-0 z-40 bg-white/90 backdrop-blur-xl border-b border-gray-100">
        <div className="flex items-center justify-between p-4">
          <button
            onClick={onBack}
            className="p-2 hover:bg-gray-100 rounded-xl transition-colors"
          >
            <ArrowLeft size={20} className="text-gray-700" />
          </button>
          <div className="flex-1"></div>
          <button className="p-2 hover:bg-gray-100 rounded-xl transition-colors">
            <MoreVertical size={20} className="text-gray-700" />
          </button>
        </div>
      </header>

      {/* Main Content */}
      <main className="pt-16">
        {/* Hero Section */}
        <div className="relative h-[85vh] overflow-hidden">
          {/* Hero Background Image */}
          <ImageWithFallback
            src={safeImages[currentImageIndex]}
            alt={travelCard.destination || travelCard.title || 'Travel destination'}
            className="w-full h-full object-cover"
          />
          
          {/* Image Navigation Controls */}
          {safeImages.length > 1 && (
            <>
              <button
                onClick={prevImage}
                className="absolute left-4 top-1/2 transform -translate-y-1/2 p-3 bg-black/50 text-white rounded-full hover:bg-black/70 transition-colors backdrop-blur-sm"
              >
                <ChevronLeft size={24} />
              </button>
              <button
                onClick={nextImage}
                className="absolute right-4 top-1/2 transform -translate-y-1/2 p-3 bg-black/50 text-white rounded-full hover:bg-black/70 transition-colors backdrop-blur-sm"
              >
                <ChevronRight size={24} />
              </button>
              
              {/* Image Indicators */}
              <div className="absolute top-20 left-1/2 transform -translate-x-1/2 flex space-x-2">
                {safeImages.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => setCurrentImageIndex(index)}
                    className={`w-2 h-2 rounded-full transition-all duration-200 ${
                      index === currentImageIndex ? 'bg-white' : 'bg-white/50'
                    }`}
                  />
                ))}
              </div>
            </>
          )}

          {/* Gradient Overlay */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
          <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-transparent to-transparent" />
          <div className="absolute inset-0 bg-black/20" />

          {/* Overlaid Content */}
          <div className="absolute inset-0 flex flex-col justify-between p-6 text-white">
            
            {/* Creator Profile - Top Right */}
            {creator && (
              <div className="absolute top-4 right-4 z-20">
                <div className="flex flex-col items-end space-y-2">
                  <button
                    onClick={() => creator && onSelectUser?.(creator.id)}
                    className="flex items-center space-x-2 bg-white/20 backdrop-blur-md rounded-full pr-3 pl-1 py-1 border border-white/30 hover:bg-white/30 transition-all duration-200"
                  >
                    <div className="w-8 h-8 rounded-full overflow-hidden border-2 border-white/50 relative">
                      <ImageWithFallback
                        src={creator.profilePic}
                        alt={creator.name}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <span className="text-xs font-medium text-white/90">
                      @{creator.username || creator.name.toLowerCase().replace(' ', '')}
                    </span>
                  </button>

                  <button
                    onClick={() => setIsFollowing(!isFollowing)}
                    className={`bg-moodboard-muted-teal/90 backdrop-blur-sm text-white px-2 py-1 rounded-full text-xs font-medium hover:bg-moodboard-muted-teal hover:scale-105 transition-all duration-200 active:scale-95 flex items-center space-x-1 border border-white/30 ${
                      isFollowing ? 'bg-white/20 text-white' : ''
                    }`}
                  >
                    <UserPlus size={8} />
                    <span>{isFollowing ? 'Following' : 'Follow'}</span>
                  </button>
                </div>
              </div>
            )}

            {/* Collaborators - Top Left */}
            {mockCollaborators.length > 0 && (
              <div className="absolute top-4 left-4 z-20">
                <div className="flex items-center space-x-2 overflow-x-auto scrollbar-hide">
                  <div className="w-7 h-7 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center border border-white/30 flex-shrink-0">
                    <Users size={12} className="text-white" />
                  </div>
                  {mockCollaborators.slice(0, 3).map((collaborator) => (
                    <button
                      key={collaborator.id}
                      onClick={() => onSelectUser?.(collaborator.id)}
                      className="flex-shrink-0 hover:scale-110 transition-transform duration-200"
                    >
                      <div className="w-7 h-7 rounded-full overflow-hidden border-2 border-white/40 shadow-lg">
                        <ImageWithFallback
                          src={collaborator.profilePic}
                          alt={collaborator.name}
                          className="w-full h-full object-cover"
                        />
                      </div>
                    </button>
                  ))}
                  {mockCollaborators.length > 3 && (
                    <div className="w-7 h-7 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center border border-white/30 text-xs text-white">
                      +{mockCollaborators.length - 3}
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* Title and Description - Center */}
            <div className="absolute inset-x-6 bottom-32 z-10">
              <div className="text-center">
                <h1 className="text-white font-bold text-3xl mb-3 leading-tight drop-shadow-lg">
                  {travelCard.title || `Adventure in ${travelCard.destination}`}
                </h1>
                
                {travelCard.description && (
                  <p className="text-white/90 text-sm leading-relaxed line-clamp-2 drop-shadow-md max-w-sm mx-auto mb-4">
                    {travelCard.description}
                  </p>
                )}
              </div>
            </div>

            {/* Trip Details - Bottom Center */}
            <div className="absolute bottom-16 left-6 right-6 z-10">
              <div className="flex items-center justify-center space-x-2 flex-wrap">
                <div className="flex items-center space-x-1 bg-white/20 backdrop-blur-md rounded-full px-3 py-1.5 border border-white/30">
                  <MapPin size={12} className="text-white" />
                  <span className="text-white text-xs font-medium">{travelCard.destination}</span>
                </div>

                {travelCard.dates && (
                  <div className="flex items-center space-x-1 bg-white/20 backdrop-blur-md rounded-full px-3 py-1.5 border border-white/30">
                    <Calendar size={12} className="text-white" />
                    <span className="text-white text-xs font-medium">{travelCard.dates}</span>
                  </div>
                )}
                
                <div className="flex items-center space-x-1 bg-white/20 backdrop-blur-md rounded-full px-3 py-1.5 border border-white/30">
                  <Clock size={12} className="text-white" />
                  <span className="text-white text-xs font-medium">{calculateDuration() || '7 days'}</span>
                </div>
                
                {calculateTotalCost() && (
                  <div className="flex items-center space-x-1 bg-white/20 backdrop-blur-md rounded-full px-3 py-1.5 border border-white/30">
                    <DollarSign size={12} className="text-white" />
                    <span className="text-white text-xs font-medium">{calculateTotalCost()}</span>
                  </div>
                )}
              </div>
            </div>

            {/* Action Buttons - Bottom */}
            <div className="absolute bottom-0 left-0 right-0 z-10">
              <div className="flex items-center justify-between px-6 py-3">
                <div className="flex items-center space-x-4">
                  <button
                    onClick={() => setIsLiked(!isLiked)}
                    className={`flex items-center space-x-1 transition-all duration-200 hover:scale-110 active:scale-95 touch-target ${
                      isLiked ? 'text-red-400' : 'text-white hover:text-red-400'
                    }`}
                  >
                    <Heart size={20} className={isLiked ? 'fill-current' : ''} />
                    <span className="text-sm font-medium">{travelCard.likes || 0}</span>
                  </button>

                  <button
                    onClick={() => window.scrollTo({ top: document.body.scrollHeight, behavior: 'smooth' })}
                    className="flex items-center space-x-1 text-white hover:text-moodboard-muted-teal transition-all duration-200 hover:scale-110 active:scale-95 touch-target"
                  >
                    <MessageCircle size={20} />
                    <span className="text-sm font-medium">{travelCard.comments || 0}</span>
                  </button>

                  <button
                    onClick={() => console.log('Share')}
                    className="text-white hover:text-moodboard-muted-teal transition-all duration-200 hover:scale-110 active:scale-95 touch-target"
                  >
                    <Share2 size={20} />
                  </button>
                </div>

                <button
                  onClick={() => setIsSaved(!isSaved)}
                  className={`transition-all duration-200 hover:scale-110 active:scale-95 touch-target ${
                    isSaved ? 'text-moodboard-warm-beige' : 'text-white hover:text-moodboard-warm-beige'
                  }`}
                >
                  <Bookmark size={20} className={isSaved ? 'fill-current' : ''} />
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Tabbed Content Section */}
        <div className="bg-white">
          {/* Tab Navigation */}
          <div className="bg-white border-b border-moodboard-muted-teal/10 sticky top-16 z-30">
            <div className="px-4 py-4">
              <div className="flex justify-evenly">
                {(Object.keys(tabLabels) as TabType[]).map((tab) => {
                  const TabIcon = tabIcons[tab];
                  const isActive = selectedTab === tab;
                  
                  let count = 0;
                  if (tab === 'gallery') count = getAllMoments().length;
                  else if (tab === 'experiences') count = safeExperiences.length;
                  else if (tab === 'travel-items') count = travelProducts.length;
                  
                  return (
                    <button
                      key={tab}
                      onClick={() => setSelectedTab(tab)}
                      className={`flex flex-col items-center gap-2 py-2 px-4 transition-all duration-300 ${
                        isActive
                          ? 'text-moodboard-muted-teal border-b-2 border-moodboard-muted-teal'
                          : 'text-moodboard-gray-dark hover:text-moodboard-muted-teal'
                      }`}
                    >
                      <TabIcon size={20} />
                      <span className="text-sm font-medium">{tabLabels[tab]}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Tab Content */}
          <div className="min-h-[60vh]">
            {selectedTab === 'gallery' && (
              <GalleryView 
                moments={getAllMoments()} 
                onSelectExperience={onSelectExperience}
              />
            )}
            
            {selectedTab === 'experiences' && (
              <ExperiencesView
                experiences={safeExperiences}
                onSelectExperience={onSelectExperience}
                onAddToItinerary={onAddToItinerary}
                savedExperiences={savedExperiences}
                onSaveExperience={handleSaveExperience}
                onAddToDraft={onAddToDraft}
              />
            )}
            
            {selectedTab === 'travel-items' && (
              <TravelItemsView onSelectProduct={onSelectProduct} />
            )}
          </div>
        </div>
      </main>
    </div>
  );
}