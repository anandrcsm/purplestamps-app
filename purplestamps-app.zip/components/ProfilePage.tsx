import { useState } from 'react';
import { 
  ArrowLeft, 
  MoreHorizontal, 
  Settings, 
  Grid3X3, 
  Bookmark,
  Edit,
  MessageCircle,
  UserPlus,
  UserMinus,
  Share,
  Heart,
  ThumbsUp,
  MessageSquare,
  MapPin,
  Clock,
  Eye,
  Calendar,
  User,
  LogOut,
  Shield,
  Link,
  HelpCircle,
  DollarSign,
  Plane
} from 'lucide-react';
import { User as UserType, TravelCard as TravelCardType, LocalGem } from '../types';
import { mockLocalGems } from '../data/localGemsData';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { getCreator } from '../data/mockData';

interface ProfilePageProps {
  user: UserType;
  travelCards: TravelCardType[];
  localGems?: LocalGem[];
  onSelectTravelCard: (id: string) => void;
  onSelectUser: (userId: string) => void;
  onNavigateToBucketList: () => void;
  bucketListCount: number;
  isOwnProfile: boolean;
  onFollowUser: (userId: string) => void;
  onMessageUser: (userId: string) => void;
  isFollowing: boolean;
  onBack?: () => void;
  onNavigateToSettings?: () => void;
  onLogout?: () => void;
  userAccountType?: 'user' | 'creator';
}

export function ProfilePage({ 
  user, 
  travelCards, 
  localGems = [],
  onSelectTravelCard, 
  onSelectUser,
  onNavigateToBucketList,
  bucketListCount = 0,
  isOwnProfile = true,
  onFollowUser,
  onMessageUser,
  isFollowing = false,
  onBack,
  onNavigateToSettings,
  onLogout,
  userAccountType = 'user'
}: ProfilePageProps) {
  const [activeTab, setActiveTab] = useState('travelcards'); // Travel Cards first
  const [likedItems, setLikedItems] = useState<Set<string>>(new Set());
  const [savedItems, setSavedItems] = useState<Set<string>>(new Set());
  const [showAccountMenu, setShowAccountMenu] = useState(false);

  // Get user's content - use passed localGems prop instead of filtering mockLocalGems
  const userLocalGems = localGems;
  
  // Enhanced mock travel cards for richer profile content
  const enhancedUserTravelCards = [
    ...travelCards,
    ...(isOwnProfile ? [
      {
        id: 'prof-card-1',
        title: 'Himalayan Odyssey',
        destination: 'Manali, Himachal Pradesh',
        thumbnail: 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=600&h=800&fit=crop',
        images: ['https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=600&h=800&fit=crop'],
        tripType: 'Adventure',
        description: 'An incredible journey through snow-capped peaks and serene valleys',
        experiences: [
          { id: 'exp-1', title: 'Rohtang Pass Adventure', category: 'activity', cost: 2500, rating: 4.8 },
          { id: 'exp-2', title: 'Local Himachali Cuisine', category: 'food', cost: 800, rating: 4.6 },
          { id: 'exp-3', title: 'Mountain Lodge Stay', category: 'stay', cost: 3500, rating: 4.7 }
        ],
        creatorId: user.id,
        creator: user,
        likes: 2847,
        comments: 156,
        views: 8924,
        cost: 25000,
        dates: '7 days',
        rating: 4.8
      },
      {
        id: 'prof-card-2',
        title: 'Rajasthani Royal Experience',
        destination: 'Jaipur, Rajasthan',
        thumbnail: 'https://images.unsplash.com/photo-1477587458883-47145ed94245?w=600&h=800&fit=crop',
        images: ['https://images.unsplash.com/photo-1477587458883-47145ed94245?w=600&h=800&fit=crop'],
        tripType: 'Cultural',
        description: 'Explore the majestic palaces and vibrant culture of the Pink City',
        experiences: [
          { id: 'exp-4', title: 'Amber Fort Tour', category: 'activity', cost: 1200, rating: 4.9 },
          { id: 'exp-5', title: 'Traditional Rajasthani Thali', category: 'food', cost: 600, rating: 4.5 },
          { id: 'exp-6', title: 'Heritage Havelis Stay', category: 'stay', cost: 4500, rating: 4.8 }
        ],
        creatorId: user.id,
        creator: user,
        likes: 3421,
        comments: 89,
        views: 12456,
        cost: 18000,
        dates: '5 days',
        rating: 4.7
      },
      {
        id: 'prof-card-3',
        title: 'Kerala Backwaters Serenity',
        destination: 'Alleppey, Kerala',
        thumbnail: 'https://images.unsplash.com/photo-1602216056096-3b40cc0c9944?w=600&h=800&fit=crop',
        images: ['https://images.unsplash.com/photo-1602216056096-3b40cc0c9944?w=600&h=800&fit=crop'],
        tripType: 'Wellness',
        description: 'Rejuvenate in the tranquil backwaters and lush greenery of Gods Own Country',
        experiences: [
          { id: 'exp-7', title: 'Houseboat Experience', category: 'stay', cost: 6000, rating: 4.9 },
          { id: 'exp-8', title: 'Ayurvedic Spa Treatment', category: 'activity', cost: 2500, rating: 4.8 },
          { id: 'exp-9', title: 'Traditional Kerala Sadya', category: 'food', cost: 400, rating: 4.6 }
        ],
        creatorId: user.id,
        creator: user,
        likes: 1987,
        comments: 67,
        views: 7832,
        cost: 22000,
        dates: '6 days',
        rating: 4.9
      },
      {
        id: 'prof-card-4',
        title: 'Mumbai Street Food Trail',
        destination: 'Mumbai, Maharashtra',
        thumbnail: 'https://images.unsplash.com/photo-1567157577867-05ccb1388e66?w=600&h=800&fit=crop',
        images: ['https://images.unsplash.com/photo-1567157577867-05ccb1388e66?w=600&h=800&fit=crop'],
        tripType: 'Food',
        description: 'A culinary adventure through the flavors of Maximum City',
        experiences: [
          { id: 'exp-10', title: 'Vada Pav Tour', category: 'food', cost: 300, rating: 4.7 },
          { id: 'exp-11', title: 'Marine Drive Evening Walk', category: 'activity', cost: 0, rating: 4.8 },
          { id: 'exp-12', title: 'Heritage Hotel Stay', category: 'stay', cost: 5500, rating: 4.6 }
        ],
        creatorId: user.id,
        creator: user,
        likes: 4235,
        comments: 198,
        views: 15672,
        cost: 12000,
        dates: '3 days',
        rating: 4.6
      },
      {
        id: 'prof-card-5',
        title: 'Goa Beach Paradise',
        destination: 'Goa',
        thumbnail: 'https://images.unsplash.com/photo-1512343879784-a960bf40e7f2?w=600&h=800&fit=crop',
        images: ['https://images.unsplash.com/photo-1512343879784-a960bf40e7f2?w=600&h=800&fit=crop'],
        tripType: 'Party',
        description: 'Sun, sand, and endless fun on the golden beaches of Goa',
        experiences: [
          { id: 'exp-13', title: 'Beach Shack Hopping', category: 'food', cost: 1500, rating: 4.5 },
          { id: 'exp-14', title: 'Water Sports Adventure', category: 'activity', cost: 3000, rating: 4.7 },
          { id: 'exp-15', title: 'Beachfront Resort', category: 'stay', cost: 4000, rating: 4.8 }
        ],
        creatorId: user.id,
        creator: user,
        likes: 5123,
        comments: 234,
        views: 18945,
        cost: 16000,
        dates: '4 days',
        rating: 4.7
      },
      {
        id: 'prof-card-6',
        title: 'Ladakh High Altitude Adventure',
        destination: 'Leh, Ladakh',
        thumbnail: 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=600&h=800&fit=crop',
        images: ['https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=600&h=800&fit=crop'],
        tripType: 'Adventure',
        description: 'Journey to the land of high passes and mystical monasteries',
        experiences: [
          { id: 'exp-16', title: 'Pangong Tso Lake Visit', category: 'activity', cost: 2000, rating: 5.0 },
          { id: 'exp-17', title: 'Monastery Meditation', category: 'activity', cost: 500, rating: 4.9 },
          { id: 'exp-18', title: 'Mountain Guesthouse', category: 'stay', cost: 2500, rating: 4.4 }
        ],
        creatorId: user.id,
        creator: user,
        likes: 3876,
        comments: 145,
        views: 11234,
        cost: 35000,
        dates: '8 days',
        rating: 4.8
      }
    ] : [])
  ];
  
  const userTravelCards = enhancedUserTravelCards;

  // User stats - Only travel cards and followers
  const userStats = {
    travelCards: userTravelCards.length,
    followers: user.followerCount || 2847
  };

  const handleFollow = () => {
    onFollowUser(user.id);
  };

  const handleMessage = () => {
    onMessageUser(user.id);
  };

  const handleEditProfile = () => {
    const toast = document.createElement('div');
    toast.className = 'fixed top-20 left-1/2 transform -translate-x-1/2 bg-moodboard-warm-beige text-moodboard-deep-green px-4 py-3 rounded-xl z-50 shadow-brand font-medium';
    toast.textContent = 'Opening profile editor...';
    document.body.appendChild(toast);
    setTimeout(() => document.body.removeChild(toast), 3000);
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: `${user.name}'s Travel Profile`,
        text: user.bio,
        url: window.location.href,
      });
    } else {
      navigator.clipboard.writeText(window.location.href);
      const toast = document.createElement('div');
      toast.className = 'fixed top-20 left-1/2 transform -translate-x-1/2 bg-moodboard-charcoal text-moodboard-cream px-4 py-3 rounded-xl z-50 shadow-brand font-medium';
      toast.textContent = 'Profile link copied!';
      document.body.appendChild(toast);
      setTimeout(() => document.body.removeChild(toast), 3000);
    }
  };

  const handleAccountAction = (action: string) => {
    setShowAccountMenu(false);
    
    switch (action) {
      case 'settings':
        if (onNavigateToSettings) {
          onNavigateToSettings();
        } else {
          const toast = document.createElement('div');
          toast.className = 'fixed top-20 left-1/2 transform -translate-x-1/2 bg-moodboard-cream border-moodboard-muted-teal text-moodboard-deep-green px-4 py-3 rounded-xl z-50 shadow-brand font-medium border';
          toast.textContent = 'Opening settings...';
          document.body.appendChild(toast);
          setTimeout(() => document.body.removeChild(toast), 3000);
        }
        break;
      case 'logout':
        if (onLogout) {
          onLogout();
        } else {
          const toast = document.createElement('div');
          toast.className = 'fixed top-20 left-1/2 transform -translate-x-1/2 bg-moodboard-cream border-red-300 text-red-800 px-4 py-3 rounded-xl z-50 shadow-brand font-medium border';
          toast.textContent = 'Logging out...';
          document.body.appendChild(toast);
          setTimeout(() => document.body.removeChild(toast), 3000);
        }
        break;
      case 'linked-accounts':
        const toast = document.createElement('div');
        toast.className = 'fixed top-20 left-1/2 transform -translate-x-1/2 bg-moodboard-cream border-moodboard-muted-teal text-moodboard-deep-green px-4 py-3 rounded-xl z-50 shadow-brand font-medium border';
        toast.textContent = 'Opening linked accounts...';
        document.body.appendChild(toast);
        setTimeout(() => document.body.removeChild(toast), 3000);
        break;
      case 'privacy':
        const privacyToast = document.createElement('div');
        privacyToast.className = 'fixed top-20 left-1/2 transform -translate-x-1/2 bg-moodboard-cream border-moodboard-muted-teal text-moodboard-deep-green px-4 py-3 rounded-xl z-50 shadow-brand font-medium border';
        privacyToast.textContent = 'Opening privacy settings...';
        document.body.appendChild(privacyToast);
        setTimeout(() => document.body.removeChild(privacyToast), 3000);
        break;
      case 'help':
        const helpToast = document.createElement('div');
        helpToast.className = 'fixed top-20 left-1/2 transform -translate-x-1/2 bg-moodboard-cream border-moodboard-muted-teal text-moodboard-deep-green px-4 py-3 rounded-xl z-50 shadow-brand font-medium border';
        helpToast.textContent = 'Opening help center...';
        document.body.appendChild(helpToast);
        setTimeout(() => document.body.removeChild(helpToast), 3000);
        break;
    }
  };

  const handleLike = (itemId: string, event: React.MouseEvent) => {
    event.stopPropagation();
    setLikedItems(prev => {
      const newSet = new Set(prev);
      if (newSet.has(itemId)) {
        newSet.delete(itemId);
      } else {
        newSet.add(itemId);
      }
      return newSet;
    });
  };

  const handleSave = (itemId: string, event: React.MouseEvent) => {
    event.stopPropagation();
    setSavedItems(prev => {
      const newSet = new Set(prev);
      if (newSet.has(itemId)) {
        newSet.delete(itemId);
      } else {
        newSet.add(itemId);
      }
      return newSet;
    });
  };

  // Tab configurations with Instagram-style icons - Travel Cards first
  const tabs = [
    { 
      id: 'travelcards', 
      icon: Calendar, 
      label: 'Travel Cards',
      count: userTravelCards.length 
    },
    { 
      id: 'gems', 
      icon: Grid3X3, 
      label: 'Local Gems',
      count: userLocalGems.length 
    }
  ];

  return (
    <div className="min-h-screen bg-moodboard-cream">
      {/* Instagram-Style Header with Account Icon */}
      <div className="sticky top-0 z-50 bg-white/95 backdrop-blur-xl border-b border-moodboard-muted-teal/10 safe-area-inset-top">
        <div className="max-w-[428px] mx-auto flex items-center justify-between h-14 px-4">
          {/* Left: Back arrow for other profiles */}
          <div className="w-8">
            {!isOwnProfile && onBack && (
              <button 
                onClick={onBack}
                className="p-1 hover:bg-moodboard-gray-light/20 rounded-full transition-colors"
              >
                <ArrowLeft size={20} className="text-moodboard-deep-green" />
              </button>
            )}
          </div>

          {/* Center: Username */}
          <div className="text-center flex-1">
            <h1 className="font-semibold text-moodboard-deep-green">
              {user.username || user.name.toLowerCase().replace(' ', '')}
            </h1>
          </div>

          {/* Right: Account Settings Icon (for own profile) or More options (for other profiles) */}
          <div className="w-8 flex justify-end">
            {isOwnProfile ? (
              <div className="relative">
                <button 
                  onClick={() => setShowAccountMenu(!showAccountMenu)}
                  className="p-1 hover:bg-moodboard-gray-light/20 rounded-full transition-colors touch-target"
                >
                  <div className="w-8 h-8 rounded-full overflow-hidden border-2 border-moodboard-muted-teal/20">
                    <ImageWithFallback 
                      src={user.profilePic} 
                      alt="Account settings"
                      className="w-full h-full object-cover" 
                    />
                  </div>
                </button>

                {/* Account Menu Dropdown */}
                {showAccountMenu && (
                  <>
                    {/* Backdrop */}
                    <div 
                      className="fixed inset-0 z-40 bg-black/20 animate-backdropFadeIn"
                      onClick={() => setShowAccountMenu(false)}
                    />
                    
                    {/* Menu */}
                    <div className="absolute top-full right-0 mt-2 w-56 bg-white rounded-xl shadow-lg border border-moodboard-muted-teal/10 z-50 animate-scaleIn overflow-hidden">
                      <div className="py-2">
                        <div className="px-4 py-3 border-b border-moodboard-muted-teal/10">
                          <div className="text-sm font-medium text-moodboard-deep-green">{user.name}</div>
                          <div className="text-xs text-moodboard-gray-dark">@{user.username || user.name.toLowerCase().replace(' ', '')}</div>
                        </div>
                        
                        <button
                          onClick={() => handleAccountAction('settings')}
                          className="w-full flex items-center px-4 py-3 text-sm text-moodboard-deep-green hover:bg-moodboard-cream transition-colors"
                        >
                          <Settings size={16} className="mr-3 text-moodboard-muted-teal" />
                          Settings
                        </button>
                        
                        <button
                          onClick={() => handleAccountAction('privacy')}
                          className="w-full flex items-center px-4 py-3 text-sm text-moodboard-deep-green hover:bg-moodboard-cream transition-colors"
                        >
                          <Shield size={16} className="mr-3 text-moodboard-muted-teal" />
                          Privacy & Security
                        </button>
                        
                        <button
                          onClick={() => handleAccountAction('linked-accounts')}
                          className="w-full flex items-center px-4 py-3 text-sm text-moodboard-deep-green hover:bg-moodboard-cream transition-colors"
                        >
                          <Link size={16} className="mr-3 text-moodboard-muted-teal" />
                          Linked Accounts
                        </button>
                        
                        <button
                          onClick={() => handleAccountAction('help')}
                          className="w-full flex items-center px-4 py-3 text-sm text-moodboard-deep-green hover:bg-moodboard-cream transition-colors"
                        >
                          <HelpCircle size={16} className="mr-3 text-moodboard-muted-teal" />
                          Help & Support
                        </button>
                        
                        <div className="border-t border-moodboard-muted-teal/10 mt-2">
                          <button
                            onClick={() => handleAccountAction('logout')}
                            className="w-full flex items-center px-4 py-3 text-sm text-red-600 hover:bg-red-50 transition-colors"
                          >
                            <LogOut size={16} className="mr-3" />
                            Logout
                          </button>
                        </div>
                      </div>
                    </div>
                  </>
                )}
              </div>
            ) : (
              <button 
                onClick={handleShare}
                className="p-1 hover:bg-moodboard-gray-light/20 rounded-full transition-colors"
              >
                <MoreHorizontal size={20} className="text-moodboard-deep-green" />
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Profile Info Section with Full-Height Cover Image */}
      <div className="relative bg-white overflow-hidden min-h-96">
        {/* Full-Height Cover Image Background */}
        <div className="absolute inset-0">
          <ImageWithFallback 
            src="https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=1200&h=600&fit=crop&crop=center"
            alt="Profile Cover"
            className="w-full h-full object-cover" 
          />
          {/* Enhanced Overlay for Better Text Readability */}
          <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-black/20 to-black/60" />
          {/* Additional subtle pattern overlay */}
          <div className="absolute inset-0" style={{ 
            backgroundImage: `radial-gradient(circle at 20% 80%, rgba(78, 155, 142, 0.1) 0%, transparent 50%),
                             radial-gradient(circle at 80% 20%, rgba(232, 220, 192, 0.1) 0%, transparent 50%)` 
          }} />
        </div>

        {/* Profile Content - Maximized Space Usage */}
        <div className="relative z-10 h-full flex flex-col justify-center items-center text-center p-6 min-h-96 space-y-6">
          {/* Profile Picture - Larger */}
          <div className="relative">
            <div className="w-36 h-36 rounded-full overflow-hidden border-4 border-white/90 shadow-2xl">
              <ImageWithFallback 
                src={user.profilePic} 
                alt={user.name}
                className="w-full h-full object-cover" 
              />
            </div>
            {/* Online Status Indicator */}
            <div className="absolute bottom-3 right-3 w-7 h-7 bg-white rounded-full flex items-center justify-center shadow-lg">
              <div className="w-5 h-5 bg-green-500 rounded-full animate-pulse" />
            </div>
          </div>

          {/* Stats - No Background */}
          <div className="flex justify-center space-x-8">
            <div className="text-center">
              <div className="font-bold text-2xl text-white drop-shadow-lg">{userStats.travelCards}</div>
              <div className="text-sm text-white/90 font-medium">Travel Cards</div>
            </div>
            <div className="text-center">
              <div className="font-bold text-2xl text-white drop-shadow-lg">
                {userStats.followers > 999 ? `${(userStats.followers / 1000).toFixed(1)}k` : userStats.followers}
              </div>
              <div className="text-sm text-white/90 font-medium">Followers</div>
            </div>
          </div>

          {/* Name and Creator Tag */}
          <div className="space-y-3">
            <div className="flex items-center justify-center space-x-3">
              <h2 className="font-bold text-2xl text-white drop-shadow-lg">{user.name}</h2>
              {/* Enhanced Creator Tag */}
              {userAccountType === 'creator' && (
                <div className="bg-moodboard-muted-teal text-white px-3 py-1 rounded-full text-sm font-semibold shadow-lg backdrop-blur-sm">
                  ✨ Creator
                </div>
              )}
            </div>
            
            {user.bio && (
              <p className="text-white/90 leading-relaxed line-clamp-3 max-w-sm mx-auto drop-shadow-md font-medium">
                {user.bio}
              </p>
            )}
            
            {user.location && (
              <div className="flex items-center justify-center text-white/90 drop-shadow-md">
                <div className="flex items-center space-x-2">
                  <MapPin size={16} />
                  <span className="text-sm font-medium">{user.location}</span>
                </div>
              </div>
            )}
          </div>

          {/* Action Icons - Minimal */}
          {isOwnProfile ? (
            <div className="flex justify-center space-x-4">
              <button
                onClick={handleEditProfile}
                className="w-12 h-12 bg-white/90 backdrop-blur-sm text-moodboard-muted-teal rounded-full hover:bg-white hover:scale-110 active:scale-95 transition-all duration-200 flex items-center justify-center shadow-lg"
              >
                <Edit size={16} />
              </button>
              
              <button
                onClick={onNavigateToBucketList}
                className="w-12 h-12 bg-moodboard-warm-beige/90 backdrop-blur-sm text-moodboard-deep-green rounded-full hover:bg-moodboard-warm-beige hover:scale-110 active:scale-95 transition-all duration-200 flex items-center justify-center shadow-lg relative"
              >
                <Bookmark size={16} />
                {bucketListCount > 0 && (
                  <div className="absolute -top-1 -right-1 w-5 h-5 bg-moodboard-muted-teal text-white rounded-full flex items-center justify-center shadow-lg animate-pulse">
                    <span className="text-xs font-bold">
                      {bucketListCount > 9 ? '9+' : bucketListCount}
                    </span>
                  </div>
                )}
              </button>
              
              <button
                onClick={handleShare}
                className="w-12 h-12 bg-white/20 backdrop-blur-sm text-white rounded-full hover:bg-white/30 hover:scale-110 active:scale-95 transition-all duration-200 flex items-center justify-center shadow-lg"
              >
                <Share size={16} />
              </button>
            </div>
          ) : (
            <div className="space-y-3 w-full max-w-xs">
              {/* Follow/Following Button */}
              <button
                onClick={handleFollow}
                className={`w-full font-semibold py-3 px-6 rounded-2xl transition-all duration-200 flex items-center justify-center space-x-2 shadow-lg hover:scale-105 active:scale-95 ${
                  isFollowing
                    ? 'bg-white/20 backdrop-blur-sm text-white border-2 border-white/30 hover:bg-red-500/20 hover:border-red-400'
                    : 'bg-moodboard-warm-beige text-moodboard-deep-green hover:bg-moodboard-warm-beige-dark'
                }`}
              >
                {isFollowing ? (
                  <>
                    <UserMinus size={16} />
                    <span>Following</span>
                  </>
                ) : (
                  <>
                    <UserPlus size={16} />
                    <span>Follow</span>
                  </>
                )}
              </button>
              
              {/* Secondary Actions */}
              <div className="flex space-x-3">
                <button
                  onClick={handleMessage}
                  className="flex-1 bg-white/20 backdrop-blur-sm text-white font-semibold py-3 px-6 rounded-2xl hover:bg-white/30 transition-all duration-200 flex items-center justify-center space-x-2 shadow-lg hover:scale-105 active:scale-95"
                >
                  <MessageCircle size={16} />
                  <span>Message</span>
                </button>
                
                <button
                  onClick={handleShare}
                  className="bg-white/20 backdrop-blur-sm text-white font-semibold py-3 px-4 rounded-2xl hover:bg-white/30 transition-all duration-200 shadow-lg hover:scale-105 active:scale-95"
                >
                  <Share size={16} />
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Tab Navigation - Instagram Style */}
      <div className="bg-white border-t border-moodboard-muted-teal/10">
        <div className="flex">
          {tabs.map((tab) => {
            const IconComponent = tab.icon;
            const isActive = activeTab === tab.id;
            
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex-1 flex flex-col items-center py-3 border-t-2 transition-colors ${
                  isActive 
                    ? 'border-moodboard-muted-teal text-moodboard-muted-teal' 
                    : 'border-transparent text-moodboard-gray-dark'
                }`}
              >
                <IconComponent size={20} strokeWidth={isActive ? 2.5 : 1.5} />
                <span className="text-xs font-medium mt-1">{tab.count}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Content Areas */}
      <div className="bg-moodboard-cream min-h-screen">
        {/* Travel Cards Grid Layout - Using SuggestedTravelCardsCarousel Design */}
        {activeTab === 'travelcards' && (
          <div className="p-3">
            {userTravelCards.length > 0 ? (
              <div className="grid grid-cols-2 gap-3">
                {userTravelCards.map((card, index) => {
                  const creator = card.creatorId ? getCreator(card.creatorId) : user;
                  
                  const getEstimatedCost = (card: any) => {
                    if (card.cost) return card.cost;
                    const baseAmount = Math.floor(Math.random() * 50000) + 10000;
                    return Math.round(baseAmount / 1000) * 1000;
                  };

                  const formatCost = (cost: number) => {
                    if (cost >= 100000) return `${(cost / 100000).toFixed(1)}L`;
                    if (cost >= 1000) return `${(cost / 1000).toFixed(0)}k`;
                    return cost.toString();
                  };

                  const estimatedCost = getEstimatedCost(card);

                  return (
                    <div
                      key={card.id}
                      className="group cursor-pointer animate-fadeIn"
                      style={{
                        animationDelay: `${index * 100}ms`
                      }}
                      onClick={() => onSelectTravelCard(card.id)}
                    >
                      {/* Modern Vertical Travel Card Container - Compact */}
                      <div 
                        className="relative bg-white rounded-2xl shadow-lg border border-moodboard-gray-light/10 overflow-hidden transition-all duration-300 hover:shadow-xl hover:scale-[1.02] group-active:scale-[0.98]"
                        style={{ height: '320px' }}
                      >
                        {/* Full-Bleed Cover Photo Background - Edge to Edge */}
                        <div className="absolute inset-0 overflow-hidden">
                          <ImageWithFallback
                            src={card.thumbnail || card.images?.[0] || 'https://images.unsplash.com/photo-1469474968028-56623f02e42e?w=600&h=800&fit=crop'}
                            alt={card.title || card.destination || 'Travel destination'}
                            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                          />
                          
                          {/* Gradient Overlay - Dark to Transparent */}
                          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent"></div>
                        </div>

                        {/* Profile Stamp - Top Right Corner */}
                        {creator && (
                          <div className="absolute top-3 right-3 z-20">
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                onSelectUser?.(creator.id);
                              }}
                              className="flex items-center space-x-1.5 bg-white/20 backdrop-blur-md rounded-full pr-2 pl-1 py-1 border border-white/30 hover:bg-white/30 transition-all duration-200"
                            >
                              {/* Circular Profile Photo */}
                              <div className="w-6 h-6 rounded-full overflow-hidden border border-white/50 relative">
                                <ImageWithFallback
                                  src={creator.profilePic}
                                  alt={creator.name}
                                  className="w-full h-full object-cover"
                                />
                                {creator.isCreator && (
                                  <div className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 bg-gradient-brand rounded-full flex items-center justify-center border border-white">
                                    <Plane size={4} className="text-white" />
                                  </div>
                                )}
                              </div>
                              
                              {/* Username */}
                              <span className="text-xs font-medium text-white/90">
                                @{creator.username || creator.name.toLowerCase().replace(' ', '')}
                              </span>
                            </button>
                          </div>
                        )}

                        {/* Trip Type Badge - Top Left */}
                        {card.tripType && (
                          <div className="absolute top-3 left-3 z-20">
                            <div className="bg-moodboard-warm-beige/90 backdrop-blur-sm text-moodboard-deep-green px-2 py-1 rounded-full text-xs font-semibold border border-white/20">
                              {card.tripType}
                            </div>
                          </div>
                        )}

                        {/* Caption Text Overlay - Center */}
                        <div className="absolute inset-x-3 bottom-16 z-10">
                          <div className="text-center">
                            {/* Trip Title - Bold */}
                            <h3 className="text-white font-bold text-base mb-1 leading-tight drop-shadow-lg line-clamp-2">
                              {card.title || `Adventure in ${card.destination}`}
                            </h3>
                            
                            {/* Location */}
                            <div className="flex items-center justify-center space-x-1 mb-2">
                              <MapPin size={10} className="text-white/80 flex-shrink-0" />
                              <span className="text-white/80 text-xs truncate">
                                {card.destination}
                              </span>
                            </div>
                          </div>
                        </div>

                        {/* Trip Details Overlay - Bottom Layer */}
                        <div className="absolute bottom-6 left-3 right-3 z-10">
                          <div className="flex items-center justify-center">
                            {/* Budget Tag Only */}
                            <div className="flex items-center space-x-1 bg-white/20 backdrop-blur-md rounded-full px-2 py-1 border border-white/30">
                              <DollarSign size={10} className="text-white" />
                              <span className="text-white text-xs font-medium">{formatCost(estimatedCost)}</span>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="text-center py-12">
                <Calendar size={48} className="text-moodboard-gray-light mx-auto mb-4" />
                <p className="text-moodboard-gray-dark font-medium">No travel cards yet</p>
                <p className="text-sm text-moodboard-gray-light">Create your first trip!</p>
              </div>
            )}
          </div>
        )}

        {/* Local Gems Grid - LocalGemsPage Design in 2-Column Grid */}
        {activeTab === 'gems' && (
          <div className="p-3">
            {userLocalGems.length > 0 ? (
              <div className="grid grid-cols-2 gap-3">
                {userLocalGems.map((gem, index) => {
                  const isLiked = likedItems.has(gem.id);
                  const isSaved = savedItems.has(gem.id);
                  
                  return (
                    <div
                      key={gem.id}
                      className="relative bg-black rounded-2xl overflow-hidden cursor-pointer group"
                      style={{ height: '280px' }}
                    >
                      {/* Full Background Image */}
                      <div className="absolute inset-0">
                        <ImageWithFallback 
                          src={gem.image} 
                          alt={gem.title} 
                          className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-700" 
                        />
                        {/* Dark overlay for better text readability */}
                        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-black/40" />
                      </div>

                      {/* Top-Left: Profile Section */}
                      <div className="absolute top-3 left-3 flex items-center space-x-2 z-10">
                        <button 
                          onClick={(e) => {
                            e.stopPropagation();
                            onSelectUser?.(user.id);
                          }}
                          className="flex items-center space-x-2 hover:bg-white/10 rounded-lg p-1 -m-1 transition-colors"
                        >
                          <div className="w-6 h-6 rounded-full overflow-hidden border border-white/20">
                            <ImageWithFallback 
                              src={user.profilePic} 
                              alt={user.name} 
                              className="w-full h-full object-cover" 
                            />
                          </div>
                          <span className="text-white font-medium text-xs drop-shadow-lg">
                            {user.name.split(' ')[0]}
                          </span>
                        </button>
                      </div>

                      {/* Category Badge */}
                      <div className="absolute top-3 right-3 z-10">
                        <span className="bg-black/60 backdrop-blur-md text-white px-2 py-1 rounded-full text-xs font-medium border border-white/20">
                          {gem.category}
                        </span>
                      </div>

                      {/* Bottom-Right: Action Icons (Compact Vertical Stack) */}
                      <div className="absolute bottom-3 right-3 z-10 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                        <div className="flex flex-col items-center space-y-2">
                          {/* Like Button */}
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              handleLike(gem.id, e);
                            }}
                            className={`p-2 rounded-full backdrop-blur-sm border border-white/20 transition-all duration-200 hover:scale-110 active:scale-95 ${
                              isLiked 
                                ? 'bg-red-500/20 text-red-400 border-red-400/40' 
                                : 'bg-black/40 text-white hover:bg-white/20'
                            }`}
                          >
                            <Heart size={14} className={isLiked ? 'fill-current' : ''} />
                          </button>

                          {/* Save Button */}
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              handleSave(gem.id, e);
                            }}
                            className={`p-2 rounded-full backdrop-blur-sm border border-white/20 transition-all duration-200 hover:scale-110 active:scale-95 ${
                              isSaved 
                                ? 'bg-brand-accent/20 text-brand-accent border-brand-accent/40' 
                                : 'bg-black/40 text-white hover:bg-white/20'
                            }`}
                          >
                            <Bookmark size={14} className={isSaved ? 'fill-current' : ''} />
                          </button>
                        </div>
                      </div>

                      {/* Bottom-Left: Content Overlay */}
                      <div className="absolute bottom-3 left-3 right-12 z-10">
                        {/* Location */}
                        <div className="flex items-center space-x-1 mb-1">
                          <MapPin size={10} className="text-white/80 flex-shrink-0" />
                          <span className="text-white/80 text-xs font-medium drop-shadow truncate">
                            {gem.location}
                          </span>
                        </div>

                        {/* Title */}
                        <h3 className="text-white font-bold text-sm drop-shadow-lg mb-1 line-clamp-2 leading-tight">
                          {gem.title}
                        </h3>
                        
                        {/* Description - Truncated */}
                        <p className="text-white/90 text-xs leading-relaxed drop-shadow line-clamp-2 mb-2">
                          {gem.description}
                        </p>

                        {/* Bottom Info */}
                        <div className="flex items-center justify-between">
                          {/* Price/Rating */}
                          {gem.price && (
                            <span className="text-xs font-semibold text-white bg-brand-primary/80 px-2 py-0.5 rounded-full backdrop-blur-sm">
                              {gem.price}
                            </span>
                          )}
                          
                          {/* Likes Count */}
                          <div className="flex items-center space-x-1">
                            <Heart size={10} className="text-red-400" />
                            <span className="text-xs text-white/80 font-medium">
                              {gem.likes + (isLiked ? 1 : 0)}
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="text-center py-12">
                <Grid3X3 size={48} className="text-moodboard-gray-light mx-auto mb-4" />
                <p className="text-moodboard-gray-dark font-medium">No local gems yet</p>
                <p className="text-sm text-moodboard-gray-light">Share your first discovery!</p>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}