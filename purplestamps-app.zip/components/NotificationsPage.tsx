import { useState } from 'react';
import { ArrowLeft, Heart, MessageCircle, UserPlus, MapPin, Star, Bell, Settings, Filter } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface NotificationsPageProps {
  onBack: () => void;
  onNavigateToSettings: () => void;
}

interface Notification {
  id: string;
  type: 'like' | 'comment' | 'follow' | 'mention' | 'trip_invite' | 'cultural_tip' | 'achievement';
  user?: {
    name: string;
    avatar: string;
    username: string;
  };
  content: string;
  timestamp: string;
  isRead: boolean;
  actionData?: any;
  image?: string;
}

export function NotificationsPage({ onBack, onNavigateToSettings }: NotificationsPageProps) {
  const [activeTab, setActiveTab] = useState<'all' | 'mentions' | 'follows'>('all');
  const [notifications, setNotifications] = useState<Notification[]>([
    {
      id: '1',
      type: 'like',
      user: {
        name: 'Sarah Chen',
        avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b5bb?w=50&h=50&fit=crop&crop=face',
        username: 'sarahexplores'
      },
      content: 'liked your Tokyo travel card',
      timestamp: '2m ago',
      isRead: false,
      image: 'https://images.unsplash.com/photo-1540959733332-eab4deabeeaf?w=100&h=100&fit=crop'
    },
    {
      id: '2',
      type: 'cultural_tip',
      content: 'New cultural insight: Japanese Tea Ceremony etiquette',
      timestamp: '1h ago',
      isRead: false,
      image: 'https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=100&h=100&fit=crop'
    },
    {
      id: '3',
      type: 'follow',
      user: {
        name: 'Alex Rodriguez',
        avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=50&h=50&fit=crop&crop=face',
        username: 'alexwanders'
      },
      content: 'started following you',
      timestamp: '3h ago',
      isRead: false
    },
    {
      id: '4',
      type: 'comment',
      user: {
        name: 'Emily Johnson',
        avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=50&h=50&fit=crop&crop=face',
        username: 'emilygoesplaces'
      },
      content: 'commented: "This looks amazing! Any restaurant recommendations?"',
      timestamp: '5h ago',
      isRead: true,
      image: 'https://images.unsplash.com/photo-1551632811-561732d1e306?w=100&h=100&fit=crop'
    },
    {
      id: '5',
      type: 'achievement',
      content: 'Congratulations! You\'ve earned the "Cultural Explorer" badge',
      timestamp: '1d ago',
      isRead: true,
      image: 'https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=100&h=100&fit=crop'
    },
    {
      id: '6',
      type: 'trip_invite',
      user: {
        name: 'Marcus Kim',
        avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=50&h=50&fit=crop&crop=face',
        username: 'marcustravels'
      },
      content: 'invited you to join "Bali Adventure Group"',
      timestamp: '2d ago',
      isRead: true
    }
  ]);

  const markAsRead = (notificationId: string) => {
    setNotifications(prev => prev.map(notif => 
      notif.id === notificationId ? { ...notif, isRead: true } : notif
    ));
  };

  const markAllAsRead = () => {
    setNotifications(prev => prev.map(notif => ({ ...notif, isRead: true })));
  };

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'like': return <Heart size={16} className="text-red-500" />;
      case 'comment': return <MessageCircle size={16} className="text-brand-primary" />;
      case 'follow': return <UserPlus size={16} className="text-brand-secondary" />;
      case 'trip_invite': return <MapPin size={16} className="text-brand-accent" />;
      case 'cultural_tip': return <Star size={16} className="text-yellow-500" />;
      case 'achievement': return <Star size={16} className="text-purple-500" />;
      default: return <Bell size={16} className="text-gray-500" />;
    }
  };

  const filteredNotifications = notifications.filter(notif => {
    if (activeTab === 'all') return true;
    if (activeTab === 'mentions') return notif.type === 'comment' || notif.type === 'mention';
    if (activeTab === 'follows') return notif.type === 'follow';
    return true;
  });

  const unreadCount = notifications.filter(n => !n.isRead).length;

  return (
    <div className="min-h-screen bg-gradient-to-br from-surface-warm to-surface-cool">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-white/90 backdrop-blur-xl border-b border-gray-100">
        <div className="flex items-center justify-between p-4">
          <div className="flex items-center space-x-4">
            <button onClick={onBack} className="p-2 hover:bg-gray-100 rounded-xl transition-colors">
              <ArrowLeft size={24} className="text-gray-700" />
            </button>
            <div>
              <h1 className="text-xl font-bold text-gray-900">Notifications</h1>
              {unreadCount > 0 && (
                <p className="text-sm text-brand-primary font-medium">
                  {unreadCount} new notification{unreadCount !== 1 ? 's' : ''}
                </p>
              )}
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <button className="p-2 hover:bg-gray-100 rounded-xl transition-colors">
              <Filter size={20} className="text-gray-700" />
            </button>
            <button 
              onClick={onNavigateToSettings}
              className="p-2 hover:bg-gray-100 rounded-xl transition-colors"
            >
              <Settings size={20} className="text-gray-700" />
            </button>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-gray-100">
          {[
            { id: 'all', label: 'All', count: notifications.length },
            { id: 'mentions', label: 'Mentions', count: notifications.filter(n => n.type === 'comment' || n.type === 'mention').length },
            { id: 'follows', label: 'Follows', count: notifications.filter(n => n.type === 'follow').length }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex-1 py-3 px-4 text-center relative transition-all duration-200 ${
                activeTab === tab.id
                  ? 'text-brand-primary font-semibold'
                  : 'text-gray-600 hover:text-gray-800'
              }`}
            >
              <div className="flex items-center justify-center space-x-2">
                <span>{tab.label}</span>
                {tab.count > 0 && (
                  <span className={`text-xs px-2 py-0.5 rounded-full ${
                    activeTab === tab.id 
                      ? 'bg-brand-primary text-white' 
                      : 'bg-gray-200 text-gray-600'
                  }`}>
                    {tab.count}
                  </span>
                )}
              </div>
              {activeTab === tab.id && (
                <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-brand-primary"></div>
              )}
            </button>
          ))}
        </div>
      </header>

      {/* Quick Actions */}
      {unreadCount > 0 && (
        <div className="p-4 bg-white/50 border-b border-gray-100">
          <button
            onClick={markAllAsRead}
            className="w-full bg-gradient-brand text-white py-3 px-4 rounded-2xl font-semibold hover:shadow-brand hover:scale-[1.02] transition-all duration-200 active:scale-95"
          >
            Mark all as read ({unreadCount})
          </button>
        </div>
      )}

      {/* Notifications List */}
      <main className="pb-24">
        <div className="divide-y divide-gray-100">
          {filteredNotifications.map((notification) => (
            <div
              key={notification.id}
              className={`p-4 hover:bg-white/50 transition-colors cursor-pointer ${
                !notification.isRead ? 'bg-brand-primary/5 border-l-4 border-brand-primary' : ''
              }`}
              onClick={() => markAsRead(notification.id)}
            >
              <div className="flex items-start space-x-3">
                {/* Icon or User Avatar */}
                <div className="flex-shrink-0">
                  {notification.user ? (
                    <div className="relative">
                      <div className="w-12 h-12 rounded-full overflow-hidden border-2 border-gray-100">
                        <ImageWithFallback
                          src={notification.user.avatar}
                          alt={notification.user.name}
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <div className="absolute -bottom-1 -right-1 w-6 h-6 bg-white rounded-full flex items-center justify-center border border-gray-200">
                        {getNotificationIcon(notification.type)}
                      </div>
                    </div>
                  ) : (
                    <div className="w-12 h-12 bg-gradient-brand rounded-full flex items-center justify-center">
                      {getNotificationIcon(notification.type)}
                    </div>
                  )}
                </div>

                {/* Content */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between">
                    <div className="flex-1 min-w-0">
                      <p className="text-sm text-gray-900 leading-relaxed">
                        {notification.user && (
                          <span className="font-semibold">{notification.user.name} </span>
                        )}
                        {notification.content}
                      </p>
                      <div className="flex items-center space-x-2 mt-1">
                        <span className="text-xs text-gray-500">{notification.timestamp}</span>
                        {!notification.isRead && (
                          <div className="w-2 h-2 bg-brand-primary rounded-full"></div>
                        )}
                      </div>
                    </div>

                    {/* Notification Image */}
                    {notification.image && (
                      <div className="ml-3 w-12 h-12 rounded-lg overflow-hidden flex-shrink-0">
                        <ImageWithFallback
                          src={notification.image}
                          alt="Notification"
                          className="w-full h-full object-cover"
                        />
                      </div>
                    )}
                  </div>

                  {/* Action Buttons for certain notification types */}
                  {(notification.type === 'follow' || notification.type === 'trip_invite') && (
                    <div className="flex items-center space-x-2 mt-3">
                      <button className="bg-gradient-brand text-white px-4 py-2 rounded-xl text-sm font-semibold hover:shadow-brand hover:scale-105 transition-all duration-200 active:scale-95">
                        {notification.type === 'follow' ? 'Follow Back' : 'Accept'}
                      </button>
                      <button className="border border-gray-300 text-gray-700 px-4 py-2 rounded-xl text-sm font-semibold hover:bg-gray-50 transition-colors">
                        {notification.type === 'follow' ? 'View Profile' : 'Decline'}
                      </button>
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>

        {filteredNotifications.length === 0 && (
          <div className="text-center py-12">
            <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Bell size={24} className="text-gray-400" />
            </div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">No notifications yet</h3>
            <p className="text-gray-600 max-w-sm mx-auto">
              When people interact with your travel stories, you'll see it here.
            </p>
          </div>
        )}
      </main>
    </div>
  );
}