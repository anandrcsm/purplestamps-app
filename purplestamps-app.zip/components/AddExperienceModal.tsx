import { useState, useEffect } from 'react';
import { 
  X, 
  Plus, 
  Clock, 
  MapPin,
  DollarSign,
  ExternalLink
} from 'lucide-react';
import { Experience, BucketListItem } from '../types';
import { CategoryTag } from './CategoryTag';

interface AddExperienceModalProps {
  isOpen: boolean;
  onClose: () => void;
  dayNumber: number;
  bucketListItems: BucketListItem[];
  onAddFromBucketList: (item: BucketListItem) => void;
  onAddNewExperience: (experience: Experience) => void;
}

export function AddExperienceModal({
  isOpen,
  onClose,
  dayNumber,
  bucketListItems,
  onAddFromBucketList,
  onAddNewExperience
}: AddExperienceModalProps) {
  const [activeTab, setActiveTab] = useState<'bucket' | 'new'>('bucket');
  const [isVisible, setIsVisible] = useState(false);
  const [newExperience, setNewExperience] = useState({
    title: '',
    location: '',
    category: 'activity' as Experience['category'],
    timeFrom: '',
    timeTo: '',
    cost: 0,
    description: '',
    bookingUrl: ''
  });

  const experienceBucketItems = bucketListItems.filter(item => item.type === 'experience');

  useEffect(() => {
    if (isOpen) {
      setIsVisible(true);
      document.body.style.overflow = 'hidden';
    } else {
      setIsVisible(false);
      document.body.style.overflow = 'unset';
    }

    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isOpen]);

  const handleClose = () => {
    setIsVisible(false);
    setTimeout(() => {
      onClose();
      setNewExperience({
        title: '',
        location: '',
        category: 'activity',
        timeFrom: '',
        timeTo: '',
        cost: 0,
        description: '',
        bookingUrl: ''
      });
    }, 250);
  };

  const handleAddFromBucket = (item: BucketListItem) => {
    onAddFromBucketList(item);
    handleClose();
  };

  const handleCreateNew = () => {
    if (newExperience.title && newExperience.location) {
      const experience: Experience = {
        id: `exp-${Date.now()}`,
        title: newExperience.title,
        category: newExperience.category,
        description: newExperience.description,
        rating: 0,
        cost: newExperience.cost,
        location: newExperience.location,
        media: [],
        timeFrom: newExperience.timeFrom,
        timeTo: newExperience.timeTo,
        bookingUrl: newExperience.bookingUrl || undefined
      };
      
      onAddNewExperience(experience);
      handleClose();
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50">
      {/* Backdrop */}
      <div 
        className={`absolute inset-0 bg-black/50 transition-opacity duration-300 ${
          isVisible ? 'opacity-100' : 'opacity-0'
        }`}
        onClick={handleClose}
      />
      
      {/* Modal */}
      <div 
        className={`absolute bottom-0 left-0 right-0 bg-white rounded-t-3xl max-h-[85vh] flex flex-col transition-transform duration-300 ${
          isVisible ? 'translate-y-0' : 'translate-y-full'
        }`}
      >
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-100">
          <h2 className="text-xl font-semibold text-gray-900">Add Experience to Day {dayNumber}</h2>
          <button
            onClick={handleClose}
            className="p-2 hover:bg-gray-100 rounded-full transition-colors"
          >
            <X size={20} className="text-gray-600" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-gray-100">
          <button
            onClick={() => setActiveTab('bucket')}
            className={`flex-1 py-4 px-6 text-sm font-medium transition-colors ${
              activeTab === 'bucket'
                ? 'text-brand-primary border-b-2 border-brand-primary'
                : 'text-gray-500 hover:text-gray-700'
            }`}
          >
            Add from Bucket List
          </button>
          <button
            onClick={() => setActiveTab('new')}
            className={`flex-1 py-4 px-6 text-sm font-medium transition-colors ${
              activeTab === 'new'
                ? 'text-brand-primary border-b-2 border-brand-primary'
                : 'text-gray-500 hover:text-gray-700'
            }`}
          >
            Create New Experience
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6">
          {activeTab === 'bucket' ? (
            <div className="space-y-3">
              {experienceBucketItems.length > 0 ? (
                experienceBucketItems.map((item) => {
                  const experience = item.data as Experience;
                  return (
                    <div
                      key={item.id}
                      className="border border-gray-200 rounded-xl p-4 hover:bg-gray-50 transition-colors cursor-pointer"
                      onClick={() => handleAddFromBucket(item)}
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <h3 className="font-medium text-gray-900 mb-1">{experience.title}</h3>
                          <div className="flex items-center space-x-2 mb-2">
                            <CategoryTag category={experience.category} size="sm" />
                            <span className="text-sm text-gray-600">
                              {experience.cost === 0 ? 'Free' : `₹${experience.cost}`}
                            </span>
                          </div>
                          <div className="flex items-center text-sm text-gray-500 mb-2">
                            <MapPin size={14} className="mr-1" />
                            <span>{experience.location}</span>
                          </div>
                          {experience.bookingUrl && (
                            <div className="flex items-center text-xs text-brand-primary">
                              <ExternalLink size={12} className="mr-1" />
                              <span>Book Now available</span>
                            </div>
                          )}
                        </div>
                        
                        <button className="bg-brand-primary text-white px-3 py-1.5 rounded-lg text-sm font-medium hover:bg-brand-primary-dark transition-colors">
                          Add
                        </button>
                      </div>
                    </div>
                  );
                })
              ) : (
                <div className="text-center py-12">
                  <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Plus size={24} className="text-gray-400" />
                  </div>
                  <p className="text-gray-500 mb-4">No experiences in your bucket list</p>
                  <button
                    onClick={() => setActiveTab('new')}
                    className="text-brand-primary font-medium hover:text-brand-primary-dark transition-colors"
                  >
                    Create a new experience instead
                  </button>
                </div>
              )}
            </div>
          ) : (
            <div className="space-y-6">
              {/* Title */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Experience Title *
                </label>
                <input
                  type="text"
                  value={newExperience.title}
                  onChange={(e) => setNewExperience(prev => ({ ...prev, title: e.target.value }))}
                  placeholder="e.g., Zostel Kaza Stay"
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-brand-primary/20 focus:border-brand-primary"
                />
              </div>

              {/* Location */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Location *
                </label>
                <input
                  type="text"
                  value={newExperience.location}
                  onChange={(e) => setNewExperience(prev => ({ ...prev, location: e.target.value }))}
                  placeholder="e.g., Kaza, Spiti Valley"
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-brand-primary/20 focus:border-brand-primary"
                />
              </div>

              {/* Category */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Category
                </label>
                <select
                  value={newExperience.category}
                  onChange={(e) => setNewExperience(prev => ({ ...prev, category: e.target.value as Experience['category'] }))}
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-brand-primary/20 focus:border-brand-primary"
                >
                  <option value="activity">Activity</option>
                  <option value="food">Food</option>
                  <option value="stay">Stay</option>
                  <option value="transport">Transport</option>
                  <option value="item">Item</option>
                </select>
              </div>

              {/* Time Range */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Time From
                  </label>
                  <input
                    type="time"
                    value={newExperience.timeFrom}
                    onChange={(e) => setNewExperience(prev => ({ ...prev, timeFrom: e.target.value }))}
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-brand-primary/20 focus:border-brand-primary"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Time To
                  </label>
                  <input
                    type="time"
                    value={newExperience.timeTo}
                    onChange={(e) => setNewExperience(prev => ({ ...prev, timeTo: e.target.value }))}
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-brand-primary/20 focus:border-brand-primary"
                  />
                </div>
              </div>

              {/* Cost */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Cost (₹)
                </label>
                <input
                  type="number"
                  value={newExperience.cost}
                  onChange={(e) => setNewExperience(prev => ({ ...prev, cost: Number(e.target.value) }))}
                  placeholder="0 for free"
                  min="0"
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-brand-primary/20 focus:border-brand-primary"
                />
              </div>

              {/* Description */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Description (Optional)
                </label>
                <textarea
                  value={newExperience.description}
                  onChange={(e) => setNewExperience(prev => ({ ...prev, description: e.target.value }))}
                  placeholder="Brief description or notes..."
                  rows={3}
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-brand-primary/20 focus:border-brand-primary resize-none"
                />
              </div>

              {/* Booking URL */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Booking URL (Optional)
                </label>
                <input
                  type="url"
                  value={newExperience.bookingUrl}
                  onChange={(e) => setNewExperience(prev => ({ ...prev, bookingUrl: e.target.value }))}
                  placeholder="https://example.com/booking"
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-brand-primary/20 focus:border-brand-primary"
                />
              </div>

              {/* Add Button */}
              <button
                onClick={handleCreateNew}
                disabled={!newExperience.title || !newExperience.location}
                className="w-full bg-brand-primary text-white py-4 rounded-xl font-semibold hover:bg-brand-primary-dark transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
              >
                <Plus size={20} className="mr-2" />
                Add to Day {dayNumber}
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}