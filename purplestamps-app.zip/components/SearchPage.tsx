import { useState } from 'react';
import { MapPin, Filter, Heart, Star, Radio, DollarSign, Plane } from 'lucide-react';
import { TravelCard as TravelCardType } from '../types';
import { getCreator } from '../data/mockData';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface SearchPageProps {
  travelCards: TravelCardType[];
  onSelectTravelCard: (id: string) => void;
  onSelectUser?: (userId: string) => void;
}

const trendingTags = ['Adventure', 'Luxury', 'Foodie', 'Solo Travel', 'Honeymoon', 'Backpacking', 'Culture'];

export function SearchPage({ travelCards, onSelectTravelCard, onSelectUser }: SearchPageProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [filters, setFilters] = useState({
    budget: '',
    tripType: '',
  });
  const [likedCards, setLikedCards] = useState<Set<string>>(new Set());
  const [savedCards, setSavedCards] = useState<Set<string>>(new Set());

  const filteredCards = travelCards.filter(card => {
    const creator = getCreator(card.creatorId);
    const matchesSearch = card.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          card.destination.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          creator?.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          card.description.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesBudget = filters.budget === '' || card.budget === filters.budget;
    const matchesTripType = filters.tripType === '' || card.tripType === filters.tripType;

    return matchesSearch && matchesBudget && matchesTripType;
  });

  const handleLike = (cardId: string, event: React.MouseEvent) => {
    event.stopPropagation();
    setLikedCards(prev => {
      const newSet = new Set(prev);
      if (newSet.has(cardId)) {
        newSet.delete(cardId);
      } else {
        newSet.add(cardId);
      }
      return newSet;
    });
  };

  const handleSave = (cardId: string, event: React.MouseEvent) => {
    event.stopPropagation();
    setSavedCards(prev => {
      const newSet = new Set(prev);
      if (newSet.has(cardId)) {
        newSet.delete(cardId);
      } else {
        newSet.add(cardId);
      }
      return newSet;
    });
  };

  // Compact Travel Card Component for Search Grid - Updated to match SuggestedTravelCardsCarousel design
  const CompactTravelCard = ({ card }: { card: TravelCardType }) => {
    const creator = card.creatorId ? getCreator(card.creatorId) : null;
    const isLiked = likedCards.has(card.id);
    const isSaved = savedCards.has(card.id);

    const getEstimatedCost = (card: any) => {
      if (card.cost) return card.cost;
      const baseAmount = Math.floor(Math.random() * 50000) + 10000;
      return Math.round(baseAmount / 1000) * 1000;
    };

    const formatCost = (cost: number) => {
      if (cost >= 100000) return `${(cost / 100000).toFixed(1)}L`;
      if (cost >= 1000) return `${(cost / 1000).toFixed(0)}k`;
      return cost.toString();
    };

    const estimatedCost = getEstimatedCost(card);
    
    return (
      <div className="flex-shrink-0 w-full group cursor-pointer animate-fadeIn">
        <div 
          className="relative bg-white rounded-2xl shadow-lg border border-moodboard-gray-light/10 overflow-hidden transition-all duration-300 hover:shadow-xl hover:scale-[1.02] group-active:scale-[0.98]"
          style={{ height: '320px' }}
          onClick={() => onSelectTravelCard(card.id)}
        >
          {/* Full-Bleed Cover Photo Background - Edge to Edge */}
          <div className="absolute inset-0 overflow-hidden">
            <ImageWithFallback
              src={card.thumbnail || card.images?.[0] || 'https://images.unsplash.com/photo-1469474968028-56623f02e42e?w=600&h=800&fit=crop'}
              alt={card.title || card.destination || 'Travel destination'}
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
            />
            
            {/* Gradient Overlay - Dark to Transparent */}
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent"></div>
          </div>

          {/* Profile Stamp - Top Right Corner */}
          {creator && (
            <div className="absolute top-3 right-3 z-20">
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onSelectUser?.(creator.id);
                }}
                className="flex items-center space-x-1.5 bg-white/20 backdrop-blur-md rounded-full pr-2 pl-1 py-1 border border-white/30 hover:bg-white/30 transition-all duration-200"
              >
                {/* Circular Profile Photo */}
                <div className="w-6 h-6 rounded-full overflow-hidden border border-white/50 relative">
                  <ImageWithFallback
                    src={creator.profilePic}
                    alt={creator.name}
                    className="w-full h-full object-cover"
                  />
                  {creator.isCreator && (
                    <div className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 bg-gradient-brand rounded-full flex items-center justify-center border border-white">
                      <Plane size={4} className="text-white" />
                    </div>
                  )}
                </div>
                
                {/* Username */}
                <span className="text-xs font-medium text-white/90">
                  @{creator.username || creator.name.toLowerCase().replace(' ', '')}
                </span>
              </button>
            </div>
          )}

          {/* Trip Type Badge - Top Left */}
          {(card.isLive || card.tripType) && (
            <div className="absolute top-3 left-3 z-20">
              {card.isLive ? (
                <div className="flex items-center space-x-1 bg-red-500 text-white px-2 py-1 rounded-full text-xs font-semibold shadow-lg">
                  <Radio size={8} className="animate-pulse" />
                  <span>LIVE</span>
                </div>
              ) : (
                <div className="bg-moodboard-warm-beige/90 backdrop-blur-sm text-moodboard-deep-green px-2 py-1 rounded-full text-xs font-semibold border border-white/20">
                  {card.tripType}
                </div>
              )}
            </div>
          )}

          {/* Action Buttons - Top Right, below profile */}
          <div className="absolute top-12 right-3 z-20 flex flex-col space-y-1 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
            <button
              onClick={(e) => handleLike(card.id, e)}
              className={`p-1.5 rounded-full backdrop-blur-sm border border-white/20 transition-all duration-200 hover:scale-110 active:scale-95 ${
                isLiked 
                  ? 'bg-red-500/20 text-red-400' 
                  : 'bg-black/20 text-white hover:bg-red-500/20 hover:text-red-400'
              }`}
            >
              <Heart size={12} className={isLiked ? 'fill-current' : ''} />
            </button>
            <button
              onClick={(e) => handleSave(card.id, e)}
              className={`p-1.5 rounded-full backdrop-blur-sm border border-white/20 transition-all duration-200 hover:scale-110 active:scale-95 ${
                isSaved 
                  ? 'bg-brand-accent/20 text-brand-accent' 
                  : 'bg-black/20 text-white hover:bg-brand-accent/20 hover:text-brand-accent'
              }`}
            >
              <Heart size={12} className={isSaved ? 'fill-current' : ''} />
            </button>
          </div>

          {/* Caption Text Overlay - Center */}
          <div className="absolute inset-x-3 bottom-16 z-10">
            <div className="text-center">
              {/* Trip Title - Bold */}
              <h3 className="text-white font-bold text-base mb-1 leading-tight drop-shadow-lg line-clamp-2">
                {card.title || `Adventure in ${card.destination}`}
              </h3>
              
              {/* Location */}
              <div className="flex items-center justify-center space-x-1 mb-2">
                <MapPin size={10} className="text-white/80 flex-shrink-0" />
                <span className="text-white/80 text-xs truncate">
                  {card.destination}
                </span>
              </div>
            </div>
          </div>

          {/* Trip Details Overlay - Bottom Layer */}
          <div className="absolute bottom-6 left-3 right-3 z-10">
            <div className="flex items-center justify-center">
              {/* Budget Tag Only */}
              <div className="flex items-center space-x-1 bg-white/20 backdrop-blur-md rounded-full px-2 py-1 border border-white/30">
                <DollarSign size={10} className="text-white" />
                <span className="text-white text-xs font-medium">{formatCost(estimatedCost)}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-surface-warm to-surface-cool">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-white/90 backdrop-blur-xl border-b border-gray-100 safe-area-inset-top">
        <div className="page-container">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Explore</h1>
              <p className="text-sm text-gray-600">Discover amazing travel experiences</p>
            </div>
            <button className="p-2 hover:bg-gray-100 rounded-xl transition-colors">
              <Filter size={20} className="text-gray-700" />
            </button>
          </div>

          {/* Search Bar */}
          <div className="relative mb-4">
            <input
              type="text"
              placeholder="Search destinations, creators, trip types..."
              className="w-full bg-gray-100 border-0 rounded-2xl pl-4 pr-4 py-3 text-gray-900 placeholder-gray-500 focus:ring-2 focus:ring-brand-primary focus:bg-white transition-all duration-200"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>

          {/* Filters */}
          <div className="bg-white/80 backdrop-blur-sm rounded-2xl p-4 border border-gray-100 mb-4">
            <h3 className="font-semibold text-gray-900 mb-3">Filters</h3>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Budget</label>
                <select
                  className="w-full p-2 border border-gray-300 rounded-xl bg-white text-gray-900 focus:ring-2 focus:ring-brand-primary focus:border-transparent"
                  value={filters.budget}
                  onChange={(e) => setFilters({ ...filters, budget: e.target.value })}
                >
                  <option value="">All</option>
                  <option value="Budget">Budget</option>
                  <option value="Mid-range">Mid-range</option>
                  <option value="Luxury">Luxury</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Trip Type</label>
                <select
                  className="w-full p-2 border border-gray-300 rounded-xl bg-white text-gray-900 focus:ring-2 focus:ring-brand-primary focus:border-transparent"
                  value={filters.tripType}
                  onChange={(e) => setFilters({ ...filters, tripType: e.target.value })}
                >
                  <option value="">All</option>
                  <option value="Romantic">Romantic</option>
                  <option value="Adventure">Adventure</option>
                  <option value="Cultural">Cultural</option>
                  <option value="Food">Food</option>
                  <option value="Wellness">Wellness</option>
                  <option value="City Break">City Break</option>
                  <option value="Party">Party</option>
                  <option value="Thematic">Thematic</option>
                </select>
              </div>
            </div>
          </div>

          {/* Trending Tags */}
          <div className="mb-4">
            <h3 className="font-semibold text-gray-900 mb-3">Trending Tags</h3>
            <div className="flex flex-wrap gap-2">
              {trendingTags.map(tag => (
                <button
                  key={tag}
                  onClick={() => setSearchTerm(tag)}
                  className="bg-gradient-to-r from-brand-primary/10 to-brand-secondary/10 text-brand-primary border border-brand-primary/20 text-sm px-3 py-2 rounded-full hover:bg-gradient-brand hover:text-white transition-all duration-200 hover:scale-105 active:scale-95"
                >
                  #{tag}
                </button>
              ))}
            </div>
          </div>
        </div>
      </header>

      {/* Search Results */}
      <main className="page-container">
        <div className="flex items-center justify-between mb-6">
          <h2 className="font-bold text-gray-900">Search Results</h2>
          <span className="text-sm text-gray-600">{filteredCards.length} results</span>
        </div>

        {filteredCards.length > 0 ? (
          <div className="grid grid-cols-2 gap-3">
            {filteredCards.map(card => (
              <CompactTravelCard key={card.id} card={card} />
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <MapPin size={24} className="text-gray-400" />
            </div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">No results found</h3>
            <p className="text-gray-600 max-w-sm mx-auto">
              Try adjusting your search terms or filters to discover amazing travel experiences.
            </p>
          </div>
        )}
      </main>
    </div>
  );
}