import { useState } from 'react';
import { ArrowLeft, Heart, Edit3, Check, MapPin, Plus, ExternalLink, Zap, Star } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { CategoryTag } from './CategoryTag';
import { TravelCard } from './TravelCard';
import { BucketListItem, TravelCardDraft, Experience, LocalGem } from '../types';

interface BucketListPageProps {
  bucketListItems: BucketListItem[];
  travelCardDrafts: TravelCardDraft[];
  onBack: () => void;
  onRemoveFromBucketList: (itemId: string) => void;
  onAddToNewTravelCard: (items: (Experience | LocalGem)[]) => void;
  onAddToItinerary: (itemId: string) => void;
  onSelectTravelCardDraft: (draftId: string) => void;
  onAddToDraft?: (itemId: string) => void;
}

export function BucketListPage({ 
  bucketListItems, 
  travelCardDrafts, 
  onBack, 
  onRemoveFromBucketList, 
  onAddToNewTravelCard, 
  onAddToItinerary,
  onSelectTravelCardDraft,
  onAddToDraft 
}: BucketListPageProps) {
  const [activeTab, setActiveTab] = useState<'experiences' | 'drafts'>('experiences');
  const [selectedItems, setSelectedItems] = useState<string[]>([]);
  const [isSelecting, setIsSelecting] = useState(false);
  const [savedExperiences] = useState<Set<string>>(new Set());

  const savedExperienceItems = bucketListItems.filter(item => item.type === 'experience' || item.type === 'localGem');

  const toggleSelection = (itemId: string) => {
    setSelectedItems(prev => 
      prev.includes(itemId) 
        ? prev.filter(id => id !== itemId)
        : [...prev, itemId]
    );
  };

  const enterSelectMode = () => {
    setIsSelecting(true);
    setSelectedItems([]);
  };

  const exitSelectMode = () => {
    setIsSelecting(false);
    setSelectedItems([]);
  };

  const handleAddToNewTravelCard = () => {
    const selectedData = selectedItems
      .map(id => bucketListItems.find(item => item.id === id)?.data)
      .filter(Boolean) as (Experience | LocalGem)[];
    
    onAddToNewTravelCard(selectedData);
    exitSelectMode();
  };

  const handleAddToExistingDraft = () => {
    // This could open the AddToExistingDraftModal
    console.log('Add to existing draft:', selectedItems);
  };

  const handleSaveExperience = (itemId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    onAddToItinerary(itemId);
  };

  const handleBookNow = (experience: Experience | LocalGem, e: React.MouseEvent) => {
    e.stopPropagation();
    const affiliateLink = (experience as any).affiliateLink;
    if (affiliateLink) {
      window.open(affiliateLink, '_blank');
    }
  };

  const renderTabSelector = () => (
    <div className="flex bg-moodboard-gray-light/10 rounded-xl p-1 mb-6">
      <button
        onClick={() => setActiveTab('experiences')}
        className={`flex-1 py-3 px-4 rounded-lg text-sm font-medium transition-all duration-200 ${
          activeTab === 'experiences'
            ? 'bg-white text-moodboard-deep-green shadow-sm'
            : 'text-moodboard-gray-dark hover:text-moodboard-muted-teal'
        }`}
      >
        Saved Experiences
        {savedExperienceItems.length > 0 && (
          <span className="ml-2 px-2 py-0.5 bg-moodboard-muted-teal text-white text-xs rounded-full">
            {savedExperienceItems.length}
          </span>
        )}
      </button>
      <button
        onClick={() => setActiveTab('drafts')}
        className={`flex-1 py-3 px-4 rounded-lg text-sm font-medium transition-all duration-200 ${
          activeTab === 'drafts'
            ? 'bg-white text-moodboard-deep-green shadow-sm'
            : 'text-moodboard-gray-dark hover:text-moodboard-muted-teal'
        }`}
      >
        Travel Card Drafts
        {travelCardDrafts.length > 0 && (
          <span className="ml-2 px-2 py-0.5 bg-moodboard-warm-beige text-moodboard-deep-green text-xs rounded-full">
            {travelCardDrafts.length}
          </span>
        )}
      </button>
    </div>
  );

  const renderActionBar = () => {
    if (!isSelecting || selectedItems.length === 0) return null;

    return (
      <div className="fixed bottom-20 left-4 right-4 z-40">
        <div className="bg-white rounded-xl shadow-brand border border-moodboard-gray-light/20 p-4">
          <div className="flex items-center justify-between mb-3">
            <span className="text-sm font-medium text-moodboard-deep-green">
              {selectedItems.length} item{selectedItems.length > 1 ? 's' : ''} selected
            </span>
            <button
              onClick={exitSelectMode}
              className="text-moodboard-gray-dark hover:text-moodboard-deep-green transition-colors"
            >
              Cancel
            </button>
          </div>
          
          <div className="flex space-x-3">
            <button
              onClick={handleAddToExistingDraft}
              disabled={travelCardDrafts.length === 0}
              className="flex-1 py-3 bg-moodboard-warm-beige text-moodboard-deep-green rounded-xl font-medium hover:bg-moodboard-warm-beige-dark transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center space-x-2"
            >
              <Edit3 size={18} />
              <span>Add to Draft</span>
            </button>
            <button
              onClick={handleAddToNewTravelCard}
              className="flex-1 py-3 bg-moodboard-muted-teal text-white rounded-xl font-medium hover:bg-moodboard-muted-teal/90 transition-colors flex items-center justify-center space-x-2"
            >
              <Edit3 size={18} />
              <span>New Travel Card</span>
            </button>
          </div>
        </div>
      </div>
    );
  };

  const renderExperienceCard = (item: BucketListItem) => {
    const isSelected = selectedItems.includes(item.id);
    const data = item.data as Experience | LocalGem;
    
    // Get the image URL based on item type
    const imageUrl = item.type === 'experience' 
      ? (data as Experience).images?.[0] || (data as any).media?.[0] 
      : (data as LocalGem).image;

    // Get pricing information
    const pricing = (data as any).pricing || (data as any).cost 
      ? `₹${(data as any).cost || 0}` 
      : 'Free';

    // Check if bookable
    const hasBookingLink = !!(data as any).affiliateLink;

    return (
      <div 
        key={item.id} 
        className={`relative h-40 overflow-hidden rounded-xl hover:scale-[1.01] transition-all duration-300 cursor-pointer group shadow-md hover:shadow-lg ${
          isSelected ? 'ring-2 ring-moodboard-muted-teal ring-offset-2' : ''
        }`}
        onClick={() => {
          if (isSelecting) {
            toggleSelection(item.id);
          } else {
            console.log('View experience detail:', item.id);
          }
        }}
        style={{
          backgroundImage: imageUrl 
            ? `url(${imageUrl})` 
            : 'linear-gradient(135deg, #4A9B8E 0%, #6BBAB0 100%)',
          backgroundSize: 'cover',
          backgroundPosition: 'center'
        }}
      >
        {/* Lighter Gradient Overlay for Better Readability */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/35 via-black/10 to-transparent"></div>
        
        {/* Content Overlay */}
        <div className="absolute inset-0 flex flex-col items-center justify-center text-center p-4">
          {/* Top Action Buttons */}
          <div className="absolute top-3 right-3 flex items-center space-x-2">
            {/* Selection Checkbox */}
            {isSelecting && (
              <div
                onClick={(e) => {
                  e.stopPropagation();
                  toggleSelection(item.id);
                }}
                className={`w-6 h-6 rounded-full border-2 flex items-center justify-center transition-all duration-200 cursor-pointer backdrop-blur-sm ${
                  isSelected
                    ? 'bg-moodboard-muted-teal border-moodboard-muted-teal'
                    : 'bg-white/20 border-white hover:bg-white/30'
                }`}
              >
                {isSelected && <Check size={14} className="text-white" />}
              </div>
            )}

            {/* Remove Heart Button */}
            {!isSelecting && (
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onRemoveFromBucketList(item.id);
                }}
                className="p-2 rounded-lg backdrop-blur-sm bg-white/20 text-red-400 hover:bg-white/30 transition-colors"
              >
                <Heart size={16} className="fill-current" />
              </button>
            )}
          </div>

          {/* Add to Draft Button - Right Side */}
          {!isSelecting && (
            <button
              onClick={(e) => {
                e.stopPropagation();
                onAddToDraft?.(item.id);
              }}
              className="absolute right-3 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full backdrop-blur-sm bg-moodboard-muted-teal/90 text-white hover:bg-moodboard-muted-teal transition-all duration-200 flex items-center justify-center border border-moodboard-muted-teal shadow-lg hover:scale-110"
            >
              <Plus size={18} />
            </button>
          )}

          {/* Main Content */}
          <div className="flex-1 flex flex-col items-center justify-center">
            {/* Category */}
            <div className="mb-2">
              <CategoryTag category={data.category || 'activity'} />
            </div>
            
            {/* Title */}
            <h4 className="font-semibold text-white text-center mb-2 line-clamp-2 group-hover:text-moodboard-warm-beige transition-colors">
              {data.title || 'Untitled Experience'}
            </h4>
            
            {/* Location and Cost */}
            <div className="flex items-center justify-center gap-4 text-white/90 mb-3">
              <div className="flex items-center gap-1">
                <MapPin size={12} />
                <span className="text-xs">{data.location || 'Location not specified'}</span>
              </div>
              <span className="font-semibold text-moodboard-warm-beige">
                {pricing}
              </span>
            </div>

            {/* Origin Attribution */}
            <div className="mb-3">
              <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-lg px-3 py-1">
                <p className="text-xs text-white/90">
                  {item.type === 'experience' 
                    ? `Saved from @wanderlust_exp's Travel Card`
                    : `Local Gem from @${(data as LocalGem).userName || 'explorer'}`
                  }
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  };

  const renderExperiencesTab = () => {
    if (savedExperienceItems.length === 0) {
      return (
        <div className="text-center py-12">
          <div className="w-24 h-24 bg-moodboard-gray-light/20 rounded-full flex items-center justify-center mx-auto mb-6">
            <Heart size={32} className="text-moodboard-gray-light" />
          </div>
          <h3 className="text-lg font-semibold text-moodboard-deep-green mb-2">
            No saved adventures yet
          </h3>
          <p className="text-moodboard-gray-dark mb-6 max-w-sm mx-auto">
            Start exploring and saving experiences to plan your next trip!
          </p>
          <button
            onClick={onBack}
            className="px-6 py-3 bg-moodboard-muted-teal text-white rounded-xl font-medium hover:bg-moodboard-muted-teal/90 transition-colors"
          >
            Explore Travel Cards
          </button>
        </div>
      );
    }

    return (
      <div className="space-y-6">
        {/* Header with Select Button */}
        <div className="flex items-center justify-between">
          <h3 className="font-semibold text-moodboard-deep-green">
            {savedExperienceItems.length} Saved Experience{savedExperienceItems.length > 1 ? 's' : ''}
          </h3>
          {!isSelecting && savedExperienceItems.length > 0 && (
            <button
              onClick={enterSelectMode}
              className="px-4 py-2 bg-moodboard-gray-light/20 text-moodboard-muted-teal rounded-lg font-medium hover:bg-moodboard-gray-light/30 transition-colors"
            >
              Select
            </button>
          )}
        </div>

        {/* Experience Cards List */}
        <div className="space-y-4">
          {savedExperienceItems.map(renderExperienceCard)}
        </div>
      </div>
    );
  };

  const renderDraftCard = (draft: TravelCardDraft) => {
    // Convert draft to TravelCard format
    const travelCardData = {
      id: draft.id,
      title: draft.title,
      destination: draft.destination,
      thumbnail: draft.coverImage,
      images: [draft.coverImage],
      description: draft.description || `A ${draft.duration} journey through ${draft.destination}`,
      rating: 4.5,
      likes: 0,
      comments: 0,
      views: 0,
      cost: draft.estimatedCost,
      dates: draft.duration,
      tripType: 'Adventure',
      creatorId: 'current-user',
      experiences: draft.experiences || [],
      isLive: false,
      isDraft: true
    };

    return (
      <div key={draft.id} className="relative">
        {/* Draft Progress Overlay */}
        <div className="absolute top-4 right-4 z-30">
          <div className="bg-white/95 backdrop-blur-sm border border-moodboard-gray-light/30 rounded-lg px-3 py-2">
            <div className="flex items-center space-x-2">
              <span className="text-xs font-medium text-moodboard-deep-green">
                {draft.completionPercentage}% Complete
              </span>
              <div className="w-12 bg-moodboard-gray-light/20 rounded-full h-1">
                <div 
                  className="bg-moodboard-muted-teal h-1 rounded-full transition-all duration-300"
                  style={{ width: `${draft.completionPercentage}%` }}
                />
              </div>
            </div>
          </div>
        </div>

        {/* Original Travel Card */}
        <TravelCard
          {...travelCardData}
          onSelect={() => onSelectTravelCardDraft(draft.id)}
          onSelectUser={() => {}}
          onLike={() => {}}
          onSave={() => {}}
        />

        {/* Last Updated Info */}
        <div className="absolute bottom-4 left-4 right-4 z-20">
          <div className="bg-white/95 backdrop-blur-sm border border-moodboard-gray-light/30 rounded-lg px-3 py-2">
            <p className="text-xs text-moodboard-gray-dark">
              Last updated {new Date(draft.lastUpdated).toLocaleDateString()} • {draft.experienceCount} experiences
            </p>
          </div>
        </div>
      </div>
    );
  };

  const renderDraftsTab = () => {
    if (travelCardDrafts.length === 0) {
      return (
        <div className="text-center py-12">
          <div className="w-24 h-24 bg-moodboard-gray-light/20 rounded-full flex items-center justify-center mx-auto mb-6">
            <Edit3 size={32} className="text-moodboard-gray-light" />
          </div>
          <h3 className="text-lg font-semibold text-moodboard-deep-green mb-2">
            No travel card drafts yet
          </h3>
          <p className="text-moodboard-gray-dark mb-6 max-w-sm mx-auto">
            Start creating a travel card to save your experiences and share your journey!
          </p>
          <button
            onClick={() => onAddToNewTravelCard([])}
            className="px-6 py-3 bg-moodboard-muted-teal text-white rounded-xl font-medium hover:bg-moodboard-muted-teal/90 transition-colors"
          >
            Create Travel Card
          </button>
        </div>
      );
    }

    return (
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <h3 className="font-semibold text-moodboard-deep-green">
            {travelCardDrafts.length} Draft{travelCardDrafts.length > 1 ? 's' : ''}
          </h3>
        </div>

        {/* Draft Cards */}
        <div className="space-y-6">
          {travelCardDrafts.map(renderDraftCard)}
        </div>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-surface-warm">
      {/* Header */}
      <div className="sticky top-0 z-50 bg-surface-warm/95 backdrop-blur-sm border-b border-moodboard-gray-light/20">
        <div className="flex items-center justify-between p-4">
          <button
            onClick={onBack}
            className="p-2 hover:bg-moodboard-gray-light/20 rounded-xl transition-colors"
          >
            <ArrowLeft size={24} className="text-moodboard-deep-green" />
          </button>
          
          <h1 className="font-semibold text-moodboard-deep-green">My Bucket List</h1>
          
          <div className="w-10" /> {/* Spacer */}
        </div>
      </div>

      {/* Content */}
      <div className="page-container pb-8">
        {renderTabSelector()}
        
        {activeTab === 'experiences' ? renderExperiencesTab() : renderDraftsTab()}
      </div>

      {/* Action Bar */}
      {renderActionBar()}
    </div>
  );
}