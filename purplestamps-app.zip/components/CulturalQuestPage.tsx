import { useState, useEffect } from 'react';
import { ArrowLeft, Trophy, Star, Globe, Brain, Zap, Target, Crown, Award, Sparkles, TrendingUp, Calendar, User } from 'lucide-react';
import { BackIcon, AchievementIcon, QuestIcon, MagicIcon } from './ui/unified-icons';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface CulturalQuestPageProps {
  onBack: () => void;
  onNavigateToTrivia: () => void;
}

// Enhanced quest data with visual elements
const questCategories = [
  {
    id: 'geography',
    name: 'Geography Master',
    icon: Globe,
    color: 'from-blue-500 to-indigo-600',
    description: 'Explore the world through maps and landmarks',
    completed: 15,
    total: 25,
    badge: '🌍'
  },
  {
    id: 'culture',
    name: 'Culture Explorer',
    icon: Brain,
    color: 'from-purple-500 to-pink-600',
    description: 'Discover traditions and customs worldwide',
    completed: 23,
    total: 30,
    badge: '🎭'
  },
  {
    id: 'history',
    name: 'Time Traveler',
    icon: Crown,
    color: 'from-yellow-500 to-orange-600',
    description: 'Journey through historical events and places',
    completed: 8,
    total: 20,
    badge: '👑'
  },
  {
    id: 'food',
    name: 'Culinary Adventurer',
    icon: Sparkles,
    color: 'from-green-500 to-emerald-600',
    description: 'Taste your way around the globe',
    completed: 12,
    total: 18,
    badge: '🍜'
  }
];

const achievements = [
  {
    id: 'beginner',
    name: 'Quest Beginner',
    description: 'Completed your first cultural quest',
    icon: Target,
    earned: true,
    earnedDate: '2024-11-15',
    badge: '🎯'
  },
  {
    id: 'streak-7',
    name: '7-Day Streak',
    description: 'Completed quests for 7 days in a row',
    icon: Zap,
    earned: true,
    earnedDate: '2024-11-20',
    badge: '⚡'
  },
  {
    id: 'perfect-score',
    name: 'Perfect Score',
    description: 'Got 100% on 5 different quests',
    icon: Star,
    earned: false,
    progress: 3,
    total: 5,
    badge: '⭐'
  },
  {
    id: 'explorer',
    name: 'World Explorer',
    description: 'Completed quests from 10 different countries',
    icon: Globe,
    earned: false,
    progress: 7,
    total: 10,
    badge: '🌏'
  }
];

const recentQuests = [
  {
    id: 'quest-1',
    title: 'Japanese Tea Ceremony Traditions',
    category: 'Culture',
    score: 95,
    date: '2024-11-25',
    image: 'https://images.unsplash.com/photo-1545056453-f0b44ac89ea2?w=100&h=100&fit=crop'
  },
  {
    id: 'quest-2',
    title: 'Ancient Egyptian Pyramids',
    category: 'History',
    score: 87,
    date: '2024-11-24',
    image: 'https://images.unsplash.com/photo-1539650116574-75c0c6d73901?w=100&h=100&fit=crop'
  },
  {
    id: 'quest-3',
    title: 'Scandinavian Geography',
    category: 'Geography',
    score: 92,
    date: '2024-11-23',
    image: 'https://images.unsplash.com/photo-1469474968028-56623f02e42e?w=100&h=100&fit=crop'
  }
];

export function CulturalQuestPage({ onBack, onNavigateToTrivia }: CulturalQuestPageProps) {
  const [activeTab, setActiveTab] = useState<'overview' | 'achievements' | 'history'>('overview');
  const [totalScore, setTotalScore] = useState(1247);
  const [currentRank, setCurrentRank] = useState('Cultural Explorer');
  const [nextRankProgress, setNextRankProgress] = useState(73);

  const overallProgress = Math.round(
    (questCategories.reduce((acc, cat) => acc + cat.completed, 0) / 
     questCategories.reduce((acc, cat) => acc + cat.total, 0)) * 100
  );

  const earnedAchievements = achievements.filter(a => a.earned);

  return (
    <div className="min-h-screen bg-gradient-to-br from-surface-warm to-surface-cool">
      {/* Header */}
      <div className="sticky top-0 z-50 bg-white/95 backdrop-blur-xl border-b border-gray-100">
        <div className="flex items-center justify-between p-4">
          <div className="flex items-center space-x-3">
            <button 
              onClick={onBack}
              className="flex items-center space-x-2 text-brand-primary hover:text-brand-primary-dark transition-colors"
            >
              <BackIcon size="md" />
            </button>
            <div>
              <h1 className="text-lg font-bold text-gray-900">Cultural Quest 🌍</h1>
              <p className="text-xs text-gray-500">Level up your world knowledge!</p>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <div className="bg-gradient-brand text-white px-3 py-1 rounded-full">
              <span className="text-xs font-bold">{totalScore} pts</span>
            </div>
          </div>
        </div>
      </div>

      {/* Hero Stats */}
      <div className="p-4">
        <div className="bg-gradient-brand text-white rounded-2xl p-6 relative overflow-hidden">
          {/* Background Pattern */}
          <div className="absolute inset-0 opacity-10">
            <div className="absolute top-4 right-4 w-16 h-16 border border-white rounded-full"></div>
            <div className="absolute bottom-4 left-4 w-12 h-12 border border-white rounded-full"></div>
            <div className="absolute top-1/2 left-1/2 w-8 h-8 border border-white rounded-full"></div>
          </div>

          <div className="relative">
            <div className="flex items-center space-x-3 mb-4">
              <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center">
                <Trophy size={24} className="text-white" />
              </div>
              <div>
                <h2 className="text-xl font-bold">{currentRank} 🏆</h2>
                <p className="text-sm opacity-90">Globetrotter Level {Math.floor(totalScore / 200) + 1}</p>
              </div>
            </div>

            <div className="mb-4">
              <div className="flex items-center justify-between text-sm mb-1">
                <span>Progress to Culture Master</span>
                <span>{nextRankProgress}%</span>
              </div>
              <div className="w-full bg-white/20 rounded-full h-2">
                <div 
                  className="bg-white h-2 rounded-full transition-all duration-500"
                  style={{ width: `${nextRankProgress}%` }}
                ></div>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-4">
              <div className="text-center">
                <div className="text-2xl font-bold">{earnedAchievements.length}</div>
                <div className="text-xs opacity-90">Badges Earned</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold">{overallProgress}%</div>
                <div className="text-xs opacity-90">Overall Progress</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold">7</div>
                <div className="text-xs opacity-90">Day Streak</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="px-4 mb-6">
        <div className="bg-white rounded-xl p-1 shadow-sm border border-gray-100">
          <div className="grid grid-cols-3 gap-1">
            {[
              { id: 'overview', label: 'Overview', icon: Globe },
              { id: 'achievements', label: 'Badges', icon: Award },
              { id: 'history', label: 'History', icon: Calendar }
            ].map((tab) => {
              const IconComponent = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`flex items-center justify-center space-x-2 py-2.5 px-3 rounded-lg text-sm font-medium transition-all ${
                    activeTab === tab.id
                      ? 'bg-gradient-brand text-white shadow-brand'
                      : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50'
                  }`}
                >
                  <IconComponent size={16} />
                  <span className="hidden sm:inline">{tab.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Content Based on Active Tab */}
      <div className="px-4 pb-24">
        {activeTab === 'overview' && (
          <div className="space-y-6">
            {/* Quest Categories */}
            <div>
              <h3 className="font-bold text-gray-900 mb-4">Quest Categories 🎯</h3>
              <div className="space-y-3">
                {questCategories.map((category) => {
                  const IconComponent = category.icon;
                  const progress = (category.completed / category.total) * 100;
                  
                  return (
                    <div key={category.id} className="card-standard hover:scale-[1.02] transition-all duration-300 cursor-pointer">
                      <div className="flex items-center space-x-4">
                        <div className={`w-12 h-12 bg-gradient-to-br ${category.color} rounded-xl flex items-center justify-center shadow-lg`}>
                          <IconComponent size={20} className="text-white" />
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center space-x-2 mb-1">
                            <h4 className="font-semibold text-gray-900">{category.name}</h4>
                            <span className="text-lg">{category.badge}</span>
                          </div>
                          <p className="text-xs text-gray-600 mb-2">{category.description}</p>
                          <div className="flex items-center justify-between">
                            <div className="flex-1 mr-3">
                              <div className="w-full bg-gray-200 rounded-full h-1.5">
                                <div 
                                  className={`bg-gradient-to-r ${category.color} h-1.5 rounded-full transition-all duration-500`}
                                  style={{ width: `${progress}%` }}
                                ></div>
                              </div>
                            </div>
                            <span className="text-xs font-medium text-gray-700">
                              {category.completed}/{category.total}
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Quick Actions */}
            <div>
              <h3 className="font-bold text-gray-900 mb-4">Ready to Learn? ✨</h3>
              <div className="grid grid-cols-2 gap-3">
                <button
                  onClick={onNavigateToTrivia}
                  className="bg-gradient-brand text-white p-4 rounded-xl hover:shadow-brand hover:scale-[1.02] transition-all duration-200 active:scale-95"
                >
                  <div className="flex items-center space-x-2 mb-2">
                    <Brain size={20} />
                    <span className="font-semibold">Start Quest</span>
                  </div>
                  <p className="text-xs opacity-90">Jump into a new cultural challenge!</p>
                </button>
                <button className="bg-gradient-brand-secondary text-white p-4 rounded-xl hover:shadow-brand-secondary hover:scale-[1.02] transition-all duration-200 active:scale-95">
                  <div className="flex items-center space-x-2 mb-2">
                    <Zap size={20} />
                    <span className="font-semibold">Daily Quest</span>
                  </div>
                  <p className="text-xs opacity-90">Complete today's special challenge!</p>
                </button>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'achievements' && (
          <div className="space-y-4">
            <h3 className="font-bold text-gray-900 mb-4">Your Achievements 🏆</h3>
            {achievements.map((achievement) => {
              const IconComponent = achievement.icon;
              return (
                <div key={achievement.id} className={`card-standard ${achievement.earned ? 'bg-gradient-to-r from-brand-primary/5 to-brand-secondary/5 border-brand-primary/20' : 'opacity-75'}`}>
                  <div className="flex items-center space-x-4">
                    <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                      achievement.earned 
                        ? 'bg-gradient-brand text-white shadow-brand' 
                        : 'bg-gray-200 text-gray-500'
                    }`}>
                      <IconComponent size={20} />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center space-x-2 mb-1">
                        <h4 className="font-semibold text-gray-900">{achievement.name}</h4>
                        <span className="text-lg">{achievement.badge}</span>
                        {achievement.earned && <Sparkles size={14} className="text-brand-accent" />}
                      </div>
                      <p className="text-xs text-gray-600 mb-2">{achievement.description}</p>
                      {achievement.earned ? (
                        <p className="text-xs text-brand-primary font-medium">
                          Earned on {new Date(achievement.earnedDate!).toLocaleDateString()}
                        </p>
                      ) : (
                        <div className="flex items-center space-x-2">
                          <div className="flex-1 bg-gray-200 rounded-full h-1.5">
                            <div 
                              className="bg-gradient-brand h-1.5 rounded-full transition-all duration-500"
                              style={{ width: `${((achievement.progress || 0) / (achievement.total || 1)) * 100}%` }}
                            ></div>
                          </div>
                          <span className="text-xs font-medium text-gray-600">
                            {achievement.progress || 0}/{achievement.total || 1}
                          </span>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {activeTab === 'history' && (
          <div className="space-y-4">
            <h3 className="font-bold text-gray-900 mb-4">Recent Quests 📚</h3>
            {recentQuests.map((quest) => (
              <div key={quest.id} className="card-standard hover:scale-[1.02] transition-all duration-300 cursor-pointer">
                <div className="flex items-center space-x-4">
                  <div className="w-16 h-16 rounded-xl overflow-hidden">
                    <ImageWithFallback 
                      src={quest.image} 
                      alt={quest.title}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="flex-1">
                    <h4 className="font-semibold text-gray-900 mb-1">{quest.title}</h4>
                    <div className="flex items-center space-x-2 mb-2">
                      <span className="text-xs bg-brand-primary/10 text-brand-primary px-2 py-1 rounded-full font-medium">
                        {quest.category}
                      </span>
                      <span className="text-xs text-gray-500">
                        {new Date(quest.date).toLocaleDateString()}
                      </span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <div className="flex items-center space-x-1">
                        <Star size={12} className="text-yellow-500 fill-current" />
                        <span className="text-sm font-semibold text-gray-700">{quest.score}%</span>
                      </div>
                      {quest.score >= 90 && (
                        <div className="flex items-center space-x-1">
                          <Trophy size={12} className="text-brand-accent" />
                          <span className="text-xs text-brand-accent font-medium">Perfect!</span>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}