import { useState } from 'react';
import { X, Camera, Image, MapPin, Tag, Type, Check } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface AddStoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  onPublish: (storyData: any) => void;
}

export function AddStoryModal({ isOpen, onClose, onPublish }: AddStoryModalProps) {
  const [selectedMedia, setSelectedMedia] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [caption, setCaption] = useState('');
  const [location, setLocation] = useState('');
  const [linkedTravelCard, setLinkedTravelCard] = useState('');
  const [isUploading, setIsUploading] = useState(false);

  if (!isOpen) return null;

  const handleMediaSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setSelectedMedia(file);
      const url = URL.createObjectURL(file);
      setPreviewUrl(url);
    }
  };

  const handlePublish = async () => {
    if (!selectedMedia || !previewUrl) return;
    
    setIsUploading(true);
    
    // Simulate upload delay
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    const storyData = {
      id: `story_${Date.now()}`,
      media: previewUrl,
      type: selectedMedia.type.startsWith('video') ? 'video' : 'image',
      caption: caption.trim(),
      location: location.trim(),
      linkedTravelCard: linkedTravelCard.trim(),
      timestamp: new Date().toISOString(),
    };

    onPublish(storyData);
    
    // Reset form
    setSelectedMedia(null);
    setPreviewUrl(null);
    setCaption('');
    setLocation('');
    setLinkedTravelCard('');
    setIsUploading(false);
  };

  const handleClose = () => {
    if (previewUrl) {
      URL.revokeObjectURL(previewUrl);
    }
    setSelectedMedia(null);
    setPreviewUrl(null);
    setCaption('');
    setLocation('');
    setLinkedTravelCard('');
    setIsUploading(false);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl w-full max-w-md max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-gray-100">
          <h2 className="font-semibold text-gray-900">Add to Story</h2>
          <button 
            onClick={handleClose}
            className="p-2 hover:bg-gray-100 rounded-full transition-colors"
          >
            <X size={20} className="text-gray-500" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto">
          {!selectedMedia ? (
            /* Media Selection */
            <div className="p-6">
              <div className="space-y-4">
                {/* Camera Option */}
                <label className="flex items-center justify-center w-full h-32 border-2 border-dashed border-gray-300 rounded-xl hover:border-brand-primary hover:bg-brand-primary/5 cursor-pointer transition-all duration-200">
                  <input
                    type="file"
                    accept="image/*,video/*"
                    capture="environment"
                    onChange={handleMediaSelect}
                    className="hidden"
                  />
                  <div className="text-center">
                    <Camera size={32} className="text-gray-400 mx-auto mb-2" />
                    <p className="text-sm font-medium text-gray-600">Take Photo/Video</p>
                  </div>
                </label>

                {/* Gallery Option */}
                <label className="flex items-center justify-center w-full h-32 border-2 border-dashed border-gray-300 rounded-xl hover:border-brand-primary hover:bg-brand-primary/5 cursor-pointer transition-all duration-200">
                  <input
                    type="file"
                    accept="image/*,video/*"
                    onChange={handleMediaSelect}
                    className="hidden"
                  />
                  <div className="text-center">
                    <Image size={32} className="text-gray-400 mx-auto mb-2" />
                    <p className="text-sm font-medium text-gray-600">Choose from Gallery</p>
                  </div>
                </label>
              </div>

              <div className="mt-6 text-center">
                <p className="text-xs text-gray-500">
                  Your story will be visible for 24 hours and can be linked to your travel experiences.
                </p>
              </div>
            </div>
          ) : (
            /* Story Editor */
            <div className="space-y-4">
              {/* Media Preview */}
              <div className="relative bg-black aspect-[9/16] flex items-center justify-center">
                {selectedMedia.type.startsWith('video') ? (
                  <video
                    src={previewUrl}
                    className="max-w-full max-h-full object-contain"
                    controls
                    muted
                  />
                ) : (
                  <ImageWithFallback
                    src={previewUrl}
                    alt="Story preview"
                    className="max-w-full max-h-full object-contain"
                  />
                )}
                
                {/* Remove Media Button */}
                <button
                  onClick={() => {
                    if (previewUrl) URL.revokeObjectURL(previewUrl);
                    setSelectedMedia(null);
                    setPreviewUrl(null);
                  }}
                  className="absolute top-4 right-4 p-2 bg-black/50 text-white rounded-full hover:bg-black/70 transition-colors"
                >
                  <X size={16} />
                </button>
              </div>

              {/* Story Details */}
              <div className="p-4 space-y-4">
                {/* Caption */}
                <div>
                  <label className="flex items-center gap-2 text-sm font-medium text-gray-700 mb-2">
                    <Type size={16} />
                    Caption (optional)
                  </label>
                  <textarea
                    value={caption}
                    onChange={(e) => setCaption(e.target.value)}
                    placeholder="What's happening?"
                    className="w-full p-3 border border-gray-200 rounded-xl resize-none focus:outline-none focus:ring-2 focus:ring-brand-primary focus:border-transparent transition-all duration-200"
                    rows={3}
                    maxLength={200}
                  />
                  <div className="text-right mt-1">
                    <span className="text-xs text-gray-400">{caption.length}/200</span>
                  </div>
                </div>

                {/* Location */}
                <div>
                  <label className="flex items-center gap-2 text-sm font-medium text-gray-700 mb-2">
                    <MapPin size={16} />
                    Location (optional)
                  </label>
                  <input
                    type="text"
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                    placeholder="Add location..."
                    className="w-full p-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-brand-primary focus:border-transparent transition-all duration-200"
                  />
                </div>

                {/* Link to Travel Card */}
                <div>
                  <label className="flex items-center gap-2 text-sm font-medium text-gray-700 mb-2">
                    <Tag size={16} />
                    Link to Travel Card (optional)
                  </label>
                  <input
                    type="text"
                    value={linkedTravelCard}
                    onChange={(e) => setLinkedTravelCard(e.target.value)}
                    placeholder="Search your travel cards..."
                    className="w-full p-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-brand-primary focus:border-transparent transition-all duration-200"
                  />
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        {selectedMedia && (
          <div className="p-4 border-t border-gray-100">
            <button
              onClick={handlePublish}
              disabled={isUploading}
              className="w-full bg-gradient-brand text-white py-3 px-6 rounded-xl font-medium hover:shadow-brand hover:scale-105 transition-all duration-200 active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:scale-100 disabled:hover:shadow-none flex items-center justify-center gap-2"
            >
              {isUploading ? (
                <>
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                  Publishing...
                </>
              ) : (
                <>
                  <Check size={18} />
                  Share to Story
                </>
              )}
            </button>
          </div>
        )}
      </div>
    </div>
  );
}