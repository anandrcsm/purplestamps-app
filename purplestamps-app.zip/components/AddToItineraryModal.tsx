import { useState, useEffect } from 'react';
import { 
  X, 
  Plus, 
  Calendar, 
  MapPin, 
  Image as ImageIcon,
  Check
} from 'lucide-react';
import { BucketListItem, TravelItinerary } from '../types';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface AddToItineraryModalProps {
  isOpen: boolean;
  onClose: () => void;
  bucketListItem: BucketListItem | null;
  existingItineraries: TravelItinerary[];
  onAddToExistingItinerary: (itineraryId: string, itemId: string) => void;
  onCreateNewItinerary: (itinerary: Omit<TravelItinerary, 'id'>, itemId: string) => void;
}

export function AddToItineraryModal({
  isOpen,
  onClose,
  bucketListItem,
  existingItineraries,
  onAddToExistingItinerary,
  onCreateNewItinerary
}: AddToItineraryModalProps) {
  const [activeTab, setActiveTab] = useState<'existing' | 'new'>('existing');
  const [isVisible, setIsVisible] = useState(false);
  const [newItinerary, setNewItinerary] = useState({
    title: '',
    destination: '',
    startDate: '',
    endDate: '',
    coverImage: ''
  });

  useEffect(() => {
    if (isOpen) {
      setIsVisible(true);
      document.body.style.overflow = 'hidden';
    } else {
      setIsVisible(false);
      document.body.style.overflow = 'unset';
    }

    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isOpen]);

  const handleClose = () => {
    setIsVisible(false);
    setTimeout(() => {
      onClose();
      setNewItinerary({ title: '', destination: '', startDate: '', endDate: '', coverImage: '' });
    }, 250);
  };

  const handleAddToExisting = (itineraryId: string) => {
    if (bucketListItem) {
      onAddToExistingItinerary(itineraryId, bucketListItem.id);
      handleClose();
      
      // Show success toast
      const toast = document.createElement('div');
      toast.className = 'fixed top-20 left-1/2 transform -translate-x-1/2 bg-white border border-green-200 text-gray-900 px-4 py-3 rounded-xl z-50 shadow-lg animate-slideDown';
      toast.innerHTML = `
        <div class="flex items-center space-x-3">
          <svg class="w-4 h-4 text-green-500" fill="currentColor" viewBox="0 0 20 20">
            <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"></path>
          </svg>
          <span class="font-medium text-sm">✅ Added to Itinerary</span>
        </div>
      `;
      document.body.appendChild(toast);
      setTimeout(() => document.body.removeChild(toast), 3000);
    }
  };

  const handleCreateNew = () => {
    if (bucketListItem && newItinerary.title && newItinerary.destination) {
      onCreateNewItinerary({
        ...newItinerary,
        experiences: [],
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      }, bucketListItem.id);
      handleClose();
      
      // Show success toast
      const toast = document.createElement('div');
      toast.className = 'fixed top-20 left-1/2 transform -translate-x-1/2 bg-white border border-green-200 text-gray-900 px-4 py-3 rounded-xl z-50 shadow-lg animate-slideDown';
      toast.innerHTML = `
        <div class="flex items-center space-x-3">
          <svg class="w-4 h-4 text-green-500" fill="currentColor" viewBox="0 0 20 20">
            <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"></path>
          </svg>
          <span class="font-medium text-sm">✅ Created "${newItinerary.title}" Itinerary</span>
        </div>
      `;
      document.body.appendChild(toast);
      setTimeout(() => document.body.removeChild(toast), 3000);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50">
      {/* Backdrop */}
      <div 
        className={`absolute inset-0 bg-black/50 transition-opacity duration-300 ${
          isVisible ? 'opacity-100' : 'opacity-0'
        }`}
        onClick={handleClose}
      />
      
      {/* Modal */}
      <div 
        className={`absolute bottom-0 left-0 right-0 bg-white rounded-t-3xl max-h-[90vh] flex flex-col transition-transform duration-300 ${
          isVisible ? 'translate-y-0' : 'translate-y-full'
        }`}
      >
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-100">
          <div>
            <h2 className="text-xl font-semibold text-gray-900">Add to an Itinerary</h2>
            {bucketListItem && (
              <p className="text-sm text-gray-500 mt-1">"{bucketListItem.data.title}"</p>
            )}
          </div>
          <button
            onClick={handleClose}
            className="p-2 hover:bg-gray-100 rounded-full transition-colors"
          >
            <X size={20} className="text-gray-600" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-gray-100">
          <button
            onClick={() => setActiveTab('existing')}
            className={`flex-1 py-4 px-6 text-sm font-medium transition-colors ${
              activeTab === 'existing'
                ? 'text-brand-primary border-b-2 border-brand-primary'
                : 'text-gray-500 hover:text-gray-700'
            }`}
          >
            Existing Itinerary
          </button>
          <button
            onClick={() => setActiveTab('new')}
            className={`flex-1 py-4 px-6 text-sm font-medium transition-colors ${
              activeTab === 'new'
                ? 'text-brand-primary border-b-2 border-brand-primary'
                : 'text-gray-500 hover:text-gray-700'
            }`}
          >
            Create New Itinerary
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6">
          {activeTab === 'existing' ? (
            <div className="space-y-4">
              {existingItineraries.length > 0 ? (
                existingItineraries.map((itinerary) => (
                  <div
                    key={itinerary.id}
                    className="bg-gray-50 rounded-2xl p-4 hover:bg-gray-100 transition-colors cursor-pointer"
                    onClick={() => handleAddToExisting(itinerary.id)}
                  >
                    <div className="flex items-center space-x-4">
                      {/* Cover Image */}
                      <div className="w-16 h-16 rounded-xl overflow-hidden bg-gray-200 flex-shrink-0">
                        {itinerary.coverImage ? (
                          <ImageWithFallback 
                            src={itinerary.coverImage} 
                            alt={itinerary.title}
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <div className="w-full h-full bg-gradient-brand flex items-center justify-center">
                            <MapPin size={24} className="text-white" />
                          </div>
                        )}
                      </div>

                      {/* Itinerary Info */}
                      <div className="flex-1">
                        <h3 className="font-semibold text-gray-900 mb-1">{itinerary.title}</h3>
                        <div className="flex items-center text-sm text-gray-500 mb-1">
                          <MapPin size={14} className="mr-1" />
                          <span>{itinerary.destination}</span>
                        </div>
                        <div className="flex items-center text-sm text-gray-500">
                          <Calendar size={14} className="mr-1" />
                          <span>
                            {new Date(itinerary.startDate).toLocaleDateString()} - {new Date(itinerary.endDate).toLocaleDateString()}
                          </span>
                        </div>
                      </div>

                      {/* Add Button */}
                      <button className="bg-brand-primary text-white px-4 py-2 rounded-xl text-sm font-medium hover:bg-brand-primary-dark transition-colors">
                        Add here
                      </button>
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-center py-12">
                  <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Calendar size={24} className="text-gray-400" />
                  </div>
                  <p className="text-gray-500 mb-4">No itineraries yet</p>
                  <button
                    onClick={() => setActiveTab('new')}
                    className="text-brand-primary font-medium hover:text-brand-primary-dark transition-colors"
                  >
                    Create your first itinerary
                  </button>
                </div>
              )}
            </div>
          ) : (
            <div className="space-y-6">
              {/* Trip Name */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Trip Name *
                </label>
                <input
                  type="text"
                  value={newItinerary.title}
                  onChange={(e) => setNewItinerary(prev => ({ ...prev, title: e.target.value }))}
                  placeholder="e.g., Japan Adventure 2025"
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-brand-primary/20 focus:border-brand-primary"
                />
              </div>

              {/* Destination */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Destination *
                </label>
                <input
                  type="text"
                  value={newItinerary.destination}
                  onChange={(e) => setNewItinerary(prev => ({ ...prev, destination: e.target.value }))}
                  placeholder="e.g., Tokyo, Japan"
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-brand-primary/20 focus:border-brand-primary"
                />
              </div>

              {/* Date Range */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Start Date
                  </label>
                  <input
                    type="date"
                    value={newItinerary.startDate}
                    onChange={(e) => setNewItinerary(prev => ({ ...prev, startDate: e.target.value }))}
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-brand-primary/20 focus:border-brand-primary"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    End Date
                  </label>
                  <input
                    type="date"
                    value={newItinerary.endDate}
                    onChange={(e) => setNewItinerary(prev => ({ ...prev, endDate: e.target.value }))}
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-brand-primary/20 focus:border-brand-primary"
                  />
                </div>
              </div>

              {/* Cover Image */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Cover Image (Optional)
                </label>
                <input
                  type="url"
                  value={newItinerary.coverImage}
                  onChange={(e) => setNewItinerary(prev => ({ ...prev, coverImage: e.target.value }))}
                  placeholder="https://example.com/image.jpg"
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-brand-primary/20 focus:border-brand-primary"
                />
              </div>

              {/* Create Button */}
              <button
                onClick={handleCreateNew}
                disabled={!newItinerary.title || !newItinerary.destination}
                className="w-full bg-brand-primary text-white py-4 rounded-xl font-semibold hover:bg-brand-primary-dark transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
              >
                <Plus size={20} className="mr-2" />
                Create & Add
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}