import { useEffect } from 'react';
import { BrandLogo } from './BrandLogo';

interface SplashScreenProps {
  onComplete: () => void;
}

export function SplashScreen({ onComplete }: SplashScreenProps) {
  useEffect(() => {
    const timer = setTimeout(() => {
      onComplete();
    }, 2500); // Show splash for 2.5 seconds

    return () => clearTimeout(timer);
  }, [onComplete]);

  return (
    <div className="min-h-screen flex items-center justify-center relative overflow-hidden">
      {/* Animated Background */}
      <div className="absolute inset-0 bg-gradient-to-br from-surface-warm via-background to-surface-cool"></div>
      
      {/* Animated Decorative Elements */}
      <div className="absolute top-20 left-10 w-32 h-32 bg-gradient-brand rounded-full opacity-20 blur-3xl animate-pulse"></div>
      <div className="absolute bottom-32 right-16 w-48 h-48 bg-gradient-brand-secondary rounded-full opacity-20 blur-3xl animate-pulse" style={{ animationDelay: '0.5s' }}></div>
      
      {/* Cultural Icons Animation */}
      <div className="absolute top-16 right-12 text-6xl opacity-10 animate-pulse" style={{ animationDelay: '1s' }}>🌍</div>
      <div className="absolute bottom-24 left-16 text-5xl opacity-10 animate-pulse" style={{ animationDelay: '1.5s' }}>❤️</div>
      <div className="absolute top-1/3 left-12 text-4xl opacity-10 animate-pulse" style={{ animationDelay: '2s' }}>🏛️</div>
      <div className="absolute bottom-1/3 right-20 text-5xl opacity-10 animate-pulse" style={{ animationDelay: '0.8s' }}>🎭</div>
      
      {/* Main Content */}
      <div className="relative z-10 text-center animate-fadeIn">
        {/* Logo with Scale Animation */}
        <div className="flex justify-center mb-8 transform hover:scale-105 transition-transform duration-300">
          <BrandLogo size="2xl" />
        </div>
        
        {/* App Name */}
        <h1 className="text-4xl font-bold text-gray-900 mb-4 animate-slideUp">
          Tryppr
        </h1>
        
        {/* Tagline */}
        <div className="flex items-center justify-center space-x-3 text-xl text-gray-600 animate-slideUp" style={{ animationDelay: '0.3s' }}>
          <span className="font-medium">Try</span>
          <div className="w-1 h-1 bg-brand-primary rounded-full"></div>
          <span className="font-medium">Explore</span>
          <div className="w-1 h-1 bg-brand-secondary rounded-full"></div>
          <span className="font-medium">Share</span>
        </div>
        
        {/* Loading Animation */}
        <div className="mt-12 animate-fadeIn" style={{ animationDelay: '0.8s' }}>
          <div className="flex justify-center space-x-2">
            <div className="w-2 h-2 bg-brand-primary rounded-full animate-bounce"></div>
            <div className="w-2 h-2 bg-brand-secondary rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
            <div className="w-2 h-2 bg-brand-accent rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
          </div>
          <p className="text-sm text-gray-500 mt-4">Loading your cultural journey...</p>
        </div>
      </div>
      
      {/* Bottom Cultural Message */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 text-center max-w-xs animate-fadeIn" style={{ animationDelay: '1.2s' }}>
        <p className="text-xs text-gray-500 italic leading-relaxed">
          "Every journey begins with a single step into the unknown beauty of our diverse world"
        </p>
      </div>
    </div>
  );
}