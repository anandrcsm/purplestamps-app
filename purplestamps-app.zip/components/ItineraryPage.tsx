import { useState } from 'react';
import { 
  ArrowLeft, 
  Plus, 
  Calendar, 
  MapPin, 
  Users, 
  Share2, 
  Edit, 
  MoreVertical,
  Clock,
  Target,
  DollarSign,
  Filter,
  Grid3X3,
  List,
  Star,
  Heart,
  Trash2
} from 'lucide-react';
import { ItineraryCard, Experience, LocalGem, Collaborator } from '../types';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { CategoryTag } from './CategoryTag';

interface ItineraryPageProps {
  itineraryCards: ItineraryCard[];
  onBack: () => void;
  onCreateNewItinerary: () => void;
  onSelectItinerary: (id: string) => void;
  onDeleteItinerary: (id: string) => void;
  onShareItinerary: (id: string) => void;
}

export function ItineraryPage({ 
  itineraryCards, 
  onBack, 
  onCreateNewItinerary,
  onSelectItinerary,
  onDeleteItinerary,
  onShareItinerary
}: ItineraryPageProps) {
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [filterStatus, setFilterStatus] = useState('all');
  const [sortBy, setSortBy] = useState('recent');

  const statusFilters = ['all', 'planning', 'upcoming', 'active', 'completed'];
  
  const filteredCards = itineraryCards.filter(card => 
    filterStatus === 'all' || card.status === filterStatus
  );

  const sortedCards = [...filteredCards].sort((a, b) => {
    switch (sortBy) {
      case 'recent':
        return new Date(b.lastModified).getTime() - new Date(a.lastModified).getTime();
      case 'upcoming':
        return new Date(a.startDate).getTime() - new Date(b.startDate).getTime();
      case 'alphabetical':
        return a.title.localeCompare(b.title);
      default:
        return 0;
    }
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'planning': return 'bg-gray-100 text-gray-700';
      case 'upcoming': return 'bg-blue-100 text-blue-700';
      case 'active': return 'bg-green-100 text-green-700';
      case 'completed': return 'bg-purple-100 text-purple-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'planning': return <Edit size={12} />;
      case 'upcoming': return <Calendar size={12} />;
      case 'active': return <Clock size={12} />;
      case 'completed': return <Target size={12} />;
      default: return <Edit size={12} />;
    }
  };

  const handleShare = (card: ItineraryCard, e: React.MouseEvent) => {
    e.stopPropagation();
    onShareItinerary(card.id);
  };

  const handleDelete = (cardId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    onDeleteItinerary(cardId);
  };

  return (
    <div className="min-h-screen bg-surface-warm pb-20">
      {/* Header */}
      <div className="sticky top-0 bg-white/90 backdrop-blur-xl border-b border-gray-200/50 shadow-sm z-10">
        <div className="flex items-center justify-between p-4">
          <button 
            onClick={onBack}
            className="flex items-center text-brand-primary hover:text-brand-primary-dark transition-colors"
          >
            <ArrowLeft size={20} className="mr-2" />
            <span>Back</span>
          </button>
          <div className="flex items-center space-x-3">
            <button
              onClick={() => setViewMode(viewMode === 'grid' ? 'list' : 'grid')}
              className="p-2 rounded-full hover:bg-gray-100 transition-colors"
            >
              {viewMode === 'grid' ? <List size={18} /> : <Grid3X3 size={18} />}
            </button>
            <button
              onClick={onCreateNewItinerary}
              className="bg-gradient-brand text-white p-2 rounded-full hover:shadow-brand transition-all duration-200"
            >
              <Plus size={18} />
            </button>
          </div>
        </div>
        
        <div className="px-4 pb-4">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h1 className="text-2xl text-gray-900">My Itineraries</h1>
              <p className="text-gray-600 text-sm">
                {itineraryCards.length} travel itineraries organized and ready
              </p>
            </div>
            <div className="w-12 h-12 bg-gradient-brand-secondary rounded-2xl flex items-center justify-center">
              <Calendar size={24} className="text-white" />
            </div>
          </div>

          {/* Filters and Sort */}
          <div className="flex space-x-2 overflow-x-auto pb-2 scrollbar-hide mb-2">
            {statusFilters.map(status => (
              <button
                key={status}
                onClick={() => setFilterStatus(status)}
                className={`px-4 py-2 rounded-xl text-sm whitespace-nowrap transition-colors flex items-center ${
                  filterStatus === status
                    ? 'bg-brand-primary text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                <Filter size={14} className="mr-1" />
                {status === 'all' ? 'All Itineraries' : status.charAt(0).toUpperCase() + status.slice(1)}
                <span className="ml-1 text-xs bg-white/20 px-1.5 py-0.5 rounded-full">
                  {status === 'all' ? itineraryCards.length : itineraryCards.filter(card => card.status === status).length}
                </span>
              </button>
            ))}
          </div>

          {/* Sort Options */}
          <div className="flex space-x-2">
            {['recent', 'upcoming', 'alphabetical'].map(sort => (
              <button
                key={sort}
                onClick={() => setSortBy(sort)}
                className={`px-3 py-1 rounded-lg text-xs transition-colors ${
                  sortBy === sort
                    ? 'bg-brand-secondary text-white'
                    : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                }`}
              >
                {sort === 'recent' ? 'Recent' : sort === 'upcoming' ? 'By Date' : 'A-Z'}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="p-4">
        {sortedCards.length > 0 ? (
          viewMode === 'grid' ? (
            <div className="grid grid-cols-1 gap-4">
              {sortedCards.map((card) => (
                <div
                  key={card.id}
                  className="bg-white rounded-2xl shadow-sm overflow-hidden cursor-pointer transform transition-all duration-200 hover:scale-[1.01] border border-white/20"
                  onClick={() => onSelectItinerary(card.id)}
                >
                  <div className="flex">
                    {/* Card Image */}
                    <div className="w-32 h-32 flex-shrink-0 relative">
                      <ImageWithFallback 
                        src={card.thumbnail} 
                        alt={card.title}
                        className="w-full h-full object-cover"
                      />
                      
                      {/* Status Badge */}
                      <div className="absolute top-2 left-2">
                        <div className={`flex items-center px-2 py-1 rounded-lg text-xs ${getStatusColor(card.status)}`}>
                          {getStatusIcon(card.status)}
                          <span className="ml-1 capitalize">{card.status}</span>
                        </div>
                      </div>
                      
                      {/* Shared Badge */}
                      {card.isShared && (
                        <div className="absolute top-2 right-2">
                          <div className="bg-brand-secondary p-1 rounded-full">
                            <Users size={10} className="text-white" />
                          </div>
                        </div>
                      )}
                    </div>
                    
                    {/* Card Info */}
                    <div className="flex-grow p-4 relative">
                      <div className="flex items-start justify-between mb-2">
                        <div className="flex-grow">
                          <h3 className="text-gray-900 text-lg line-clamp-1 mb-1">
                            {card.title}
                          </h3>
                          <div className="flex items-center text-sm text-gray-600 mb-2">
                            <MapPin size={14} className="mr-1" />
                            <span className="line-clamp-1">{card.destination}</span>
                          </div>
                          <div className="flex items-center text-xs text-gray-500 mb-2">
                            <Calendar size={12} className="mr-1" />
                            <span>
                              {new Date(card.startDate).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })} - 
                              {new Date(card.endDate).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                            </span>
                          </div>
                        </div>
                        
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            // Show options menu
                          }}
                          className="p-1 hover:bg-gray-100 rounded-lg transition-colors"
                        >
                          <MoreVertical size={16} className="text-gray-400" />
                        </button>
                      </div>
                      
                      <p className="text-xs text-gray-600 line-clamp-2 mb-3 leading-relaxed">
                        {card.description}
                      </p>
                      
                      {/* Stats */}
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-4 text-xs text-gray-500">
                          <span className="flex items-center">
                            <Target size={10} className="mr-1" />
                            {card.experiences.length + card.localGems.length} items
                          </span>
                          {card.budget && (
                            <span className="flex items-center">
                              <DollarSign size={10} className="mr-1" />
                              {card.budget.estimated}
                            </span>
                          )}
                          {card.collaborators.length > 0 && (
                            <span className="flex items-center">
                              <Users size={10} className="mr-1" />
                              {card.collaborators.length + 1}
                            </span>
                          )}
                        </div>
                        
                        <div className="flex items-center space-x-2">
                          <button
                            onClick={(e) => handleShare(card, e)}
                            className="text-gray-400 hover:text-brand-primary transition-colors p-1"
                          >
                            <Share2 size={14} />
                          </button>
                          <button
                            onClick={(e) => handleDelete(card.id, e)}
                            className="text-gray-400 hover:text-red-500 transition-colors p-1"
                          >
                            <Trash2 size={14} />
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            /* List View */
            <div className="space-y-3">
              {sortedCards.map((card) => (
                <div
                  key={card.id}
                  className="bg-white rounded-xl p-4 cursor-pointer transition-all duration-200 border border-white/20 hover:border-gray-200"
                  onClick={() => onSelectItinerary(card.id)}
                >
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex-grow">
                      <div className="flex items-center space-x-2 mb-1">
                        <h3 className="text-gray-900 text-lg">{card.title}</h3>
                        <div className={`flex items-center px-2 py-1 rounded-lg text-xs ${getStatusColor(card.status)}`}>
                          {getStatusIcon(card.status)}
                          <span className="ml-1 capitalize">{card.status}</span>
                        </div>
                        {card.isShared && (
                          <div className="bg-brand-secondary/10 p-1 rounded-full">
                            <Users size={12} className="text-brand-secondary" />
                          </div>
                        )}
                      </div>
                      
                      <div className="flex items-center space-x-4 text-sm text-gray-600 mb-2">
                        <div className="flex items-center">
                          <MapPin size={14} className="mr-1" />
                          {card.destination}
                        </div>
                        <div className="flex items-center">
                          <Calendar size={14} className="mr-1" />
                          {new Date(card.startDate).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                        </div>
                        <div className="flex items-center">
                          <Target size={14} className="mr-1" />
                          {card.experiences.length + card.localGems.length} items
                        </div>
                      </div>
                      
                      <p className="text-sm text-gray-700 line-clamp-2">
                        {card.description}
                      </p>
                    </div>
                    
                    <div className="flex items-center space-x-2 ml-4">
                      <button
                        onClick={(e) => handleShare(card, e)}
                        className="text-gray-400 hover:text-brand-primary transition-colors p-1"
                      >
                        <Share2 size={16} />
                      </button>
                      <button
                        onClick={(e) => handleDelete(card.id, e)}
                        className="text-gray-400 hover:text-red-500 transition-colors p-1"
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )
        ) : (
          <div className="text-center py-12">
            <div className="w-24 h-24 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Calendar size={32} className="text-gray-400" />
            </div>
            <p className="text-gray-600 mb-2">No itineraries yet</p>
            <p className="text-sm text-gray-500 mb-4">Create your first travel itinerary to start planning!</p>
            <button
              onClick={onCreateNewItinerary}
              className="bg-gradient-brand text-white px-6 py-3 rounded-xl hover:shadow-brand transition-all duration-200 flex items-center mx-auto"
            >
              <Plus size={18} className="mr-2" />
              Create Itinerary
            </button>
          </div>
        )}
      </div>
    </div>
  );
}