import { useState } from 'react';
import { ArrowRight, Globe, Users, Camera, Heart } from 'lucide-react';
import { BrandLogo } from './BrandLogo';
import { culturalFacts } from '../data/culturalTrivia';

interface WelcomeScreenProps {
  onNavigateToLogin: () => void;
  onNavigateToSignUp: () => void;
}

export function WelcomeScreen({ onNavigateToLogin, onNavigateToSignUp }: WelcomeScreenProps) {
  const [currentFactIndex, setCurrentFactIndex] = useState(0);

  // Rotate cultural facts every 4 seconds
  useState(() => {
    const interval = setInterval(() => {
      setCurrentFactIndex(prev => (prev + 1) % culturalFacts.length);
    }, 4000);
    return () => clearInterval(interval);
  });

  const currentFact = culturalFacts[currentFactIndex];

  const features = [
    {
      icon: Camera,
      title: 'Share Your Journey',
      description: 'Create beautiful travel cards and capture moments'
    },
    {
      icon: Globe,
      title: 'Discover Cultures',
      description: 'Learn about diverse traditions and customs'
    },
    {
      icon: Users,
      title: 'Connect with Travelers',
      description: 'Join a community of cultural explorers'
    },
    {
      icon: Heart,
      title: 'Find Local Gems',
      description: 'Uncover hidden treasures around the world'
    }
  ];

  return (
    <div className="min-h-screen flex flex-col relative overflow-hidden">
      {/* Animated Background */}
      <div className="absolute inset-0 bg-gradient-to-br from-surface-warm via-background to-surface-cool"></div>
      
      {/* Decorative Elements */}
      <div className="absolute top-20 left-10 w-32 h-32 bg-gradient-brand rounded-full opacity-10 blur-3xl animate-pulse"></div>
      <div className="absolute bottom-32 right-16 w-48 h-48 bg-gradient-brand-secondary rounded-full opacity-10 blur-3xl animate-pulse" style={{ animationDelay: '1s' }}></div>
      
      {/* Cultural Pattern Decorations */}
      <div className="absolute top-12 right-8 text-5xl opacity-5 animate-pulse" style={{ animationDelay: '2s' }}>🌍</div>
      <div className="absolute bottom-20 left-12 text-4xl opacity-5 animate-pulse" style={{ animationDelay: '3s' }}>🏛️</div>
      <div className="absolute top-1/2 left-8 text-3xl opacity-5 animate-pulse" style={{ animationDelay: '4s' }}>🎭</div>
      <div className="absolute top-1/3 right-12 text-4xl opacity-5 animate-pulse" style={{ animationDelay: '5s' }}>🗺️</div>

      {/* Main Content */}
      <div className="relative z-10 flex-1 flex flex-col justify-center p-6 max-w-md mx-auto w-full">
        {/* Logo and Brand */}
        <div className="text-center mb-8 animate-fadeIn">
          <div className="flex justify-center mb-6">
            <BrandLogo size="xl" />
          </div>
          <h1 className="text-4xl font-bold text-gray-900 mb-3">
            Welcome to Tryppr
          </h1>
          <p className="text-lg text-gray-600 leading-relaxed">
            Your gateway to trying new places, discovering authentic experiences, and sharing travel memories
          </p>
        </div>

        {/* Cultural Fact Carousel */}
        <div className="glass-effect rounded-2xl p-5 mb-8 border border-white/20 animate-slideUp" style={{ animationDelay: '0.3s' }}>
          <div className="flex items-start">
            <div className="bg-gradient-brand-secondary p-2 rounded-full mr-3 flex-shrink-0">
              <Globe size={16} className="text-white" />
            </div>
            <div>
              <div className="flex items-center mb-2">
                <span className="text-xs font-semibold text-brand-secondary uppercase tracking-wide">
                  Cultural Discovery
                </span>
                <span className="ml-2 text-xs bg-brand-secondary/10 text-brand-secondary px-2 py-0.5 rounded-full">
                  {currentFact.culture}
                </span>
              </div>
              <p className="text-sm text-gray-700 italic leading-relaxed">
                "{currentFact.fact}"
              </p>
              <div className="text-xs text-gray-500 mt-1 flex items-center">
                <span>📍 {currentFact.region}</span>
              </div>
            </div>
          </div>
          
          {/* Indicator dots */}
          <div className="flex justify-center mt-4 space-x-1">
            {culturalFacts.slice(0, 5).map((_, index) => (
              <div
                key={index}
                className={`w-1.5 h-1.5 rounded-full transition-all duration-200 ${
                  index === currentFactIndex % 5 ? 'bg-brand-secondary' : 'bg-gray-300'
                }`}
              />
            ))}
          </div>
        </div>

        {/* Feature Highlights */}
        <div className="grid grid-cols-2 gap-4 mb-8 animate-slideUp" style={{ animationDelay: '0.6s' }}>
          {features.map((feature, index) => {
            const IconComponent = feature.icon;
            return (
              <div key={index} className="text-center p-3">
                <div className="w-12 h-12 bg-gradient-brand rounded-2xl flex items-center justify-center mx-auto mb-3 shadow-brand">
                  <IconComponent size={20} className="text-white" />
                </div>
                <h3 className="font-semibold text-gray-900 text-sm mb-1">{feature.title}</h3>
                <p className="text-xs text-gray-600 leading-relaxed">{feature.description}</p>
              </div>
            );
          })}
        </div>

        {/* Action Buttons */}
        <div className="space-y-4 animate-slideUp" style={{ animationDelay: '0.9s' }}>
          <button
            onClick={onNavigateToSignUp}
            className="w-full bg-gradient-brand text-white py-4 rounded-2xl font-semibold text-lg hover:shadow-brand hover:scale-[1.02] transition-all duration-200 active:scale-95 flex items-center justify-center gap-2"
          >
            Start Your Journey
            <ArrowRight size={18} />
          </button>
          
          <button
            onClick={onNavigateToLogin}
            className="w-full bg-white/80 backdrop-blur-sm text-gray-700 py-4 rounded-2xl font-semibold text-lg border border-white/40 hover:bg-white hover:scale-[1.02] transition-all duration-200 active:scale-95"
          >
            I Already Have an Account
          </button>
        </div>

        {/* Terms and Privacy */}
        <div className="text-center mt-6 animate-fadeIn" style={{ animationDelay: '1.2s' }}>
          <p className="text-xs text-gray-500 leading-relaxed">
            By continuing, you agree to our{' '}
            <a href="#" className="text-brand-primary hover:underline">Cultural Guidelines</a>
            {' '}and{' '}
            <a href="#" className="text-brand-primary hover:underline">Privacy Policy</a>
          </p>
        </div>
      </div>

      {/* Bottom Mission Statement */}
      <div className="relative z-10 p-6 animate-fadeIn" style={{ animationDelay: '1.5s' }}>
        <div className="glass-effect rounded-2xl p-4 border border-white/20 text-center">
          <p className="text-sm text-gray-700 italic leading-relaxed">
            "Try • Explore • Share"
          </p>
          <p className="text-xs text-gray-500 mt-1">
            Discover new places and create lasting memories
          </p>
        </div>
      </div>
    </div>
  );
}