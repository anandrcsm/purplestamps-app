import { useState } from 'react';
import { Heart, MessageCircle, Share, Bookmark, MapPin, Calendar, Star, Users, MoreHorizontal, Plane, Radio, ExternalLink, Clock, DollarSign } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { SwipeUpCommentSheet } from './SwipeUpCommentSheet';
import { BookNowNudge } from './BookNowNudge';
import { UnifiedButton } from './ui/unified-icons';
import { getCreator } from '../data/mockData';

interface TravelCardProps {
  id: string;
  title?: string;
  destination?: string;
  images?: string[];
  thumbnail?: string;
  description?: string;
  creatorId?: string;
  likes?: number;
  comments?: number;
  shares?: number;
  rating?: number;
  dates?: string;
  tripType?: string;
  budget?: string;
  experiences?: any[];
  createdAt?: string;
  isLiked?: boolean;
  isSaved?: boolean;
  isLive?: boolean;
  isDraft?: boolean;
  hasBookingLinks?: boolean;
  onSelect: (id: string) => void;
  onSelectUser?: (userId: string) => void;
  onLike?: () => void;
  onSave?: () => void;
  onFollowTrip?: (id: string) => void;
  showCommentsModal?: boolean;
}

export function TravelCard({
  id,
  title,
  destination,
  images = [],
  thumbnail,
  description,
  creatorId,
  likes = 0,
  comments = 0,
  shares = 0,
  rating,
  dates,
  tripType,
  budget,
  experiences = [],
  createdAt,
  isLiked = false,
  isSaved = false,
  isLive = false,
  isDraft = false,
  hasBookingLinks = false,
  onSelect,
  onSelectUser,
  onLike,
  onSave,
  onFollowTrip,
  showCommentsModal = false
}: TravelCardProps) {
  const [isCommentSheetOpen, setIsCommentSheetOpen] = useState(false);
  const [showNudge, setShowNudge] = useState(false);
  const [commentsList, setCommentsList] = useState([
    {
      id: '1',
      userId: 'user1',
      userName: 'sarah.explores',
      userAvatar: 'https://images.unsplash.com/photo-1494790108755-2616b612e2fa?w=50&h=50&fit=crop&crop=face',
      text: 'This looks absolutely incredible! 😍 Adding this to my bucket list right now',
      timestamp: '2h',
      likes: 12,
      isLiked: false,
      repliesCount: 3,
      replies: [
        {
          id: '1-1',
          userId: 'user2',
          userName: 'mike.wanderer',
          userAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=50&h=50&fit=crop&crop=face',
          text: 'Same here! Have you been to this region before?',
          timestamp: '1h',
          likes: 2,
          isLiked: false
        }
      ]
    }
  ]);
  
  const creator = creatorId ? getCreator(creatorId) : null;
  const coverImage = thumbnail || images[0] || 'https://images.unsplash.com/photo-1469474968028-56623f02e42e?w=600&h=800&fit=crop';

  // Calculate estimated cost
  const getEstimatedCost = () => {
    if (experiences && experiences.length > 0) {
      const totalCost = experiences.reduce((sum, exp) => sum + (exp.cost || 0), 0);
      return totalCost;
    }
    // Fallback based on trip type and budget
    if (budget === 'Luxury') return 85000;
    if (budget === 'Mid-range') return 35000;
    if (budget === 'Budget') return 15000;
    return 25000;
  };

  const formatCost = (cost: number) => {
    if (cost >= 100000) {
      return `₹${(cost / 100000).toFixed(1)}L`;
    } else if (cost >= 1000) {
      return `₹${(cost / 1000).toFixed(1)}k`;
    }
    return `₹${cost}`;
  };

  const estimatedCost = getEstimatedCost();
  
  const handleCardClick = () => {
    onSelect(id);
  };

  const handleActionClick = (e: React.MouseEvent, action: () => void) => {
    e.stopPropagation();
    action();
  };

  const handleCommentClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (showCommentsModal) {
      setIsCommentSheetOpen(true);
    } else {
      onSelect(id);
    }
  };

  const handleAddComment = (text: string) => {
    const newComment = {
      id: `comment-${Date.now()}`,
      userId: 'current-user',
      userName: 'you',
      userAvatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=50&h=50&fit=crop&crop=face',
      text,
      timestamp: 'now',
      likes: 0,
      isLiked: false,
      repliesCount: 0
    };
    setCommentsList(prev => [newComment, ...prev]);
  };

  const handleLikeComment = (commentId: string) => {
    setCommentsList(prev => prev.map(comment => {
      if (comment.id === commentId) {
        return {
          ...comment,
          isLiked: !comment.isLiked,
          likes: comment.isLiked ? comment.likes - 1 : comment.likes + 1
        };
      }
      if (comment.replies) {
        return {
          ...comment,
          replies: comment.replies.map(reply => 
            reply.id === commentId 
              ? {
                  ...reply,
                  isLiked: !reply.isLiked,
                  likes: reply.isLiked ? reply.likes - 1 : reply.likes + 1
                }
              : reply
          )
        };
      }
      return comment;
    }));
  };

  const handleReplyComment = (commentId: string, replyText: string) => {
    const newReply = {
      id: `reply-${Date.now()}`,
      userId: 'current-user',
      userName: 'you',
      userAvatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=50&h=50&fit=crop&crop=face',
      text: replyText,
      timestamp: 'now',
      likes: 0,
      isLiked: false
    };
    
    setCommentsList(prev => prev.map(comment => 
      comment.id === commentId 
        ? {
            ...comment,
            replies: [...(comment.replies || []), newReply],
            repliesCount: (comment.repliesCount || 0) + 1
          }
        : comment
    ));
  };

  // Format like count
  const formatLikeCount = (count: number) => {
    if (count >= 1000) {
      return `${(count / 1000).toFixed(1)}k`;
    }
    return count.toString();
  };

  return (
    <article className="w-full animate-fadeIn">
      {/* Modern Vertical Travel Card Container */}
      <div 
        className="relative bg-white rounded-2xl shadow-lg border border-moodboard-gray-light/10 overflow-hidden cursor-pointer group transition-all duration-300 hover:shadow-xl hover:scale-[1.02] active:scale-[0.98]"
        style={{ height: '480px' }}
        onClick={handleCardClick}
      >
        {/* Full-Bleed Cover Photo Background */}
        <div className="absolute inset-0">
          <ImageWithFallback
            src={coverImage}
            alt={title || destination || 'Travel destination'}
            className="w-full h-full object-cover"
          />
          
          {/* Gradient Overlay - Dark to Transparent */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent"></div>
        </div>

        {/* Profile Stamp - Top Right Corner */}
        {creator && (
          <div className="absolute top-4 right-4 z-20">
            <div className="flex flex-col items-end space-y-2">
              {/* Creator Profile Button */}
              <button
                onClick={(e) => handleActionClick(e, () => onSelectUser?.(creator.id))}
                className="flex items-center space-x-2 bg-white/20 backdrop-blur-md rounded-full pr-3 pl-1 py-1 border border-white/30 hover:bg-white/30 transition-all duration-200"
              >
                {/* Circular Profile Photo */}
                <div className="w-8 h-8 rounded-full overflow-hidden border-2 border-white/50 relative">
                  <ImageWithFallback
                    src={creator.profilePic}
                    alt={creator.name}
                    className="w-full h-full object-cover"
                  />
                  {creator.isCreator && (
                    <div className="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-gradient-brand rounded-full flex items-center justify-center border border-white">
                      <Plane size={6} className="text-white" />
                    </div>
                  )}
                </div>
                
                {/* Username */}
                <span className="text-xs font-medium text-white/90">
                  @{creator.username || creator.name.toLowerCase().replace(' ', '')}
                </span>
              </button>

              {/* Small Follow Trip Button - Under Creator Name for Live Cards */}
              {onFollowTrip && isLive && (
                <button
                  onClick={(e) => handleActionClick(e, () => onFollowTrip(id))}
                  className="bg-moodboard-muted-teal/90 backdrop-blur-sm text-white px-2 py-1 rounded-full text-xs font-medium hover:bg-moodboard-muted-teal hover:scale-105 transition-all duration-200 active:scale-95 flex items-center space-x-1 border border-white/30"
                >
                  <Users size={8} />
                  <span>Follow Trip</span>
                </button>
              )}
            </div>
          </div>
        )}

        {/* Trip Type Badge - Top Left */}
        {tripType && (
          <div className="absolute top-4 left-4 z-20">
            <div className="bg-moodboard-warm-beige/90 backdrop-blur-sm text-moodboard-deep-green px-3 py-1.5 rounded-full text-xs font-semibold border border-white/20">
              {tripType}
            </div>
          </div>
        )}

        {/* Draft Badge */}
        {isDraft && (
          <div className="absolute top-4 left-4 z-20">
            <div className="bg-orange-500/90 backdrop-blur-sm text-white px-3 py-1.5 rounded-full text-xs font-semibold border border-white/20">
              DRAFT
            </div>
          </div>
        )}

        {/* Live Indicator */}
        {isLive && (
          <div className="absolute top-16 left-4 z-20">
            <div className="flex items-center space-x-1 bg-red-500/90 backdrop-blur-sm text-white px-2 py-1 rounded-full text-xs font-semibold">
              <Radio size={10} className="animate-pulse" />
              <span>LIVE</span>
            </div>
          </div>
        )}



        {/* Caption Text Overlay - Center */}
        <div className="absolute inset-x-4 bottom-32 z-10">
          <div className="text-center">
            {/* Trip Title - Bold */}
            <h2 className="text-white font-bold text-xl mb-2 leading-tight drop-shadow-lg">
              {title || `Adventure in ${destination}`}
            </h2>
            
            {/* Short Caption/Travel Quote */}
            {description && (
              <p className="text-white/90 text-sm leading-relaxed line-clamp-2 drop-shadow-md max-w-sm mx-auto">
                {description}
              </p>
            )}
          </div>
        </div>

        {/* Trip Details Overlay - Bottom Layer */}
        <div className="absolute bottom-16 left-4 right-4 z-10">
          <div className="flex items-center justify-center space-x-3">
            {/* Duration Tag */}
            {dates && (
              <div className="flex items-center space-x-1 bg-white/20 backdrop-blur-md rounded-full px-3 py-1.5 border border-white/30">
                <Clock size={12} className="text-white" />
                <span className="text-white text-xs font-medium">{dates}</span>
              </div>
            )}
            
            {/* Budget Tag */}
            <div className="flex items-center space-x-1 bg-white/20 backdrop-blur-md rounded-full px-3 py-1.5 border border-white/30">
              <DollarSign size={12} className="text-white" />
              <span className="text-white text-xs font-medium">{formatCost(estimatedCost)}</span>
            </div>


          </div>
        </div>

        {/* Action Strip - Fixed Bottom */}
        <div className="absolute bottom-0 left-0 right-0 z-10">
          <div className="flex items-center justify-between px-4 py-3 bg-[rgba(0,0,0,0)]">
            {/* Left Side Actions */}
            <div className="flex items-center space-x-4">
              {/* Like Button */}
              <button
                onClick={(e) => handleActionClick(e, onLike || (() => {}))}
                className={`flex items-center space-x-1 transition-all duration-200 hover:scale-110 active:scale-95 touch-target ${
                  isLiked ? 'text-red-500' : 'text-white hover:text-red-500'
                }`}
              >
                <Heart size={20} className={isLiked ? 'fill-current' : ''} />
                <span className="text-sm font-medium">{formatLikeCount(likes)}</span>
              </button>

              {/* Comment Button */}
              <button
                onClick={handleCommentClick}
                className="flex items-center space-x-1 text-white hover:text-moodboard-muted-teal transition-all duration-200 hover:scale-110 active:scale-95 touch-target"
              >
                <MessageCircle size={20} />
                <span className="text-sm font-medium">{comments}</span>
              </button>

              {/* Share Button */}
              <button
                onClick={(e) => handleActionClick(e, () => console.log('Share'))}
                className="text-white hover:text-moodboard-muted-teal transition-all duration-200 hover:scale-110 active:scale-95 touch-target"
              >
                <Share size={20} />
              </button>
            </div>

            {/* Save Button - Right Side */}
            <button
              onClick={(e) => handleActionClick(e, onSave || (() => {}))}
              className={`transition-all duration-200 hover:scale-110 active:scale-95 touch-target ${
                isSaved ? 'text-moodboard-warm-beige-dark' : 'text-white hover:text-moodboard-warm-beige-dark'
              }`}
            >
              <Bookmark size={20} className={isSaved ? 'fill-current' : ''} />
            </button>
          </div>
        </div>

        {/* Additional CTAs for Interactive Cards */}
        {(hasBookingLinks || (onFollowTrip && isLive)) && (
          <div className="absolute bottom-20 left-4 right-4 z-10">
            {/* Book Now CTA */}
            {hasBookingLinks && (
              <UnifiedButton
                variant="book-now"
                size="sm"
                icon={<ExternalLink size={14} />}
                iconPosition="right"
                onClick={(e) => {
                  e.stopPropagation();
                  onSelect(id);
                }}
                className="w-full mb-2 bg-moodboard-warm-beige/95 backdrop-blur-sm text-moodboard-deep-green hover:bg-moodboard-warm-beige border border-white/20"
              >
                Book Experience
              </UnifiedButton>
            )}


          </div>
        )}
      </div>

      {/* Swipe Up Comment Sheet */}
      <SwipeUpCommentSheet
        isOpen={isCommentSheetOpen}
        onClose={() => setIsCommentSheetOpen(false)}
        contentId={id}
        contentType="travel-card"
        comments={commentsList}
        totalComments={commentsList.length + commentsList.reduce((sum, c) => sum + (c.repliesCount || 0), 0)}
        onAddComment={handleAddComment}
        onLikeComment={handleLikeComment}
        onReplyComment={handleReplyComment}
      />

      {/* Book Now Nudge */}
      {hasBookingLinks && (
        <BookNowNudge 
          cardId={id}
          location={destination}
          onDismiss={() => setShowNudge(false)}
        />
      )}
    </article>
  );
}