import { useState } from 'react';
import { 
  ArrowLeft, 
  Plus, 
  Calendar, 
  MapPin, 
  Clock, 
  Save, 
  Share2, 
  Image as ImageIcon,
  Trash2,
  Edit3
} from 'lucide-react';
import { TravelItinerary, ItineraryDay, ItineraryActivity, BucketListItem } from '../types';
import { ImageWithFallback } from './figma/ImageWithFallback';
import exampleImage from 'figma:asset/6a2ce057b9fcd45be1a8d2fa95186129c1e64495.png';

interface CreateItineraryPageProps {
  onBack: () => void;
  onSave: (itinerary: TravelItinerary) => void;
  bucketListItems?: BucketListItem[];
  prefilledData?: {
    title?: string;
    destination?: string;
    startDate?: string;
    endDate?: string;
  };
}

export function CreateItineraryPage({ onBack, onSave, bucketListItems = [], prefilledData }: CreateItineraryPageProps) {
  const [title, setTitle] = useState(prefilledData?.title || '');
  const [destination, setDestination] = useState(prefilledData?.destination || '');
  const [startDate, setStartDate] = useState(prefilledData?.startDate || '');
  const [endDate, setEndDate] = useState(prefilledData?.endDate || '');
  const [days, setDays] = useState<ItineraryDay[]>([]);
  const [showPreview, setShowPreview] = useState(false);

  // Generate days when dates are set
  const generateDays = () => {
    if (!startDate || !endDate) return;
    
    const start = new Date(startDate);
    const end = new Date(endDate);
    const diffTime = Math.abs(end.getTime() - start.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)) + 1;
    
    const newDays: ItineraryDay[] = [];
    for (let i = 0; i < diffDays; i++) {
      const currentDate = new Date(start);
      currentDate.setDate(start.getDate() + i);
      
      newDays.push({
        day: i + 1,
        date: currentDate.toISOString().split('T')[0],
        title: i === 0 ? 'Arrival' : i === diffDays - 1 ? 'Departure' : `Day ${i + 1}`,
        activities: [],
        images: []
      });
    }
    
    setDays(newDays);
  };

  const addActivity = (dayIndex: number) => {
    const newActivity: ItineraryActivity = {
      id: `activity-${Date.now()}`,
      time: '09:00 AM',
      activity: 'New Activity',
      location: destination
    };
    
    setDays(prev => prev.map((day, index) => 
      index === dayIndex 
        ? { ...day, activities: [...day.activities, newActivity] }
        : day
    ));
  };

  const updateActivity = (dayIndex: number, activityIndex: number, field: string, value: string) => {
    setDays(prev => prev.map((day, dIndex) => 
      dIndex === dayIndex 
        ? {
            ...day,
            activities: day.activities.map((activity, aIndex) => 
              aIndex === activityIndex 
                ? { ...activity, [field]: value }
                : activity
            )
          }
        : day
    ));
  };

  const removeActivity = (dayIndex: number, activityIndex: number) => {
    setDays(prev => prev.map((day, dIndex) => 
      dIndex === dayIndex 
        ? { ...day, activities: day.activities.filter((_, aIndex) => aIndex !== activityIndex) }
        : day
    ));
  };

  const addImage = (dayIndex: number, imageUrl: string) => {
    setDays(prev => prev.map((day, dIndex) => 
      dIndex === dayIndex 
        ? { ...day, images: [...day.images, imageUrl] }
        : day
    ));
  };

  const handleSave = () => {
    if (!title || !destination || !startDate || !endDate) {
      // Show error toast
      const toast = document.createElement('div');
      toast.className = 'fixed top-20 left-1/2 transform -translate-x-1/2 bg-red-500 text-white px-4 py-2 rounded-xl z-50 shadow-lg';
      toast.textContent = 'Please fill in all required fields';
      document.body.appendChild(toast);
      setTimeout(() => document.body.removeChild(toast), 3000);
      return;
    }

    const newItinerary: TravelItinerary = {
      id: `itinerary-${Date.now()}`,
      title,
      destination,
      startDate,
      endDate,
      days,
      createdBy: 'user1',
      createdAt: new Date(),
      lastModified: new Date(),
      isShared: false,
      collaborators: []
    };

    onSave(newItinerary);
  };

  const renderPreview = () => (
    <div className="bg-white rounded-2xl p-6 shadow-lg" style={{ 
      backgroundImage: `url(${exampleImage})`,
      backgroundSize: 'cover',
      backgroundPosition: 'center',
      minHeight: '600px'
    }}>
      <div className="bg-white/95 backdrop-blur-sm rounded-xl p-6">
        <div className="text-center mb-8">
          <h1 className="text-3xl text-gray-900 mb-2">
            Travel <span className="text-green-600">ITINERARY</span>
          </h1>
          <h2 className="text-xl text-gray-700">{title}</h2>
          <p className="text-gray-600">{destination}</p>
        </div>

        <div className="space-y-8">
          {days.map((day, dayIndex) => (
            <div key={day.day} className="relative">
              <div className="flex items-start">
                <div className="flex-grow">
                  <h3 className="text-lg text-gray-900 mb-4 font-script">
                    Day {day.day}: {day.title}
                  </h3>
                  
                  <div className="space-y-2">
                    {day.activities.map((activity, actIndex) => (
                      <div key={activity.id} className="flex items-start">
                        <div className="w-20 text-sm text-gray-700 font-medium mr-4">
                          {activity.time}
                        </div>
                        <div className="flex-grow">
                          <p className="text-gray-800">{activity.activity}</p>
                          {activity.location && (
                            <p className="text-xs text-gray-600">{activity.location}</p>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
                
                {/* Polaroid Images */}
                <div className="ml-6 flex flex-col space-y-4">
                  {day.images.slice(0, 2).map((image, imgIndex) => (
                    <div key={imgIndex} className="relative">
                      <div className="bg-white p-2 rounded-lg shadow-md transform rotate-3 hover:rotate-0 transition-transform">
                        <ImageWithFallback
                          src={image}
                          alt={`Day ${day.day} memory`}
                          className="w-20 h-20 object-cover rounded"
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
              
              {/* Dotted line separator */}
              {dayIndex < days.length - 1 && (
                <div className="border-b border-dotted border-gray-300 my-6"></div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-surface-warm pb-20">
      {/* Header */}
      <div className="sticky top-0 bg-white/90 backdrop-blur-xl border-b border-gray-200/50 shadow-sm z-10">
        <div className="flex items-center justify-between p-4">
          <button 
            onClick={onBack}
            className="flex items-center text-brand-primary hover:text-brand-primary-dark transition-colors"
          >
            <ArrowLeft size={20} className="mr-2" />
            <span>Back</span>
          </button>
          
          <div className="flex items-center space-x-3">
            <button
              onClick={() => setShowPreview(!showPreview)}
              className="px-4 py-2 bg-brand-secondary text-white rounded-xl hover:bg-brand-secondary-dark transition-colors"
            >
              {showPreview ? 'Edit' : 'Preview'}
            </button>
            <button
              onClick={handleSave}
              className="px-4 py-2 bg-gradient-brand text-white rounded-xl hover:shadow-brand transition-all duration-200 flex items-center"
            >
              <Save size={16} className="mr-2" />
              Save
            </button>
          </div>
        </div>
      </div>

      <div className="p-4">
        {showPreview ? renderPreview() : (
          <div className="max-w-2xl mx-auto space-y-6">
            {/* Basic Info */}
            <div className="bg-white rounded-2xl p-6 border border-white/20">
              <h2 className="text-xl text-gray-900 mb-4">Trip Details</h2>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-sm text-gray-700 mb-2">Trip Title</label>
                  <input
                    type="text"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder="Enter trip title"
                    className="w-full p-3 bg-gray-50 rounded-xl border-0 focus:ring-2 focus:ring-brand-primary focus:bg-white transition-all"
                  />
                </div>
                
                <div>
                  <label className="block text-sm text-gray-700 mb-2">Destination</label>
                  <input
                    type="text"
                    value={destination}
                    onChange={(e) => setDestination(e.target.value)}
                    placeholder="Enter destination"
                    className="w-full p-3 bg-gray-50 rounded-xl border-0 focus:ring-2 focus:ring-brand-primary focus:bg-white transition-all"
                  />
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm text-gray-700 mb-2">Start Date</label>
                    <input
                      type="date"
                      value={startDate}
                      onChange={(e) => setStartDate(e.target.value)}
                      className="w-full p-3 bg-gray-50 rounded-xl border-0 focus:ring-2 focus:ring-brand-primary focus:bg-white transition-all"
                    />
                  </div>
                  <div>
                    <label className="block text-sm text-gray-700 mb-2">End Date</label>
                    <input
                      type="date"
                      value={endDate}
                      onChange={(e) => setEndDate(e.target.value)}
                      className="w-full p-3 bg-gray-50 rounded-xl border-0 focus:ring-2 focus:ring-brand-primary focus:bg-white transition-all"
                    />
                  </div>
                </div>
                
                <button
                  onClick={generateDays}
                  className="w-full bg-brand-primary text-white py-3 rounded-xl hover:bg-brand-primary-dark transition-colors"
                >
                  Generate Itinerary Days
                </button>
              </div>
            </div>

            {/* Daily Itinerary */}
            {days.map((day, dayIndex) => (
              <div key={day.day} className="bg-white rounded-2xl p-6 border border-white/20">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h3 className="text-lg text-gray-900">Day {day.day}</h3>
                    <p className="text-sm text-gray-600">
                      {new Date(day.date).toLocaleDateString('en-US', { 
                        weekday: 'long', 
                        year: 'numeric', 
                        month: 'long', 
                        day: 'numeric' 
                      })}
                    </p>
                  </div>
                  <input
                    type="text"
                    value={day.title}
                    onChange={(e) => {
                      setDays(prev => prev.map((d, index) => 
                        index === dayIndex ? { ...d, title: e.target.value } : d
                      ));
                    }}
                    className="px-3 py-2 bg-gray-50 rounded-xl border-0 focus:ring-2 focus:ring-brand-primary text-sm"
                    placeholder="Day title"
                  />
                </div>

                <div className="space-y-3 mb-4">
                  {day.activities.map((activity, actIndex) => (
                    <div key={activity.id} className="flex items-start space-x-3 p-3 bg-gray-50 rounded-xl">
                      <input
                        type="time"
                        value={activity.time.split(' ')[0]}
                        onChange={(e) => {
                          const time = e.target.value;
                          const hour = parseInt(time.split(':')[0]);
                          const minute = time.split(':')[1];
                          const ampm = hour >= 12 ? 'PM' : 'AM';
                          const displayHour = hour > 12 ? hour - 12 : hour === 0 ? 12 : hour;
                          const formattedTime = `${displayHour}:${minute} ${ampm}`;
                          updateActivity(dayIndex, actIndex, 'time', formattedTime);
                        }}
                        className="px-2 py-1 bg-white rounded-lg border-0 focus:ring-2 focus:ring-brand-primary text-xs"
                      />
                      <div className="flex-grow space-y-2">
                        <input
                          type="text"
                          value={activity.activity}
                          onChange={(e) => updateActivity(dayIndex, actIndex, 'activity', e.target.value)}
                          className="w-full px-3 py-2 bg-white rounded-lg border-0 focus:ring-2 focus:ring-brand-primary text-sm"
                          placeholder="Activity description"
                        />
                        <input
                          type="text"
                          value={activity.location || ''}
                          onChange={(e) => updateActivity(dayIndex, actIndex, 'location', e.target.value)}
                          className="w-full px-3 py-2 bg-white rounded-lg border-0 focus:ring-2 focus:ring-brand-primary text-xs"
                          placeholder="Location (optional)"
                        />
                      </div>
                      <button
                        onClick={() => removeActivity(dayIndex, actIndex)}
                        className="p-1 text-red-500 hover:bg-red-50 rounded-lg transition-colors"
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  ))}
                </div>

                <div className="flex space-x-3">
                  <button
                    onClick={() => addActivity(dayIndex)}
                    className="flex-1 flex items-center justify-center py-2 bg-brand-primary text-white rounded-xl hover:bg-brand-primary-dark transition-colors"
                  >
                    <Plus size={16} className="mr-2" />
                    Add Activity
                  </button>
                  <button
                    onClick={() => addImage(dayIndex, `https://images.unsplash.com/photo-${Math.floor(Math.random() * 1000000000000)}?w=400&h=300&fit=crop`)}
                    className="flex-1 flex items-center justify-center py-2 bg-brand-secondary text-white rounded-xl hover:bg-brand-secondary-dark transition-colors"
                  >
                    <ImageIcon size={16} className="mr-2" />
                    Add Image
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}