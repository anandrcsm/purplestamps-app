import { useState } from 'react';
import { X, Plus, Camera, MapPin, Tag, Upload } from 'lucide-react';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { Button } from './ui/button';

interface Moment {
  id: string;
  image: string;
  experienceTitle: string;
  experienceLocation: string;
  experienceCategory: string;
  caption?: string;
  tags?: string[];
}

interface AddMomentModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAdd: (moment: Moment) => void;
}

export function AddMomentModal({
  isOpen,
  onClose,
  onAdd
}: AddMomentModalProps) {
  const [formData, setFormData] = useState({
    image: '',
    experienceTitle: '',
    experienceLocation: '',
    experienceCategory: 'activities',
    caption: '',
    tags: ''
  });

  const [errors, setErrors] = useState<Record<string, string>>({});

  if (!isOpen) return null;

  const validateForm = () => {
    const newErrors: Record<string, string> = {};
    
    if (!formData.image.trim()) {
      newErrors.image = 'Image URL is required';
    }
    
    if (!formData.experienceTitle.trim()) {
      newErrors.experienceTitle = 'Experience title is required';
    }
    
    if (!formData.experienceLocation.trim()) {
      newErrors.experienceLocation = 'Location is required';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSave = () => {
    if (!validateForm()) return;

    const newMoment: Moment = {
      id: `moment-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      image: formData.image,
      experienceTitle: formData.experienceTitle,
      experienceLocation: formData.experienceLocation,
      experienceCategory: formData.experienceCategory,
      caption: formData.caption || undefined,
      tags: formData.tags ? formData.tags.split(',').map(tag => tag.trim()).filter(tag => tag) : []
    };

    onAdd(newMoment);
    onClose();
    
    // Reset form
    setFormData({
      image: '',
      experienceTitle: '',
      experienceLocation: '',
      experienceCategory: 'activities',
      caption: '',
      tags: ''
    });
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  const categories = [
    { value: 'activities', label: 'Activities' },
    { value: 'food', label: 'Food' },
    { value: 'stay', label: 'Stay' },
    { value: 'transport', label: 'Transport' },
    { value: 'travel-items', label: 'Travel Items' }
  ];

  const suggestedImages = [
    'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=400&h=400&fit=crop',
    'https://images.unsplash.com/photo-1469474968028-56623f02e42e?w=400&h=400&fit=crop',
    'https://images.unsplash.com/photo-1564507592333-c60657eea523?w=400&h=400&fit=crop',
    'https://images.unsplash.com/photo-1551632811-561732d1e306?w=400&h=400&fit=crop'
  ];

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl w-full max-w-md max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="sticky top-0 bg-white border-b border-moodboard-gray-light/20 p-6 rounded-t-2xl">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-bold text-moodboard-deep-green">Add Moment to Gallery</h2>
            <button
              onClick={onClose}
              className="p-2 hover:bg-moodboard-gray-light/20 rounded-xl transition-colors"
            >
              <X size={20} className="text-moodboard-gray-dark" />
            </button>
          </div>
        </div>

        {/* Form Content */}
        <div className="p-6 space-y-6">
          {/* Image URL */}
          <div className="space-y-2">
            <label className="text-sm font-medium text-moodboard-deep-green flex items-center space-x-2">
              <Camera size={16} className="text-moodboard-muted-teal" />
              <span>Image URL</span>
            </label>
            <Input
              value={formData.image}
              onChange={(e) => handleInputChange('image', e.target.value)}
              placeholder="https://images.unsplash.com/photo-..."
              className={`${errors.image ? 'border-red-300' : ''}`}
            />
            {errors.image && <p className="text-red-500 text-xs">{errors.image}</p>}
          </div>

          {/* Quick Image Suggestions */}
          <div className="space-y-2">
            <span className="text-sm font-medium text-moodboard-deep-green">Or choose from suggestions:</span>
            <div className="grid grid-cols-4 gap-2">
              {suggestedImages.map((imageUrl, index) => (
                <button
                  key={index}
                  onClick={() => handleInputChange('image', imageUrl)}
                  className="aspect-square rounded-lg overflow-hidden border-2 border-transparent hover:border-moodboard-muted-teal transition-colors"
                >
                  <img
                    src={imageUrl}
                    alt={`Suggestion ${index + 1}`}
                    className="w-full h-full object-cover"
                  />
                </button>
              ))}
            </div>
          </div>

          {/* Image Preview */}
          {formData.image && (
            <div className="space-y-2">
              <span className="text-sm font-medium text-moodboard-deep-green">Preview</span>
              <div className="w-full h-48 rounded-lg overflow-hidden bg-moodboard-gray-light/10">
                <img
                  src={formData.image}
                  alt="Preview"
                  className="w-full h-full object-cover"
                />
              </div>
            </div>
          )}

          {/* Experience Title */}
          <div className="space-y-2">
            <label className="text-sm font-medium text-moodboard-deep-green">
              Experience Title
            </label>
            <Input
              value={formData.experienceTitle}
              onChange={(e) => handleInputChange('experienceTitle', e.target.value)}
              placeholder="e.g., Sunset at Key Monastery"
              className={`${errors.experienceTitle ? 'border-red-300' : ''}`}
            />
            {errors.experienceTitle && <p className="text-red-500 text-xs">{errors.experienceTitle}</p>}
          </div>

          {/* Location */}
          <div className="space-y-2">
            <label className="text-sm font-medium text-moodboard-deep-green flex items-center space-x-2">
              <MapPin size={16} className="text-moodboard-muted-teal" />
              <span>Location</span>
            </label>
            <Input
              value={formData.experienceLocation}
              onChange={(e) => handleInputChange('experienceLocation', e.target.value)}
              placeholder="e.g., Key Village, Spiti Valley"
              className={`${errors.experienceLocation ? 'border-red-300' : ''}`}
            />
            {errors.experienceLocation && <p className="text-red-500 text-xs">{errors.experienceLocation}</p>}
          </div>

          {/* Category */}
          <div className="space-y-2">
            <label className="text-sm font-medium text-moodboard-deep-green">
              Category
            </label>
            <div className="grid grid-cols-3 gap-2">
              {categories.map((category) => (
                <button
                  key={category.value}
                  onClick={() => handleInputChange('experienceCategory', category.value)}
                  className={`p-3 rounded-xl text-sm font-medium transition-all duration-200 ${
                    formData.experienceCategory === category.value
                      ? 'bg-moodboard-muted-teal text-white'
                      : 'bg-moodboard-gray-light/10 text-moodboard-gray-dark hover:bg-moodboard-gray-light/20'
                  }`}
                >
                  {category.label}
                </button>
              ))}
            </div>
          </div>

          {/* Caption */}
          <div className="space-y-2">
            <label className="text-sm font-medium text-moodboard-deep-green">
              Caption (Optional)
            </label>
            <Textarea
              value={formData.caption}
              onChange={(e) => handleInputChange('caption', e.target.value)}
              placeholder="Share your thoughts about this moment..."
              rows={3}
              className="resize-none"
            />
          </div>

          {/* Tags */}
          <div className="space-y-2">
            <label className="text-sm font-medium text-moodboard-deep-green flex items-center space-x-2">
              <Tag size={16} className="text-moodboard-muted-teal" />
              <span>Tags (Optional)</span>
            </label>
            <Input
              value={formData.tags}
              onChange={(e) => handleInputChange('tags', e.target.value)}
              placeholder="monastery, sunset, peaceful, buddhist (comma separated)"
            />
            <p className="text-xs text-moodboard-gray-dark">
              Separate tags with commas to help organize your moments
            </p>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="sticky bottom-0 bg-white border-t border-moodboard-gray-light/20 p-6 rounded-b-2xl">
          <div className="flex space-x-3">
            <Button
              onClick={onClose}
              variant="outline"
              className="flex-1"
            >
              Cancel
            </Button>
            <Button
              onClick={handleSave}
              className="flex-1 bg-moodboard-muted-teal hover:bg-moodboard-muted-teal/90 text-white"
            >
              Add Moment
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}