import { useState } from 'react';
import { MapPin, Star, ExternalLink, Bookmark, Heart, Clock, Users, DollarSign } from 'lucide-react';
import { Experience } from '../types';
import { StarRating } from './StarRating';
import { CategoryTag } from './CategoryTag';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface ExperienceCardProps {
  experience: Experience;
  onClick?: () => void;
  onAddToItinerary?: () => void;
}

export function ExperienceCard({ experience, onClick, onAddToItinerary }: ExperienceCardProps) {
  const [isLiked, setIsLiked] = useState(false);
  const [isSaved, setIsSaved] = useState(false);

  const handleLike = (e: React.MouseEvent) => {
    e.stopPropagation();
    setIsLiked(!isLiked);
  };

  const handleSave = (e: React.MouseEvent) => {
    e.stopPropagation();
    setIsSaved(!isSaved);
    if (onAddToItinerary) {
      onAddToItinerary();
    }
  };

  const handleBookNow = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (experience.affiliateLink) {
      window.open(experience.affiliateLink, '_blank');
    }
  };

  // Safely access media array with fallback
  const mediaImages = experience.media || [];
  const tags = experience.tags || [];

  return (
    <article 
      className="card-standard card-margin overflow-hidden cursor-pointer transform transition-all duration-300 hover:scale-[1.02] active:scale-95 group"
      onClick={onClick}
    >
      {/* Media - Standardized */}
      <div className="relative aspect-[4/3] media-standard overflow-hidden -mx-4 mb-4">
        <ImageWithFallback 
          src={mediaImages[0] || 'https://images.unsplash.com/photo-1469474968028-56623f02e42e?w=500&h=400&fit=crop'} 
          alt={experience.title}
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
        />
        
        {/* Gradient Overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
        
        {/* Action Buttons Overlay */}
        <div className="absolute top-3 right-3 flex space-x-2 opacity-0 group-hover:opacity-100 transition-all duration-300">
          <button
            onClick={handleLike}
            className={`p-2 rounded-full backdrop-blur-md border border-white/20 transition-all duration-200 hover:scale-110 active:scale-95 ${
              isLiked 
                ? 'bg-red-500/90 text-white shadow-lg' 
                : 'bg-black/20 text-white hover:bg-red-500/20 hover:text-red-400'
            }`}
          >
            <Heart size={16} className={isLiked ? 'fill-current' : ''} />
          </button>
          
          <button
            onClick={handleSave}
            className={`p-2 rounded-full backdrop-blur-md border border-white/20 transition-all duration-200 hover:scale-110 active:scale-95 ${
              isSaved 
                ? 'bg-brand-accent/90 text-white shadow-lg' 
                : 'bg-black/20 text-white hover:bg-brand-accent/20 hover:text-brand-accent'
            }`}
          >
            <Bookmark size={16} className={isSaved ? 'fill-current' : ''} />
          </button>
        </div>

        {/* Category Badge */}
        <div className="absolute top-3 left-3">
          <CategoryTag category={experience.category} size="sm" />
        </div>

        {/* Rating Badge */}
        <div className="absolute bottom-3 left-3">
          <div className="flex items-center space-x-1 bg-white/95 backdrop-blur-sm px-3 py-1.5 rounded-full shadow-sm">
            <Star size={12} className="text-yellow-500 fill-current" />
            <span className="text-xs font-semibold text-gray-900">{experience.rating}</span>
          </div>
        </div>

        {/* Cost Badge */}
        <div className="absolute bottom-3 right-3">
          <div className="bg-brand-primary/95 backdrop-blur-sm text-white px-3 py-1.5 rounded-full shadow-sm">
            <span className="text-xs font-semibold">
              {experience.cost > 0 ? `${experience.cost}` : 'Free'}
            </span>
          </div>
        </div>
      </div>

      {/* Enhanced Experience Info */}
      <div>
        {/* Title and Location */}
        <div className="mb-4">
          <h3 className="card-title line-clamp-2 group-hover:text-brand-primary transition-colors duration-200">
            {experience.title}
          </h3>
          
          <div className="flex items-center card-subtitle">
            <MapPin size={14} className="mr-2 text-brand-secondary flex-shrink-0" />
            <span className="line-clamp-1 font-medium">{experience.location}</span>
          </div>
        </div>

        {/* Description */}
        <p className="card-description line-clamp-3">
          {experience.review || experience.description}
        </p>

        {/* Tags */}
        {tags.length > 0 && (
          <div className="flex flex-wrap gap-2 mb-4">
            {tags.slice(0, 3).map((tag, idx) => (
              <span 
                key={idx}
                className="bg-gradient-to-r from-brand-primary/10 to-brand-secondary/10 text-brand-primary border border-brand-primary/20 px-3 py-1 rounded-full text-xs font-medium"
              >
                #{tag}
              </span>
            ))}
            {tags.length > 3 && (
              <span className="bg-gray-100 text-gray-600 px-3 py-1 rounded-full text-xs font-medium">
                +{tags.length - 3} more
              </span>
            )}
          </div>
        )}

        {/* Experience Stats */}
        <div className="flex items-center justify-between mb-5 py-3 border-t border-gray-100">
          <div className="flex items-center space-x-4 text-xs text-gray-600">
            <div className="flex items-center space-x-1">
              <Clock size={12} />
              <span>2-3 hours</span>
            </div>
            <div className="flex items-center space-x-1">
              <Users size={12} />
              <span>Small group</span>
            </div>
          </div>
          
          {/* Enhanced Rating Display */}
          <div className="flex items-center space-x-1">
            <StarRating rating={experience.rating} size="sm" />
            <span className="text-xs text-gray-500 ml-1">(245)</span>
          </div>
        </div>

        {/* Enhanced Action Buttons */}
        <div className="flex items-center space-x-3">
          <button
            onClick={handleSave}
            className={`flex-1 py-3 px-4 rounded-2xl font-semibold transition-all duration-200 hover:scale-[1.02] active:scale-95 flex items-center justify-center space-x-2 ${
              isSaved
                ? 'bg-brand-accent/10 text-brand-accent border-2 border-brand-accent/20'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200 border-2 border-transparent'
            }`}
          >
            <Bookmark size={16} className={isSaved ? 'fill-current' : ''} />
            <span>{isSaved ? 'Saved' : 'Save to Bucket List'}</span>
          </button>

          {experience.affiliateLink && (
            <button
              onClick={handleBookNow}
              className="bg-gradient-brand text-white py-3 px-6 rounded-2xl font-semibold hover:shadow-brand hover:scale-[1.02] transition-all duration-200 active:scale-95 flex items-center justify-center space-x-2 min-w-[120px]"
            >
              <ExternalLink size={16} />
              <span>Book Now</span>
            </button>
          )}
        </div>

        {/* Cultural Tip */}
        {experience.culturalTip && (
          <div className="mt-4 bg-gradient-to-r from-brand-secondary/10 to-brand-primary/10 border border-brand-secondary/20 rounded-2xl p-4">
            <div className="flex items-start space-x-2">
              <div className="w-6 h-6 bg-gradient-brand-secondary rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                <span className="text-white text-xs">💡</span>
              </div>
              <div>
                <h4 className="font-semibold text-brand-secondary-dark text-sm mb-1">Cultural Tip</h4>
                <p className="text-xs text-brand-secondary-dark/80 leading-relaxed">
                  {experience.culturalTip}
                </p>
              </div>
            </div>
          </div>
        )}
      </div>
    </article>
  );
}