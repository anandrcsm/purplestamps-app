import { useState, useEffect } from 'react';
import { Instagram, CheckCircle, AlertCircle, ArrowLeft, Lock, ExternalLink, Shield } from 'lucide-react';
import { BrandLogo } from './BrandLogo';

interface InstagramBusinessVerificationPageProps {
  onVerificationSuccess: (instagramData: any) => void;
  onBack: () => void;
}

export function InstagramBusinessVerificationPage({ 
  onVerificationSuccess, 
  onBack 
}: InstagramBusinessVerificationPageProps) {
  const [isConnecting, setIsConnecting] = useState(false);
  const [verificationStep, setVerificationStep] = useState<'initial' | 'connecting' | 'failed'>('initial');
  const [instagramHandle, setInstagramHandle] = useState('');
  const [showBusinessGuide, setShowBusinessGuide] = useState(false);

  const handleConnectInstagram = async () => {
    setIsConnecting(true);
    setVerificationStep('connecting');
    
    // Simulate Instagram OAuth flow
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    // Simulate verification check - randomly succeed or fail for demo
    const isBusinessAccount = Math.random() > 0.3; // 70% success rate for demo
    
    if (isBusinessAccount) {
      // Simulate successful verification
      const mockInstagramData = {
        id: 'ig_business_123',
        username: instagramHandle || 'travel_creator_demo',
        display_name: 'Travel Creator Demo',
        followers_count: 12500,
        is_business_account: true,
        verified: true,
        profile_picture_url: 'https://images.unsplash.com/photo-1494790108755-2616b612b93c?w=100&h=100&fit=crop&crop=face'
      };
      
      setIsConnecting(false);
      onVerificationSuccess(mockInstagramData);
    } else {
      // Simulate failed verification
      setIsConnecting(false);
      setVerificationStep('failed');
    }
  };

  const showToast = (message: string, type: 'success' | 'info' | 'error' = 'success') => {
    const styles = {
      success: 'bg-moodboard-cream border-moodboard-muted-teal text-moodboard-deep-green shadow-brand',
      info: 'bg-moodboard-cream border-moodboard-warm-beige text-moodboard-charcoal shadow-brand-secondary',
      error: 'bg-moodboard-cream border-red-300 text-red-800 shadow-lg'
    };

    const toast = document.createElement('div');
    toast.className = `fixed top-20 left-1/2 transform -translate-x-1/2 ${styles[type]} border px-4 py-3 rounded-xl z-50 backdrop-blur-sm animate-slideDown max-w-sm`;
    toast.innerHTML = `
      <div class="flex items-center space-x-3">
        <span class="font-medium text-sm">${message}</span>
      </div>
    `;
    document.body.appendChild(toast);
    setTimeout(() => {
      toast.style.opacity = '0';
      setTimeout(() => document.body.removeChild(toast), 300);
    }, 3000);
  };

  const BusinessGuideModal = () => (
    <>
      {/* Backdrop */}
      <div 
        className="fixed inset-0 z-50 bg-black/50 animate-backdropFadeIn"
        onClick={() => setShowBusinessGuide(false)}
      />
      
      {/* Modal */}
      <div className="fixed top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 z-50 w-full max-w-md mx-4 bg-white rounded-xl shadow-2xl animate-scaleIn">
        <div className="p-6">
          <div className="text-center mb-6">
            <div className="w-16 h-16 bg-gradient-to-r from-pink-500 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-4">
              <Instagram size={32} className="text-white" />
            </div>
            <h2 className="text-xl font-semibold text-moodboard-deep-green mb-2">
              Switch to Business Account
            </h2>
            <p className="text-sm text-moodboard-gray-dark">
              Quick steps to convert your Instagram to business
            </p>
          </div>

          <div className="space-y-4 mb-6">
            <div className="flex items-start space-x-3">
              <div className="w-6 h-6 bg-moodboard-muted-teal rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                <span className="text-white text-xs font-bold">1</span>
              </div>
              <div>
                <p className="font-medium text-sm text-moodboard-deep-green">Open Instagram App</p>
                <p className="text-xs text-moodboard-gray-dark">Go to your profile settings</p>
              </div>
            </div>

            <div className="flex items-start space-x-3">
              <div className="w-6 h-6 bg-moodboard-muted-teal rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                <span className="text-white text-xs font-bold">2</span>
              </div>
              <div>
                <p className="font-medium text-sm text-moodboard-deep-green">Account Type</p>
                <p className="text-xs text-moodboard-gray-dark">Tap "Switch to Professional Account"</p>
              </div>
            </div>

            <div className="flex items-start space-x-3">
              <div className="w-6 h-6 bg-moodboard-muted-teal rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                <span className="text-white text-xs font-bold">3</span>
              </div>
              <div>
                <p className="font-medium text-sm text-moodboard-deep-green">Choose Business</p>
                <p className="text-xs text-moodboard-gray-dark">Select "Business" instead of "Creator"</p>
              </div>
            </div>

            <div className="flex items-start space-x-3">
              <div className="w-6 h-6 bg-moodboard-warm-beige rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                <CheckCircle size={14} className="text-moodboard-deep-green" />
              </div>
              <div>
                <p className="font-medium text-sm text-moodboard-deep-green">You're Done!</p>
                <p className="text-xs text-moodboard-gray-dark">Come back and connect your account</p>
              </div>
            </div>
          </div>

          <div className="flex space-x-3">
            <button
              onClick={() => setShowBusinessGuide(false)}
              className="flex-1 py-3 px-4 border border-moodboard-muted-teal/30 text-moodboard-muted-teal rounded-xl font-medium hover:bg-moodboard-muted-teal/5 transition-colors"
            >
              Got it!
            </button>
            <button
              onClick={() => {
                setShowBusinessGuide(false);
                showToast('Opening Instagram...', 'info');
              }}
              className="flex-1 bg-gradient-to-r from-pink-500 to-purple-600 text-white py-3 px-4 rounded-xl font-medium hover:shadow-lg transition-all flex items-center justify-center gap-2"
            >
              <Instagram size={16} />
              Open IG
            </button>
          </div>
        </div>
      </div>
    </>
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-surface-warm via-white to-surface-cool flex flex-col">
      {/* Header */}
      <div className="bg-gradient-to-r from-moodboard-muted-teal to-moodboard-muted-teal-light text-white py-4 px-4 relative overflow-hidden">
        <div className="absolute inset-0 bg-black/10"></div>
        <div className="relative flex items-center justify-center space-x-3">
          <Shield size={18} className="animate-pulse" />
          <p className="text-sm font-semibold">Creator Verification Required</p>
        </div>
      </div>

      <div className="flex-1 flex items-center justify-center p-6">
        <div className="w-full max-w-sm">
          {/* Back Button */}
          <button
            onClick={onBack}
            className="flex items-center space-x-2 text-moodboard-gray-dark hover:text-moodboard-deep-green mb-6 transition-colors"
          >
            <ArrowLeft size={16} />
            <span className="text-sm">Back to sign up</span>
          </button>

          {/* Header */}
          <div className="text-center mb-8">
            <div className="mb-6">
              <BrandLogo />
            </div>
            
            <div className="relative mb-6">
              <div className="w-20 h-20 bg-gradient-to-r from-pink-500 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg">
                <Instagram size={40} className="text-white" />
                <div className="absolute -bottom-2 -right-2">
                  <div className="w-8 h-8 bg-moodboard-warm-beige rounded-full flex items-center justify-center border-2 border-white">
                    <Lock size={14} className="text-moodboard-deep-green" />
                  </div>
                </div>
              </div>
            </div>

            <h1 className="text-2xl font-bold text-moodboard-deep-green mb-2">
              Verify Instagram Business Account
            </h1>
            <p className="text-moodboard-gray-dark text-sm leading-relaxed">
              To access affiliate link features and earn from your travel content, please connect your Instagram Business account.
            </p>

            {/* Required Badge */}
            <div className="inline-flex items-center space-x-2 mt-4 px-3 py-1 bg-moodboard-warm-beige/20 rounded-full border border-moodboard-warm-beige/30">
              <Shield size={12} className="text-moodboard-warm-beige-dark" />
              <span className="text-xs font-medium text-moodboard-warm-beige-dark">
                Required for Creator Access
              </span>
            </div>
          </div>

          {/* Main Content */}
          {verificationStep === 'initial' && (
            <div className="space-y-6">
              {/* Benefits Section */}
              <div className="bg-moodboard-cream rounded-xl p-4 border border-moodboard-muted-teal/10">
                <h3 className="font-semibold text-moodboard-deep-green mb-3 text-sm">
                  Why Instagram Business?
                </h3>
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <CheckCircle size={14} className="text-moodboard-muted-teal" />
                    <span className="text-xs text-moodboard-charcoal">Add affiliate links to travel cards</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <CheckCircle size={14} className="text-moodboard-muted-teal" />
                    <span className="text-xs text-moodboard-charcoal">Earn commissions from bookings</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <CheckCircle size={14} className="text-moodboard-muted-teal" />
                    <span className="text-xs text-moodboard-charcoal">Access creator analytics</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <CheckCircle size={14} className="text-moodboard-muted-teal" />
                    <span className="text-xs text-moodboard-charcoal">Verified creator badge</span>
                  </div>
                </div>
              </div>

              {/* Connect Button */}
              <button
                onClick={handleConnectInstagram}
                disabled={isConnecting}
                className="w-full bg-gradient-to-r from-pink-500 to-purple-600 text-white py-4 px-4 rounded-xl font-semibold hover:shadow-lg hover:scale-[1.02] transition-all duration-200 active:scale-95 disabled:opacity-50 disabled:hover:scale-100 flex items-center justify-center space-x-3"
              >
                <Instagram size={24} />
                <span>Connect Instagram</span>
              </button>

              {/* Privacy Note */}
              <div className="bg-moodboard-cream/50 rounded-lg p-3 border border-moodboard-muted-teal/10">
                <div className="flex items-start space-x-2">
                  <Shield size={14} className="text-moodboard-muted-teal mt-0.5" />
                  <div>
                    <p className="text-xs font-medium text-moodboard-deep-green mb-1">
                      Your data is secure
                    </p>
                    <p className="text-xs text-moodboard-gray-dark leading-relaxed">
                      We only access basic profile info to verify your business account status. Your content and followers data remain private.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {verificationStep === 'connecting' && (
            <div className="text-center space-y-6">
              <div className="w-20 h-20 bg-gradient-to-r from-pink-500 to-purple-600 rounded-full flex items-center justify-center mx-auto animate-pulse">
                <Instagram size={40} className="text-white" />
              </div>
              <div>
                <h3 className="font-semibold text-moodboard-deep-green mb-2">Connecting to Instagram...</h3>
                <p className="text-sm text-moodboard-gray-dark">
                  Please wait while we verify your business account status
                </p>
              </div>
              <div className="flex justify-center">
                <div className="w-6 h-6 border-2 border-moodboard-muted-teal/30 border-t-moodboard-muted-teal rounded-full animate-spin"></div>
              </div>
            </div>
          )}

          {verificationStep === 'failed' && (
            <div className="space-y-6">
              <div className="text-center">
                <div className="w-20 h-20 bg-red-50 rounded-full flex items-center justify-center mx-auto mb-4 border-2 border-red-200">
                  <AlertCircle size={40} className="text-red-500" />
                </div>
                <h3 className="font-semibold text-moodboard-deep-green mb-2">
                  Not a Business Account Yet
                </h3>
                <p className="text-sm text-moodboard-gray-dark mb-6">
                  Looks like this Instagram account isn't set up as a Business account. Don't worry - it's super easy to switch!
                </p>
              </div>

              {/* Action Buttons */}
              <div className="space-y-3">
                <button
                  onClick={() => setShowBusinessGuide(true)}
                  className="w-full bg-moodboard-muted-teal text-white py-3 px-4 rounded-xl font-semibold hover:bg-moodboard-muted-teal-light transition-colors flex items-center justify-center space-x-2"
                >
                  <ExternalLink size={18} />
                  <span>How to Switch?</span>
                </button>
                
                <button
                  onClick={() => setVerificationStep('initial')}
                  className="w-full border border-moodboard-muted-teal text-moodboard-muted-teal py-3 px-4 rounded-xl font-medium hover:bg-moodboard-muted-teal/5 transition-colors"
                >
                  Try Again
                </button>
              </div>

              {/* Help Section */}
              <div className="bg-moodboard-warm-beige/10 rounded-lg p-3 border border-moodboard-warm-beige/30">
                <p className="text-xs text-moodboard-charcoal text-center">
                  <strong>Need help?</strong> Switching takes just 2 minutes and unlocks all creator features including affiliate earnings!
                </p>
              </div>
            </div>
          )}

          {/* Skip Option for Demo */}
          <div className="mt-6 text-center">
            <button
              onClick={() => {
                // Allow skip for demo purposes - in production this wouldn't be available
                const demoData = {
                  id: 'demo_account',
                  username: 'demo_creator',
                  display_name: 'Demo Creator',
                  is_business_account: false,
                  demo_skip: true
                };
                onVerificationSuccess(demoData);
              }}
              className="text-xs text-moodboard-gray-dark hover:text-moodboard-gray-dark underline"
            >
              Skip for now (Demo only)
            </button>
          </div>
        </div>
      </div>

      {/* Business Guide Modal */}
      {showBusinessGuide && <BusinessGuideModal />}

      {/* Footer */}
      <div className="p-4 text-center">
        <p className="text-xs text-gray-500">
          Secure verification powered by Instagram Business API 🔐
        </p>
      </div>
    </div>
  );
}