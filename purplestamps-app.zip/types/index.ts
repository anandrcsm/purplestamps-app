export interface User {
  id: string;
  name: string;
  username: string;
  profilePic: string;
  bio: string;
  followers: number;
  following: number;
  countries: number;
  cities: number;
  isCreator: boolean;
  badges: string[];
}

export interface Experience {
  id: string;
  title: string;
  category: 'stay' | 'food' | 'transport' | 'activity' | 'travel-item';
  location?: string;
  description?: string;
  rating?: number;
  reviewCount?: number;
  cost?: number;
  pricing?: string;
  images?: string[];
  review?: string;
  tags?: string[];
  affiliateLink?: string;
  media?: any[];
  scheduledDate?: string;
  timeFrom?: string;
  timeTo?: string;
  bookingUrl?: string;
}

export interface Moment {
  id: string;
  user: User;
  image: string;
  caption: string;
  location: string;
  timestamp: string;
  likes: number;
  comments: number;
  isLiked: boolean;
}

export interface TravelCard {
  id: string;
  title: string;
  description: string;
  thumbnail: string;
  destination: string;
  images: string[];
  rating: number;
  likes: number;
  comments: number;
  views: number;
  cost: number;
  dates: string;
  tripType: string;
  creatorId: string;
  creator?: User;
  experiences: Experience[];
  isLive: boolean;
  itinerary?: TravelItinerary;
}

export interface TravelCardDraft {
  id: string;
  title: string;
  destination: string;
  duration: string;
  coverImage: string;
  estimatedCost: number;
  completionPercentage: number;
  lastUpdated: string;
  experienceCount: number;
  isDraft: true;
  experiences?: Experience[];
  collaborators?: any[];
  startDate?: string;
  endDate?: string;
  description?: string;
}

export interface LocalGem {
  id: string;
  title: string;
  description: string;
  location: string;
  category: string;
  tags: string[];
  image: string;
  userId: string;
  userName: string;
  userAvatar: string;
  timestamp: string;
  likes: number;
  comments: number;
  isLiked: boolean;
  rating: number;
  priceRange: string;
  isOpen: boolean;
  distance: string;
}

export interface LocalGemDraft {
  id: string;
  title: string;
  description: string;
  location: string;
  category: string;
  tags: string[];
  image: string;
  userId: string;
  lastUpdated: string;
  isDraft: true;
}

export interface Story {
  id: string;
  userId: string;
  userName: string;
  userAvatar: string;
  preview: string;
  content: StoryContent[];
  timestamp: string;
  isLive: boolean;
  location: string;
  isViewed: boolean;
  viewCount: number;
  expiresAt: string;
}

export interface StoryContent {
  id: string;
  type: 'image' | 'video';
  url: string;
  caption: string;
  timestamp: string;
}

export interface BucketListItem {
  id: string;
  type: 'experience' | 'localGem' | 'travelCard';
  data: Experience | LocalGem | TravelCard;
  addedDate: string;
}

export interface TravelItinerary {
  id: string;
  title: string;
  destination: string;
  startDate: string;
  endDate: string;
  coverImage: string;
  experiences: Experience[];
  createdAt: string;
  updatedAt: string;
}

export interface ChatMessage {
  id: string;
  sender: User;
  content: string;
  timestamp: string;
  type: 'text' | 'image' | 'travel_card' | 'experience';
  metadata?: any;
}

export interface Chat {
  id: string;
  participants: User[];
  messages: ChatMessage[];
  lastActivity: string;
  isGroup: boolean;
  unreadCount: number;
}

export interface ExperienceMoment {
  id: string;
  experienceId: string;
  type: 'image' | 'video';
  image: string;
  caption: string;
  likes: number;
  comments: number;
  timestamp: string;
  userId: string;
  userName: string;
  userAvatar: string;
}

export interface TravelProduct {
  id: string;
  title: string;
  description: string;
  price: number;
  originalPrice?: number;
  discount?: number;
  images: string[];
  category: 'luggage' | 'electronics' | 'clothing' | 'accessories' | 'books' | 'health';
  rating: number;
  reviewCount: number;
  features: string[];
  inStock: boolean;
  freeShipping: boolean;
  affiliateLink: string;
  brand: string;
}

export interface CulturalInsight {
  id: string;
  title: string;
  description: string;
  location: string;
  category: 'tradition' | 'food' | 'festival' | 'history' | 'etiquette' | 'language';
  image: string;
  readTime: string;
  likes: number;
  shares: number;
  isLiked: boolean;
  isBookmarked: boolean;
  publishedAt: string;
  author: {
    name: string;
    avatar: string;
    expertise: string;
  };
}

export interface TriviaQuestion {
  id: string;
  question: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
  category: string;
  difficulty: 'easy' | 'medium' | 'hard';
  points: number;
  image?: string;
  location: string;
}

export interface UserTriviaStats {
  totalQuestions: number;
  correctAnswers: number;
  totalPoints: number;
  streak: number;
  longestStreak: number;
  categoriesPlayed: string[];
  lastPlayed: string;
  level: number;
  rank: string;
}